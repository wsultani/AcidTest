Welcome to ntop!

(C) 1998-2001 by  Luca Deri <deri@ntop.org>

http://www.ntop.org/

ntop is a tool that shows the network usage, similar to what the popular top Unix command does. ntop is based on pcapture and it has been written in a portable way in order to virtually run on every Unix platform.

ntop is distributed under the GNU GPL license.

Problems, bugs, questions, desirable enhancements, source code contributions, etc., should be sent to the email address <ntop@ntop.org>.

NOTE: This package will be installed under /usr/local/ntop
