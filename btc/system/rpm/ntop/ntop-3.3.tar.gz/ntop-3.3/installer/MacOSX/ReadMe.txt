Welcome to ntop!

(C) 1998-2005 by Luca Deri <deri@ntop.org>

http://www.ntop.org/

ntop is a network probe that shows the network usage, similar to what the popular top Unix command does. ntop is based on pcap and it has been written in a portable way in order to virtually run on every Unix platform.

1. This package will be installed under /usr/local/ntop-3.2
2. In order to start ntop please type (as root)
   /usr/local/ntop-3.2/bin/ntop -u <user> -i <interface>

If you like ntop, please support its development by making a donation to the project (see http://shop.ntop.org/ for further details).

Problems, bugs, questions, desirable enhancements, source code contributions, etc., should be sent to the ntop mailing lists.

ntop is distributed under the GNU GPL license.
