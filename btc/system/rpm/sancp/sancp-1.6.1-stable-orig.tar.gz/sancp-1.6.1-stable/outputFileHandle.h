/**************************************************************************
 **sA Network Connection Profiler [sancp] - A TCP/IP statistical/collection tool
 * ************************************************************************
 * * Copyright (C) 2003 John Curry <john.curry@metre.net>
 * *
 * * This program is distributed under the terms of version 1.0 of the
 * * Q Public License.  See LICENSE.QPL for further details.
 * *
 * * This program is distributed in the hope that it will be useful,
 * * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * *
 * ***********************************************************************/

#ifndef FILEHANDLE_H
#include "fileHandle.h"
#endif

#define OUTPUTFILEHANDLE_H

class outputFileHandle : public fileHandle {

	public: 
		outputFileHandle();

		outputFileHandle(const char *newfilename, char * fmt, int fmtlen, int mode );

		outputFileHandle(FILE *, int mode, char *fmt, int fmtlen);

		outputFileHandle * attach();


		char * setFormat(char *ifmt, int len);
		char * getFormat();
		int getFormatLen();
		void setDelimiter(char);
		char getDelimiter();
		void setEor(char);
		char getEor();


			
	protected:
		~outputFileHandle();

	private:
		char *fmt;
		int fmtlen;
		char delimiter;
		char eor;

};

