#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <stdlib.h>
#include <fcntl.h>
#include <netdb.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <pcap.h>
#include <stdio.h>
#include <getopt.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "quicklz.c"

/* ****************************************** */

#define NUM_PKTS_PER_PACKET 32
#define DEFAULT_PKT_LEN     74
#define PKT_LEN             (PKT_LEN+sizeof(struct pcap_pkthdr))
#define MAX_LEN             3800

#define min(a, b) (a < b ? a : b)

/* ****************************************** */

void help() {
  printf("ntop remote\n(C) 2007 Deri Luca <deri@ntop.org>\n");
  printf("-h              [Print help]\n");
  printf("-n <host:port>  [Packets recipient]\n");
  printf("-i <device>     [Device name]\n");
  printf("-f <filter>     [BPF filter]\n");
  printf("-s <snaplen>    [Snap length (default %d)]\n", DEFAULT_PKT_LEN);
  printf("-v              [Verbose]\n");
  printf("\n\nExample: remote -n 127.0.0.1:4000 -i eth0\n");
  exit(0);
}

/* ****************************************** */

int main(int argc, char* argv[]) {
  char *device = NULL, *bpfFilter = NULL, c;
  u_int verbose = 0, max_num_pkts;
  pcap_t *pcap_ptr;
  char ebuf[PCAP_ERRBUF_SIZE], *buffer, *compressed_buffer, *buf, *destination, *dest_host, *dest_port;
  u_int snaplen = DEFAULT_PKT_LEN;
  u_short num_pkts, pkt_len;
  struct sockaddr_in remoteServAddr;
  int sd;

  destination = strdup("127.0.0.1:4000");

  while((c = getopt(argc,argv,"hi:vf:s:n:")) != -1) {
    switch(c) {
    case 'h':
      help();
      return(0);
      break;
    case 'n':
      destination = strdup(optarg);
      break;
    case 'i':
      device = strdup(optarg);
      break;
    case 's':
      snaplen = atoi(optarg);
      break;
    case 'v':
      verbose = 1;
      break;
    case 'f':
      bpfFilter = strdup(optarg);
      break;
    }
  }

  if(device == NULL) device = pcap_lookupdev(ebuf);

  if(device == NULL) {
    printf("Error: no default device. Please use -i\n");
    return(-1);
  }

  if((!strncmp(device, "e", 1)) /* Ethernet */
     || (!strncmp(device, "l", 1)) /* Loopback */) {
    if((pcap_ptr = pcap_open_live(device, snaplen,
				  1 /* promiscuous */,
				  1000 /* ms */, ebuf)) == NULL) {
      pcap_ptr = pcap_open_offline(device, ebuf);
    };

    if(pcap_ptr == NULL) {
      printf("Error while opening '%s': are you super-user?\n", device);
      return(-1);
    } else {
      printf("Device %s open successfully\n", device);
    }
  } else {
    pcap_ptr = pcap_open_offline(device, ebuf);
    if(pcap_ptr == NULL) {
      printf("Error while opening file '%s': are you super-user?\n", device);
      return(-1);
    }
  }
  
  pkt_len      = snaplen + sizeof(struct pcap_pkthdr);
  max_num_pkts = MAX_LEN / pkt_len;
  
  if(max_num_pkts == 0) {
    printf("Error: the snaplen you selected is too large. Please try again\n");
    return(-1);
  } else
    printf("Clustering %d packets\n", max_num_pkts);

  buffer = malloc(MAX_LEN);
  compressed_buffer = malloc(MAX_LEN+400);
  buf = malloc(STREAM_BUFFER_SIZE);
  
  if((!buffer) || (!compressed_buffer) || (!buf)) {
    printf("Error: not enough memory\n");
    return(-1);
  }

  dest_host = strtok(destination, ":");
  if(dest_host) dest_port = strtok(NULL, "\n"); else dest_port = NULL;

  if((!dest_host) || (!dest_port)) {
    printf("Error: -n parameter is not well specified\n");
    return(-1);
  } else {
    struct hostent *h = gethostbyname(dest_host);

    if(!h) {
      printf("Error: unknown host '%s'\n", dest_host);
      exit(1);
    }

    remoteServAddr.sin_family = h->h_addrtype;
    memcpy((char *) &remoteServAddr.sin_addr.s_addr,
	   h->h_addr_list[0], h->h_length);
    remoteServAddr.sin_port = htons(atoi(dest_port));    
  }

  sd = socket(AF_INET,SOCK_DGRAM,0);

  if(sd < 0) {
    printf("Error: cannot create socket\n");
    exit(1);
  }

  memset(buf, 0, STREAM_BUFFER_SIZE);
  num_pkts = 0;

  while(1) {
    const u_char *packet;
    struct pcap_pkthdr *h;
    int rc, len;

    rc = pcap_next_ex(pcap_ptr, &h, &packet);

    if((rc > 0) && (packet != NULL)) {
      if(verbose) {
	// printf("Received %d bytes packet\n", h->len);
	fflush(stdout);
      }

      if(num_pkts < max_num_pkts) {
	u_short displ = num_pkts*pkt_len;
	// printf("[num=%02d][displ=%d]\n", num_pkts, displ);
	memcpy(&buffer[displ], h, sizeof(struct pcap_pkthdr));
	len = min(snaplen, h->caplen);
	memcpy(&buffer[displ+sizeof(struct pcap_pkthdr)], packet, len);
	num_pkts++;
      }

      if(num_pkts == max_num_pkts) {	
	u_int tot_len =  pkt_len*max_num_pkts, rc;
	len = qlz_compress_packet(buffer, compressed_buffer, tot_len, buf);
	if(verbose) printf("%d -> %d\n", tot_len, len);

	rc = sendto(sd, compressed_buffer, len, 0,
		    (struct sockaddr *) &remoteServAddr,
		    sizeof(remoteServAddr));

	if(rc < 0) {
	  printf("Error: cannot send data [errno=%d][rc=%d]\n", errno, rc);
	  break;
	}

	memset(buf, 0, STREAM_BUFFER_SIZE);
	num_pkts = 0;
      }
    }
  }

  close(sd);
  pcap_close(pcap_ptr);

  return(0);
}
