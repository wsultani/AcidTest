/*
 *  Copyright (C) 2007 Luca Deri <deri@ntop.org>
 *
 *  		       http://www.ntop.org/
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "remote/quicklz.c"
#include "nprobe.h"

extern int datalink;
static int netFlowInSocket = -1, netFlowInSctpSocket = -1, remoteInSocket = -1;
static pthread_t collectThread;
static FlowSetV9 *templates;

/* forward */
void* netFlowCollectLoop(void* notUsed);
void* remoteCollectLoop(void* notUsed);

struct generic_netflow_record {
  /* v5 */
  u_int32_t srcaddr;    /* Source IP Address */
  u_int32_t dstaddr;    /* Destination IP Address */
  u_int32_t nexthop;    /* Next hop router's IP Address */
  u_int16_t input;      /* Input interface index */
  u_int16_t output;     /* Output interface index */
  u_int32_t sentPkts, rcvdPkts;
  u_int32_t sentOctets, rcvdOctets;
  u_int32_t first;      /* SysUptime at start of flow */
  u_int32_t last;       /* and of last packet of the flow */
  u_int16_t srcport;    /* TCP/UDP source port number (.e.g, FTP, Telnet, etc.,or equivalent) */
  u_int16_t dstport;    /* TCP/UDP destination port number (.e.g, FTP, Telnet, etc.,or equivalent) */
  u_int8_t  tcp_flags;  /* Cumulative OR of tcp flags */
  u_int8_t  proto;      /* IP protocol, e.g., 6=TCP, 17=UDP, etc... */
  u_int8_t  tos;        /* IP Type-of-Service */
  u_int16_t dst_as;     /* dst peer/origin Autonomous System */
  u_int16_t src_as;     /* source peer/origin Autonomous System */
  u_int8_t  dst_mask;   /* destination route's mask bits */
  u_int8_t  src_mask;   /* source route's mask bits */

  /* v9 */
  u_int16_t vlanId;

  /* Latency extensions */
  u_int32_t nw_latency_sec, nw_latency_usec;

  /* VoIP Extensions */
  char sip_call_id[50], sip_calling_party[50], sip_called_party[50];
};

/* ********************************************************* */

int createNetFlowListener(u_short netFlowInPort) {
  int sockopt = 1;
  struct sockaddr_in sockIn;

  if(netFlowInPort > 0) {
    errno = 0;
    netFlowInSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if((netFlowInSocket <= 0) || (errno != 0) ) {
      traceEvent(TRACE_INFO, "Unable to create a UDP socket - returned %d, error is '%s'(%d)",
		 netFlowInSocket, strerror(errno), errno);
      return(-1);
    }

#ifdef HAVE_SCTP
    netFlowInSctpSocket = socket(AF_INET, SOCK_SEQPACKET, IPPROTO_SCTP);

    if((netFlowInSctpSocket <= 0) || (errno != 0)) {
      traceEvent(TRACE_INFO, "Unable to create a SCTP socket - returned %d, error is '%s'(%d)",
		 netFlowInSocket, strerror(errno), errno);
    }
#endif

    traceEvent(TRACE_INFO, "Created a UDP socket (%d)", netFlowInSocket);

#ifdef HAVE_SCTP
    if(netFlowInSctpSocket > 0)
      traceEvent(TRACE_INFO, "Created a SCTP socket (%d)", netFlowInSctpSocket);
#endif

    setsockopt(netFlowInSocket, SOL_SOCKET, SO_REUSEADDR, (char *)&sockopt, sizeof(sockopt));

    sockIn.sin_family            = AF_INET;
    sockIn.sin_port              = (int)htons(netFlowInPort);
    sockIn.sin_addr.s_addr       = INADDR_ANY;

    if((bind(netFlowInSocket, (struct sockaddr *)&sockIn, sizeof(sockIn)) < 0)
#ifdef HAVE_SCTP
       || ((netFlowInSctpSocket > 0)
	   && (bind(netFlowInSctpSocket, (struct sockaddr *)&sockIn, sizeof(sockIn)) < 0))
#endif
       ) {
      traceEvent(TRACE_ERROR, "Collector port %d already in use", netFlowInPort);
      close(netFlowInSocket);
      netFlowInSocket = 0;
#ifdef HAVE_SCTP
      if(netFlowInSctpSocket) close(netFlowInSctpSocket);
      netFlowInSctpSocket = 0;
#endif
      return(0);
    }

#ifdef HAVE_SCTP
    if(netFlowInSctpSocket > 0) {
      if(listen(netFlowInSctpSocket, 100) == -1) {
	traceEvent(TRACE_ERROR, "listen on SCTP socket failed [%s]", strerror(errno));
      }
    }
#endif

    traceEvent(TRACE_NORMAL, "Collector listening on port %d", netFlowInPort);
    pthread_create(&collectThread, NULL, netFlowCollectLoop, NULL);
  }

  return(0);
}

/* ********************************************************* */

void closeNetFlowListener() {
  if(netFlowInSocket != -1)     close(netFlowInSocket);
  if(netFlowInSctpSocket != -1) close(netFlowInSctpSocket);  
}

/* ********************************************************* */

int createRemoteListener(u_short remoteInPort) {
  int sockopt = 1;
  struct sockaddr_in sockIn;

  if(remoteInPort > 0) {
    errno = 0;
    remoteInSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if((remoteInSocket <= 0) || (errno != 0) ) {
      traceEvent(TRACE_INFO, "Unable to create a UDP socket - returned %d, error is '%s'(%d)",
		 remoteInSocket, strerror(errno), errno);
      return(-1);
    }

    traceEvent(TRACE_INFO, "Created a UDP socket (%d)", remoteInSocket);

    setsockopt(remoteInSocket, SOL_SOCKET, SO_REUSEADDR, (char *)&sockopt, sizeof(sockopt));

    sockIn.sin_family            = AF_INET;
    sockIn.sin_port              = (int)htons(remoteInPort);
    sockIn.sin_addr.s_addr       = INADDR_ANY;

    if(bind(remoteInSocket, (struct sockaddr *)&sockIn, sizeof(sockIn)) < 0) {
      traceEvent(TRACE_ERROR, "Remote collector port %d already in use", remoteInPort);
      close(remoteInSocket);
      remoteInSocket = 0;
      return(0);
    }

    traceEvent(TRACE_NORMAL, "Remote collector listening on port %d", remoteInPort);
    pthread_create(&collectThread, NULL, remoteCollectLoop, NULL);
  }

  return(0);
}

/* ********************************************************* */

void closeRemoteListener() {
  if(remoteInSocket != -1) close(remoteInSocket);
}

/* *************************** */

static int handleGenericFlow(u_int32_t netflow_device_ip,
			     time_t recordActTime, time_t recordSysUpTime,
			     struct generic_netflow_record *record,
			     time_t *firstSeen, time_t *lastSeen) {
  IpAddress src, dst;
  struct pcap_pkthdr h;

  /* FIX: handle first and last seen */
  h.ts.tv_sec = *firstSeen, h.ts.tv_usec = 0;

  src.ipVersion = 4, dst.ipVersion = 4;
  src.ipType.ipv4 = ntohl(record->srcaddr), dst.ipType.ipv4 = ntohl(record->dstaddr);

  traceEvent(TRACE_INFO, "Called addPktToHash()");

  record->srcport = ntohs(record->srcport), record->dstport = ntohs(record->dstport);

  addPktToHash(record->proto, 
	       0 /* isFragment */, 
	       record->sentPkts,
	       record->tos,
	       record->vlanId, 
	       NULL, /* Ethernet */
	       src,
	       record->srcport, 
	       dst, 
	       record->dstport, 
	       record->sentOctets, 
	       record->tcp_flags,
	       0,
	       0,
	       0, NULL, /* MPLS */
	       NULL, /* fingerprint */
	       &h, NULL, 0, 0 /* payload */
	       );

  if(record->rcvdOctets > 0) {
    addPktToHash(record->proto, 
		 0 /* isFragment */, 
		 record->rcvdPkts,
		 record->tos,
		 record->vlanId, 
		 NULL, /* Ethernet */
		 dst,
		 record->dstport, 
		 src, 
		 record->srcport, 
		 record->rcvdOctets, 
		 record->tcp_flags,
		 0,
		 0,
		 0, NULL, /* MPLS */
		 NULL, /* fingerprint */
		 &h, NULL, 0, 0 /* payload */
		 );
  }
}

/* ********************************************************* */

static void dissectFlow(u_int32_t netflow_device_ip,
			char *buffer, int bufferLen) {
  NetFlow5Record the5Record;
  int flowVersion;
  time_t recordActTime = 0, recordSysUpTime = 0;
  struct generic_netflow_record record;

#ifdef DEBUG_FLOWS
  char buf[LEN_SMALL_WORK_BUFFER], buf1[LEN_SMALL_WORK_BUFFER];
#endif

#ifdef DEBUG_FLOWS
  if(0)
    traceEvent(TRACE_INFO, "NETFLOW: dissectFlow(len=%d)", bufferLen);
#endif

  memcpy(&the5Record, buffer, bufferLen > sizeof(the5Record) ? sizeof(the5Record): bufferLen);
  flowVersion = ntohs(the5Record.flowHeader.version);

#ifdef DEBUG_FLOWS
  if(0)
    traceEvent(TRACE_INFO, "NETFLOW: +++++++ version=%d",  flowVersion);
#endif

  /*
    Convert V7 flows into V5 flows in order to make ntop
    able to handle V7 flows.

    Courtesy of Bernd Ziller <bziller@ba-stuttgart.de>
  */
  if((flowVersion == 1) || (flowVersion == 7)) {
    int numFlows, i, j;
    NetFlow1Record the1Record;
    NetFlow7Record the7Record;

    if(flowVersion == 1) {
      memcpy(&the1Record, buffer, bufferLen > sizeof(the1Record) ?
	     sizeof(the1Record): bufferLen);
      numFlows = ntohs(the1Record.flowHeader.count);
      if(numFlows > V1FLOWS_PER_PAK) numFlows = V1FLOWS_PER_PAK;
      recordActTime   = the1Record.flowHeader.unix_secs;
      recordSysUpTime = the1Record.flowHeader.sysUptime;
    } else {
      memcpy(&the7Record, buffer, bufferLen > sizeof(the7Record) ?
	     sizeof(the7Record): bufferLen);
      numFlows = ntohs(the7Record.flowHeader.count);
      if(numFlows > V7FLOWS_PER_PAK) numFlows = V7FLOWS_PER_PAK;
      recordActTime   = the7Record.flowHeader.unix_secs;
      recordSysUpTime = the7Record.flowHeader.sysUptime;
    }

#ifdef DEBUG_FLOWS
    if(0)
      traceEvent(TRACE_INFO, "NETFLOW: +++++++ flows=%d",  numFlows);
#endif

    the5Record.flowHeader.version = htons(5);
    the5Record.flowHeader.count = htons(numFlows);

    /* rest of flowHeader will not be used */

    for(j=i=0; i<numFlows; i++) {
      if(flowVersion == 7) {
	the5Record.flowRecord[i].srcaddr   = the7Record.flowRecord[i].srcaddr;
	the5Record.flowRecord[i].dstaddr   = the7Record.flowRecord[i].dstaddr;
	the5Record.flowRecord[i].srcport   = the7Record.flowRecord[i].srcport;
	the5Record.flowRecord[i].dstport   = the7Record.flowRecord[i].dstport;
	the5Record.flowRecord[i].dPkts     = the7Record.flowRecord[i].dPkts;
	the5Record.flowRecord[i].dOctets   = the7Record.flowRecord[i].dOctets;
	the5Record.flowRecord[i].proto     = the7Record.flowRecord[i].proto;
	the5Record.flowRecord[i].tos       = the7Record.flowRecord[i].tos;
	the5Record.flowRecord[i].first     = the7Record.flowRecord[i].first;
	the5Record.flowRecord[i].last      = the7Record.flowRecord[i].last;
	the5Record.flowRecord[i].tcp_flags = the7Record.flowRecord[i].tcp_flags;
	/* rest of flowRecord will not be used */
      } else {
	/*
	  Some NetFlow v1 implementations (e.g. Extreme Networks) are
	  limited and most of the NetFlow fields are empty. In particular
	  the following fields are empty:
	  - input
	  - output
	  - dOctets
	  - first
	  - last
	  - tos
	  - tcp_flags


	  In this case we add a patch for filling some of the fields
	  in order to let ntop digest this flow.
	*/

	the5Record.flowRecord[i].srcaddr   = the1Record.flowRecord[i].srcaddr;
	the5Record.flowRecord[i].dstaddr   = the1Record.flowRecord[i].dstaddr;
	the5Record.flowRecord[i].srcport   = the1Record.flowRecord[i].srcport;
	the5Record.flowRecord[i].dstport   = the1Record.flowRecord[i].dstport;
	the5Record.flowRecord[i].dPkts     = the1Record.flowRecord[i].dPkts;
	if(ntohl(the1Record.flowRecord[i].dOctets) == 0) {
	  /* We assume that all packets are 512 bytes long */
	  u_int32_t tmp = ntohl(the1Record.flowRecord[i].dPkts);
	  the5Record.flowRecord[i].dOctets = htonl(tmp*512);
	} else
	  the5Record.flowRecord[i].dOctets = the1Record.flowRecord[i].dOctets;

	the5Record.flowRecord[i].proto     = the1Record.flowRecord[i].proto;
	the5Record.flowRecord[i].tos       = the1Record.flowRecord[i].tos;
	the5Record.flowRecord[i].first     = the1Record.flowRecord[i].first;
	the5Record.flowRecord[i].last      = the1Record.flowRecord[i].last;
	/* rest of flowRecord will not be used */
      }
    }
  }  /* DON'T ADD a else here ! */

  if((the5Record.flowHeader.version == htons(9))
     || (the5Record.flowHeader.version == htons(10))) {
    /* NetFlowV9/IPFIX Record */
    u_char foundRecord = 0, done = 0;
    u_short numEntries, displ, record_len;
    V9Template template;
    int i;
    u_char handle_ipfix;

    if(the5Record.flowHeader.version == htons(9)) handle_ipfix = 0; else handle_ipfix = 1;

    if(handle_ipfix) {
      numEntries = ntohs(the5Record.flowHeader.count), displ = sizeof(V9FlowHeader);
#ifdef DEBUG_FLOWS
	traceEvent(TRACE_INFO, "Num IPFIX Entries: %d", numEntries);
#endif

    } else {
      numEntries = ntohs(the5Record.flowHeader.count),
	record_len = ntohs(the5Record.flowHeader.count), displ = sizeof(V9FlowHeader);
    }

    recordActTime = the5Record.flowHeader.unix_secs;
    recordSysUpTime = the5Record.flowHeader.sysUptime;

    for(i=0; (!done) && (displ < bufferLen) && (i < numEntries); i++) {
      /* 1st byte */
      if(buffer[displ] == 0) {
	u_char isOptionTemplate = (u_char)buffer[displ+1];

	/* Template */
#ifdef DEBUG_FLOWS
	traceEvent(TRACE_INFO, "Found Template [displ=%d]", displ);
	traceEvent(TRACE_INFO, "Found Template Type: %d", isOptionTemplate);
#endif

	if(bufferLen > (displ+sizeof(V9Template))) {
	  FlowSetV9 *cursor = templates;
	  u_char found = 0;
	  u_short len;
	  int fieldId;

	  if(!isOptionTemplate) {
	    len = sizeof(V9Template);

	    memcpy(&template, &buffer[displ], sizeof(V9Template));

	    template.templateId = ntohs(template.templateId);
	    template.fieldCount = ntohs(template.fieldCount);
	    template.flowsetLen = ntohs(template.flowsetLen);

#ifdef DEBUG_FLOWS
	    if(1)
	      traceEvent(TRACE_INFO, "Template [id=%d] fields: %d",
			 template.templateId, template.fieldCount);
#endif

	    /* Check the template before to handle it */
	    for(fieldId=0; (fieldId < template.fieldCount)
		  && (len < template.flowsetLen); fieldId++) {
	      V9FlowSet *set = (V9FlowSet*)&buffer[displ+sizeof(V9Template)+fieldId*sizeof(V9FlowSet)];

	      len += 4; /* Field Type (2) + Field Length (2) */
#ifdef DEBUG_FLOWS
	      if(1)
		traceEvent(TRACE_INFO, "[%d] fieldLen=%d/len=%d",
			   1+fieldId, htons(set->flowsetLen), len);
#endif
	    }

	    if(len > template.flowsetLen) {
	      static u_short lastBadTemplate = 0;

	      if(template.templateId != lastBadTemplate) {
		traceEvent(TRACE_WARNING, "Template %d has wrong size [actual=%d/expected=%d]: skipped",
			   template.templateId, len, template.flowsetLen);
		lastBadTemplate = template.templateId;
	      }
	    } else {
	      while(cursor != NULL) {
		if(cursor->templateInfo.templateId == template.templateId) {
		  found = 1;
		  break;
		} else
		  cursor = cursor->next;
	      }

	      if(found) {
#ifdef DEBUG_FLOWS
		traceEvent(TRACE_INFO, ">>>>> Redefined existing template [id=%d]",
			   template.templateId);
#endif

		free(cursor->fields);
	      } else {
#ifdef DEBUG_FLOWS
		traceEvent(TRACE_INFO, ">>>>> Found new flow template definition [id=%d]",
			   template.templateId);
#endif

		cursor = (FlowSetV9*)malloc(sizeof(FlowSetV9));
		cursor->next = templates;
		templates = cursor;
	      }

	      memcpy(&cursor->templateInfo, &buffer[displ], sizeof(V9Template));
	      cursor->templateInfo.flowsetLen = ntohs(cursor->templateInfo.flowsetLen);
	      cursor->templateInfo.templateId = ntohs(cursor->templateInfo.templateId);
	      cursor->templateInfo.fieldCount = ntohs(cursor->templateInfo.fieldCount);
	      cursor->fields = (V9TemplateField*)malloc(cursor->templateInfo.flowsetLen-sizeof(V9Template));
	      memcpy(cursor->fields, &buffer[displ+sizeof(V9Template)],
		     cursor->templateInfo.flowsetLen-sizeof(V9Template));
	    }
	  } else {
	    u_short move_ahead;

	    memcpy(&move_ahead, &buffer[displ+2], 2);
	    template.flowsetLen = ntohs(move_ahead);
	  }

#ifdef DEBUG_FLOWS
	  traceEvent(TRACE_INFO, "Moving ahead of %d bytes", template.flowsetLen);
#endif

	  /* Skip template definition */
	  displ += template.flowsetLen;
	} else {
	  done = 1;
	}
      } else {
#ifdef DEBUG_FLOWS
	traceEvent(TRACE_INFO, "Found FlowSet [displ=%d]", displ);
#endif
	foundRecord = 1;
      }

      if(foundRecord) {
	V9FlowSet fs;

	if(bufferLen > (displ+sizeof(V9FlowSet))) {
	  FlowSetV9 *cursor = templates;
	  u_short tot_len = 0;

	  memcpy(&fs, &buffer[displ], sizeof(V9FlowSet));

	  fs.flowsetLen = ntohs(fs.flowsetLen);
	  fs.templateId = ntohs(fs.templateId);

	  while(cursor != NULL) {
	    if(cursor->templateInfo.templateId == fs.templateId) {
	      break;
	    } else
	      cursor = cursor->next;
	  }

	  if(cursor != NULL) {
	    /* Template found */
	    int fieldId, init_displ;
	    V9TemplateField *fields = cursor->fields;
	    time_t firstSeen, lastSeen;

            /* initialize to zero */
	    memset(&record, 0, sizeof(record));
	    record.vlanId = NO_VLAN; /* No VLAN */

	    init_displ = displ;
	    displ += sizeof(V9FlowSet);

#ifdef DEBUG_FLOWS
	    if(0)
	      traceEvent(TRACE_INFO, ">>>>> Rcvd flow with known template %d [%d...%d]",
			 fs.templateId, displ, fs.flowsetLen);
#endif

	    while(displ < (init_displ + fs.flowsetLen)) {
	      u_short accum_len = 0;

	      /* Defaults */
	      record.nw_latency_sec = record.nw_latency_usec = htonl(0);

#ifdef DEBUG_FLOWS
	      if(0)
		traceEvent(TRACE_INFO, ">>>>> Stats [%d...%d]", displ, (init_displ + fs.flowsetLen));
#endif

	      for(fieldId=0; fieldId<cursor->templateInfo.fieldCount; fieldId++) {
		if(!(displ < (init_displ + fs.flowsetLen))) break; /* Flow too short */

#ifdef DEBUG_FLOWS
		if(0)
		  traceEvent(TRACE_INFO, ">>>>> Dissecting flow field "
			     "[displ=%d/%d][template=%d][fieldType=%d][fieldLen=%d][field=%d/%d] [%d...%d][%s]",
			     displ, fs.flowsetLen,
			     fs.templateId, ntohs(fields[fieldId].fieldType),
			     ntohs(fields[fieldId].fieldLen),
			     fieldId, cursor->templateInfo.fieldCount,
			     displ, (init_displ + fs.flowsetLen),
			     nf_hex_dump(&buffer[displ], ntohs(fields[fieldId].fieldLen)));
#endif

		switch(ntohs(fields[fieldId].fieldType)) {
		case 1: /* IN_BYTES */
		  memcpy(&record.rcvdOctets, &buffer[displ], 4);
		  break;
		case 2: /* IN_PKTS */
		  memcpy(&record.rcvdPkts, &buffer[displ], 4);
		  break;
		case 4: /* PROT */
		  memcpy(&record.proto, &buffer[displ], 1);
		  break;
		case 5: /* TOS */
		  memcpy(&record.tos, &buffer[displ], 1);
		  break;
		case 6: /* TCP_FLAGS */
		  memcpy(&record.tcp_flags, &buffer[displ], 1);
		  break;
		case 7: /* L4_SRC_PORT */
		  memcpy(&record.srcport, &buffer[displ], 2);
		  break;
		case 8: /* IP_SRC_ADDR */
		  memcpy(&record.srcaddr, &buffer[displ], 4);
		  break;
		case 9: /* SRC_MASK */
		  memcpy(&record.src_mask, &buffer[displ], 1);
		  break;
		case 10: /* INPUT SNMP */
		  memcpy(&record.input, &buffer[displ], 2);
		  break;
		case 11: /* L4_DST_PORT */
		  memcpy(&record.dstport, &buffer[displ], 2);
		  break;
		case 12: /* IP_DST_ADDR */
		  memcpy(&record.dstaddr, &buffer[displ], 4);
		  break;
		case 13: /* DST_MASK */
		  memcpy(&record.dst_mask, &buffer[displ], 1);
		  break;
		case 14: /* OUTPUT SNMP */
		  memcpy(&record.output, &buffer[displ], 2);
		  break;
		case 15: /* IP_NEXT_HOP */
		  memcpy(&record.nexthop, &buffer[displ], 4);
		  break;
		case 17: /* DST_AS */
		  memcpy(&record.dst_as, &buffer[displ], 2);
		  break;
		case 21: /* LAST_SWITCHED */
		  memcpy(&record.last, &buffer[displ], 4);
		  break;
		case 22: /* FIRST SWITCHED */
		  memcpy(&record.first, &buffer[displ], 4);
		  break;
		case 23: /* OUT_BYTES */
		  memcpy(&record.sentOctets, &buffer[displ], 4);
		  break;
		case 24: /* OUT_PKTS */
		  memcpy(&record.sentPkts, &buffer[displ], 4);
		  break;
		case 58: /* SRC_VLAN */
		case 59: /* DST_VLAN */
		  memcpy(&record.vlanId, &buffer[displ], 2);
		  record.vlanId = ntohs(record.vlanId);
		  break;
		case 92: /* NW_LATENCY_SEC */
		  memcpy(&record.nw_latency_sec, &buffer[displ], 4);
		  break;
		case 93: /* NW_LATENCY_USEC */
		  memcpy(&record.nw_latency_usec, &buffer[displ], 4);
		  break;

		  /* VoIP Extensions */
		case 130: /* SIP_CALL_ID */
		  memcpy(&record.sip_call_id, &buffer[displ], 50);
		  traceEvent(TRACE_INFO, "SIP: sip_call_id=%s", record.sip_call_id);
		  break;
		case 131: /* SIP_CALLING_PARTY */
		  memcpy(&record.sip_calling_party, &buffer[displ], 50);
		  traceEvent(TRACE_INFO, "SIP: sip_calling_party=%s", record.sip_calling_party);
		  break;
		case 132: /* SIP_CALLED_PARTY */
		  memcpy(&record.sip_called_party, &buffer[displ], 50);
		  traceEvent(TRACE_INFO, "SIP: sip_called_party=%s", record.sip_called_party);
		  break;
		}

		accum_len += ntohs(fields[fieldId].fieldLen);
		displ += ntohs(fields[fieldId].fieldLen);
	      }

	      /*
		IMPORTANT NOTE

		handleGenericFlow handles monodirectional flows, whereas
		v9 flows and bidirectional. This means that if there's some
		bidirectional traffic, handleGenericFlow is called twice.
	      */
	      handleGenericFlow(netflow_device_ip, recordActTime,
				recordSysUpTime, &record,
				&firstSeen, &lastSeen);

#ifdef DEBUG_FLOWS
	      if(0)
		traceEvent(TRACE_INFO, ">>>> NETFLOW: Calling insert_flow_record() [accum_len=%d][save=%d]",
			   accum_len, saveFlowsIntoDB);
#endif

	      tot_len += accum_len;

	      if(record.rcvdPkts > 0) {
		u_int32_t tmp;

		record.sentPkts   = record.rcvdPkts;
		record.sentOctets = record.rcvdOctets;

		tmp = record.srcaddr;
		record.srcaddr = record.dstaddr;
		record.dstaddr = tmp;
		tmp = record.srcport;
		record.srcport = record.dstport;
		record.dstport = tmp;

		handleGenericFlow(netflow_device_ip, recordActTime, recordSysUpTime, &record,
				  &firstSeen, &lastSeen);
	      }
	    }

	    if(tot_len < fs.flowsetLen) {
	      u_short padding = fs.flowsetLen - tot_len;

	      if(padding >= 4) {
		traceEvent(TRACE_WARNING, "Template len mismatch [tot_len=%d][flow_len=%d]",
			   tot_len, fs.flowsetLen);
	      } else {
#ifdef DEBUG_FLOWS
		traceEvent(TRACE_INFO, ">>>>> %d bytes padding [tot_len=%d][flow_len=%d]",
			   padding, tot_len, fs.flowsetLen);
#endif
		displ += padding;
	      }
	    }
	  } else {
#ifdef DEBUG_FLOWS
	    traceEvent(TRACE_INFO, ">>>>> Rcvd flow with UNKNOWN template %d [displ=%d][len=%d]",
		       fs.templateId, displ, fs.flowsetLen);
#endif
	    displ += fs.flowsetLen;
	  }
	}
      }
    } /* for */
  } else if(the5Record.flowHeader.version == htons(5)) {
    int i, numFlows = ntohs(the5Record.flowHeader.count);

    recordActTime   = the5Record.flowHeader.unix_secs;
    recordSysUpTime = the5Record.flowHeader.sysUptime;

    if(numFlows > V5FLOWS_PER_PAK) numFlows = V5FLOWS_PER_PAK;

#ifdef DEBUG_FLOWS
    if(0) traceEvent(TRACE_INFO, "dissectFlow(%d flows)", numFlows);
#endif

    /*
      Reset the record so that fields that are not contained
      into v5 records are set to zero
    */
    memset(&record, 0, sizeof(record));
    record.vlanId = NO_VLAN; /* No VLAN */
    record.nw_latency_sec = record.nw_latency_usec = htonl(0);

    for(i=0; i<numFlows; i++) {
      time_t firstSeen, lastSeen;

      record.srcaddr    = the5Record.flowRecord[i].srcaddr;
      record.dstaddr    = the5Record.flowRecord[i].dstaddr;
      record.nexthop    = the5Record.flowRecord[i].nexthop;
      record.input      = the5Record.flowRecord[i].input;
      record.output     = the5Record.flowRecord[i].output;
      record.sentPkts   = the5Record.flowRecord[i].dPkts;
      record.sentOctets = the5Record.flowRecord[i].dOctets;
      record.first      = the5Record.flowRecord[i].first;
      record.last       = the5Record.flowRecord[i].last;
      record.srcport    = the5Record.flowRecord[i].srcport;
      record.dstport    = the5Record.flowRecord[i].dstport;
      record.tcp_flags  = the5Record.flowRecord[i].tcp_flags;
      record.proto      = the5Record.flowRecord[i].proto;
      record.dst_as     = the5Record.flowRecord[i].dst_as;
      record.src_as     = the5Record.flowRecord[i].src_as;
      record.dst_mask   = the5Record.flowRecord[i].dst_mask;
      record.src_mask   = the5Record.flowRecord[i].src_mask;

      handleGenericFlow(netflow_device_ip, recordActTime,
			recordSysUpTime, &record,
			&firstSeen, &lastSeen);
    }
  }
}

/* ********************************************************* */

void* netFlowCollectLoop(void* notUsed) {
  fd_set netflowMask;
  int rc, len;
#ifdef DEBUG_FLOWS
  int deviceId;
#endif
  u_char buffer[2048];
  struct sockaddr_in fromHost;

  traceEvent(TRACE_INFO, "netFlowMainLoop() thread...");

  while(!shutdownInProgress) {
    int maxSock = netFlowInSocket;
    struct timeval wait_time;

    FD_ZERO(&netflowMask);
    FD_SET(netFlowInSocket, &netflowMask);
    
#ifdef HAVE_SCTP
    if(netFlowInSctpSocket > 0) {
      FD_SET(netFlowInSctpSocket, &netflowMask);
      if(netFlowInSctpSocket > maxSock)
	maxSock = netFlowInSctpSocket;
    }
#endif

    rc = select(maxSock+1, &netflowMask, NULL, NULL, &wait_time);
    if(shutdownInProgress) break;

    if(rc > 0) {
      if(FD_ISSET(netFlowInSocket, &netflowMask)){
	len = sizeof(fromHost);
	rc = recvfrom(netFlowInSocket,
		      (char*)&buffer, sizeof(buffer),
		      0, (struct sockaddr*)&fromHost, (socklen_t*)&len);
      }
#ifdef HAVE_SCTP
      else {
	struct msghdr msg;
	struct iovec iov[2];
	char controlVector[256];

	memset(controlVector, 0, sizeof(controlVector));
	iov[0].iov_base = buffer;
	iov[0].iov_len  = sizeof(buffer);
	iov[1].iov_base = NULL;
	iov[1].iov_len  = 0;
	msg.msg_name = (caddr_t)&fromHost;
	msg.msg_namelen = sizeof(fromHost);
	msg.msg_iov = iov;
	msg.msg_iovlen = 1;
	msg.msg_control = (caddr_t)controlVector;
	msg.msg_controllen = sizeof(controlVector);

	rc = recvmsg(netFlowInSctpSocket, &msg, 0);
      }
#endif


#ifdef DEBUG_FLOWS
      traceEvent(TRACE_INFO, "NETFLOW_DEBUG: Received NetFlow packet(len=%d)(deviceId=%d)",
		 rc,  deviceId);
#endif

      if(rc > 0) {
#ifdef MAX_NETFLOW_PACKET_BUFFER
        gettimeofday(&netflowStartOfRecordProcessing, NULL);
#endif
	dissectFlow(fromHost.sin_addr.s_addr, (char*)buffer, rc);
      }
    }
  }

  return(NULL);
}

/* ********************************************************* */

void* remoteCollectLoop(void* notUsed) {
  fd_set remoteMask;
  int rc, len, debug = 0;
#ifdef DEBUG_FLOWS
  int deviceId;
#endif
  char buffer[4096], buf[STREAM_BUFFER_SIZE], decompressed_buffer[4096];
  struct sockaddr_in fromHost;

  traceEvent(TRACE_INFO, "remoteCollectLoop() thread...");

  datalink = DLT_EN10MB; /* FIX */

  while(!shutdownInProgress) {
    int maxSock = remoteInSocket;
    struct timeval wait_time;

    FD_ZERO(&remoteMask);
    FD_SET(remoteInSocket, &remoteMask);
    
    rc = select(maxSock+1, &remoteMask, NULL, NULL, &wait_time);
    if(shutdownInProgress) break;

    if(rc > 0) {
      if(FD_ISSET(remoteInSocket, &remoteMask)) {
	len = sizeof(fromHost);
	rc = recvfrom(remoteInSocket,
		      (char*)&buffer, sizeof(buffer),
		      0, (struct sockaddr*)&fromHost, (socklen_t*)&len);
      }

      if(rc > 0) {
	int len, i, num_pkts, pkt_len;

	/* if(debug) */ traceEvent(TRACE_INFO, "REMOTE_DEBUG: Received Remote packet(len=%d)", rc);

	memset(buf, 0, sizeof(buf));
	len = qlz_decompress_packet(buffer, decompressed_buffer, buf);
	if(debug) traceEvent(TRACE_INFO, "%d -> %d\n", rc, len);
	
	num_pkts = 42; /* FIX */
	pkt_len = len/num_pkts;

	for(i=0; i<num_pkts; i++) {
	  u_char *packet;
	  struct pcap_pkthdr *h;

	  h      = (struct pcap_pkthdr*)&decompressed_buffer[i*pkt_len];
	  packet = (u_char*)&decompressed_buffer[i*pkt_len+sizeof(struct pcap_pkthdr)];
	  if(debug) traceEvent(TRACE_INFO, "[caplen=%d][len=%d]", h->caplen, h->len);
	  decodePacket(NULL, h, packet);
	}
      }
    }
  }

  return(NULL);
}

