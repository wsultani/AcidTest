/*
 *  Copyright (C) 2007 Luca Deri <deri@ntop.org>
 *
 *  		       http://www.ntop.org/
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "nprobe.h"


#define BASE_ID           188

static V9V10TemplateElementId videoPlugin_template[] = {
  { NTOP_ENTERPRISE_ID /* Used by IPFIX */, BASE_ID /* NFlow/IPFIX Id */, 4 /* Length */,
    "VIDEO_PROTO" /* Symbolic name */, "Simple counter" /* Comment */},
  { NTOP_ENTERPRISE_ID, 0, 0, NULL, NULL } /* End of templates */
};

struct plugin_info {
  u_int32_t video_counter; /* Size is 4 bytes as specified in videoPlugin_template */
};

/* *********************************************** */

static PluginInfo videoPlugin; /* Forward */

/* ******************************************* */

/* ******************************************* */

void videoPlugin_init(int argc, char *argv[]) {
  /* Initialize here all the video stuff */
}

/* *********************************************** */

/* Handler called whenever an incoming packet is received */

static void videoPlugin_packet(u_char new_bucket, void *pluginData,
			    HashBucket* bkt,
			    u_short proto, u_char isFragment,
			    u_short numPkts, u_char tos,
			    u_short vlanId, struct ether_header *ehdr,
			    IpAddress *src, u_short sport,
			    IpAddress *dst, u_short dport,
			    u_int len, u_int8_t flags, u_int8_t icmpType,
			    u_short numMplsLabels,
			    u_char mplsLabels[MAX_NUM_MPLS_LABELS][MPLS_LABEL_LEN],
			    char *fingerprint,
			    const struct pcap_pkthdr *h, const u_char *p,
			    u_char *payload, int payloadLen) {
  struct plugin_info *pinfo;

  if(new_bucket) {
    PluginInformation *info;

    /* Bucket memory allocation: nothing to do here */
    
    info = (PluginInformation*)malloc(sizeof(PluginInformation));
    if(info == NULL) {
      traceEvent(TRACE_ERROR, "Not enough memory?");
      return; /* Not enough memory */
    }

    info->pluginPtr  = (void*)&videoPlugin;
    pluginData = info->pluginData = malloc(sizeof(struct plugin_info));

    if(info->pluginData == NULL) {
      traceEvent(TRACE_ERROR, "Not enough memory?");
      free(info);
      return; /* Not enough memory */
    } else
      memset(info->pluginData, 0, sizeof(struct plugin_info));

    info->next = bkt->plugin;
    bkt->plugin = info;
  }

  pinfo = (struct plugin_info*)pluginData;

  /* Update your counter: add your code here */
  pinfo->video_counter++;
}

/* *********************************************** */

/* Handler called when the flow is deleted (after export) */

static void videoPlugin_delete(HashBucket* bkt, void *pluginData) {
  if(pluginData != NULL) {
    /* Free any nested datastructure of "struct plugin_info" */
    free(pluginData);
  }
}

/* *********************************************** *

/*
Handler called at startup when the template is read 
*/

static V9V10TemplateElementId* videoPlugin_get_template(char* template_name) {
  int i;

  for(i=0; videoPlugin_template[i].templateElementId != 0; i++) {
    if(!strcmp(template_name, videoPlugin_template[i].templateElementName)) {
      return(&videoPlugin_template[i]);
    }
  }

  return(NULL); /* Unknown */
}

/* *********************************************** */

/* Handler called whenever a flow attribute needs to be exported */

static int videoPlugin_export(void *pluginData, V9V10TemplateElementId *theTemplate,
			   int direction /* 0 = src->dst, 1 = dst->src */,
			   HashBucket *bkt, char *outBuffer,
			   u_int* outBufferBegin, u_int* outBufferMax) {
  int i;

  for(i=0; videoPlugin_template[i].templateElementId != 0; i++) {
    if(theTemplate->templateElementId == videoPlugin_template[i].templateElementId) {
      if((*outBufferBegin)+videoPlugin_template[i].templateElementLen > (*outBufferMax))
	return(-2); /* Too long */

      if(pluginData) {
	struct plugin_info *info = (struct plugin_info *)pluginData;

	switch(videoPlugin_template[i].templateElementId) {
	case BASE_ID:
	  {
	    u_int32_t my_value = htonl(info->video_counter);
	    
	    memcpy(&outBuffer[*outBufferBegin], &my_value, videoPlugin_template[i].templateElementLen);
	    if(traceMode) traceEvent(TRACE_INFO, "-> VIDEO_PROTO: %d", info->video_counter);
	  }
	  break;
	default:
	  return(-1); /* Not handled */
	}

	return(0);
      }
    }
  }

  return(-1); /* Not handled */
}

/* *********************************************** */

static int videoPlugin_print(void *pluginData, V9V10TemplateElementId *theTemplate,
			     int direction /* 0 = src->dst, 1 = dst->src */,
			     HashBucket *bkt, char *line_buffer, u_int line_buffer_len) {
  int i;

  for(i=0; videoPlugin_template[i].templateElementId != 0; i++) {
    if(theTemplate->templateElementId == videoPlugin_template[i].templateElementId) {
 
      if(pluginData) {
	struct plugin_info *info = (struct plugin_info *)pluginData;

	switch(videoPlugin_template[i].templateElementId) {
	case BASE_ID:
	  snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", info->video_counter);
	  break;
	default:
	  return(-1); /* Not handled */
	}

	return(0);
      }
    }
  }

  return(-1); /* Not handled */
}

/* *********************************************** */

static V9V10TemplateElementId* videoPlugin_conf() {
  return(videoPlugin_template);
}

/* *********************************************** */

/* Plugin entrypoint */
static PluginInfo videoPlugin = {
  "Video protocol detection (skeleton plugin)",
  "0.1",
  "Handle video protocols",
  "L.Deri <deri@ntop.org>",
  0 /* not always enabled */, 1, /* enabled */
  videoPlugin_init,
  videoPlugin_conf,
  videoPlugin_delete,
  videoPlugin_packet,
  videoPlugin_get_template,
  videoPlugin_export,
  videoPlugin_print,
  NULL
};

/* *********************************************** */

/* Plugin entry fctn */
#ifdef MAKE_STATIC_PLUGINS
PluginInfo* videoPluginEntryFctn(void)
#else
     PluginInfo* PluginEntryFctn(void)
#endif
{
  return(&videoPlugin);
}

