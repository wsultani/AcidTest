/*
 *  Copyright (C) 2002-06 Luca Deri <deri@ntop.org>
 *
 *  			  http://www.ntop.org/
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "nprobe.h"

#ifdef sun
extern char *strtok_r(char *, const char *, char **);
#endif

#ifdef WIN32
#define strtok_r(a, b, c) strtok(a, b)
#endif

#ifdef HAVE_SQLITE
extern void sqlite_exec_sql(char* sql);
#endif

extern  u_int sql_row_idx;
extern DumpFormat dumpFormat;

/* ********************** */

static u_int32_t localNetworks[MAX_NUM_NETWORKS][CONST_NETWORK_SIZE];
u_int32_t numLocalNetworks = 0;

/* ********************** */

extern struct timeval initialSniffTime;
extern pthread_mutex_t traceEventMutex;
extern u_char useDynamicInterfaceIdx;
#ifndef WIN32
static u_char syslog_opened = 0;
#endif

/* ************************************ */

void traceEvent(int eventTraceLevel, char* file, int line, char * format, ...) {
  va_list va_ap;

  if(eventTraceLevel <= traceLevel) {
    char buf[2048], out_buf[640];
    char theDate[32], *extra_msg = "";
    time_t theTime = time(NULL);

    va_start (va_ap, format);

    /* We have two paths - one if we're logging, one if we aren't
     *   Note that the no-log case is those systems which don't support it (WIN32),
     *                                those without the headers !defined(USE_SYSLOG)
     *                                those where it's parametrically off...
     */

    memset(buf, 0, sizeof(buf));
    strftime(theDate, 32, "%d/%b/%Y %H:%M:%S", localtime(&theTime));

    vsnprintf(buf, sizeof(buf)-1, format, va_ap);

    if(eventTraceLevel == 0 /* TRACE_ERROR */)
      extra_msg = "ERROR: ";
    else if(eventTraceLevel == 1 /* TRACE_WARNING */)
      extra_msg = "WARNING: ";

    while(buf[strlen(buf)-1] == '\n') buf[strlen(buf)-1] = '\0';

    snprintf(out_buf, sizeof(out_buf), "%s [%s:%d] %s%s", theDate, file, line, extra_msg, buf);

#ifndef WIN32
    if(useSyslog) {
      if(!syslog_opened) {
	openlog(nprobeId, LOG_PID, LOG_DAEMON);
	syslog_opened = 1;
      }

      syslog(LOG_INFO, out_buf);
    } else
      printf("%s\n", out_buf);
#else
    printf("%s\n", out_buf);
#endif
  }

  fflush(stdout);
  va_end(va_ap);
}


/* ************************************ */

#ifdef WIN32
unsigned long waitForNextEvent(unsigned long ulDelay /* ms */) {
  unsigned long ulSlice = 1000L; /* 1 Second */

  while(ulDelay > 0L) {
    if(ulDelay < ulSlice)
      ulSlice = ulDelay;
    Sleep(ulSlice);
    ulDelay -= ulSlice;
  }

  return ulDelay;
}

/* ******************************* */

void initWinsock32() {
  WORD wVersionRequested;
  WSADATA wsaData;
  int err;

  wVersionRequested = MAKEWORD(2, 0);
  err = WSAStartup( wVersionRequested, &wsaData );
  if( err != 0 ) {
    /* Tell the user that we could not find a usable */
    /* WinSock DLL.                                  */
    traceEvent(TRACE_ERROR, "FATAL ERROR: unable to initialise Winsock 2.x.");
    exit(-1);
  }
}

/* ******************************** */

short isWinNT() {
  DWORD dwVersion;
  DWORD dwWindowsMajorVersion;

  dwVersion=GetVersion();
  dwWindowsMajorVersion =  (DWORD)(LOBYTE(LOWORD(dwVersion)));
  if(!(dwVersion >= 0x80000000 && dwWindowsMajorVersion >= 4))
    return 1;
  else
    return 0;
}

/* ****************************************************** */
/*
int snprintf(char *string, size_t maxlen, const char *format, ...) {
  int ret=0;
  va_list args;

  va_start(args, format);
  vsprintf(string,format,args);
  va_end(args);
  return ret;
}
*/
#endif /* Win32 */

/* ****************************************************** */

void checkHostFingerprint(char *fingerprint, char *osName, int osNameLen) {
  FILE *fd = NULL;
  char *WIN, *MSS, *WSS, *ttl, *flags;
  int S, N, D, T, done = 0;
  char *strtokState;

  osName[0] = '\0';
  strtokState = NULL;
  WIN = strtok_r(fingerprint, ":", &strtokState);
  MSS = strtok_r(NULL, ":", &strtokState);
  ttl = strtok_r(NULL, ":", &strtokState);
  WSS = strtok_r(NULL, ":", &strtokState);
  S = atoi(strtok_r(NULL, ":", &strtokState));
  N = atoi(strtok_r(NULL, ":", &strtokState));
  D = atoi(strtok_r(NULL, ":", &strtokState));
  T = atoi(strtok_r(NULL, ":", &strtokState));
  flags = strtok_r(NULL, ":", &strtokState);

  fd = fopen("etter.passive.os.fp", "r");

  if(fd) {
    char line[384];
    char *b, *d, *ptr;

    while((!done) && fgets(line, sizeof(line)-1, fd)) {
      if((line[0] == '\0') || (line[0] == '#') || (strlen(line) < 30)) continue;
      line[strlen(line)-1] = '\0';

      strtokState = NULL;
      ptr = strtok_r(line, ":", &strtokState); if(ptr == NULL) continue;
      if(strcmp(ptr, WIN)) continue;
      b = strtok_r(NULL, ":", &strtokState); if(b == NULL) continue;
      if(strcmp(MSS, "_MSS") != 0) {
	if(strcmp(b, "_MSS") != 0) {
	  if(strcmp(b, MSS)) continue;
	}
      }

      ptr = strtok_r(NULL, ":", &strtokState); if(ptr == NULL) continue;
      if(strcmp(ptr, ttl)) continue;

      d = strtok_r(NULL, ":", &strtokState); if(d == NULL) continue;
      if(strcmp(WSS, "WS") != 0) {
	if(strcmp(d, "WS") != 0) {
	  if(strcmp(d, WSS)) continue;
	}
      }

      ptr = strtok_r(NULL, ":", &strtokState); if(ptr == NULL) continue;
      if(atoi(ptr) != S) continue;
      ptr = strtok_r(NULL, ":", &strtokState); if(ptr == NULL) continue;
      if(atoi(ptr) != N) continue;
      ptr = strtok_r(NULL, ":", &strtokState); if(ptr == NULL) continue;
      if(atoi(ptr) != D) continue;
      ptr = strtok_r(NULL, ":", &strtokState); if(ptr == NULL) continue;
      if(atoi(ptr) != T) continue;
      ptr = strtok_r(NULL, ":", &strtokState); if(ptr == NULL) continue;
      if(strcmp(ptr, flags)) continue;

      /* NOTE
	 strlen(srcHost->fingerprint) is 29 as the fingerprint length is so
	 Example: 0212:_MSS:80:WS:0:1:0:0:A:LT
      */

      snprintf(osName, osNameLen, "%s", &line[29]);
      done = 1;
    }

    fclose(fd);
  }
}

/* *************************************************** */

/* Courtesy of Andreas Pfaller <apfaller@yahoo.com.au> */

typedef struct IPNode {
  struct IPNode *b[2];
  u_short as;
} IPNode;

IPNode *asHead = NULL;
u_long asMem = 0, asCount=0;

/* *************************************************** */

/* Courtesy of Andreas Pfaller <apfaller@yahoo.com.au> */

static u_int32_t xaton(char *s) {
  u_int32_t a, b, c, d;

  if(4!=sscanf(s, "%d.%d.%d.%d", &a, &b, &c, &d))
    return 0;
  return((a&0xFF)<<24)|((b&0xFF)<<16)|((c&0xFF)<<8)|(d&0xFF);
}

/* ******************************************************************* */

static void addNodeInternal(u_int32_t ip, int prefix, u_short as) {
  IPNode *p1 = asHead;
  IPNode *p2 = NULL;
  int i, b;

  for(i=0; i<prefix; i++) {
    b=(ip>>(31-i)) & 0x1;
    if(!p1->b[b]) {
      if(!(p2=malloc(sizeof(IPNode)))) {
	traceEvent(TRACE_ERROR, "Not enough memory?");
	return;
      }
      memset(p2, 0, sizeof(IPNode));
      asMem += sizeof(IPNode);
      p1->b[b]=p2;
    }
    else
      p2=p1->b[b];

    p1=p2;
  }

  if(p2->as == 0)
    p2->as = as;
}

/* ******************************************************************* */

u_short ip2mask(IpAddress ip) {
  if((numLocalNetworks == 0) || (ip.ipVersion != 4))
    return(0);
  else {
    int i;
    u_int32_t addr = htonl(ip.ipType.ipv4);

    for(i=0; i<numLocalNetworks; i++) {
      if((addr & localNetworks[i][CONST_NETMASK_ENTRY]) == localNetworks[i][CONST_NETWORK_ENTRY]) {
	// traceEvent(TRACE_INFO, "--> %d", localNetworks[i][CONST_NETMASK_V6_ENTRY]);
	return(localNetworks[i][CONST_NETMASK_V6_ENTRY]);
      }
    }
  }

  return(0); /* Unknown */
}

/* ******************************************************************* */

u_short ip2AS(IpAddress ip) {
  if(ignoreAS || (ip.ipVersion != 4))
    return(0);
  else {
    IPNode *p = asHead;
    int i, b;
    u_short as = 0;

    i=0;
    while(p != NULL) {
      if(p->as != 0) as = p->as;
      b = (ip.ipType.ipv4 >> (31-i)) & 0x1;
      p = p->b[b];
      i++;
    }

#ifdef DEBUG
    {
      char buf[64];
      struct in_addr addr;

      addr.s_addr = ip.ipType.ipv4;
      traceEvent(TRACE_INFO, "%s: %d AS",  _intoaV4(addr.s_addr, buf, sizeof(buf)), as);
    }
#endif

    return(as);
  }
}

/* ************************************ */

void readASs(char *path) {
  if(ignoreAS || (path == NULL))
    return;
  else {
    FILE *fd;
    u_char useGz;

    traceEvent(TRACE_INFO, "Attempting to read AS table from file %s", path);

#ifdef HAVE_ZLIB_H
    if(!strcmp(&path[strlen(path)-3], ".gz")) {
      useGz = 1;
      fd = gzopen(path, "r");
    } else
#endif
      {
	useGz = 0;
	fd = fopen(path, "r");
      }

    if(fd != NULL) {
      asHead = malloc(sizeof(IPNode));

      if(asHead == NULL) {
	traceEvent(TRACE_ERROR, "Not enough memory?");
	return;
      }

      memset(asHead, 0, sizeof(IPNode));
      asHead->as = 0;
      asMem += sizeof(IPNode);

      while(1) {
	char buff[256];
	char *strTokState, *as, *ip, *prefix;

#ifdef HAVE_ZLIB_H
	if(useGz) {
	  if(gzeof(fd)) break;
	} else
#endif
	  {
	    if(feof(fd)) break;
	  }

#ifdef HAVE_ZLIB_H
	if(useGz) {
	  if(gzgets(fd, buff, sizeof(buff)) == NULL) continue;
	} else
#endif
	  {
	    if(fgets(buff, sizeof(buff), fd) == NULL) continue;
	  }

	if((as = strtok_r(buff, ":", &strTokState)) == NULL)  continue;
	if((ip = strtok_r(NULL, "/", &strTokState)) == NULL)  continue;
	if((prefix = strtok_r(NULL, "\n", &strTokState)) == NULL)  continue;

	addNodeInternal(xaton(ip), atoi(prefix), atoi(as));
	asCount++;
      }

#ifdef HAVE_ZLIB_H
      if(useGz)
	gzclose(fd);
      else
#endif
	fclose(fd);

      traceEvent(TRACE_INFO, "Read %d ASs [Used %d KB of memory]", asCount, asMem/1024);
    } else
      traceEvent(TRACE_ERROR, "Unable to read file %s", path);

    if(asCount > 0)
      ignoreAS = 0;
    else
      ignoreAS = 1;
  }
}

/* ********* NetFlow v9/IPFIX ***************************** */

/*
  Cisco Systems NetFlow Services Export Version 9

  http://www.faqs.org/rfcs/rfc3954.html
*/

V9V10TemplateElementId ver9_templates[] = {
  /* { 0,  0, "NOT_USED", "" }, */
  { STANDARD_ENTERPRISE_ID, 1,  4, "IN_BYTES", "Incoming flow bytes" },
  { STANDARD_ENTERPRISE_ID, 1,  0, "SYSTEM_ID", "" }, /* Hack for options template */
  { STANDARD_ENTERPRISE_ID, 2,  4, "IN_PKTS", "Incoming flow packets" },
  { STANDARD_ENTERPRISE_ID, 2,  0, "INTERFACE_ID", "" }, /* Hack for options template */
  { STANDARD_ENTERPRISE_ID, 3,  4, "FLOWS", "Number of flows" },
  { STANDARD_ENTERPRISE_ID, 3,  0, "LINE_CARD", "" }, /* Hack for options template */
  { STANDARD_ENTERPRISE_ID, 4,  1, "PROTOCOL", "IP protocol byte" },
  { STANDARD_ENTERPRISE_ID, 0xFF+4,  0, "PROTOCOL_MAP", "IP protocol name" },
  { STANDARD_ENTERPRISE_ID, 4,  0, "NETFLOW_CACHE", "" }, /* Hack for options template */
  { STANDARD_ENTERPRISE_ID, 5,  1, "SRC_TOS", "Type of service byte" },
  { STANDARD_ENTERPRISE_ID, 5,  0, "TEMPLATE_ID", "" }, /* Hack for options template */
  { STANDARD_ENTERPRISE_ID, 6,  1, "TCP_FLAGS", "Cumulative of all flow TCP flags" },
  { STANDARD_ENTERPRISE_ID, 7,  2, "L4_SRC_PORT", "IPv4 source port" },
  { STANDARD_ENTERPRISE_ID, 0xFF+7,  0, "L4_SRC_PORT_MAP", "IPv4 source port symbolic name" },
  { STANDARD_ENTERPRISE_ID, 8,  4, "IPV4_SRC_ADDR", "IPv4 source address" },
  { STANDARD_ENTERPRISE_ID, 9,  1, "SRC_MASK", "Source subnet mask (/<bits>)" },
  { STANDARD_ENTERPRISE_ID, 10,  2, "INPUT_SNMP", "Input interface SNMP idx" },
  { STANDARD_ENTERPRISE_ID, 11,  2, "L4_DST_PORT", "IPv4 destination port" },
  { STANDARD_ENTERPRISE_ID, 0xFF+11,  0, "L4_DST_PORT_MAP", "IPv4 destination port symbolic name" },
  { STANDARD_ENTERPRISE_ID, 12,  4, "IPV4_DST_ADDR", "IPv4 destination address" },
  { STANDARD_ENTERPRISE_ID, 13,  1, "DST_MASK", "Dest subnet mask (/<bits>)" },
  { STANDARD_ENTERPRISE_ID, 14,  2, "OUTPUT_SNMP", "Output interface SNMP idx" },
  { STANDARD_ENTERPRISE_ID, 15,  4, "IPV4_NEXT_HOP", "IPv4 next hop address" },
  { STANDARD_ENTERPRISE_ID, 16,  2, "SRC_AS", "Source BGP AS" },
  { STANDARD_ENTERPRISE_ID, 17,  2, "DST_AS", "Destination BGP AS" },
  /*
  { STANDARD_ENTERPRISE_ID, 18,  4, "BGP_IPV4_NEXT_HOP", "" },
  { STANDARD_ENTERPRISE_ID, 19,  4, "MUL_DST_PKTS", "" },
  { STANDARD_ENTERPRISE_ID, 20,  4, "MUL_DST_BYTES", "" },
  */
  { STANDARD_ENTERPRISE_ID, 21,  4, "LAST_SWITCHED", "SysUptime (msec) of the last flow pkt" },
  { STANDARD_ENTERPRISE_ID, 22,  4, "FIRST_SWITCHED", "SysUptime (msec) of the first flow pkt" },
  { STANDARD_ENTERPRISE_ID, 23,  4, "OUT_BYTES", "Outgoing flow bytes" },
  { STANDARD_ENTERPRISE_ID, 24,  4, "OUT_PKTS", "Outgoing flow packets" },
  /* { STANDARD_ENTERPRISE_ID, 25,  0, "RESERVED", "" }, */
  /* { STANDARD_ENTERPRISE_ID, 26,  0, "RESERVED", "" }, */
  { STANDARD_ENTERPRISE_ID, 27,  16, "IPV6_SRC_ADDR", "IPv6 source address" },
  { STANDARD_ENTERPRISE_ID, 28,  16, "IPV6_DST_ADDR", "IPv6 destination address" },
  { STANDARD_ENTERPRISE_ID, 29,  1, "IPV6_SRC_MASK", "IPv4 source mask" },
  { STANDARD_ENTERPRISE_ID, 30,  1, "IPV6_DST_MASK", "IPv4 destination mask" },
  /* { STANDARD_ENTERPRISE_ID, 31,  3, "IPV6_FLOW_LABEL", "" }, */
  { STANDARD_ENTERPRISE_ID, 32,  2, "ICMP_TYPE", "ICMP Type * 256 + ICMP code" },
  /* { STANDARD_ENTERPRISE_ID, 33,  1, "MUL_IGMP_TYPE", "" }, */
  { STANDARD_ENTERPRISE_ID, 34,  4, "SAMPLING_INTERVAL", "Sampling rate" },
  { STANDARD_ENTERPRISE_ID, 35,  1, "SAMPLING_ALGORITHM", "Sampling type (deterministic/random)" },
  { STANDARD_ENTERPRISE_ID, 36,  2, "FLOW_ACTIVE_TIMEOUT", "Activity timeout of flow cache entries" },
  { STANDARD_ENTERPRISE_ID, 37,  2, "FLOW_INACTIVE_TIMEOUT", "Inactivity timeout of flow cache entries" },
  { STANDARD_ENTERPRISE_ID, 38,  1, "ENGINE_TYPE", "Flow switching engine" },
  { STANDARD_ENTERPRISE_ID, 39,  1, "ENGINE_ID", "Id of the flow switching engine" },
  { STANDARD_ENTERPRISE_ID, 40,  4, "TOTAL_BYTES_EXP", "Total bytes exported" },
  { STANDARD_ENTERPRISE_ID, 41,  4, "TOTAL_PKTS_EXP", "Total flow packets exported" },
  { STANDARD_ENTERPRISE_ID, 42,  4, "TOTAL_FLOWS_EXP", "Total number of exported flows" },
  /* { STANDARD_ENTERPRISE_ID, 43,  0, "RESERVED", "" }, */
  /* { STANDARD_ENTERPRISE_ID, 44,  0, "RESERVED", "" }, */
  /* { STANDARD_ENTERPRISE_ID, 45,  0, "RESERVED", "" }, */
  /* { STANDARD_ENTERPRISE_ID, 46,  0, "RESERVED", "" }, i*/
  /* { STANDARD_ENTERPRISE_ID, 47,  0, "RESERVED", "" }, */
  /* { STANDARD_ENTERPRISE_ID, 48,  0, "RESERVED", "" }, */
  /* { STANDARD_ENTERPRISE_ID, 49,  0, "RESERVED", "" }, */
  /* { STANDARD_ENTERPRISE_ID, 50,  0, "RESERVED", "" }, */
  /* { STANDARD_ENTERPRISE_ID, 51,  0, "RESERVED", "" }, */
  /* { STANDARD_ENTERPRISE_ID, 52,  0, "RESERVED", "" }, */
  /* { STANDARD_ENTERPRISE_ID, 53,  0, "RESERVED", "" }, */
  /* { STANDARD_ENTERPRISE_ID, 54,  0, "RESERVED", "" }, */
  /* { STANDARD_ENTERPRISE_ID, 55,  0, "RESERVED", "" }, */
  { STANDARD_ENTERPRISE_ID, 56,  6, "IN_SRC_MAC", "Source MAC Address" }, /* new */
  { STANDARD_ENTERPRISE_ID, 57,  6, "OUT_DST_MAC", "Destination MAC Address" }, /* new */
  { STANDARD_ENTERPRISE_ID, 58,  2, "SRC_VLAN", "Source VLAN" },
  { STANDARD_ENTERPRISE_ID, 59,  2, "DST_VLAN", "Destination VLAN" },
  { STANDARD_ENTERPRISE_ID, 60,  1, "IP_PROTOCOL_VERSION", "[4=IPv4][6=IPv6]" },
  { STANDARD_ENTERPRISE_ID, 61,  1, "DIRECTION", "[0=ingress][1=egress] flow" },
  /*
  { STANDARD_ENTERPRISE_ID, 62,  1, "IPV6_NEXT_HOP", "IPv4 next hop address" },
  { STANDARD_ENTERPRISE_ID, 63,  16, "BPG_IPV6_NEXT_HOP", "" },
  { STANDARD_ENTERPRISE_ID, 64,  16, "IPV6_OPTION_HEADERS", "" },
  */
  /* { STANDARD_ENTERPRISE_ID, 65,  0, "RESERVED", "" }, */
  /* { STANDARD_ENTERPRISE_ID, 66,  0, "RESERVED", "" }, */
  /* { STANDARD_ENTERPRISE_ID, 67,  0, "RESERVED", "" }, */
  /* { STANDARD_ENTERPRISE_ID, 68,  0, "RESERVED", "" }, */
  /* { STANDARD_ENTERPRISE_ID, 69,  0, "RESERVED", "" }, */
  { STANDARD_ENTERPRISE_ID, 70,  3, "MPLS_LABEL_1",  "MPLS label at position 1" },
  { STANDARD_ENTERPRISE_ID, 71,  3, "MPLS_LABEL_2",  "MPLS label at position 2" },
  { STANDARD_ENTERPRISE_ID, 72,  3, "MPLS_LABEL_3",  "MPLS label at position 3" },
  { STANDARD_ENTERPRISE_ID, 73,  3, "MPLS_LABEL_4",  "MPLS label at position 4" },
  { STANDARD_ENTERPRISE_ID, 74,  3, "MPLS_LABEL_5",  "MPLS label at position 5" },
  { STANDARD_ENTERPRISE_ID, 75,  3, "MPLS_LABEL_6",  "MPLS label at position 6" },
  { STANDARD_ENTERPRISE_ID, 76,  3, "MPLS_LABEL_7",  "MPLS label at position 7" },
  { STANDARD_ENTERPRISE_ID, 77,  3, "MPLS_LABEL_8",  "MPLS label at position 8" },
  { STANDARD_ENTERPRISE_ID, 78,  3, "MPLS_LABEL_9",  "MPLS label at position 9" },
  { STANDARD_ENTERPRISE_ID, 79,  3, "MPLS_LABEL_10", "MPLS label at position 10" },

  /*
    ntop Extensions

    IMPORTANT
    if you change/add constants here/below make sure
    you change them into ntop too.
  */

  { STANDARD_ENTERPRISE_ID, 90,  1, "FRAGMENTED", "1=some flow packets are fragmented" },
  { STANDARD_ENTERPRISE_ID, 91,  FINGERPRINT_LEN, "FINGERPRINT", "TCP fingerprint" },
  { STANDARD_ENTERPRISE_ID, 92,  4, "NW_LATENCY_SEC", "Network latency (sec)" },
  { STANDARD_ENTERPRISE_ID, 93,  4, "NW_LATENCY_USEC", "Network latency (usec)" },
  { STANDARD_ENTERPRISE_ID, 94,  4, "APPL_LATENCY_SEC", "Application latency (sec)" },
  { STANDARD_ENTERPRISE_ID, 95,  4, "APPL_LATENCY_USEC", "Application latency (sec)" },
  { STANDARD_ENTERPRISE_ID, IN_PAYLOAD_ID,  0 /* The length is set at runtime */, "IN_PAYLOAD", "Initial payload bytes" },
  { STANDARD_ENTERPRISE_ID, OUT_PAYLOAD_ID,  0 /* The length is set at runtime */, "OUT_PAYLOAD", "Initial payload bytes" },
  { STANDARD_ENTERPRISE_ID, 98,  4, "ICMP_FLAGS", "Cumulative of all flow ICMP types" },
/*
  { STANDARD_ENTERPRISE_ID, 0,  1, "PAD1", "" },
  { STANDARD_ENTERPRISE_ID, 0,  2, "PAD2", "" },
  */
  { STANDARD_ENTERPRISE_ID, 0,  0, NULL, NULL }
};

/* ******************************************** */

void printTemplateInfo(V9V10TemplateElementId *templates,
		       u_char show_private_elements) {
  int j = 0;

  while(templates[j].templateElementName != NULL) {
    if(((!show_private_elements)
       && ((templates[j].templateElementLen > 0)
		   || (templates[j].templateElementId == IN_PAYLOAD_ID)
		   || (templates[j].templateElementId == OUT_PAYLOAD_ID)))
		   || (show_private_elements && (templates[j].templateElementId >= 0xFF))) {
      printf("[%3d] %%%-22s\t%s\n",
	     templates[j].templateElementId,
	     templates[j].templateElementName,
	     templates[j].templateElementDescr);
    }

    j++;
  }
}

/* ******************************************** */

void setPayloadLength(int len) {
  int i = 0;

  while(ver9_templates[i].templateElementName != NULL) {
    if((ver9_templates[i].templateElementId == IN_PAYLOAD_ID)
       || (ver9_templates[i].templateElementId == OUT_PAYLOAD_ID)) {
      ver9_templates[i].templateElementLen = len;
      break;
    }
    i++;
  }
}

/* ******************************************** */

void copyInt8(u_int8_t t8, char *outBuffer,
	      u_int *outBufferBegin, u_int *outBufferMax) {
  if((*outBufferBegin)+sizeof(t8) < (*outBufferMax)) {
    memcpy(&outBuffer[(*outBufferBegin)], &t8, sizeof(t8));
    (*outBufferBegin) += sizeof(t8);
  }
}

/* ******************************************** */

void copyInt16(u_int16_t _t16, char *outBuffer,
	       u_int *outBufferBegin, u_int *outBufferMax) {
  u_int16_t t16 = htons(_t16);

  if((*outBufferBegin)+sizeof(t16) < (*outBufferMax)) {
    memcpy(&outBuffer[(*outBufferBegin)], &t16, sizeof(t16));
    (*outBufferBegin) += sizeof(t16);
  }
}

/* ******************************************** */

void copyInt32(u_int32_t _t32, char *outBuffer,
	       u_int *outBufferBegin, u_int *outBufferMax) {
  u_int32_t t32 = htonl(_t32);

  if((*outBufferBegin)+sizeof(t32) < (*outBufferMax)) {
#ifdef DEBUG
    char buf1[32];

    printf("(8) %s\n", _intoaV4(_t32, buf1, sizeof(buf1)));
#endif

    memcpy(&outBuffer[(*outBufferBegin)], &t32, sizeof(t32));
    (*outBufferBegin) += sizeof(t32);
  }
}

/* ******************************************** */

void copyLen(u_char *str, int strLen, char *outBuffer,
	     u_int *outBufferBegin, u_int *outBufferMax) {
  if((*outBufferBegin)+strLen < (*outBufferMax)) {
    memcpy(&outBuffer[(*outBufferBegin)], str, strLen);
    (*outBufferBegin) += strLen;
  }
}

/* ******************************************** */

static void copyIpV6(struct in6_addr ipv6, char *outBuffer,
		     u_int *outBufferBegin, u_int *outBufferMax) {
  copyLen((u_char*)&ipv6, sizeof(ipv6), outBuffer,
	  outBufferBegin, outBufferMax);
}

/* ******************************************** */

static void copyMac(u_char *macAddress, char *outBuffer,
		    u_int *outBufferBegin, u_int *outBufferMax) {
  copyLen(macAddress, 6 /* lenght of mac address */,
	  outBuffer, outBufferBegin, outBufferMax);
}

/* ******************************************** */

static void copyMplsLabel(struct mpls_labels *mplsInfo, int labelId,
			  char *outBuffer, u_int *outBufferBegin,
			  u_int *outBufferMax) {
  if(mplsInfo == NULL) {
    int i;

    for(i=0; (i < 3) && (*outBufferBegin < *outBufferMax); i++) {
      outBuffer[*outBufferBegin] = 0;
      (*outBufferBegin)++;
    }
  } else {
    if(((*outBufferBegin)+MPLS_LABEL_LEN) < (*outBufferMax)) {
      memcpy(outBuffer, mplsInfo->mplsLabels[labelId-1], MPLS_LABEL_LEN);
      (*outBufferBegin) += MPLS_LABEL_LEN;
    }
  }
}

/* ****************************************************** */

static void exportPayload(HashBucket *myBucket, int direction,
			  V9V10TemplateElementId *theTemplate,
			  char *outBuffer, u_int *outBufferBegin,
			  u_int *outBufferMax) {
  if(maxPayloadLen > 0) {
    u_char thePayload[MAX_PAYLOAD_LEN];
    int len;

    if(direction == 0)
      len = myBucket->src2dstPayloadLen;
    else
      len = myBucket->dst2srcPayloadLen;

    /*
      u_int16_t t16;

      t16 = theTemplate->templateId;
      copyInt16(t16, outBuffer, outBufferBegin, outBufferMax);
      t16 = maxPayloadLen;
      copyInt16(t16, outBuffer, outBufferBegin, outBufferMax);
    */

    memset(thePayload, 0, maxPayloadLen);
    if(len > maxPayloadLen) len = maxPayloadLen;
    memcpy(thePayload, direction == 0 ? myBucket->src2dstPayload : myBucket->dst2srcPayload, len);

    copyLen(thePayload, maxPayloadLen, outBuffer, outBufferBegin, outBufferMax);
  }
}

/* ******************************************** */

u_int16_t ifIdx(HashBucket *myBucket, int direction, int inputIf) {
  u_char *mac;
  u_int16_t idx;

  if(setLocalTrafficDirection) {
    struct in_addr addr;

    if(direction == 0 /* src -> dst */) {
      /* Source */
      if(inputIf) {
	addr.s_addr = htonl(myBucket->src.ipType.ipv4);
	if(isLocalAddress(&addr)) return(inputInterfaceIndex); else return(outputInterfaceIndex);
      } else {
	addr.s_addr = htonl(myBucket->dst.ipType.ipv4);
	if(isLocalAddress(&addr)) return(inputInterfaceIndex); else return(outputInterfaceIndex);
      }
    } else {
      /* Destination */
      if(inputIf) {
	addr.s_addr = htonl(myBucket->dst.ipType.ipv4);
	if(isLocalAddress(&addr)) return(inputInterfaceIndex); else return(outputInterfaceIndex);
      } else {
	addr.s_addr = htonl(myBucket->src.ipType.ipv4);
	if(isLocalAddress(&addr)) return(inputInterfaceIndex); else return(outputInterfaceIndex);
      }
    }
  }

  if(num_src_mac_export > 0) {
    int i = 0;

    for(i = 0; i<num_src_mac_export; i++)
      if((((inputIf == 1) && (direction == 0)) || ((inputIf == 0) && (direction == 1)))
	 && (memcmp(myBucket->srcMacAddress, mac_if_match[i].mac_address, 6) == 0))
        return(mac_if_match[i].interface_id);
      else if((((inputIf == 0) && (direction == 0)) || ((inputIf == 1) && (direction == 1)))
	      && (memcmp(myBucket->dstMacAddress, mac_if_match[i].mac_address, 6) == 0))
        return(mac_if_match[i].interface_id);
  }
  
#if 1
  if(inputIf) {
    if(inputInterfaceIndex != (u_int16_t)-1)
      return(inputInterfaceIndex);
  } else {
    if(outputInterfaceIndex != (u_int16_t)-1)
      return(outputInterfaceIndex);
  }
#else
  /* non-mirror mode */
  if(direction == 0 /* src -> dst */) {
    /* Source */
    if(inputIf) {
      if(inputInterfaceIndex != (u_int16_t)-1)
	return(inputInterfaceIndex);
    } else {
      if(outputInterfaceIndex != (u_int16_t)-1)
	return(outputInterfaceIndex);
    }
    /* else dynamic */
  } else {
    /* Destination */
    if(inputIf) {
      if(outputInterfaceIndex != (u_int16_t)-1)
	return(outputInterfaceIndex);
    } else {
      if(inputInterfaceIndex != (u_int16_t)-1)
	return(inputInterfaceIndex);
    }
  }
#endif

  /* ...else dynamic */

  /* Calculate the input/output interface using
     the last two MAC address bytes */
  if(direction == 0 /* src -> dst */) {
    if(inputIf)
      mac = &(myBucket->srcMacAddress[4]);
    else
      mac = &(myBucket->dstMacAddress[4]);
  } else {
    if(inputIf)
      mac = &(myBucket->dstMacAddress[4]);
    else
      mac = &(myBucket->srcMacAddress[4]);
  }

  idx = (mac[0] * 256) + mac[1];

  return(idx);
}

/* ******************************************** */

static void handleTemplate(V9V10TemplateElementId *theTemplateElement,
			   char *outBuffer, u_int *outBufferBegin,
			   u_int *outBufferMax,
			   char buildTemplate, int *numElements,
			   HashBucket *theFlow, int direction,
			   int addTypeLen, int optionTemplate) {
  if(buildTemplate || addTypeLen) {
    u_int16_t t16 = theTemplateElement->templateElementId;

    if((netFlowVersion == 10)
       && (theTemplateElement->templateElementEnterpriseId != STANDARD_ENTERPRISE_ID))
      t16 = t16 | 0x8000;

    copyInt16(t16, outBuffer, outBufferBegin, outBufferMax);
    t16 = theTemplateElement->templateElementLen;
    copyInt16(t16, outBuffer, outBufferBegin, outBufferMax);

    if((netFlowVersion == 10)
       && (theTemplateElement->templateElementEnterpriseId != STANDARD_ENTERPRISE_ID))
      copyInt32(theTemplateElement->templateElementEnterpriseId, outBuffer, outBufferBegin, outBufferMax);
  }

  if(!buildTemplate) {
    if(theTemplateElement->templateElementLen == 0)
      ; /* Nothing to do: all fields have zero length */
    else {
      if(0)
	traceEvent(TRACE_INFO, "[%s][%d]", theTemplateElement->templateElementName,
		   theTemplateElement->templateElementLen);

      switch(theTemplateElement->templateElementId) {
      case 1:
	copyInt32(direction == 0 ? theFlow->bytesSent : theFlow->bytesRcvd,
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case 2:
	copyInt32(direction == 0 ? theFlow->pktSent : theFlow->pktRcvd,
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case 4:
	copyInt8((u_int8_t)theFlow->proto, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 5:
	copyInt8(direction == 0 ? theFlow->src2dstTos : theFlow->dst2srcTos,
		 outBuffer, outBufferBegin, outBufferMax);
	break;
      case 6:
	copyInt8(direction == 0 ? theFlow->src2dstTcpFlags : theFlow->dst2srcTcpFlags,
		 outBuffer, outBufferBegin, outBufferMax);
	break;
      case 7:
	copyInt16(direction == 0 ? theFlow->sport : theFlow->dport,
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case 8:
	copyInt32(direction == 0 ? theFlow->src.ipType.ipv4 : theFlow->dst.ipType.ipv4,
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case 9: /* SRC_MASK */
	copyInt8(ip2mask((direction == 0) ? theFlow->src: theFlow->dst), 
		 outBuffer, outBufferBegin, outBufferMax);
	break;
      case 10: /* INPUT_SNMP */
	copyInt16(ifIdx(theFlow, direction, 1), outBuffer, outBufferBegin, outBufferMax);
	break;
      case 11:
	copyInt16(direction == 0 ? theFlow->dport : theFlow->sport,
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case 12:
	copyInt32(direction == 0 ? theFlow->dst.ipType.ipv4 : theFlow->src.ipType.ipv4,
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case 13: /* DST_MASK */
	copyInt8(ip2mask((direction == 1) ? theFlow->src: theFlow->dst), 
		 outBuffer, outBufferBegin, outBufferMax);
	break;
      case 14: /* OUTPUT_SNMP */
	copyInt16(ifIdx(theFlow, direction, 0), outBuffer, outBufferBegin, outBufferMax);
	break;
      case 15: /* IPV4_NEXT_HOP */
	copyInt32(0, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 16:
	copyInt16(direction == 0 ? ip2AS(theFlow->src) : ip2AS(theFlow->dst),
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case 17:
	copyInt16(direction == 0 ? ip2AS(theFlow->dst) : ip2AS(theFlow->src),
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case 21:
	copyInt32(direction == 0 ? msTimeDiff(theFlow->lastSeenSent, initialSniffTime)
		  : msTimeDiff(theFlow->lastSeenRcvd, initialSniffTime),
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case 22:
	copyInt32(direction == 0 ? msTimeDiff(theFlow->firstSeenSent, initialSniffTime)
		  : msTimeDiff(theFlow->firstSeenRcvd, initialSniffTime),
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case 23:
	copyInt32(direction == 0 ? theFlow->bytesRcvd : theFlow->bytesSent,
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case 24:
	copyInt32(direction == 1 ? theFlow->pktRcvd : theFlow->pktSent,
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case 27:
	copyIpV6(direction == 0 ? theFlow->src.ipType.ipv6 : theFlow->dst.ipType.ipv6,
		 outBuffer, outBufferBegin, outBufferMax);
	break;
      case 28:
	copyIpV6(direction == 0 ? theFlow->dst.ipType.ipv6 : theFlow->src.ipType.ipv6,
		 outBuffer, outBufferBegin, outBufferMax);
	break;
      case 29:
      case 30:
	{
	  IpAddress addr;

	  memset(&addr, 0, sizeof(addr));
	  copyIpV6(addr.ipType.ipv6, outBuffer, outBufferBegin, outBufferMax);
	}
	break;
      case 32:
	copyInt16(direction == 0 ? theFlow->src2dstIcmpType : theFlow->dst2srcIcmpType,
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case 34: /* SAMPLING INTERVAL */
	copyInt32(1 /* 1:1 = no sampling */, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 35: /* SAMPLING ALGORITHM */
	copyInt8(0x01 /* 1=Deterministic Sampling, 0x02=Random Sampling */,
		 outBuffer, outBufferBegin, outBufferMax);
	break;
      case 36: /* FLOW ACTIVE TIMEOUT */
	copyInt16(lifetimeTimeout, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 37: /* FLOW INACTIVE TIMEOUT */
	copyInt16(idleTimeout, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 38:
	copyInt8((u_int8_t)engineType, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 39:
	copyInt8((u_int8_t)engineId, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 40: /* TOTAL_BYTES_EXP */
	copyInt32(totBytesExp, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 41: /* TOTAL_PKTS_EXP */
	copyInt32(totExpPktSent, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 42: /* TOTAL_FLOWS_EXP */
	copyInt32(totFlowExp, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 56: /* IN_SRC_MAC */
	copyMac(theFlow->srcMacAddress, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 57: /* OUT_DST_MAC */
	copyMac(theFlow->dstMacAddress, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 58: /* SRC_VLAN */
	/* no break */
      case 59: /* DST_VLAN */
	copyInt16(theFlow->vlanId, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 60: /* IP_PROTOCOL_VERSION */
	copyInt8(useIpV6 == 1 ? 6 : 4, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 61: /* Direction */
	copyInt8(direction, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 70: /* MPLS: label 1 */
	copyMplsLabel(theFlow->mplsInfo, 1, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 71: /* MPLS: label 2 */
	copyMplsLabel(theFlow->mplsInfo, 2, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 72: /* MPLS: label 3 */
	copyMplsLabel(theFlow->mplsInfo, 3, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 73: /* MPLS: label 4 */
	copyMplsLabel(theFlow->mplsInfo, 4, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 74: /* MPLS: label 5 */
	copyMplsLabel(theFlow->mplsInfo, 5, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 75: /* MPLS: label 6 */
	copyMplsLabel(theFlow->mplsInfo, 6, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 76: /* MPLS: label 7 */
	copyMplsLabel(theFlow->mplsInfo, 7, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 77: /* MPLS: label 8 */
	copyMplsLabel(theFlow->mplsInfo, 8, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 78: /* MPLS: label 9 */
	copyMplsLabel(theFlow->mplsInfo, 9, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 79: /* MPLS: label 10 */
	copyMplsLabel(theFlow->mplsInfo, 10, outBuffer, outBufferBegin, outBufferMax);
	break;

	/* ************************************ */

	/* nFlow Extensions */
      case 90:
	copyInt8(direction == 0 ? fragmentedPacketSrc2Dst(theFlow) :
		 fragmentedPacketSrc2Dst(theFlow),
		 outBuffer, outBufferBegin, outBufferMax);
	break;
      case 91:
	copyLen(direction == 0 ? theFlow->src2dstFingerprint : theFlow->dst2srcFingerprint,
		FINGERPRINT_LEN,
		outBuffer, outBufferBegin, outBufferMax);
	break;
      case 92:
	copyInt32(nwLatencyComputed(theFlow) ? theFlow->nwLatency.tv_sec : 0,
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case 93:
	copyInt32(nwLatencyComputed(theFlow) ? theFlow->nwLatency.tv_usec : 0,
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case 94:
	copyInt32(applLatencyComputed(theFlow) ? (direction == 0 ? theFlow->src2dstApplLatency.tv_sec
						  : theFlow->dst2srcApplLatency.tv_sec) : 0,
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case 95:
	copyInt32(applLatencyComputed(theFlow) ?
		  (direction == 0 ? theFlow->src2dstApplLatency.tv_usec :
		   theFlow->dst2srcApplLatency.tv_usec) : 0,
		  outBuffer, outBufferBegin, outBufferMax);
	break;
      case IN_PAYLOAD_ID:
	exportPayload(theFlow, 0, theTemplateElement, outBuffer, outBufferBegin, outBufferMax);
	break;
      case OUT_PAYLOAD_ID:
	exportPayload(theFlow, 1, theTemplateElement, outBuffer, outBufferBegin, outBufferMax);
	break;
      case 98:
        copyInt32(direction == 0 ? theFlow->src2dstIcmpFlags : theFlow->dst2srcIcmpFlags,
                  outBuffer, outBufferBegin, outBufferMax);
        break;
      default:
	if(checkPluginExport(theTemplateElement, direction, theFlow,
			     outBuffer, outBufferBegin, outBufferMax) == -1) {
	  u_char null_data[128] = { 0 };
	/*
	  This flow is the one we like, however we need
	  to store some values anyway, so we put an empty value
	*/

	  copyLen(null_data, theTemplateElement->templateElementLen,
		  outBuffer, outBufferBegin, outBufferMax);
	}
      }
    }

#ifdef DEBUG
    traceEvent(TRACE_INFO, "name=%s/Id=%d/len=%d [len=%d][outBufferMax=%d]\n",
	       theTemplateElement->templateElementName, 
	       theTemplateElement->templateElementId,
	       theTemplateElement->templateElementLen,
	       *outBufferBegin, *outBufferMax);    
#endif
  }

  (*numElements) = (*numElements)+1;
  return;
}

/* ******************************************** */

static char *port_mapping[0xFFFF] = { NULL };
static char *proto_mapping[0xFF] = { NULL };

void load_mappings() {
  struct servent *sv;
#if !defined(WIN32)
  struct protoent *pe;
#endif

  while((sv = getservent()) != NULL) {
    u_short port = ntohs(sv->s_port);
    if(port_mapping[port] == NULL)
      port_mapping[port] = strdup(sv->s_name);
  }

#if !defined(WIN32)
  endservent();
#endif

  /* ******************** */

#if !defined(WIN32)
  while((pe = getprotoent()) != NULL) {
    if(proto_mapping[pe->p_proto] == NULL) {
      proto_mapping[pe->p_proto] = strdup(pe->p_name);
      // traceEvent(TRACE_INFO, "[%d][%s]", pe->p_proto, pe->p_name);
    }
  }

  endprotoent();
#else
proto_mapping[0] = strdup("ip");
proto_mapping[1] = strdup("icmp");
proto_mapping[2] = strdup("igmp");
proto_mapping[6] = strdup("tcp");
proto_mapping[17] = strdup("udp");
#endif
}

/* ******************************************** */

void unload_mappings() {
  int i;

  for(i=0; i<0xFFFF; i++) if(port_mapping[i])  free(port_mapping[i]);
  for(i=0; i<0xFF; i++)   if(proto_mapping[i]) free(proto_mapping[i]);
}

/* ******************************************** */

/* FIX: improve performance */
char* proto2name(u_int8_t proto) {
#if 0
  struct protoent *svt;

  if(proto == 6)       return("tcp");
  else if(proto == 17) return("udp");
  else if(proto == 1)  return("icmp");
  else if(proto == 2)  return("igmp");
  else if((svt = getprotobynumber(proto)) != NULL)
    return(svt->p_name);
  else {
    static char the_proto[8];

    snprintf(the_proto, sizeof(the_proto), "%d", proto);
    return(the_proto);
  }
#else
  if(proto_mapping[proto] != NULL) {
    // traceEvent(TRACE_INFO, "[%d][%s]", proto, proto_mapping[proto]);
    return(proto_mapping[proto]);
  } else
    return("unknown");
#endif
}

/* ******************************************** */

static char* port2name(u_int16_t port, u_int8_t proto) {
#if 0
  struct servent *svt;

  if((svt = getservbyport(htons(port), proto2name(proto))) != NULL)
    return(svt->s_name);
  else {
    static char the_port[8];

    snprintf(the_port, sizeof(the_port), "%d", port);
    return(the_port);
  }
#else
  if(port_mapping[port] != NULL)
    return(port_mapping[port]);
  else if(proto == 6)  return("tcp_other");
  else if(proto == 17) return("udp_other");
  else return("<unknown>"); /* Not reached */
#endif
}

/* ******************************************** */

static void printRecordWithTemplate(V9V10TemplateElementId *theTemplateElement,
				    char *line_buffer, u_int line_buffer_len,
				    HashBucket *theFlow, int direction) {
  char buf[32];

  /* traceEvent(TRACE_INFO, "[%s][%d]",
     theTemplate->templateElementName, theTemplate->templateElementLen);
  */

  switch(theTemplateElement->templateElementId) {
  case 1:
    snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%lu", direction == 0 ? theFlow->bytesSent : theFlow->bytesRcvd);
    break;
  case 2:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%lu", direction == 0 ? theFlow->pktSent : theFlow->pktRcvd);
    break;
  case 4:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", theFlow->proto);
    break;
  case 0xFF+4:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%s", proto2name(theFlow->proto));
    break;
  case 5:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", direction == 0 ? theFlow->src2dstTos : theFlow->dst2srcTos);
    break;
  case 6:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", direction == 0 ? theFlow->src2dstTcpFlags : theFlow->dst2srcTcpFlags);
    break;
  case 7:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", direction == 0 ? theFlow->sport : theFlow->dport);
    break;
  case 0xFF+7:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%s", port2name(direction == 0 ? theFlow->sport : theFlow->dport, theFlow->proto));
    break;
  case 8:
  case 27:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%s", direction == 0 ? _intoa(theFlow->src, buf, sizeof(buf)):
	    _intoa(theFlow->dst, buf, sizeof(buf)));
    break;
  case 9: /* SRC_MASK */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", ip2mask((direction == 0) ? theFlow->src : theFlow->dst));
    break;
  case 10: /* INPUT_SNMP */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", ifIdx(theFlow, direction, 1));
    break;
  case 11:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", direction == 0 ? theFlow->dport : theFlow->sport);
    break;
  case 0xFF+11:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%s", port2name(direction == 0 ? theFlow->dport : theFlow->sport, theFlow->proto));
    break;
  case 12:
  case 28:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%s", direction == 0 ? _intoa(theFlow->dst, buf, sizeof(buf)):
	    _intoa(theFlow->src, buf, sizeof(buf)));
    break;
  case 13: /* DST_MASK */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", ip2mask((direction == 1) ? theFlow->src : theFlow->dst));
    break;
  case 14: /* OUTPUT_SNMP */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", ifIdx(theFlow, direction, 0));
    break;
  case 15: /* IPV4_NEXT_HOP */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", 0);
    break;
  case 16:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", direction == 0 ? ip2AS(theFlow->src) : ip2AS(theFlow->dst));
    break;
  case 17:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", direction == 0 ? ip2AS(theFlow->dst) : ip2AS(theFlow->src));
    break;
  case 21:
	    snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%u", direction == 0 ? theFlow->lastSeenSent: theFlow->lastSeenRcvd);
    break;
  case 22:
	    snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%u", direction == 0 ? theFlow->firstSeenSent :theFlow->firstSeenRcvd);
    break;
  case 23:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%lu", direction == 0 ? theFlow->bytesRcvd : theFlow->bytesSent);
    break;
  case 24:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%lu", direction == 0 ? theFlow->pktRcvd : theFlow->pktSent);
    break;
  case 29:
  case 30:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", 0);
    break;
  case 32:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", direction == 0 ? theFlow->src2dstIcmpType : theFlow->dst2srcIcmpType);
    break;
  case 34: /* SAMPLING INTERVAL */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", 1 /* 1:1 = no sampling */);
    break;
  case 35: /* SAMPLING ALGORITHM */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", 0x01 /* 1=Deterministic Sampling, 0x02=Random Sampling */);
    break;
  case 36: /* FLOW ACTIVE TIMEOUT */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", lifetimeTimeout);
    break;
  case 37: /* FLOW INACTIVE TIMEOUT */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", idleTimeout);
    break;
  case 38:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", engineType);
    break;
  case 39:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", engineId);
    break;
  case 40: /* TOTAL_BYTES_EXP */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", totBytesExp);
    break;
  case 41: /* TOTAL_PKTS_EXP */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", totExpPktSent);
    break;
  case 42: /* TOTAL_FLOWS_EXP */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", totFlowExp);
    break;
  case 56: /* IN_SRC_MAC */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%s", direction == 0 ? etheraddr_string(theFlow->srcMacAddress, buf)
	    : etheraddr_string(theFlow->dstMacAddress, buf));
    break;
  case 57: /* OUT_DST_MAC */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%s", direction == 0 ? etheraddr_string(theFlow->dstMacAddress, buf)
	    : etheraddr_string(theFlow->srcMacAddress, buf));
    break;
  case 58: /* SRC_VLAN */
  case 59: /* DST_VLAN */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", theFlow->vlanId);
    break;
  case 60: /* IP_PROTOCOL_VERSION */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", useIpV6 == 1 ? 6 : 4);
    break;
  case 61: /* Direction */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", direction);
    break;
  case 70: /* MPLS: label 1 */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", theFlow->mplsInfo[0]);
    break;
  case 71: /* MPLS: label 2 */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", theFlow->mplsInfo[1]);
    break;
  case 72: /* MPLS: label 3 */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", theFlow->mplsInfo[2]);
    break;
  case 73: /* MPLS: label 4 */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", theFlow->mplsInfo[3]);
    break;
  case 74: /* MPLS: label 5 */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", theFlow->mplsInfo[4]);
    break;
  case 75: /* MPLS: label 6 */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", theFlow->mplsInfo[5]);
    break;
  case 76: /* MPLS: label 7 */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", theFlow->mplsInfo[6]);
    break;
  case 77: /* MPLS: label 8 */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", theFlow->mplsInfo[7]);
    break;
  case 78: /* MPLS: label 9 */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", theFlow->mplsInfo[8]);
    break;
  case 79: /* MPLS: label 10 */
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", theFlow->mplsInfo[9]);
    break;

    /* ************************************ */

    /* nFlow Extensions */
  case 90:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", direction == 0 ? fragmentedPacketSrc2Dst(theFlow) : fragmentedPacketSrc2Dst(theFlow));
    break;
  case 91:
    {
      int idx;

      for(idx=0; idx<FINGERPRINT_LEN; idx++)
	  snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%c", direction == 0 ? theFlow->src2dstFingerprint[idx] : theFlow->dst2srcFingerprint[idx]);
    }
    break;
  case 92:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", nwLatencyComputed(theFlow) ? theFlow->nwLatency.tv_sec : 0);
    break;
  case 93:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", nwLatencyComputed(theFlow) ? theFlow->nwLatency.tv_usec : 0);
    break;
  case 94:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", applLatencyComputed(theFlow) ? (direction == 0 ? theFlow->src2dstApplLatency.tv_sec
							  : theFlow->dst2srcApplLatency.tv_sec) : 0);
    break;
  case 95:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", applLatencyComputed(theFlow) ? (direction == 0 ? theFlow->src2dstApplLatency.tv_usec
							  : theFlow->dst2srcApplLatency.tv_usec) : 0);
    break;
  case IN_PAYLOAD_ID:
  case OUT_PAYLOAD_ID:
    {
      int idx, len;

      if(theTemplateElement->templateElementId == IN_PAYLOAD_ID)
	len = theFlow->src2dstPayloadLen;
      else
	len = theFlow->dst2srcPayloadLen;

      for(idx=0; idx<len; idx++)
	  snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%c", (theTemplateElement->templateElementId == IN_PAYLOAD_ID)
		? theFlow->src2dstPayload[idx] : theFlow->dst2srcPayload[idx]);
    }
    break;
  case 98:
      snprintf(&line_buffer[strlen(line_buffer)], (line_buffer_len-strlen(line_buffer)), "%d", direction == 0 ? theFlow->src2dstIcmpFlags : theFlow->dst2srcIcmpFlags);
    break;
  default:
    checkPluginPrint(theTemplateElement, direction, theFlow, line_buffer, line_buffer_len);
  }

#ifdef DEBUG
  traceEvent(TRACE_INFO, "name=%s/Id=%d\n",
	     theTemplateElement->templateElementName,
	     theTemplateElement->templateElementId);
#endif
}

/* ******************************************** */

void flowPrintf(V9V10TemplateElementId **templateList, char *outBuffer,
		u_int *outBufferBegin, u_int *outBufferMax,
		int *numElements, char buildTemplate,
		HashBucket *theFlow, int direction,
		int addTypeLen, int optionTemplate) {
  int idx = 0;

  (*numElements) = 0;

  while(templateList[idx] != NULL) {
    handleTemplate(templateList[idx], outBuffer, outBufferBegin, outBufferMax,
		   buildTemplate, numElements,
		   theFlow, direction, addTypeLen,
		   optionTemplate);
    idx++;
  }
}

/* ******************************************** */

void flowFilePrintf(V9V10TemplateElementId **templateList,
		    FILE *stream, HashBucket *theFlow, int direction) {
  int idx = 0;
  char line_buffer[2048] = { '\0' };

  sql_row_idx++;
  if(dumpFormat == sqlite_format)
    snprintf(&line_buffer[strlen(line_buffer)], sizeof(line_buffer), "insert into flows values ('");
  
  while(templateList[idx] != NULL) {
    if(idx > 0) {
      if(dumpFormat == sqlite_format)
	snprintf(&line_buffer[strlen(line_buffer)], sizeof(line_buffer), "','");
      else
	snprintf(&line_buffer[strlen(line_buffer)], sizeof(line_buffer), "|");
    }

    printRecordWithTemplate(templateList[idx], line_buffer, 
			    sizeof(line_buffer), theFlow, direction);
    idx++;
  }
  
  if(dumpFormat == sqlite_format) {
    snprintf(&line_buffer[strlen(line_buffer)], sizeof(line_buffer), "');");
#ifdef HAVE_SQLITE
    sqlite_exec_sql(line_buffer);
#endif
  } else
    fprintf(stream, "%s\n", line_buffer);
}

/* ******************************************** */

void compileTemplate(char *_fmt, V9V10TemplateElementId **templateList, int templateElements) {
  int idx=0, endIdx, i, templateIdx, len = strlen(_fmt);
  char fmt[1024], tmpChar, found;

  templateIdx = 0;
  snprintf(fmt, sizeof(fmt), "%s", _fmt);

  while((idx < len) && (fmt[idx] != '\0')) {	/* scan format string characters */
    switch(fmt[idx]) {
    case '%':	        /* special format follows */
      endIdx = ++idx;
      while(fmt[endIdx] != '\0') {
	if((fmt[endIdx] == ' ') || (fmt[endIdx] == '%'))
	  break;
	else
	  endIdx++;
      }

      if((endIdx == (idx+1)) && (fmt[endIdx] == '\0')) return;
      tmpChar = fmt[endIdx]; fmt[endIdx] = '\0';

      i = 0, found = 0;

      while(ver9_templates[i].templateElementName != NULL) {
	if(strcmp(&fmt[idx], ver9_templates[i].templateElementName) == 0) {
	  templateList[templateIdx++] = &ver9_templates[i];
	  found = 1;
	  break;
	}

	i++;
      }

      if(!found) {
	if((templateList[templateIdx] = getPluginTemplate(&fmt[idx])) != NULL)
	  templateIdx++;
	else
	  traceEvent(TRACE_WARNING, "Unable to locate template '%s'. Discarded.", &fmt[idx]);
      }

      if(templateIdx >= (templateElements-1)) {
	traceEvent(TRACE_WARNING, "Unable to add further template elements (%d).", templateIdx);
	break;
      }

      fmt[endIdx] = tmpChar;
      if(tmpChar == '%')
	idx = endIdx;
      else
	idx = endIdx+1;
      break;
    default:
      idx++;
      break;
    }
  }

  templateList[templateIdx] = NULL;
}

/* ******************************************** */

double toMs(struct timeval theTime) {
  return(theTime.tv_sec+(float)theTime.tv_usec/1000000);
}

/* ****************************************************** */

u_int32_t msTimeDiff(struct timeval end, struct timeval begin) {
  if((end.tv_sec == 0) && (end.tv_usec == 0))
    return(0);
  else
    return((end.tv_sec-begin.tv_sec)*1000+(end.tv_usec-begin.tv_usec)/1000);
}

/* ****************************************************** */

#ifndef WIN32
int createCondvar(ConditionalVariable *condvarId) {
  int rc;

  rc = pthread_mutex_init(&condvarId->mutex, NULL);
  rc = pthread_cond_init(&condvarId->condvar, NULL);
  condvarId->predicate = 0;

  return(rc);
}

/* ************************************ */

void deleteCondvar(ConditionalVariable *condvarId) {
  pthread_mutex_destroy(&condvarId->mutex);
  pthread_cond_destroy(&condvarId->condvar);
}

/* ************************************ */

int waitCondvar(ConditionalVariable *condvarId) {
  int rc;

  if((rc = pthread_mutex_lock(&condvarId->mutex)) != 0)
    return rc;

  while(condvarId->predicate <= 0) {
    rc = pthread_cond_wait(&condvarId->condvar, &condvarId->mutex);
  }

  condvarId->predicate--;

  rc = pthread_mutex_unlock(&condvarId->mutex);

  return rc;
}
/* ************************************ */

int signalCondvar(ConditionalVariable *condvarId, int broadcast) {
  int rc;

  rc = pthread_mutex_lock(&condvarId->mutex);

  condvarId->predicate++;

  rc = pthread_mutex_unlock(&condvarId->mutex);
  if(broadcast)
    rc = pthread_cond_broadcast(&condvarId->condvar);
  else
    rc = pthread_cond_signal(&condvarId->condvar);

  return rc;
}

#undef sleep /* Used by ntop_sleep */

#else /* WIN32 */

/* ************************************ */

int createCondvar(ConditionalVariable *condvarId) {
  condvarId->condVar = CreateEvent(NULL,  /* no security */
				   TRUE , /* auto-reset event (FALSE = single event, TRUE = broadcast) */
				   FALSE, /* non-signaled initially */
				   NULL); /* unnamed */
  InitializeCriticalSection(&condvarId->criticalSection);
  return(1);
}

/* ************************************ */

void deleteCondvar(ConditionalVariable *condvarId) {
  CloseHandle(condvarId->condVar);
  DeleteCriticalSection(&condvarId->criticalSection);
}

/* ************************************ */

int waitCondvar(ConditionalVariable *condvarId) {
  int rc;
#ifdef DEBUG
  traceEvent(CONST_TRACE_INFO, "Wait (%x)...", condvarId->condVar);
#endif
  EnterCriticalSection(&condvarId->criticalSection);
  rc = WaitForSingleObject(condvarId->condVar, INFINITE);
  LeaveCriticalSection(&condvarId->criticalSection);

#ifdef DEBUG
  traceEvent(CONST_TRACE_INFO, "Got signal (%d)...", rc);
#endif

  return(rc);
}

/* ************************************ */

/* NOTE: broadcast is currently ignored */
int signalCondvar(ConditionalVariable *condvarId, int broadcast) {
#ifdef DEBUG
  traceEvent(CONST_TRACE_INFO, "Signaling (%x)...", condvarId->condVar);
#endif
  return((int)PulseEvent(condvarId->condVar));
}

#define sleep(a /* sec */) waitForNextEvent(1000*a /* ms */)

#endif /* WIN32 */

/* ******************************************* */

unsigned int ntop_sleep(unsigned int secs) {
  unsigned int unsleptTime = secs, rest;

  while((rest = sleep(unsleptTime)) > 0)
    unsleptTime = rest;

  return(secs);
}

/* ******************************************* */

HashBucket* getListHead(HashBucket **list) {
  HashBucket *bkt = *list;

  (*list) = bkt->next;

  return(bkt);
}

/* ******************************************* */

void addToList(HashBucket *bkt, HashBucket **list) {
  bkt->next = *list;
  (*list) = bkt;
}

/* **************************************** */

#ifndef WIN32

void detachFromTerminal(int doChdir) {
  int rc;
  
  if(doChdir) rc = chdir("/");
  setsid();  /* detach from the terminal */

  fclose(stdin);
  fclose(stdout);
  /* fclose(stderr); */

  /*
   * clear any inherited file mode creation mask
   */
  umask (0);

  /*
   * Use line buffered stdout
   */
  /* setlinebuf (stdout); */
  setvbuf(stdout, (char *)NULL, _IOLBF, 0);
}

/* **************************************** */

void daemonize(void) {
  int childpid;

  signal(SIGHUP, SIG_IGN);
  signal(SIGCHLD, SIG_IGN);
  signal(SIGQUIT, SIG_IGN);

  if((childpid = fork()) < 0)
    traceEvent(TRACE_ERROR, "INIT: Occurred while daemonizing (errno=%d)", errno);
  else {
#ifdef DEBUG
    traceEvent(TRACE_INFO, "DEBUG: after fork() in %s (%d)",
	       childpid ? "parent" : "child", childpid);
#endif
    if(!childpid) { /* child */
      traceEvent(TRACE_INFO, "INIT: Bye bye: I'm becoming a daemon...");
      detachFromTerminal(1);
    } else { /* father */
      traceEvent(TRACE_INFO, "INIT: Parent process is exiting (this is normal)");
      exit(0);
    }
  }
}

#endif /* WIN32 */

/* ****************************************

   Address management

   **************************************** */

static int int2bits(int number) {
  int bits = 8;
  int test;

  if((number > 255) || (number < 0))
    return(CONST_INVALIDNETMASK);
  else {
    test = ~number & 0xff;
    while (test & 0x1)
      {
	bits --;
	test = test >> 1;
      }
    if(number != ((~(0xff >> bits)) & 0xff))
      return(CONST_INVALIDNETMASK);
    else
      return(bits);
  }
}

/* ********************** */

static int dotted2bits(char *mask) {
  int		fields[4];
  int		fields_num, field_bits;
  int		bits = 0;
  int		i;

  fields_num = sscanf(mask, "%d.%d.%d.%d",
		      &fields[0], &fields[1], &fields[2], &fields[3]);
  if((fields_num == 1) && (fields[0] <= 32) && (fields[0] >= 0))
    {
#ifdef DEBUG
      traceEvent(CONST_TRACE_INFO, "DEBUG: dotted2bits (%s) = %d", mask, fields[0]);
#endif
      return(fields[0]);
    }
  for (i=0; i < fields_num; i++)
    {
      /* We are in a dotted quad notation. */
      field_bits = int2bits (fields[i]);
      switch (field_bits)
	{
	case CONST_INVALIDNETMASK:
	  return(CONST_INVALIDNETMASK);

	case 0:
	  /* whenever a 0 bits field is reached there are no more */
	  /* fields to scan                                       */
	  /* In this case we are in a bits (not dotted quad) notation */
	  return(bits /* fields[0] - L.Deri 08/2001 */);

	default:
	  bits += field_bits;
	}
    }
  return(bits);
}

/* ********************************* */

static char* read_file(char* path, char* buf, u_int buf_len) {
  FILE *fd = fopen(&path[1], "r");

  if(fd == NULL) {
    traceEvent(TRACE_WARNING, "Unable to read file %s", path);
    return(NULL);
  } else {
    char line[256];
    int idx = 0;
    
    while(!feof(fd) && (fgets(line, sizeof(line), fd) != NULL)) {
      if((line[0] == '#') || (line[0] == '\n')) continue;
      while(strlen(line) && (line[strlen(line)-1] == '\n')) {
	line[strlen(line)-1] = '\0';
      }
      
      snprintf(&buf[idx], buf_len-idx-2, "%s%s", (idx > 0) ? "," : "", line);     
      idx = strlen(buf);
    }

    fclose(fd);
    return(buf);
  }
}

/* ********************************* */

static u_int8_t num_network_bits(u_int32_t addr) {
  u_int8_t i, j, bits = 0, fields[4];
  
  memcpy(fields, &addr, 4);
  
  for(i = 8; i <= 8; i--)
    for(j=0; j<4; j++)
      if ((fields[j] & (1 << i)) != 0) bits++;	
  
  return(bits);
}

/* ********************** */

void parseLocalAddressLists(char* _addresses) {
  char *address, *addresses, *strTokState, buf[2048];

  numLocalNetworks = 0;

  if((_addresses == NULL) || (_addresses[0] == '\0'))
    return;
  else if(_addresses[0] == '@') {
    addresses = strdup(read_file(_addresses, buf, sizeof(buf)));
  } else
    addresses = strdup(_addresses);

  address = strtok_r(addresses, ",", &strTokState);

  while(address != NULL) {
    char *mask = strchr(address, '/');

    if(mask == NULL) {
      traceEvent(TRACE_WARNING, "Empty mask '%s' - ignoring entry", address);
    } else {
      u_int32_t network, networkMask, broadcast;
      int bits, a, b, c, d;

      mask[0] = '\0';
      mask++;
      bits = dotted2bits (mask);

      if(sscanf(address, "%d.%d.%d.%d", &a, &b, &c, &d) != 4) {
	address = strtok_r(NULL, ",", &strTokState);
	continue;
      }

      if(bits == CONST_INVALIDNETMASK) {
        traceEvent(TRACE_WARNING, "netmask '%s' not valid - ignoring entry", mask);
	/* malformed netmask specification */
	address = strtok_r(NULL, ",", &strTokState);
	continue;
      }

      network = ((a & 0xff) << 24) + ((b & 0xff) << 16) + ((c & 0xff) << 8) + (d & 0xff);
      /* Special case the /32 mask - yeah, we could probably do it with some fancy
         u long long stuff, but this is simpler...
         Burton Strauss <Burton@ntopsupport.com> Jun2002
      */
      if(bits == 32) {
	networkMask = 0xffffffff;
      } else {
	networkMask = 0xffffffff >> bits;
	networkMask = ~networkMask;
      }

      if((network & networkMask) != network)  {
	/* malformed network specification */

	traceEvent(TRACE_WARNING, "%d.%d.%d.%d/%d is not a valid network - correcting mask",
		   a, b, c, d, bits);
	/* correcting network numbers as specified in the netmask */
	network &= networkMask;

	a = (int) ((network >> 24) & 0xff);
	b = (int) ((network >> 16) & 0xff);
	c = (int) ((network >>  8) & 0xff);
	d = (int) ((network >>  0) & 0xff);

	/*
	  traceEvent(CONST_TRACE_NOISY, "Assuming %d.%d.%d.%d/%d [0x%08x/0x%08x]",
	  a, b, c, d, bits, network, networkMask);
	*/
      }

      broadcast = network | (~networkMask);

      a = (int) ((network >> 24) & 0xff);
      b = (int) ((network >> 16) & 0xff);
      c = (int) ((network >>  8) & 0xff);
      d = (int) ((network >>  0) & 0xff);

      traceEvent(TRACE_INFO, "Adding %d.%d.%d.%d/%d to the local network list",
		 a, b, c, d, bits);

      /* NOTE: entries are saved in network byte order for performance reasons */
      localNetworks[numLocalNetworks][CONST_NETWORK_ENTRY]    = htonl(network);
      localNetworks[numLocalNetworks][CONST_NETMASK_ENTRY]    = htonl(networkMask);
      localNetworks[numLocalNetworks][CONST_BROADCAST_ENTRY]  = htonl(broadcast);
      localNetworks[numLocalNetworks][CONST_NETMASK_V6_ENTRY] = num_network_bits(networkMask); /* Host byte-order */
      numLocalNetworks++;
    }

    address = strtok_r(NULL, ",", &strTokState);
  }

  free(addresses);
}

/* ************************************************ */

#undef DEBUG

unsigned short isLocalAddress(struct in_addr *addr) {
  int i;
#ifdef DEBUG
  char buf[64];
#endif

  /* If unset all the addresses are local */
  if(numLocalNetworks == 0) return(1);

  for(i=0; i<numLocalNetworks; i++)
    if((addr->s_addr & localNetworks[i][CONST_NETMASK_ENTRY])
       == localNetworks[i][CONST_NETWORK_ENTRY]) {
#ifdef DEBUG
      traceEvent(TRACE_INFO, "%s is local",
		 _intoaV4(ntohl(addr->s_addr), buf, sizeof(buf)));
#endif
      return 1;
    }

#ifdef DEBUG
  traceEvent(TRACE_INFO, "%s is NOT local",
	     _intoaV4(ntohl(addr->s_addr), buf, sizeof(buf)));
#endif
  return(0);
}

/* ************************************************ */

/* Utility function */
uint32_t str2addr(char *address) {
  int a, b, c, d;

  if(sscanf(address, "%d.%d.%d.%d", &a, &b, &c, &d) != 4) {
    return(0);
  } else
    return(((a & 0xff) << 24) + ((b & 0xff) << 16) + ((c & 0xff) << 8) + (d & 0xff));
}

/* ************************************************ */

static char hex[] = "0123456789ABCDEF";

char* etheraddr_string(const u_char *ep, char *buf) {
  u_int i, j;
  char *cp;

  cp = buf;
  if ((j = *ep >> 4) != 0)
    *cp++ = hex[j];
  else
    *cp++ = '0';

  *cp++ = hex[*ep++ & 0xf];

  for(i = 5; (int)--i >= 0;) {
    *cp++ = ':';
    if ((j = *ep >> 4) != 0)
      *cp++ = hex[j];
    else
      *cp++ = '0';

    *cp++ = hex[*ep++ & 0xf];
  }

  *cp = '\0';
  return (buf);
}

/* ************************************ */

void resetBucketStats(HashBucket* bkt,
		      const struct pcap_pkthdr *h,
		      u_int len,
		      u_short sport, u_short dport,
		      u_char *payload, int payloadLen) {
  if(bkt->sport == sport) {
    bkt->bytesSent = len, bkt->pktSent = 1, bkt->bytesRcvd = bkt->pktRcvd = 0;
    memcpy(&bkt->firstSeenSent, &h->ts, sizeof(struct timeval));
    memcpy(&bkt->lastSeenSent, &h->ts, sizeof(struct timeval));
    memset(&bkt->firstSeenRcvd, 0, sizeof(struct timeval));
    memset(&bkt->lastSeenRcvd, 0, sizeof(struct timeval));
  } else {
    bkt->bytesSent = bkt->pktSent = 0, bkt->bytesRcvd = len, bkt->pktRcvd = 1;
    memset(&bkt->firstSeenRcvd, 0, sizeof(struct timeval));
    memset(&bkt->lastSeenRcvd, 0, sizeof(struct timeval));
    memcpy(&bkt->firstSeenSent, &h->ts, sizeof(struct timeval));
    memcpy(&bkt->lastSeenRcvd, &h->ts, sizeof(struct timeval));
  }

  if(bkt->src2dstPayload) { free(bkt->src2dstPayload);  bkt->src2dstPayload = NULL;  }
  if(bkt->dst2srcPayload) { free(bkt->dst2srcPayload); bkt->dst2srcPayload = NULL; }
  setPayload(bkt, h, payload, payloadLen, bkt->sport == sport ? 0 : 1);
}

/* ****************************************** */

/*
  UNIX was not designed to stop you from doing stupid things, because that
  would also stop you from doing clever things.
  -- Doug Gwyn
*/
void maximize_socket_buffer(int sock_fd, int buf_type) {
  int i, rcv_buffsize_base, rcv_buffsize, max_buf_size = 1024 * 2 * 1024 /* 2 MB */, debug = 0;
  socklen_t len = sizeof(rcv_buffsize_base);

  if(getsockopt(sock_fd, SOL_SOCKET, buf_type, &rcv_buffsize_base, &len) < 0) {
    traceEvent(TRACE_ERROR, "Unable to read socket receiver buffer size [%s]",
	       strerror(errno));
    return;
  } else {
    if(debug) traceEvent(TRACE_INFO, "Default socket %s buffer size is %d",
			 buf_type == SO_RCVBUF ? "receive" : "send",
			 rcv_buffsize_base);
  }

  for(i=2;; i++) {
    rcv_buffsize = i * rcv_buffsize_base;
    if(rcv_buffsize > max_buf_size) break;

    if(setsockopt(sock_fd, SOL_SOCKET, buf_type, &rcv_buffsize, sizeof(rcv_buffsize)) < 0) {
      if(debug) traceEvent(TRACE_ERROR, "Unable to set socket %s buffer size [%s]",
			   buf_type == SO_RCVBUF ? "receive" : "send",
			   strerror(errno));
      break;
    } else
      if(debug) traceEvent(TRACE_INFO, "%s socket buffer size set %d",
			   buf_type == SO_RCVBUF ? "Receive" : "Send",
			   rcv_buffsize);
  }
}

