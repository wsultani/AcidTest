/*
** Copyright (C) 2001-2007 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  rwsort reads SiLK Flow Records from the standard input or from
**  named files and sorts them on one or more user-specified fields.
**
**  A large buffer is allocated; we attempt to create a buffer of
**  MAX_IN_CORE_SIZE bytes, but back off if the allocation fails.
**
**  Records are read and stored in this buffer; if the input ends
**  before the buffer is filled, the records are sorted and printed to
**  standard out or to the named output file.
**
**  However, if the buffer fills before the input is completely read,
**  the records in the buffer are sorted and written to a temporary
**  file on disk; the buffer is cleared, and reading of the input
**  resumes, repeating the process as necessary until all records are
**  read or until we write MAX_TMP_FILES temporary files.  We then do
**  an N-way merge-sort on the temporary files, where N is either all
**  the files or the maximum number that we can open before running
**  out of descriptors (EMFILE).  If we hit EMFILE, we merge the N
**  files into a new temporary file, then add it to the list of files
**  to merge.
**
**  When the temporary files are written to the same volume (file
**  system) as the final output, the maximum disk usage will be
**  2-times the number of records read (times the size per record);
**  when different volumes are used, the disk space required for the
**  temporary files will be between 1 and 1.5 times the number of
**  records.
**
**  TO DO:
**
**    -- Should better handle the case where we reach the
**    MAX_TMP_FILES limit.
**
*/

#include "silk.h"

RCSIDENTVAR(rcsID_RWSORTUTILS_H, "$SiLK: rwsortutils.h 8549 2007-08-20 15:13:10Z mthomas $");



/* LOCAL DEFINES AND TYPEDEFS */

/*
 *  For debugging.  Argument should be surrounded by double-parens:
 *      PRINTDEBUG((stderr, "My output\n"));
 */
#if 0
#  define PRINTDEBUG(args) fprintf args
#endif
#ifndef PRINTDEBUG
#  define PRINTDEBUG(args)
#endif

/*
 *  Maximum number of temporary files to create.  We need an array of
 *  this many char*'s to point to the file names.
 */
#define MAX_TMP_FILES  2048

/*
 *  Where to create temp files by default.  This can be overridden by
 *  the --temp-dir switch, or environment variable named in
 *  TMPDIR_ENVAR1 or the environment variable named in TMPDIR2.
 *
 *  If this is not defined, no default exists.
 */
#define DEFAULT_TEMP_DIR "/tmp"

/*
 *  Name of primary envionment variable that holds name of temp
 *  directory.  This is consulted when the --temp-dir switch is not
 *  given.
 */
#define TMPDIR_ENVAR1 "SILK_TMPDIR"

/*
 *  Name of alternate envionment variable that holds name of temp
 *  directory.  Used when the --temp-dir switch is not given and the
 *  variable named by TMPDIR_ENVAR1 is not set.
 */
#define TMPDIR_ENVAR2 "TMPDIR"

/*
 *  Function type for signal handler
 */
typedef void (*sig_fn_t)(int);


int appSetSignalHandler(sig_fn_t);
void tempFileSetTempdir(const char *temp_dir);
int tempFileCheckTempdir(void);
const char *tempFileGetName(int tmp_idx);
FILE *tempFileCreate(int tmp_idx);
FILE *tempFileOpen(int tmp_idx);
void tempFileRemove(int tmp_idx);
void tempFileRemoveAll(void);
int tempFileDumpRecords(
    int             tmp_idx,
    const void     *rec_buffer,
    uint32_t        rec_size,
    uint32_t        rec_count);
void rwqsort(char *a, size_t n, size_t es, int (*cmp)());


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
