/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  rwsort reads SiLK Flow Records from the standard input or from
**  named files and sorts them on one or more user-specified fields.
**
**  A large buffer is allocated; we attempt to create a buffer of
**  MAX_IN_CORE_SIZE bytes, but back off if the allocation fails.
**
**  Records are read and stored in this buffer; if the input ends
**  before the buffer is filled, the records are sorted and printed to
**  standard out or to the named output file.
**
**  However, if the buffer fills before the input is completely read,
**  the records in the buffer are sorted and written to a temporary
**  file on disk; the buffer is cleared, and reading of the input
**  resumes, repeating the process as necessary until all records are
**  read or until we write MAX_TMP_FILES temporary files.  We then do
**  an N-way merge-sort on the temporary files, where N is either all
**  the files or the maximum number that we can open before running
**  out of descriptors (EMFILE).  If we hit EMFILE, we merge the N
**  files into a new temporary file, then add it to the list of files
**  to merge.
**
**  When the temporary files are written to the same volume (file
**  system) as the final output, the maximum disk usage will be
**  2-times the number of records read (times the size per record);
**  when different volumes are used, the disk space required for the
**  temporary files will be between 1 and 1.5 times the number of
**  records.
**
**  TO DO:
**
**    -- Should better handle the case where we reach the
**    MAX_TMP_FILES limit.
**
*/

#include "silk.h"

RCSIDENT("$SiLK: rwsortutils.c 10646 2008-02-25 23:00:56Z mthomas $");

#include "rwsortutils.h"
#include "utils.h"


/* LOCAL VARIABLES */

/* temporary directory */
static const char *user_temp_dir = NULL;

/* template used to make temporary files. */
static char temp_file_template[PATH_MAX];

/* names of temporary files */
static char *tmp_names[MAX_TMP_FILES];



/* LOCAL FUNCTION PROTOTYPES */




/* FUNCTION DEFINITIONS */


/*
 *  ok = appSetSignalHandler(sig_fn)
 *
 *    Call sig_fn to clean up any temporary files whenever we get a
 *    signal.
 */
int appSetSignalHandler(sig_fn_t sig_fn)
{
    /* list of handled signals */
    int sigs[] = {SIGINT, SIGPIPE, SIGQUIT, SIGTERM};
    struct sigaction act;
    size_t i;

    act.sa_handler = sig_fn;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;
#ifdef SA_INTERRUPT
    act.sa_flags |= SA_INTERRUPT;
#endif

    for (i = 0; i < (sizeof(sigs)/sizeof(int)); ++i) {
        if (sigaction(sigs[i], &act, NULL) < 0) {
            skAppPrintErr("Cannot register handler for signal #%d",
                          sigs[i]);
            return -1;
        }
    }
    return 0;
}


/*
 *  tempFileSetTempdir(dir);
 *
 *    Set the directory to use for temporary files to 'dir'.
 */
void tempFileSetTempdir(const char *temp_dir)
{
    user_temp_dir = temp_dir;
}


/*
 *  ok = tempFileCheckTempdir();
 *
 *    Fill in the C string 'template' of size 'len' with the temp-file
 *    template.  Attempts to find a temporary directory, either from
 *    the user's input, from the TMPDIR environment variable, or from
 *    the DEFAULT_TEMP_DIR macro.  Also uses the application name.
 *    'template' is suitable for passing to mkstemp().  Returns 0 on
 *    success, or -1 if no directory could be found.
 */
int tempFileCheckTempdir(void)
{
    const char *tmp_dir = NULL;
    int rv;

    /* initialize tmp_names */
    memset(tmp_names, 0, sizeof(tmp_names));

    /* First, figure out the directory to use.  Use the user's option
     * if given, or SILK_TMPDIR, TMPDIR, or the default */
    if (!tmp_dir) {
        tmp_dir = user_temp_dir;
    }
    if (!tmp_dir) {
        tmp_dir = getenv(TMPDIR_ENVAR1);
    }
    if (!tmp_dir) {
        tmp_dir = getenv(TMPDIR_ENVAR2);
    }
#ifdef DEFAULT_TEMP_DIR
    if (!tmp_dir) {
        tmp_dir = DEFAULT_TEMP_DIR;
        if (tmp_dir && FILEIsATty(stderr)) {
            skAppPrintErr("Warning: Using default temporary directory %s",
                          tmp_dir);
        }
    }
#endif /* DEFAULT_TEMP_DIR */
    if (!tmp_dir) {
        skAppPrintErr("Cannot find a value for the temporary directory.");
        return -1;
    }
    if ( !skDirExists(tmp_dir)) {
        skAppPrintErr("Temporary directory '%s' does not exist", tmp_dir);
        return -1;
    }

    rv = snprintf(temp_file_template, sizeof(temp_file_template),
                  "%s/%s_tmp.XXXXXXXX", tmp_dir, skAppName());
    if ((size_t)rv >= sizeof(temp_file_template) || rv < 0) {
        skAppPrintErr("snprintf error");
        return -1;
    }

    return 0;
}


const char *tempFileGetName(int tmp_idx)
{
    return (tmp_names[tmp_idx] ? tmp_names[tmp_idx] : "NULL");
}


/*
 *  filep = tempFileCreate(tmp_idx);
 *
 *    Create and open a new temporary file indexed by 'tmp_idx.'  The
 *    name of the file can be found by tempFileGetName(), and the file
 *    can be re-opened with the tempFileOpen() function.  Returns a
 *    file pointer to the new file, or NULL on error: 'tmp_idx' out of
 *    range, mkstemp() fails.
 *
 */
FILE *tempFileCreate(int tmp_idx)
{
    FILE *fp = NULL;
    int fd;

    /* check that tmp_idx is in range */
    if (tmp_idx < 0 || tmp_idx >= MAX_TMP_FILES) {
        skAppPrintErr("tempFileCreate index %d out of range 0 < n < %d",
                      tmp_idx, MAX_TMP_FILES);
        return NULL;
    }

    /* copy template name */
    tmp_names[tmp_idx] = strdup(temp_file_template);
    if (NULL == tmp_names[tmp_idx]) {
        skAppPrintErr("Out of memory!");
        return NULL;
    }

    /* open file */
    fd = mkstemp(tmp_names[tmp_idx]);
    if (fd == -1) {
        skAppPrintErr("Cannot create temp file %s: %s",
                      tmp_names[tmp_idx], strerror(errno));
        free(tmp_names[tmp_idx]);
        tmp_names[tmp_idx] = NULL;
        return NULL;
    }

    /* convert descriptor to pointer */
    fp = fdopen(fd, "w");
    if (fp == NULL) {
        skAppPrintErr("Cannot convert descriptor to pointer for %s: %s",
                      tmp_names[tmp_idx], strerror(errno));
        close(fd);
        return NULL;
    }

    PRINTDEBUG((stderr, "new tmp %d => '%s'\n", tmp_idx, tmp_names[tmp_idx]));

    return fp;
}


/*
 *  fp = tempFileOpen(tmp_idx);
 *
 *    Returns a FILE* pointing to a unique temporary filename
 *    associated with 'tmp_idx' that has been previously created with
 *    tempFileCreate().  Returns NULL if file cannot be opened.
 */
FILE *tempFileOpen(int tmp_idx)
{
    const char *fn;

    assert (0 <= tmp_idx && tmp_idx < MAX_TMP_FILES);
    assert (tmp_names[tmp_idx]);

    fn = tempFileGetName(tmp_idx);
    PRINTDEBUG((stderr, "existing tmp %d => '%s'\n", tmp_idx, fn));

    return fopen(fn, "r");
}


/*
 *  tempFileRemove(tmp_idx);
 *
 *    Remove the temporary file indexed by 'tmp_idx'.
 */
void tempFileRemove(int tmp_idx)
{
    const char *fn;

    assert (0 <= tmp_idx && tmp_idx < MAX_TMP_FILES);
    assert (tmp_names[tmp_idx]);

    fn = tempFileGetName(tmp_idx);

    PRINTDEBUG((stderr, "Removing file %s of size %lu\n",
                fn, (unsigned long)skFileSize(fn)));
    if (-1 == remove(fn)) {
        if (skFileExists(fn)) {
            skAppPrintErr("Cannot remove file '%s': %s",
                          fn, strerror(errno));
        }
    }

    tmp_names[tmp_idx][0] = '\0';
    free(tmp_names[tmp_idx]);
    tmp_names[tmp_idx] = NULL;
}


/*
 *  tempFileRemoveAll();
 *
 *    Remove all temporary files.
 */
void tempFileRemoveAll(void)
{
    int i;

    for (i = 0; i < MAX_TMP_FILES; ++i) {
        if (tmp_names[i]) {
            tempFileRemove(i);
        }
    }

}


/*
 *  ok = tempFileDumpRecords(tmp_idx, buffer, size, count);
 *
 *    Print 'count' records having size 'size' bytes from 'buffer'
 *    into a newly created temporary file.  Index the temp file by
 *    'tmp_idx'.  Returns 0 on success, or -1 if a temp file cannot be
 *    created, or the write or close calls fail.
 */
int tempFileDumpRecords(
    int             tmp_idx,
    const void     *rec_buffer,
    uint32_t        rec_size,
    uint32_t        rec_count)
{
    FILE* temp_filep = NULL;
    int rv = -1; /* return value */

    temp_filep = tempFileCreate(tmp_idx);
    if (temp_filep == NULL) {
        goto END;
    }

    PRINTDEBUG((stderr, "Writing %lu records to '%s'...",
                (unsigned long)rec_count, tempFileGetName(tmp_idx)));
    if (rec_count != fwrite(rec_buffer, rec_size, rec_count, temp_filep)) {
        /* error writing, errno may or may not be set */
        PRINTDEBUG((stderr, "ERROR!\n"));
        skAppPrintErr("Error writing records to temp file %s: %s",
                      tempFileGetName(tmp_idx), strerror(errno));
        goto END;
    }

    /* Success so far */
    PRINTDEBUG((stderr, "done\n"));
    rv = 0;

  END:
    /* close the file if open */
    if (temp_filep) {
        if (fclose(temp_filep) == EOF) {
            /* error closing file; only report error if status so far
             * is good. */
            if (rv == 0) {
                skAppPrintErr("Error closing temp file %s: %s",
                              tempFileGetName(tmp_idx), strerror(errno));
                rv = -1;
            }
        }
    }

    return rv;
}


/*
  qsort()

  A la Bentley and McIlroy in Software - Practice and Experience,
  Vol. 23 (11) 1249-1265. Nov. 1993


*/

typedef long WORD;
#define W               sizeof(WORD)    /* must be a power of 2 */
#define SWAPINIT(a, es) swaptype = \
                        (( (a-(char *)0) | es) % W) ? 2 : (es > W) ? 1 : 0
#define exch(a, b, t)   (t = a, a = b, b = t)
#define swap(a, b)      swaptype != 0 ? swapfunc(a, b, es, swaptype) : \
                        (void )exch(*(WORD*)(a), *(WORD*)(b), t)
/* swap sequences of records */
#define vecswap(a, b, n)        if ( n > 0) swapfunc(a, b, n, swaptype)

#define PVINIT(pv, pm)  if (swaptype != 0) pv = a, swap(pv, pm); \
                        else pv = (char *)&v, v = *(WORD*)pm

#define min(a, b)       a <= b ? a : b

static char *med3(char *a, char *b, char *c, int (*cmp)())
{
    return(   cmp(a, b) < 0 ?
              (cmp(b, c) < 0 ? b : cmp(a, c) < 0 ? c : a)
              : (cmp(b, c) > 0 ? b : cmp(a, c) > 0 ? c : a)
              );
}


static void swapfunc(char *a, char *b, size_t n, int swaptype)
{
    if( swaptype <= 1)
        {
            WORD t;
            for( ; n > 0; a += W, b += W, n -= W)
                exch(*(WORD*)a, *(WORD*)b, t);
        }
    else
        {
            char t;
            for( ; n > 0; a += 1, b += 1, n -= 1)
                exch(*a, *b, t);
        }
}


void rwqsort(char *a, size_t n, size_t es, int (*cmp)())
{
    char *pa, *pb, *pc, *pd, *pl, *pm, *pn, *pv;
    int r, swaptype;
    WORD t, v;
    size_t s;

    SWAPINIT(a, es);
    if(n < 7)
        {
            /* use insertion sort on smallest arrays */
            for (pm = a + es; pm < a + n*es; pm += es)
                for(pl = pm; pl > a && cmp(pl-es, pl) > 0; pl -= es)
                    swap(pl, pl-es);
            return;
        }

    pm = a + (n/2)*es;            /* small arrays middle element */
    if ( n > 7)                   /* SLK What about n == 7 ? */
        {
            pl = a;
            pn = a + (n - 1)*es;
            if( n > 40 )
                {
                    /* big arays.  Pseudomedian of 9 */
                    s = (n / 8) * es;
                    pl = med3(pl, pl + s, pl + 2 * s, cmp);
                    pm = med3(pm - s, pm, pm + s, cmp);
                    pn = med3(pn - 2 * s, pn - s, pn, cmp);
                }
            pm = med3(pl, pm, pn, cmp); /* mid-size, med of 3 */
        }
    PVINIT(pv, pm);               /* pv points to the partition value */
    pa = pb = a;
    pc = pd = a + (n - 1) * es;
    for(;;)
        {
            while(pb <= pc && (r = cmp(pb, pv)) <= 0)
                {
                    if (r == 0)
                        {
                            swap(pa, pb);
                            pa += es;
                        }
                    pb += es;
                }
            while (pc >= pb && (r = cmp(pc, pv)) >= 0)
                {
                    if( r == 0)
                        {
                            swap(pc, pd);
                            pd -= es;
                        }
                    pc -= es;
                }
            if( pb > pc)
                break;
            swap(pb, pc);
            pb += es;
            pc -= es;
        }
    pn = a + n * es;
    s = min(pa - a, pb - pa);
    vecswap(a, pb - s, s);
    s = min(pd - pc, pn -pd -(int32_t)es);
    vecswap(pb, pn - s, s);
    if (( s = pb - pa) > es) {
        rwqsort(a, s/es, es, cmp);
    }
    if (( s = pd - pc) > es) {
        rwqsort(pn - s, s/es, es, cmp);
    }

    return;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
