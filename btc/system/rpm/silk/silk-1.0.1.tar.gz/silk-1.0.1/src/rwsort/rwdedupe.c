/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  rwdedupe reads SiLK Flow Records from the standard input or from
**  named files, re-orders them, removes duplicate records, and writes
**  the result.
**
**  A large buffer is allocated; we attempt to create a buffer of
**  --buffer-size bytes (default of DEFAULT_BUFFER_SIZE), but back off
**  if the allocation fails.
**
**  Records are read and stored in this buffer; if the input ends
**  before the buffer is filled, the records are sorted and printed to
**  standard out or to the named output file.
**
**  However, if the buffer fills before the input is completely read,
**  the records in the buffer are sorted and written to a temporary
**  file on disk; the buffer is cleared, and reading of the input
**  resumes, repeating the process as necessary until all records are
**  read or until we write MAX_TMP_FILES temporary files.  We then do
**  an N-way merge-sort on the temporary files, where N is either all
**  the files or the maximum number that we can open before running
**  out of descriptors (EMFILE).  If we hit EMFILE, we merge the N
**  files into a new temporary file, then add it to the list of files
**  to merge.
**
**  When the temporary files are written to the same volume (file
**  system) as the final output, the maximum disk usage will be
**  2-times the number of records read (times the size per record);
**  when different volumes are used, the disk space required for the
**  temporary files will be between 1 and 1.5 times the number of
**  records.
**
**  TO DO:
**
**    -- Should better handle the case where we reach the
**    MAX_TMP_FILES limit.
**
*/

#include "silk.h"

RCSIDENT("$SiLK: rwdedupe.c 11239 2008-04-11 13:58:43Z mthomas $");

#include "rwdedupe.h"


/* TYPEDEFS AND DEFINES */

typedef int (*rec_compare_fn_t)(const uint8_t *a, const uint8_t *b);


/* EXPORTED VARIABLES */

/* number of fields to sort over; rwAsciiFieldMapParseFields() sets this */
uint32_t num_fields = 0;

/* IDs of the fields to sort over; rwAsciiFieldMapParseFields() sets
 * it; values are from the rwrec_printable_fields_t enum. */
uint32_t sort_fields[RWREC_PRINTABLE_FIELD_COUNT];

/* the size of a "node".  Because the output from rwsort are SiLK
 * records, the node size includes the complete rwRec, plus any binary
 * fields that we get from plug-ins to use as the key.  This node_size
 * value may increase when we parse the --fields switch. */
uint32_t node_size = sizeof(rwRec);

/* output stream */
rwIOStruct_t *out_rwios = NULL;

/* maximum amount of RAM to attempt to allocate */
uint64_t buffer_size = DEFAULT_BUFFER_SIZE;

/* differences to allow between flows */
flow_delta_t delta;


/* FUNCTION DEFINITIONS */


/*
 *  simpleCompare(const uint8_t *a, const uint8_t *b);
 *
 *    Compare memory of 'a' vs 'b'.
 */
static int simpleCompare(const uint8_t *a, const uint8_t *b)
{
    return memcmp(a, b, node_size);
}


/* Define our raw sorting functions */
#define RETURN_IF_SORTED(a, b)                  \
    if ((a) < (b)) { return -1; }               \
    else { if ((a) > (b)) { return 1; } }

#define RETURN_IF_SORTED_DELTA(a, b, d)                                 \
    if ((d) == 0) {                                                     \
        RETURN_IF_SORTED(a, b);                                         \
    } else if ((a) < (b)) {                                             \
        if ((b) - (a) > (d)) {                                          \
            return -1;                                                  \
        }                                                               \
    } else if ((a) - (b) > (d)) {                                       \
        return 1;                                                       \
    }


/*
 *  rwrecCompare(a, b);
 *
 *     Returns an ordering on the recs pointed to `a' and `b' by
 *     comparing the fields listed in the sort_fields[] array.
 */
static int rwrecCompare(const uint8_t *a, const uint8_t *b)
{
    uint32_t i;

    for (i = 0; i < num_fields; i++) {
        switch (sort_fields[i]) {
          case RWREC_FIELD_SIP:
            RETURN_IF_SORTED((rwRecGetSIPv4((rwRec*)a)),
                             (rwRecGetSIPv4((rwRec*)b)));
            break;

          case RWREC_FIELD_DIP:
            RETURN_IF_SORTED((rwRecGetDIPv4((rwRec*)a)),
                             (rwRecGetDIPv4((rwRec*)b)));
            break;

          case RWREC_FIELD_SPORT:
            RETURN_IF_SORTED(rwRecGetSPort((rwRec*)a),
                             rwRecGetSPort((rwRec*)b));
            break;

          case RWREC_FIELD_DPORT:
            RETURN_IF_SORTED(rwRecGetDPort((rwRec*)a),
                             rwRecGetDPort((rwRec*)b));
            break;

          case RWREC_FIELD_PROTO:
            RETURN_IF_SORTED(rwRecGetProto((rwRec*)a),
                             rwRecGetProto((rwRec*)b));
            break;

          case RWREC_FIELD_PKTS:
            RETURN_IF_SORTED_DELTA(rwRecGetPkts((rwRec*)a),
                                   rwRecGetPkts((rwRec*)b),
                                   delta.d_packets);
            break;

          case RWREC_FIELD_BYTES:
            RETURN_IF_SORTED_DELTA(rwRecGetBytes((rwRec*)a),
                                   rwRecGetBytes((rwRec*)b),
                                   delta.d_bytes);
            break;

          case RWREC_FIELD_FLAGS:
            RETURN_IF_SORTED(rwRecGetFlags((rwRec*)a),
                             rwRecGetFlags((rwRec*)b));
            break;

          case RWREC_FIELD_STIME:
          case RWREC_FIELD_STIME_MSEC:
            RETURN_IF_SORTED_DELTA(rwRecGetStartTime((rwRec*)a),
                                   rwRecGetStartTime((rwRec*)b),
                                   delta.d_stime);
            break;

          case RWREC_FIELD_ELAPSED:
          case RWREC_FIELD_ELAPSED_MSEC:
            RETURN_IF_SORTED_DELTA(rwRecGetElapsed((rwRec*)a),
                                   rwRecGetElapsed((rwRec*)b),
                                   delta.d_elapsed);
            break;

          case RWREC_FIELD_SID:
            RETURN_IF_SORTED(rwRecGetSensor((rwRec*)a),
                             rwRecGetSensor((rwRec*)b));
            break;

          case RWREC_FIELD_INPUT:
            RETURN_IF_SORTED(rwRecGetInput((rwRec*)a),
                             rwRecGetInput((rwRec*)b));
            break;

          case RWREC_FIELD_OUTPUT:
            RETURN_IF_SORTED(rwRecGetOutput((rwRec*)a),
                             rwRecGetOutput((rwRec*)b));
            break;

          case RWREC_FIELD_NHIP:
            RETURN_IF_SORTED((rwRecGetNhIPv4((rwRec*)a)),
                             (rwRecGetNhIPv4((rwRec*)b)));
            break;

          case RWREC_FIELD_INIT_FLAGS:
            RETURN_IF_SORTED(rwRecGetInitFlags((rwRec*)a),
                             rwRecGetInitFlags((rwRec*)b));
            break;

          case RWREC_FIELD_REST_FLAGS:
            RETURN_IF_SORTED(rwRecGetRestFlags((rwRec*)a),
                             rwRecGetRestFlags((rwRec*)b));
            break;

          case RWREC_FIELD_TCP_STATE:
            RETURN_IF_SORTED(rwRecGetTcpState((rwRec*)a),
                             rwRecGetTcpState((rwRec*)b));
            break;

          case RWREC_FIELD_APPLICATION:
            RETURN_IF_SORTED(rwRecGetApplication((rwRec*)a),
                             rwRecGetApplication((rwRec*)b));
            break;

          case RWREC_FIELD_FTYPE_CLASS:
          case RWREC_FIELD_FTYPE_TYPE:
            RETURN_IF_SORTED(rwRecGetFlowType((rwRec*)a),
                             rwRecGetFlowType((rwRec*)b));
            break;

          case RWREC_FIELD_ICMP_TYPE_CODE:
            {
                /* Figure out whether sPort or dPort has the ICMP
                 * values.  We must check each record's values. */
                uint16_t icmp_a = ((rwRecGetDPort((rwRec*)a) == 0)
                                   ? (rwRecGetSPort((rwRec*)a))
                                   : (rwRecGetDPort((rwRec*)a)));
                uint16_t icmp_b = ((rwRecGetDPort((rwRec*)b)== 0)
                                   ? (rwRecGetSPort((rwRec*)b))
                                   : (rwRecGetDPort((rwRec*)b)));
                RETURN_IF_SORTED(icmp_a, icmp_b);
            }
            break;
        }
    }

    return 0;
}


/*
 *  mergeFiles(temp_id_1, temp_id_2)
 *
 *    Merge the temporary files numbered from 'temp_id_1' to
 *    'temp_id_2' into the output file 'out_ios', maintaining sorted
 *    order.  Exits the application if an error occurs.
 */
static void mergeFiles(int tmp_idx_1, int tmp_idx_2, rec_compare_fn_t recsort)
{
    FILE *fps[MAX_TMP_FILES];
    uint8_t recs[MAX_TMP_FILES][MAX_NODE_SIZE];
    size_t has_data[MAX_TMP_FILES];
    uint8_t lowest_rec[MAX_NODE_SIZE];
    int i, j;
    int count = 0;
    int lowest = 0;
    int tmp_idx_a = tmp_idx_1;
    int tmp_idx_b = tmp_idx_2;
    FILE *fp_intermediate = NULL;
    int tmp_idx_intermediate = tmp_idx_2;
    int opened_all = 0;
    int rv;
    uint8_t prev_lowest[MAX_NODE_SIZE];


    PRINTDEBUG((stderr, "merging %d through %d to %s\n",
                tmp_idx_1, tmp_idx_2, rwGetFileName(out_rwios)));

    memset(has_data, 0, sizeof(has_data));
    memset(lowest_rec, 0, sizeof(lowest_rec));
    memset(prev_lowest, 0, sizeof(lowest_rec));

    /* This loop repeats as long as we haven't read all of the temp
     * files generated in the qsort stage. */
    do {
        /* open an intermediate temp file.  The merge-sort will have
         * to write records here if there are not enough file handles
         * available to open all the tempoary files we wrote while
         * reading the data. */
        ++tmp_idx_intermediate;
        fp_intermediate = tempFileCreate(tmp_idx_intermediate);
        if (fp_intermediate == NULL) {
            appExit(EXIT_FAILURE);
        }

        /* Repeat for as many temp files as we can open before we hit
         * EMFILE or ENOMEM, or all of them if we can */
        for (count = 0, j = tmp_idx_a; j <= tmp_idx_b; count++, j++) {
            if (count == MAX_TMP_FILES) {
                PRINTDEBUG((stderr, "too many temporary files opened\n"));
                appExit(EXIT_FAILURE);
            }
            fps[count] = tempFileOpen(j);
            if (fps[count] == NULL) {
                if ((count > 0) && ((errno == EMFILE) || (errno == ENOMEM))) {
                    /* Blast!  We can't open any more temp files.  So,
                     * we rewind by one to catch this one the next
                     * time around. */
                    tmp_idx_b = j - 1;
                    PRINTDEBUG((stderr, ("EMFILE limit hit--"
                                         "merging %d through %d to %d\n"),
                                tmp_idx_a, tmp_idx_b, tmp_idx_intermediate));
                    break;
                } else {
                    PRINTDEBUG((stderr, "couldn't open tmp file %s\n",
                                tempFileGetName(j)));
                    appExit(EXIT_FAILURE);
                }
            }
        }

        /* Here, we check to see if we've opened all temp files.  If
         * so, set a flag so we write data to final destination and
         * break out of the loop after we're done. */
        if (tmp_idx_b == tmp_idx_2) {
            opened_all = 1;
        }
        PRINTDEBUG((stderr,"count: %d\n", count));

        /* Read the first record from each temp file into the work buffer. */
        for (i = 0; i < count; i++) {
            has_data[i] = fread(recs[i], node_size, 1, fps[i]);
        }

        /* assign an arbitary record as the lowest */
        lowest = 0;

        while (1) {
            /* make certain 'lowest' record has data; if not assign a
             * new record arbitrarily as lowest. */
            if ( !has_data[lowest]) {
                for (lowest = 0; lowest < count; ++lowest) {
                    if (has_data[lowest]) {
                        break;
                    }
                }
                /* exit the inner-while() if all records for all
                 * opened files have been processed */
                if (lowest == count) {
                    break;
                }
            }

            /* Loop over each of the files */
            for (i = 0; i < count; i++) {
                /* If the temp file has not reached EOF yet and if the
                 * temp file's record is lower than the lowest... */
                if ((i != lowest)
                    && has_data[i]
                    && (recsort(recs[i], recs[lowest]) < 0))
                {
                    /* record the index of this temp file as having
                     * the lowest record */
                    lowest = i;
                }
            }

            /* write the lowest record */
            if (opened_all) {
                /* if we successfully opened all (remaining) temp
                 * files, write to record to the final destination */
                rv = rwWrite(out_rwios, (rwRec*)recs[lowest]);
                if (0 != rv) {
                    rwioPrintLastErr(out_rwios, rv, &skAppPrintErr);
                    if (RWIO_ERROR_IS_FATAL(rv)) {
                        appExit(EXIT_FAILURE);
                    }
                }
            } else {
                /* otherwise, write record to intermediate tmp file */
                if (fwrite(recs[lowest], node_size, 1, fp_intermediate) != 1) {
                    skAppPrintErr("Could not write to tmpfile %s",
                                  tempFileGetName(tmp_idx_intermediate));
                    appExit(EXIT_FAILURE);
                }
            }

            /* for each input file, read records until we get one that
             * does not match lowest rec.  any record that matches
             * lowest rec is a duplicate so it is ignored. */
            memcpy(lowest_rec, recs[lowest], node_size);
            for (i = 0; i < count; ++i) {
                while (has_data[i] && 0 == recsort(lowest_rec, recs[i])) {
                    has_data[i] = fread(recs[i], node_size, 1, fps[i]);
                }
            }
        }

        /* Close and delete all of the temp files that we processed
         * this time. */
        for (i = 0; i < count; i++) {
            if (fps[i]) {
                fclose(fps[i]);
            }
            tempFileRemove(tmp_idx_a + i);
        }

        /* Close the intermediate temp file. */
        if (fp_intermediate) {
            if (EOF == fclose(fp_intermediate)) {
                skAppPrintErr("Error closing file %s: %s",
                              tempFileGetName(tmp_idx_intermediate),
                              strerror(errno));
                appExit(EXIT_FAILURE);
            }
            fp_intermediate = NULL;
        }

        /* Start the next merge with the next input temp file */
        tmp_idx_a = tmp_idx_b + 1;

        /* End the next merge with the temp file we just created */
        tmp_idx_2 = tmp_idx_b = tmp_idx_intermediate;

    } while (!opened_all);
}


/*
 *  sortRandom();
 *
 *    Don't make any assumptions about the input.  Store the input
 *    records in a large buffer, and sort those in-core records once
 *    all records are processed or the buffer is full.  If the buffer
 *    fills up, store the sorted records into temporary files.  Once
 *    all records are read, use mergeFiles() above to merge-sort the
 *    temporary files.
 *
 *    Exits the application if an error occurs.
 */
static void sortRandom(rec_compare_fn_t recsort)
{
    int temp_file_no = 0;
    rwIOStruct_t *input_rwios;      /* input stream */
    void *record_buffer = NULL;     /* Region of memory for records */
    uint8_t *cur_node = NULL;       /* Ptr into record_buffer */
    uint8_t *prev_node = NULL;      /* Ptr into record_buffer */
    uint32_t buffer_max_recs;       /* buffer size (in number of records) */
    uint32_t record_count = 0;      /* Number of records read */
    double multiplier = 1.0;
    int rv;

    /* Allocate the buffer: We'll try to allocate a really BIG
     * chunk...if that fails, reduce the chunk until we succeed. */
    buffer_max_recs = buffer_size / node_size;
    while (1) {
        PRINTDEBUG((stderr, "buffer_max_recs = %d\n", buffer_max_recs));
        record_buffer = malloc(node_size * buffer_max_recs);
        if (record_buffer) {
            /* malloc was successful */
            break;
        } else if (buffer_max_recs < MIN_IN_CORE_RECORDS) {
            /* give up at this point */
            skAppPrintErr("Could not allocate space for %d records; abort",
                          MIN_IN_CORE_RECORDS);
            appExit(EXIT_FAILURE);
        } else {
            /* reduce it and try again */
            multiplier *= IN_CORE_REDUCE_RATIO;
            buffer_max_recs = (buffer_size * multiplier) / node_size;
        }
    }

    /* open first file */
    rv = appNextInput(&input_rwios);
    if (rv) {
        appExit(EXIT_FAILURE);
    }

    record_count = 0;
    cur_node = record_buffer;
    while (input_rwios != NULL) {
        /* read record */
        if (rwRead(input_rwios, (rwRec*)cur_node) == 0) {
            /* end of file: close current and open next */
            rwioDestroy(&input_rwios);
            rv = appNextInput(&input_rwios);
            if (rv < 0) {
                appExit(EXIT_FAILURE);
            }
            continue;
        }

        record_count++;
        cur_node += node_size;
        if (record_count == buffer_max_recs) {
            /* Sort */
            rwqsort(record_buffer, record_count, node_size, recsort);

            /* Write to temp file */
            if (tempFileDumpRecords(temp_file_no++, record_buffer,
                                    node_size, record_count))
            {
                appExit(EXIT_FAILURE);
            }

            /* Reset record buffer to 'empty' */
            record_count = 0;
            cur_node = record_buffer;
        }
    }

    /* Sort (and maybe store) last batch of records */
    if (record_count > 0) {
        rwqsort(record_buffer, record_count, node_size, recsort);

        if (temp_file_no > 0) {
            /* Write last batch to temp file */
            if (tempFileDumpRecords(temp_file_no++, record_buffer,
                                    node_size, record_count))
            {
                appExit(EXIT_FAILURE);
            }
        }
    }

    /* Generate the output */

    if (record_count == 0 && temp_file_no == 0) {
        /* No records were read at all; write the header to the output
         * file */
        rv = rwioWriteHeader(out_rwios);
        if (0 != rv) {
            rwioPrintLastErr(out_rwios, rv, &skAppPrintErr);
        }
    } else if (temp_file_no == 0) {
        /* No temp files written, just output batch of records */
        uint32_t c;

        PRINTDEBUG((stderr, "Writing %lu records to '%s'\n",
                    (unsigned long)record_count, rwGetFileName(out_rwios)));
        for (c = 0, cur_node = record_buffer;
             c < record_count;
             ++c, cur_node += node_size)
        {
            if (prev_node && 0 != recsort(prev_node, cur_node)) {
                rv = rwWrite(out_rwios, (rwRec*)cur_node);
                if (0 != rv) {
                    rwioPrintLastErr(out_rwios, rv, &skAppPrintErr);
                    if (RWIO_ERROR_IS_FATAL(rv)) {
                        free(record_buffer);
                        appExit(EXIT_FAILURE);
                    }
                }
            }
            prev_node = cur_node;
        }
    } else {
        /* no longer have a need for the record buffer */
        free(record_buffer);
        record_buffer = NULL;

        /* now merge all the temp files */
        mergeFiles(0, (temp_file_no - 1), recsort);
    }

    if (record_buffer) {
        free(record_buffer);
    }
}


int main(int argc, char **argv)
{
    int rv;

    appSetup(argc, argv);                 /* never returns on error */

    if (num_fields == 0) {
        /* no fields, so use the entire rwRec */
        sortRandom(&simpleCompare);
    } else {
        sortRandom(&rwrecCompare);
    }

    /* close the file */
    if ((rv = rwioClose(out_rwios))
        || (rv = rwioDestroy(&out_rwios)))
    {
        rwioPrintLastErr(out_rwios, rv, &skAppPrintErr);
        appExit(EXIT_FAILURE);
    }
    out_rwios = NULL;

    appExit(EXIT_SUCCESS);
    return 0; /* NOTREACHED */
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
