/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  rwsort reads SiLK Flow Records from the standard input or from
**  named files and sorts them on one or more user-specified fields.
**
**  A large buffer is allocated; we attempt to create a buffer of
**  MAX_IN_CORE_SIZE bytes, but back off if the allocation fails.
**
**  Records are read and stored in this buffer; if the input ends
**  before the buffer is filled, the records are sorted and printed to
**  standard out or to the named output file.
**
**  However, if the buffer fills before the input is completely read,
**  the records in the buffer are sorted and written to a temporary
**  file on disk; the buffer is cleared, and reading of the input
**  resumes, repeating the process as necessary until all records are
**  read or until we write MAX_TMP_FILES temporary files.  We then do
**  an N-way merge-sort on the temporary files, where N is either all
**  the files or the maximum number that we can open before running
**  out of descriptors (EMFILE).  If we hit EMFILE, we merge the N
**  files into a new temporary file, then add it to the list of files
**  to merge.
**
**  When the temporary files are written to the same volume (file
**  system) as the final output, the maximum disk usage will be
**  2-times the number of records read (times the size per record);
**  when different volumes are used, the disk space required for the
**  temporary files will be between 1 and 1.5 times the number of
**  records.
**
**  TO DO:
**
**    -- Should better handle the case where we reach the
**    MAX_TMP_FILES limit.
**
*/

#include "silk.h"

RCSIDENT("$SiLK: rwsort.c 11239 2008-04-11 13:58:43Z mthomas $");

#include "rwsort.h"


/* EXPORTED VARIABLES */

/* number of fields to sort over; rwAsciiFieldMapParseFields() sets this */
uint32_t num_fields = 0;

/* IDs of the fields to sort over; rwAsciiFieldMapParseFields() sets
 * it; values are from the rwrec_printable_fields_t enum and from
 * values that come from dynamic libraries. */
uint32_t *sort_fields = NULL;

/* the size of a "node".  Because the output from rwsort are SiLK
 * records, the node size includes the complete rwRec, plus any binary
 * fields that we get from plug-ins to use as the key.  This node_size
 * value may increase when we parse the --fields switch. */
uint32_t node_size = sizeof(rwRec);

/* the columns that make up the key that come from plug-ins */
key_field_t key_fields[MAX_PLUGIN_KEY_FIELDS];

/* the number of these key_fields */
size_t key_num_fields = 0;

/* output stream */
rwIOStruct_t *out_rwios = NULL;

/* whether to treat the input files as already sorted */
int presorted_input = 0;

/* maximum amount of RAM to attempt to allocate */
uint64_t sort_buffer_size = DEFAULT_SORT_BUFFER_SIZE;



/* FUNCTION DEFINITIONS */


/* Define our raw sorting functions */
#define RETURN_IF_SORTED(func, rec_a, rec_b)                            \
    {                                                                   \
        if (func((rwRec*)(rec_a)) < func((rwRec*)(rec_b))) { return -1; } \
        if (func((rwRec*)(rec_a)) > func((rwRec*)(rec_b))) { return 1; } \
    }

#define RETURN_IF_SORTED_IPS(func, rec_a, rec_b)        \
    {                                                   \
        skipaddr_t ipa, ipb;                            \
        int cmp;                                        \
        func((rwRec*)(rec_a), &ipa);                    \
        func((rwRec*)(rec_b), &ipb);                    \
        cmp = skipaddrCompare(&ipa, &ipb);              \
        if (cmp != 0) {                                 \
            return cmp;                                 \
        }                                               \
    }


/*
 *  rwrecCompare(a, b);
 *
 *     Returns an ordering on the recs pointed to `a' and `b' by
 *     comparing the fields listed in the sort_fields[] array.
 */
static int rwrecCompare(const uint8_t *a, const uint8_t *b)
{
    uint32_t i;
    size_t plugin_field = 0;
    int rv;

    for (i = 0; i < num_fields; i++) {
        switch (sort_fields[i]) {
          case RWREC_FIELD_SIP:
#if !SK_ENABLE_IPV6
            RETURN_IF_SORTED(rwRecGetSIPv4, a, b);
#else
            RETURN_IF_SORTED_IPS(rwRecMemGetSIP, a, b);
#endif /* SK_ENABLE_IPV6 */
            break;

          case RWREC_FIELD_DIP:
#if !SK_ENABLE_IPV6
            RETURN_IF_SORTED(rwRecGetDIPv4, a, b);
#else
            RETURN_IF_SORTED_IPS(rwRecMemGetDIP, a, b);
#endif /* SK_ENABLE_IPV6 */
            break;

          case RWREC_FIELD_NHIP:
#if !SK_ENABLE_IPV6
            RETURN_IF_SORTED(rwRecGetNhIPv4, a, b);
#else
            RETURN_IF_SORTED_IPS(rwRecMemGetNhIP, a, b);
#endif /* SK_ENABLE_IPV6 */
            break;

          case RWREC_FIELD_SPORT:
            RETURN_IF_SORTED(rwRecGetSPort, a, b);
            break;

          case RWREC_FIELD_DPORT:
            RETURN_IF_SORTED(rwRecGetDPort, a, b);
            break;

          case RWREC_FIELD_PROTO:
            RETURN_IF_SORTED(rwRecGetProto, a, b);
            break;

          case RWREC_FIELD_PKTS:
            RETURN_IF_SORTED(rwRecGetPkts, a, b);
            break;

          case RWREC_FIELD_BYTES:
            RETURN_IF_SORTED(rwRecGetBytes, a, b);
            break;

          case RWREC_FIELD_FLAGS:
            RETURN_IF_SORTED(rwRecGetFlags, a, b);
            break;

          case RWREC_FIELD_STIME:
          case RWREC_FIELD_STIME_MSEC:
            RETURN_IF_SORTED(rwRecGetStartTime, a, b);
            break;

          case RWREC_FIELD_ELAPSED:
          case RWREC_FIELD_ELAPSED_MSEC:
            RETURN_IF_SORTED(rwRecGetElapsed, a, b);
            break;

          case RWREC_FIELD_ETIME:
          case RWREC_FIELD_ETIME_MSEC:
            RETURN_IF_SORTED(rwRecGetEndTime, a, b);
            break;

          case RWREC_FIELD_SID:
            RETURN_IF_SORTED(rwRecGetSensor, a, b);
            break;

          case RWREC_FIELD_INPUT:
            RETURN_IF_SORTED(rwRecGetInput, a, b);
            break;

          case RWREC_FIELD_OUTPUT:
            RETURN_IF_SORTED(rwRecGetOutput, a, b);
            break;

          case RWREC_FIELD_INIT_FLAGS:
            RETURN_IF_SORTED(rwRecGetInitFlags, a, b);
            break;

          case RWREC_FIELD_REST_FLAGS:
            RETURN_IF_SORTED(rwRecGetRestFlags, a, b);
            break;

          case RWREC_FIELD_TCP_STATE:
            RETURN_IF_SORTED(rwRecGetTcpState, a, b);
            break;

          case RWREC_FIELD_APPLICATION:
            RETURN_IF_SORTED(rwRecGetApplication, a, b);
            break;

          case RWREC_FIELD_FTYPE_CLASS:
          case RWREC_FIELD_FTYPE_TYPE:
            RETURN_IF_SORTED(rwRecGetFlowType, a, b);
            break;

          case RWREC_FIELD_ICMP_TYPE_CODE:
            RETURN_IF_SORTED(rwRecGetIcmpType, a, b);
            RETURN_IF_SORTED(rwRecGetIcmpCode, a, b);
            break;

          default:
            /* we go through the fields in the same way they were
             * added, and plugin_field should always be pointing to
             * the current plugin. */
            assert(plugin_field < key_num_fields);
            assert(key_fields[plugin_field].kf_id == sort_fields[i]);
            rv = memcmp(&(a[key_fields[plugin_field].kf_offset]),
                        &(b[key_fields[plugin_field].kf_offset]),
                        key_fields[plugin_field].kf_width);
            ++plugin_field;
            if (rv != 0) {
                return rv;
            }
            break;
        }
    }

    return 0;
}


/*
 *  mergeFiles(temp_id_1, temp_id_2)
 *
 *    Merge the temporary files numbered from 'temp_id_1' to
 *    'temp_id_2' into the output file 'out_ios', maintaining sorted
 *    order.  Exits the application if an error occurs.
 */
static void mergeFiles(int tmp_idx_1, int tmp_idx_2)
{
    FILE *fps[MAX_TMP_FILES];
    uint8_t recs[MAX_TMP_FILES][MAX_NODE_SIZE];
    size_t has_data[MAX_TMP_FILES];
    int i, j;
    int count = 0;
    int lowest = 0;
    int tmp_idx_a = tmp_idx_1;
    int tmp_idx_b = tmp_idx_2;
    FILE *fp_intermediate = NULL;
    int tmp_idx_intermediate = tmp_idx_2;
    int opened_all = 0;
    int rv;

    PRINTDEBUG((stderr, "merging %d through %d to %s\n",
                tmp_idx_1, tmp_idx_2, rwGetFileName(out_rwios)));

    memset(has_data, 0, sizeof(has_data));

    /* This loop repeats as long as we haven't read all of the temp
     * files generated in the qsort stage. */
    do {
        /* open an intermediate temp file.  The merge-sort will have
         * to write records here if there are not enough file handles
         * available to open all the tempoary files we wrote while
         * reading the data. */
        ++tmp_idx_intermediate;
        fp_intermediate = tempFileCreate(tmp_idx_intermediate);
        if (fp_intermediate == NULL) {
            appExit(EXIT_FAILURE);
        }

        /* Repeat for as many temp files as we can open before we hit
         * EMFILE or ENOMEM, or all of them if we can */
        for (count = 0, j = tmp_idx_a; j <= tmp_idx_b; count++, j++) {
            if (count == MAX_TMP_FILES) {
                PRINTDEBUG((stderr, "too many temporary files opened\n"));
                appExit(EXIT_FAILURE);
            }
            fps[count] = tempFileOpen(j);
            if (fps[count] == NULL) {
                if ((count > 0) && ((errno == EMFILE) || (errno == ENOMEM))) {
                    /* Blast!  We can't open any more temp files.  So,
                     * we rewind by one to catch this one the next
                     * time around. */
                    tmp_idx_b = j - 1;
                    PRINTDEBUG((stderr, ("EMFILE limit hit--"
                                         "merging %d through %d to %d\n"),
                                tmp_idx_a, tmp_idx_b, tmp_idx_intermediate));
                    break;
                } else {
                    PRINTDEBUG((stderr, "couldn't open tmp file %s\n",
                                tempFileGetName(j)));
                    appExit(EXIT_FAILURE);
                }
            }
        }

        /* Here, we check to see if we've opened all temp files.  If
         * so, set a flag so we write data to final destination and
         * break out of the loop after we're done. */
        if (tmp_idx_b == tmp_idx_2) {
            opened_all = 1;
        }
        PRINTDEBUG((stderr,"count: %d\n", count));

        /* Read the first record from each temp file into the work buffer. */
        for (i = 0; i < count; i++) {
            has_data[i] = fread(recs[i], node_size, 1, fps[i]);
        }

        /* assign an arbitary record as the lowest */
        lowest = 0;

        while (1) {
            /* make certain 'lowest' record has data; if not assign a
             * new record arbitrarily as lowest. */
            if ( !has_data[lowest]) {
                for (lowest = 0; lowest < count; ++lowest) {
                    if (has_data[lowest]) {
                        break;
                    }
                }
                /* exit the inner-while() if all records for all
                 * opened files have been processed */
                if (lowest == count) {
                    break;
                }
            }

            /* Loop over each of the files */
            for (i = 0; i < count; i++) {
                /* If the temp file has not reached EOF yet and if the
                 * temp file's record is lower than the lowest... */
                if ((i != lowest)
                    && has_data[i]
                    && (rwrecCompare(recs[i], recs[lowest]) < 0))
                {
                    /* record the index of this temp file as having
                     * the lowest record */
                    lowest = i;
                }
            }

            /* write the lowest record */
            if (opened_all) {
                /* if we successfully opened all (remaining) temp
                 * files, write to record to the final destination */
                rv = rwWrite(out_rwios, (rwRec*)recs[lowest]);
                if (0 != rv) {
                    rwioPrintLastErr(out_rwios, rv, &skAppPrintErr);
                    if (RWIO_ERROR_IS_FATAL(rv)) {
                        appExit(EXIT_FAILURE);
                    }
                }
            } else {
                /* otherwise, write record to intermediate tmp file */
                if (fwrite(recs[lowest], node_size, 1, fp_intermediate) != 1) {
                    skAppPrintErr("Could not write to tmpfile %s",
                                  tempFileGetName(tmp_idx_intermediate));
                    appExit(EXIT_FAILURE);
                }
            }

            /* replace the record we just wrote */
            has_data[lowest] = fread(recs[lowest], node_size, 1, fps[lowest]);
        }

        /* Close and delete all of the temp files that we processed
         * this time. */
        for (i = 0; i < count; i++) {
            if (fps[i]) {
                fclose(fps[i]);
            }
            tempFileRemove(tmp_idx_a + i);
        }

        /* Close the intermediate temp file. */
        if (fp_intermediate) {
            if (EOF == fclose(fp_intermediate)) {
                skAppPrintErr("Error closing file %s: %s",
                              tempFileGetName(tmp_idx_intermediate),
                              strerror(errno));
                appExit(EXIT_FAILURE);
            }
            fp_intermediate = NULL;
        }

        /* Start the next merge with the next input temp file */
        tmp_idx_a = tmp_idx_b + 1;

        /* End the next merge with the temp file we just created */
        tmp_idx_2 = tmp_idx_b = tmp_idx_intermediate;

    } while (!opened_all);
}


/*
 *  sortPresorted();
 *
 *    Assume all input files have been sorted using the exact same
 *    --fields value as those we are using, and simply merge sort
 *    them.
 *
 *    This function is still fairly complicated, because we have to
 *    handle running out of memory or file descriptors as we process
 *    the inputs.  When that happens, we write the records to
 *    temporary files and then use mergeFiles() above to sort those
 *    files.
 *
 *    Exits the application if an error occurs.
 */
static void sortPresorted(void)
{
    rwIOStruct_t *rwios[MAX_TMP_FILES];
    uint8_t recs[MAX_TMP_FILES][MAX_NODE_SIZE];
    size_t has_data[MAX_TMP_FILES];
    int i, count = 0;
    size_t j;
    int lowest = 0;
    FILE *fp_intermediate = NULL;
    int temp_file_count = 0;
    int temp_idx;
    int opened_all = 0;
    int rv;

    memset(has_data, 0, sizeof(has_data));
    memset(rwios, 0, sizeof(rwios));
    memset(recs, 0, sizeof(recs));

    /* This loop repeats as long as we haven't read all of input
     * files */
    do {
        /* open an intermediate temp file.  The merge-sort will have
         * to write records here if there are not enough file handles
         * available to open all the input files. */
        temp_idx = temp_file_count;
        fp_intermediate = tempFileCreate(temp_idx);
        if (fp_intermediate == NULL) {
            appExit(EXIT_FAILURE);
        }

        /* Repeat for as many input files as we can open before we hit
         * EMFILE or run out of memory */
        for (count = 0; count < MAX_TMP_FILES; ++count) {
            rv = appNextInput(&(rwios[count]));
            if (rv != 0) {
                break;
            }
        }
        switch (rv) {
          case 1:
            /* successfully opened all input files */
            PRINTDEBUG((stderr, "opened all inputs\n"));
            opened_all = 1;
            break;
          case -1:
            /* unexpected error opening a file */
            appExit(EXIT_FAILURE);
          case -2:
            /* ran out of memory or file descriptors */
            PRINTDEBUG((stderr, "unable to open all inputs\n"));
            ++temp_file_count;
            break;
          case 0:
            if (count == MAX_TMP_FILES) {
                /* ran out of pointers for this run */
                PRINTDEBUG((stderr, "unable to open all inputs\n"));
                ++temp_file_count;
                break;
            }
            /* no other way that rv == 0 */
            abort();
          default:
            /* unexpected error */
            PRINTDEBUG((stderr, "got unexpected rv value = %d\n", rv));
            abort();
        }

        PRINTDEBUG((stderr, "count: %d\n", count));

        /* Read the first record from each file into the work buffer. */
        for (i = 0; i < count; i++) {
            has_data[i] = rwRead(rwios[i], (rwRec*)recs[i]);
            /* lookup data from plug-in */
            for (j = 0; j < key_num_fields; ++j) {
                key_field_t *key = &(key_fields[j]);
                key->kf_fxn(key->kf_fxn_id, &(recs[i][key->kf_offset]),
                            (rwRec*)recs[i]);
            }
        }

        /* assign an arbitary record as the lowest. */
        lowest = 0;

        while (1) {
            /* make certain 'lowest' record has data; if not assign a
             * new record arbitrarily as lowest. */
            if ( !has_data[lowest]) {
                for (lowest = 0; lowest < count; ++lowest) {
                    if (has_data[lowest]) {
                        break;
                    }
                }
                /* exit the inner-while() if all records for all
                 * opened files have been processed */
                if (lowest == count) {
                    break;
                }
            }

            /* Loop over each of the files */
            for (i = 0; i < count; i++) {
                /* If the file has not reached EOF yet and if the
                 * file's record is lower than the lowest... */
                if ((i != lowest)
                    && has_data[i]
                    && (rwrecCompare(recs[i], recs[lowest]) < 0))
                {
                    /* record the index of this file as having the
                     * lowest record */
                    lowest = i;
                }
            }

            /* write the lowest record */
            if (temp_file_count == 0) {
                /* if we are not using any temp files, write the
                 * record to the final destination */
                rv = rwWrite(out_rwios, (rwRec*)recs[lowest]);
                if (0 != rv) {
                    rwioPrintLastErr(out_rwios, rv, &skAppPrintErr);
                    if (RWIO_ERROR_IS_FATAL(rv)) {
                        appExit(EXIT_FAILURE);
                    }
                }
            } else {
                /* otherwise, write record to intermediate tmp file */
                if (fwrite(recs[lowest], node_size, 1, fp_intermediate) != 1) {
                    skAppPrintErr("Could not write to tmpfile %s",
                                  tempFileGetName(temp_idx));
                    appExit(EXIT_FAILURE);
                }
            }

            /* replace the record we just wrote */
            has_data[lowest] = rwRead(rwios[lowest], (rwRec*)recs[lowest]);
            /* lookup data from plug-in */
            for (j = 0; j < key_num_fields; ++j) {
                key_field_t *key = &(key_fields[j]);
                key->kf_fxn(key->kf_fxn_id, &(recs[lowest][key->kf_offset]),
                            (rwRec*)recs[lowest]);
            }
        }

        /* Close the input files that we processed this time. */
        for (i = 0; i < count; i++) {
            rwioDestroy(&rwios[i]);
        }

        /* Close the intermediate temp file. */
        if (fp_intermediate) {
            if (EOF == fclose(fp_intermediate)) {
                skAppPrintErr("Error closing file %s: %s",
                              tempFileGetName(temp_idx),
                              strerror(errno));
                appExit(EXIT_FAILURE);
            }
            fp_intermediate = NULL;
        }
    } while (!opened_all);

    /* If any temporary files were written, we now have to merge-sort
     * them */
    if (0 != temp_file_count) {
        mergeFiles(0, temp_file_count);
    }
}


/*
 *  sortRandom();
 *
 *    Don't make any assumptions about the input.  Store the input
 *    records in a large buffer, and sort those in-core records once
 *    all records are processed or the buffer is full.  If the buffer
 *    fills up, store the sorted records into temporary files.  Once
 *    all records are read, use mergeFiles() above to merge-sort the
 *    temporary files.
 *
 *    Exits the application if an error occurs.
 */
static void sortRandom(void)
{
    int temp_file_no = 0;
    rwIOStruct_t *input_rwios;      /* input stream */
    void *record_buffer = NULL;     /* Region of memory for records */
    uint8_t *cur_node = NULL;       /* Ptr into record_buffer */
    uint32_t buffer_max_recs;       /* buffer size (in number of records) */
    uint32_t record_count = 0;      /* Number of records read */
    double multiplier = 1.0;
    size_t i;
    int rv;

    /* Allocate the buffer: We'll try to allocate a really BIG
     * chunk...if that fails, reduce the chunk until we succeed. */
    buffer_max_recs = sort_buffer_size / node_size;
    while (1) {
        PRINTDEBUG((stderr, "buffer_max_recs = %d\n", buffer_max_recs));
        record_buffer = malloc(node_size * buffer_max_recs);
        if (record_buffer) {
            /* malloc was successful */
            break;
        } else if (buffer_max_recs < MIN_IN_CORE_RECORDS) {
            /* give up at this point */
            skAppPrintErr("Could not allocate space for %d records; abort",
                          MIN_IN_CORE_RECORDS);
            appExit(EXIT_FAILURE);
        } else {
            /* reduce it and try again */
            multiplier *= IN_CORE_REDUCE_RATIO;
            buffer_max_recs = (sort_buffer_size * multiplier) / node_size;
        }
    }

    /* open first file */
    rv = appNextInput(&input_rwios);
    if (rv) {
        appExit(EXIT_FAILURE);
    }

    record_count = 0;
    cur_node = record_buffer;
    while (input_rwios != NULL) {
        /* read record */
        if (rwRead(input_rwios, (rwRec*)cur_node) == 0) {
            /* end of file: close current and open next */
            rwioDestroy(&input_rwios);
            rv = appNextInput(&input_rwios);
            if (rv < 0) {
                appExit(EXIT_FAILURE);
            }
            continue;
        }

        /* lookup data from plug-in */
        for (i = 0; i < key_num_fields; ++i) {
            key_field_t *key = &(key_fields[i]);
            key->kf_fxn(key->kf_fxn_id, &(cur_node[key->kf_offset]),
                        (rwRec*)cur_node);
        }

        record_count++;
        cur_node += node_size;
        if (record_count == buffer_max_recs) {
            /* Sort */
            rwqsort(record_buffer, record_count, node_size, &rwrecCompare);

            /* Write to temp file */
            if (tempFileDumpRecords(temp_file_no++, record_buffer,
                                    node_size, record_count))
            {
                appExit(EXIT_FAILURE);
            }

            /* Reset record buffer to 'empty' */
            record_count = 0;
            cur_node = record_buffer;
        }
    }

    /* Sort (and maybe store) last batch of records */
    if (record_count > 0) {
        rwqsort(record_buffer, record_count, node_size, &rwrecCompare);

        if (temp_file_no > 0) {
            /* Write last batch to temp file */
            if (tempFileDumpRecords(temp_file_no++, record_buffer,
                                    node_size, record_count))
            {
                appExit(EXIT_FAILURE);
            }
        }
    }

    /* Generate the output */

    if (record_count == 0 && temp_file_no == 0) {
        /* No records were read at all; write the header to the output
         * file */
        rv = rwioWriteHeader(out_rwios);
        if (0 != rv) {
            rwioPrintLastErr(out_rwios, rv, &skAppPrintErr);
        }
    } else if (temp_file_no == 0) {
        /* No temp files written, just output batch of records */
        uint32_t c;

        PRINTDEBUG((stderr, "Writing %lu records to '%s'\n",
                    (unsigned long)record_count, rwGetFileName(out_rwios)));
        for (c = 0, cur_node = record_buffer;
             c < record_count;
             ++c, cur_node += node_size)
        {
            rv = rwWrite(out_rwios, (rwRec*)cur_node);
            if (0 != rv) {
                rwioPrintLastErr(out_rwios, rv, &skAppPrintErr);
                if (RWIO_ERROR_IS_FATAL(rv)) {
                    free(record_buffer);
                    appExit(EXIT_FAILURE);
                }
            }
        }
    } else {
        /* no longer have a need for the record buffer */
        free(record_buffer);
        record_buffer = NULL;

        /* now merge all the temp files */
        mergeFiles(0, temp_file_no - 1);
    }

    if (record_buffer) {
        free(record_buffer);
    }
}


int main(int argc, char **argv)
{
    int rv;

    appSetup(argc, argv);                 /* never returns on error */

    if (presorted_input) {
        sortPresorted();
    } else {
        sortRandom();
    }

    /* close the file */
    if ((rv = rwioClose(out_rwios))
        || (rv = rwioDestroy(&out_rwios)))
    {
        rwioPrintLastErr(out_rwios, rv, &skAppPrintErr);
        appExit(EXIT_FAILURE);
    }
    out_rwios = NULL;

    appExit(EXIT_SUCCESS);
    return 0; /* NOTREACHED */
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
