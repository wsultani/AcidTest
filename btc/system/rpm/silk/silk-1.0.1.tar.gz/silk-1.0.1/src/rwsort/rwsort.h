/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  rwsort reads SiLK Flow Records from the standard input or from
**  named files and sorts them on one or more user-specified fields.
**
**  A large buffer is allocated; we attempt to create a buffer of
**  MAX_IN_CORE_SIZE bytes, but back off if the allocation fails.
**
**  Records are read and stored in this buffer; if the input ends
**  before the buffer is filled, the records are sorted and printed to
**  standard out or to the named output file.
**
**  However, if the buffer fills before the input is completely read,
**  the records in the buffer are sorted and written to a temporary
**  file on disk; the buffer is cleared, and reading of the input
**  resumes, repeating the process as necessary until all records are
**  read or until we write MAX_TMP_FILES temporary files.  We then do
**  an N-way merge-sort on the temporary files, where N is either all
**  the files or the maximum number that we can open before running
**  out of descriptors (EMFILE).  If we hit EMFILE, we merge the N
**  files into a new temporary file, then add it to the list of files
**  to merge.
**
**  When the temporary files are written to the same volume (file
**  system) as the final output, the maximum disk usage will be
**  2-times the number of records read (times the size per record);
**  when different volumes are used, the disk space required for the
**  temporary files will be between 1 and 1.5 times the number of
**  records.
**
**  TO DO:
**
**    -- Should better handle the case where we reach the
**    MAX_TMP_FILES limit.
**
*/
#ifndef _RWSORT_H
#define _RWSORT_H

#include "silk.h"

RCSIDENTVAR(rcsID_RWSORT_H, "$SiLK: rwsort.h 10004 2008-01-04 23:08:59Z mthomas $");

#include "rwpack.h"
#include "utils.h"
#include "rwsortutils.h"


/* LOCAL DEFINES AND TYPEDEFS */

/*
 *  How large of a buffer to attempt to allocate; scale back if we
 *  cannot allocate this much space
 *
 *  Try to allocate almost 2GB of RAM.
 */
#define DEFAULT_SORT_BUFFER_SIZE   0x78000000

/*
 *  How quickly to back off when allocation fails.
 */
#define IN_CORE_REDUCE_RATIO  0.75

/*
 *  If we can't allocate space for at least this many records, give
 *  up.
 */
#define MIN_IN_CORE_RECORDS     1000

/*
 *  Max number of plug-ins supported
 */
#define APP_MAX_DYNLIBS 8

/*
 *  Maximum number of fields that can come from plugins.  Allow four
 *  per plug-in.
 */
#define MAX_PLUGIN_KEY_FIELDS  32

/*
 *  Maximum bytes allotted to a "node", which is the complete rwRec
 *  and the bytes required by all keys that can come from plug-ins.
 *  Allow 8 bytes per field, plus enough space for an rwRec.
 */
#define MAX_NODE_SIZE  (256 + SK_MAX_RECORD_SIZE)

/* function that plugins must supply */
typedef int (*sortf_t)(unsigned int, uint8_t *bin_val, const rwRec *);

/* for key fields that come from plug-ins, this struct will hold
 * information about a single field */
typedef struct key_field_st {
    /* the id of the column (from librw) that make up this key_field */
    uint32_t        kf_id;
    /* the byte-offset for this field */
    size_t          kf_offset;
    /* the byte-width of this field */
    size_t          kf_width;
    /* the function to call to fill in this field: used to convert a
     * member of an rwRec into a binary value. */
    sortf_t         kf_fxn;
    /* the field_id that must be passed to kf_fxn for this field */
    unsigned int    kf_fxn_id;
} key_field_t;



/* LOCAL VARIABLES */

/* number of fields to sort over; rwAsciiFieldMapParseFields() sets this */
extern uint32_t num_fields;

/* IDs of the fields to sort over; rwAsciiFieldMapParseFields() sets
 * it; values are from the rwrec_printable_fields_t enum and from
 * values that come from dynamic libraries. */
extern uint32_t *sort_fields;

/* the size of a "node".  Because the output from rwsort are SiLK
 * records, the node size includes the complete rwRec, plus any binary
 * fields that we get from plug-ins to use as the key.  This node_size
 * value may increase when we parse the --fields switch. */
extern uint32_t node_size;

/* the columns that make up the key that come from plug-ins */
extern key_field_t key_fields[MAX_PLUGIN_KEY_FIELDS];

/* the number of these key_fields */
extern size_t key_num_fields;

/* output stream */
extern rwIOStruct_t *out_rwios;

/* whether to treat the input files as already sorted */
extern int presorted_input;

/* maximum amount of RAM to attempt to allocate */
extern uint64_t sort_buffer_size;


void appExit(int status);                /* never returns */
void appSetup(int argc, char **argv);
int  appNextInput(rwIOStruct_t **rwios);

#endif /* _RWSORT_H */

/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
