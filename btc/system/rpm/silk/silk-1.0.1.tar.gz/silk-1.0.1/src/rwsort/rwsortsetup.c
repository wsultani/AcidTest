/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  rwsort reads SiLK Flow Records from the standard input or from
**  named files and sorts them on one or more user-specified fields.
**
**  A large buffer is allocated; we attempt to create a buffer of
**  MAX_IN_CORE_SIZE bytes, but back off if the allocation fails.
**
**  Records are read and stored in this buffer; if the input ends
**  before the buffer is filled, the records are sorted and printed to
**  standard out or to the named output file.
**
**  However, if the buffer fills before the input is completely read,
**  the records in the buffer are sorted and written to a temporary
**  file on disk; the buffer is cleared, and reading of the input
**  resumes, repeating the process as necessary until all records are
**  read or until we write MAX_TMP_FILES temporary files.  We then do
**  an N-way merge-sort on the temporary files, where N is either all
**  the files or the maximum number that we can open before running
**  out of descriptors (EMFILE).  If we hit EMFILE, we merge the N
**  files into a new temporary file, then add it to the list of files
**  to merge.
**
**  When the temporary files are written to the same volume (file
**  system) as the final output, the maximum disk usage will be
**  2-times the number of records read (times the size per record);
**  when different volumes are used, the disk space required for the
**  temporary files will be between 1 and 1.5 times the number of
**  records.
**
**  TO DO:
**
**    -- Should better handle the case where we reach the
**    MAX_TMP_FILES limit.
**
*/

#include "silk.h"

RCSIDENT("$SiLK: rwsortsetup.c 11018 2008-03-24 14:23:51Z mthomas $");

#include "rwsort.h"
#include "rwpack.h"
#include "utils.h"
#include "iochecks.h"
#include "skstringmap.h"
#include "sksite.h"
#include "dynlib.h"


/* LOCAL DEFINES AND TYPEDEFS */

/* where to send --help output */
#define USAGE_FH stdout

/* Internal interface to libdynlib */
typedef struct app_dynlib_st {
    /* the libdynlib object */
    dynlibInfoStruct   *dlisp;
    /* number of field just before this dynlib */
    unsigned int        offset;
    /* function to get output from dynlib */
    sortf_t             fxn;
} app_dynlib_t;



/* LOCAL VARIABLES */

/* available key fields; rwAsciiFieldMapAddDefaultFields() fills this */
static sk_stringmap_t *field_map = NULL;

/* the maximum ID in the field_names string-map */
static uint32_t max_field_id = 0;

/* input checker */
static iochecksInfoStruct_t *ioISP;

/* non-zero if we are shutting down due to a signal; controls whether
 * errors are printed in appTeardown(). */
static int g_caught_signal = 0;

/* the compression method to use when writing the file.
 * sksiteCompmethodOptionsRegister() will set this to the default or
 * to the value the user specifies. */
static sk_compmethod_t comp_method;

/* number of shared object plug-ins loaded */
static int app_dynlib_count;

/* pointer to each plug-in */
static app_dynlib_t app_dynlib_list[APP_MAX_DYNLIBS];

/* names of plug-ins to attempt to load at startup */
static const char *app_dynlib_names[] = {
    "addrtype.so",
    "ccfilter.so",
    "pmapfilter.so",
    NULL /* sentinel */
};


/* OPTIONS */

typedef enum {
    OPT_FIELDS,
    OPT_OUTPUT_PATH,
    OPT_INPUT_PIPE,
    OPT_DYNAMIC_LIB_VALUE,
    OPT_PRESORTED_INPUT,
    OPT_SORT_BUFFER_SIZE,
    OPT_TEMP_DIRECTORY
} appOptionsEnum;

static struct option appOptions[] = {
    {"fields",              REQUIRED_ARG, 0, OPT_FIELDS},
    {"output-path",         REQUIRED_ARG, 0, OPT_OUTPUT_PATH},
    {"input-pipe",          REQUIRED_ARG, 0, OPT_INPUT_PIPE},
    {OPT_DYNAMIC_LIBRARY,   REQUIRED_ARG, 0, OPT_DYNAMIC_LIB_VALUE},
    {"presorted-input",     NO_ARG,       0, OPT_PRESORTED_INPUT},
    {"sort-buffer-size",    REQUIRED_ARG, 0, OPT_SORT_BUFFER_SIZE},
    {"temp-directory",      REQUIRED_ARG, 0, OPT_TEMP_DIRECTORY},
    {0,0,0,0}               /* sentinel entry */
};

static const char *appHelp[] = {
    NULL, /* generated dynamically */
    ("Destination for sorted output (stdout|pipe).\n"
     "\tDefault is stdout if stdout is not a terminal"),
    ("Get input byte stream from pipe (stdin|pipe).\n"
     "\tDefault is stdin if no filenames are given on the command line"),
    "Use given dynamic library to add fields. Def. None",
    ("Assume input has been presorted using\n"
     "\trwsort invoked with the exact same --fields value. Def. No"),
    NULL, /* generated dynamically */
    NULL, /* generated dynamically */
    (char *)NULL
};



/* LOCAL FUNCTION PROTOTYPES */

static void appUsageLong(void);
static void appTeardown(void);
static int  appOptionsHandler(clientData cData, int opt_index, char *opt_arg);
static void appHandleSignal(int sig);
static int  parseFields(const char *fields_string);
static int  appAddDynlib(const char *dlpath, int warn_on_error);
static app_dynlib_t* fieldNum2Dynlib(uint32_t field_id);



/* FUNCTION DEFINITIONS */

/*
 *  appUsageLong();
 *
 *    Print complete usage information to USAGE_FH.  Pass this
 *    function to skOptionsSetUsageCallback(); skOptionsParse() will
 *    call this funciton and then exit the program when the --help
 *    option is given.
 */
static void appUsageLong(void)
{
#define USAGE_MSG                                                             \
    ("--fields=<FIELDS> [SWITCHES] [FILES]\n"                                 \
     "\tRead SiLK Flow records, sort them by the specified FIELD(S), and\n"   \
     "\twrite the records to the named output path or to the standard\n"      \
     "\toutput.  When no FILES are given on command line, flows are read\n"   \
     "\tfrom the standard input.\n")

    FILE *fh = USAGE_FH;
    int i, j;

    fprintf(fh, "%s %s", skAppName(), USAGE_MSG);
    fprintf(fh, "\nSWITCHES:\n");
    skOptionsDefaultUsage(fh);
    sksiteOptionsUsage(fh);

    for (i = 0; appOptions[i].name; i++ ) {
        fprintf(fh, "--%s %s. ", appOptions[i].name,
                SK_OPTION_HAS_ARG(appOptions[i]));
        switch (i) {
          case OPT_FIELDS:
            /* Dynamically build the help */
            fprintf(fh, "Field(s) to use as key:\n");
            rwAsciiFieldMapPrintUsage(fh, field_map);
            break;
          case OPT_SORT_BUFFER_SIZE:
            fprintf(fh,
                    ("Attempt to allocate this much memory for the sort\n"
                     "\tbuffer, in bytes."
                     "  Append k, m, g, for kilo-, mega-, giga-bytes,\n"
                     "\trespectively. Def. %" PRIu32 "\n"),
                    DEFAULT_SORT_BUFFER_SIZE);
            break;
          case OPT_TEMP_DIRECTORY:
            fprintf(fh,
                    ("Store temporary files in this directory while sorting.\n"
                     "\tDef. $" TMPDIR_ENVAR1 " or $" TMPDIR_ENVAR2));
#ifdef DEFAULT_TEMP_DIR
            fprintf(fh, " or %s", DEFAULT_TEMP_DIR);
#endif
            fprintf(fh, "\n");
            break;
          default:
            /* Simple help text from the appHelp array */
            assert(appHelp[i]);
            fprintf(fh, "%s\n", appHelp[i]);
            break;
        }
    }

    sksiteCompmethodOptionsUsage(fh);

    for (j = 0; j < app_dynlib_count; ++j) {
        dynlibOptionsUsage(app_dynlib_list[j].dlisp, fh);
    }

    fprintf(fh, "\nNOTE: The --fields switch is required.\n");
}


/*
 *  appTeardown()
 *
 *    Teardown all modules, close all files, and tidy up all
 *    application state.
 *
 *    This function is idempotent.
 */
static void appTeardown(void)
{
    static int teardownFlag = 0;
    int i;
    int rv;

    if (teardownFlag) {
        return;
    }
    teardownFlag = 1;

    iochecksTeardown(ioISP);

    /* close and destroy output */
    if (out_rwios) {
        rv = rwioDestroy(&out_rwios);
        if (rv && !g_caught_signal) {
            /* only print error when not in signal handler */
            rwioPrintLastErr(out_rwios, rv, &skAppPrintErr);
        }
        out_rwios = NULL;
    }

    /* remove any temporary files */
    tempFileRemoveAll();

    /* Dynamic library teardown */
    for (i = 0; i < app_dynlib_count; ++i) {
        dynlibTeardown(app_dynlib_list[i].dlisp);
        app_dynlib_list[i].dlisp = NULL;
    }
    app_dynlib_count = 0;

    /* free variables */
    if (sort_fields != NULL) {
        free(sort_fields);
    }
    if (field_map) {
        skStringMapDestroy(field_map);
    }

    skAppUnregister();
}


/*
 *  appExit(status)
 *
 *  Exit the application with the given status.
 */
void appExit(int status)
{
    appTeardown();
    exit(status);
}


/*
 *  appSetup(argc, argv);
 *
 *    Perform all the setup for this application include setting up
 *    required modules, parsing options, etc.  This function should be
 *    passed the same arguments that were passed into main().
 *
 *    Returns to the caller if all setup succeeds.  If anything fails,
 *    this function will cause the application to exit with a FAILURE
 *    exit status.
 */
void appSetup(int argc, char **argv)
{
    sk_file_header_t *hdr;
    int rv = RWIO_OK;
    int j;

    /* verify same number of options and help strings */
    assert((sizeof(appHelp)/sizeof(char *)) ==
           (sizeof(appOptions)/sizeof(struct option)));

#ifdef DEFAULT_TEMP_DIR
    assert(DEFAULT_TEMP_DIR != NULL);
#endif

    /* register the application */
    skAppRegister(argv[0]);
    skOptionsSetUsageCallback(&appUsageLong);

    /* Initialize variables */
    memset(key_fields, 0, sizeof(key_fields));

    /* register the options */
    if (skOptionsRegister(appOptions, &appOptionsHandler, NULL)
        || sksiteCompmethodOptionsRegister(&comp_method)
        || sksiteOptionsRegister(SK_SITE_FLAG_CONFIG_FILE))
    {
        skAppPrintErr("Unable to register options");
        appExit(EXIT_FAILURE);
    }

    /* allow for 0 input and 0 output pipes */
    ioISP = iochecksSetup(0, 0, argc, argv);

    /* initialize string-map of field identifiers: add default fields;
     * keep the millisecond fields so rwcut and rwsort take the same
     * switches; the seconds and milliseconds value map to the same
     * code. */
    if (rwAsciiFieldMapAddDefaultFields(&field_map)) {
        skAppPrintErr("Unable to setup fields stringmap");
        exit(EXIT_FAILURE);
    }
    max_field_id = RWREC_PRINTABLE_FIELD_COUNT - 1;

    /* add hard-coded dynamic libraries */
    for (j = 0; app_dynlib_names[j]; ++j) {
        appAddDynlib(app_dynlib_names[j], 0);
    }

    /* parse options */
    ioISP->firstFile = skOptionsParse(argc, argv);
    if (ioISP->firstFile < 0) {
        skAppUsage();           /* never returns */
    }

    /* try to load site config file; if it fails, we will not be able
     * to resolve flowtype and sensor from input file names */
    sksiteConfigure(0);

    /* Make sure the user specified at least one field */
    if (num_fields == 0) {
        skAppPrintErr("The sorting key (--%s switch) was not given",
                      appOptions[OPT_FIELDS].name);
        skAppUsage();           /* never returns */
    }

    /* verify that the temp directory is valid */
    if (tempFileCheckTempdir()) {
        appExit(EXIT_FAILURE);
    }

    /* Use STDIN as an input stream if it is not a TTY; make certain
     * we have some input and we are either reading from STDIN or
     * using files listed the command line, but not both. */
    if (iochecksAcceptFromStdin(ioISP) || iochecksInputs(ioISP, 0)) {
        skAppUsage();
    }

    /* Check for an output stream; or default to stdout  */
    if (out_rwios == NULL) {
        rv = rwioCreate(&out_rwios, "stdout", SK_IO_WRITE);
        if (rv) {
            rwioPrintLastErr(out_rwios, rv, NULL);
            appExit(EXIT_FAILURE);
        }
    }

    /* set the compmethod and command line invocation on the header */
    hdr = skStreamGetSilkHeader(out_rwios);
    if ((rv = skHeaderSetCompressionMethod(hdr, comp_method))
        || (skHeaderAddInvocation(hdr, 1, argc, argv)))
    {
        skAppPrintErr("Error setting header on %s: %s",
                      rwGetFileName(out_rwios), skHeaderStrerror(rv));
        appExit(EXIT_FAILURE);
    }

    /* open output */
    rv = rwioOpen(out_rwios);
    if (rv) {
        rwioPrintLastErr(out_rwios, rv, NULL);
        skAppPrintErr("Could not open output file.  Exiting.");
        appExit(EXIT_FAILURE);
    }

    if (atexit(appTeardown) < 0) {
        skAppPrintErr("Unable to register appTeardown() with atexit()");
        appTeardown();
        appExit(EXIT_FAILURE);
    }

    /* set signal handler to clean up temp files on SIGINT, SIGTERM, etc */
    if (appSetSignalHandler(&appHandleSignal)) {
        appExit(EXIT_FAILURE);
    }

    return;                       /* OK */
}


/*
 *  status = appOptionsHandler(cData, opt_index, opt_arg);
 *
 *    This function is passed to skOptionsRegister(); it will be called
 *    by skOptionsParse() for each user-specified switch that the
 *    application has registered; it should handle the switch as
 *    required---typically by setting global variables---and return 1
 *    if the switch processing failed or 0 if it succeeded.  Returning
 *    a non-zero from from the handler causes skOptionsParse() to return
 *    a negative value.
 *
 *    The clientData in 'cData' is typically ignored; 'opt_index' is
 *    the index number that was specified as the last value for each
 *    struct option in appOptions[]; 'opt_arg' is the user's argument
 *    to the switch for options that have a REQUIRED_ARG or an
 *    OPTIONAL_ARG.
 */
static int appOptionsHandler(
    clientData  UNUSED(cData),
    int         opt_index,
    char       *opt_arg)
{
    int rv;

    switch ((appOptionsEnum)opt_index) {
      case OPT_FIELDS:
        assert(opt_arg);
        if (parseFields(opt_arg)) {
            return 1;
        }
        break;

      case OPT_OUTPUT_PATH:
        /* check for switch given multiple times */
        if (out_rwios) {
            skAppPrintErr("Multiple output files: '%s' and '%s'",
                          rwGetFileName(out_rwios), opt_arg);
            rwioDestroy(&out_rwios);
            return 1;
        }
        rv = rwioCreate(&out_rwios, opt_arg, SK_IO_WRITE);
        if (rv) {
            rwioPrintLastErr(out_rwios, rv, NULL);
            return 1;
        }
        break;

      case OPT_INPUT_PIPE:
        assert(opt_arg);
        if (iochecksInputSource(ioISP, opt_arg)) {
            return 1;
        }
        break;

      case OPT_DYNAMIC_LIB_VALUE:
        /* dynamic library */
        if (appAddDynlib(opt_arg, 1)) {
            return 1;
        }
        break;

      case OPT_PRESORTED_INPUT:
        presorted_input = 1;
        break;

      case OPT_SORT_BUFFER_SIZE:
        rv = skStringParseHumanUint64(&sort_buffer_size, opt_arg,
                                      SK_HUMAN_NORMAL);
        if (rv) {
            skAppPrintErr("Invalid %s '%s': %s",
                          appOptions[opt_index].name, opt_arg,
                          skStringParseStrerror(rv));
            return 1;
        }
        if ((sort_buffer_size < MIN_IN_CORE_RECORDS * node_size)
            || (sort_buffer_size >= UINT32_MAX))
        {
            skAppPrintErr(("The --%s value must be between %" PRIu32
                           " and %" PRIu32),
                          appOptions[opt_index].name,
                          (MIN_IN_CORE_RECORDS * node_size), UINT32_MAX);
            return 1;
        }
        break;

      case OPT_TEMP_DIRECTORY:
        assert(opt_arg);
        tempFileSetTempdir(opt_arg);
        break;
    }

    return 0;                     /* OK */
}


/*
 *  appHandleSignal(signal_value)
 *
 *    Call appExit() to exit the program.  If signal_value is SIGPIPE,
 *    close cleanly; otherwise print a message that we've caught the
 *    signal and exit with EXIT_FAILURE.
 */
static void appHandleSignal(int sig)
{
    g_caught_signal = 1;

    if (sig == SIGPIPE) {
        /* we get SIGPIPE if something downstream, like rwcut, exits
         * early, so don't bother to print a warning, and exit
         * successfully */
        appExit(EXIT_SUCCESS);
    } else {
        skAppPrintErr("Caught signal..cleaning up and exiting");
        appExit(EXIT_FAILURE);
    }
}


/*
 *  status = parseFields(fields_string);
 *
 *    Parse the user's option for the --fields switch and fill in the
 *    global g_fields[].  Return 0 on success; 1 on failure.
 */
static int parseFields(const char *field_string)
{
    uint32_t i;

    /* have we been here before? */
    if (num_fields > 0) {
        skAppPrintErr("--%s switch provided multiple times",
                      appOptions[OPT_FIELDS].name);
        return 1;
    }

    /* verify user gave us input */
    if (field_string == NULL || field_string[0] == '\0') {
        skAppPrintErr("Missing a value for the --%s switch",
                      appOptions[OPT_FIELDS].name);
        return 1;
    }

    /* parse the input */
    if (rwAsciiFieldMapParseFields(&sort_fields, &num_fields, field_string,
                                   field_map, RW_ASCII_DUPES_ERROR))
    {
        /* library printed the error */
        return 1;
    }

    /* initialize any dynlibs; return error if initialization fails */
    for (i = 0; i < num_fields; ++i) {
        if (sort_fields[i] >=  RWREC_PRINTABLE_FIELD_COUNT) {
            /* field comes from a plug-in */
            app_dynlib_t *app_dl;
            key_field_t *key;

            /* field is from a plug-in */
            app_dl = fieldNum2Dynlib(sort_fields[i]);
            if (NULL == app_dl) {
                /* could not initialize the plug-in */
                return 1;
            }
            if (key_num_fields == MAX_PLUGIN_KEY_FIELDS) {
                skAppPrintErr("Too many fields specified %lu > %u max",
                              (unsigned long)key_num_fields,
                              MAX_PLUGIN_KEY_FIELDS);
                return 1;
            }

            key = &(key_fields[key_num_fields]);
            key->kf_fxn    = app_dl->fxn;
            key->kf_id     = sort_fields[i];
            key->kf_fxn_id = key->kf_id - app_dl->offset;
            key->kf_offset = node_size;
            key->kf_width  = (size_t)key->kf_fxn(key->kf_fxn_id, NULL, NULL);

            ++key_num_fields;
            node_size += key->kf_width;
            if (node_size > MAX_NODE_SIZE) {
                skAppPrintErr("Sort key is too large %lu bytes > %d max",
                              (unsigned long)node_size, MAX_NODE_SIZE);
                return 1;
            }
        }
    }

    return 0;
}


/*
 *  appAddDynlib(dlpath, warnOnError);
 *
 *    Load the dynamic library at 'dlpath', store its information in
 *    the global 'app_dynlib_list', and increment the global
 *    'app_dynlib_count'.  Return 0 on success.  Return 1 if the
 *    library cannot be loaded or if too many dynamic libraries have
 *    been loaded.
 */
static int appAddDynlib(const char *dlpath, int warn_on_error)
{
    dynlibInfoStruct *dlisp = NULL;
    sortf_t sortf;
    sk_stringmap_entry_t *entries = NULL;
    int i;
    uint32_t offset;
    int rv = 1; /* return value; assume error */

    /* fields from the plug-in are added above this value.  All fields
     * from the plug-in must have an ID > 0. */
    offset = max_field_id;

    /* too many plug-ins? */
    if (app_dynlib_count == APP_MAX_DYNLIBS) {
        skAppPrintErr("Too many dynlibs.  Only %u allowed",
                      APP_MAX_DYNLIBS);
        goto END;
    }

    /* load plug-in */
    dlisp = dynlibCreate(DYNLIB_SORT);
    if (dynlibLoad(dlisp, dlpath)) {
        /* failed to find library, missing symbols, or setup failed */
        if (warn_on_error) {
            skAppPrintErr("Error loading dynamic library '%s': %s",
                          dlpath, dynlibLastError(dlisp));
        }
        goto END;
    }
    sortf = (sortf_t)dynlibGetRWProcessor(dlisp);
    /* dynlibCheck() should have made this check already */
    assert(sortf != NULL);

    /* get the fields for the application */
    if (dynlibConfigure(dlisp, (void*)(&entries)) != 0) {
        skAppPrintErr("Error getting fields from plug-in %s",
                      dynlibGetPath(dlisp));
        goto END;
    }
    if (entries == NULL) {
        /* We didn't get any fields from dynlibConfigure().  That's
         * the only way this application supports fields, so ignore
         * this dynlib. */
        if (warn_on_error) {
            skAppPrintErr(("Did not get fields from configure() method in\n"
                           "plug-in '%s'"),
                          dynlibGetPath(dlisp));
        }
        goto END;
    }

    /* the dynlibConfigure() routine gave us the fields */
    for (i = 0; entries[i].name; ++i) {
        /* check that value is not too small or too big */
        if (entries[i].id == 0) {
            skAppPrintErr("Invalid id '0' for field '%s' in %s plugin",
                          entries[i].name, dynlibGetPath(dlisp));
            goto END;
        }
        if (offset >= (UINT32_MAX - entries[i].id)) {
            skAppPrintErr("Invalid id '%u' for field '%s' in %s plugin",
                          entries[i].id, entries[i].name,
                          dynlibGetPath(dlisp));
            goto END;
        }

        /* add it */
        if (SKSTRINGMAP_OK != skStringMapAddID(field_map, entries[i].name,
                                               offset + entries[i].id))
        {
            skAppPrintErr("Cannot add entries to map");
            goto END;
        }
        /* keep track of the maximum field id */
        if (max_field_id < (offset + entries[i].id)) {
            max_field_id = offset + entries[i].id;
        }
    }

    /* success, add the dynamic library */
    app_dynlib_list[app_dynlib_count].dlisp  = dlisp;
    app_dynlib_list[app_dynlib_count].fxn    = sortf;
    app_dynlib_list[app_dynlib_count].offset = offset;
    ++app_dynlib_count;

    rv = 0;

  END:
    if ((rv != 0) && (dlisp != NULL)) {
        sk_link_err_t link_rv;
        sk_link_item_t *node;
        sk_stringmap_entry_t *entry;

        dynlibTeardown(dlisp);

        /* roll back the field_map to those whose IDs are <= offset */
        link_rv = skLinkGetHead(&node, field_map);
        while (link_rv == SKLINK_OK) {
            skLinkGetData((void**)&entry, node);
            link_rv = skLinkGetNext(&node, node);
            if (entry->id > offset) {
                /* remove the entry */
                skStringMapRemoveByName(field_map, entry->name);
            }
        }
        max_field_id = offset;
    }

    return rv;
}


/*
 *  fieldNum2Dynlib(field_id);
 *
 *    Given a field number 'field_id' from the global 'field_map',
 *    return a pointer to a app_dynlib_t from the app_dynlib_list[]
 *    that points to the dynamic library used to print the field_id
 *    field.  Initializes the dynamic library.
 *
 *    Return NULL if the field_id is not related to any dynamic
 *    library or if the initialization of dynamic library failed.
 */
static app_dynlib_t *fieldNum2Dynlib(uint32_t field_id)
{
    int j;
    app_dynlib_t *app_dl;

    if (!app_dynlib_count || (field_id <= app_dynlib_list[0].offset)) {
        return NULL;
    }

    for (j = 1; j < app_dynlib_count; ++j) {
        if (field_id <= app_dynlib_list[j].offset) {
            break;
        }
    }
    app_dl = &(app_dynlib_list[j-1]);

    /* since we will be using the dynamic library, initialize it */
    if (dynlibInitialize(app_dl->dlisp)) {
        /* did not find the field; go through a lot of trouble to
         * print an error message, then return */
        sk_vector_t *entries_vec;
        sk_stringmap_entry_t *entry = NULL;

        entries_vec = skVectorNew(sizeof(sk_stringmap_entry_t*));
        if (NULL == entries_vec) {
            skAppPrintErr(("Field not available--cannot initialize %s"),
                          dynlibGetPath(app_dl->dlisp));
            return NULL;
        }
        skStringMapGetNames(entries_vec, field_map, field_id);
        skVectorGetValue(&entry, entries_vec, 0);
        if (NULL != entry) {
            skAppPrintErr(("Field '%s' not available--cannot initialize %s"),
                          entry->name, dynlibGetPath(app_dl->dlisp));
        }
        skVectorClear(entries_vec);
        return NULL;
    }

    return app_dl;
}


/*
 *  int = appNextInput(&rwios);
 *
 *    Fill 'rwios' with the next input file to read.  Return 0 if
 *    'rwios' was successfully opened or 1 if there are no more input
 *    files.
 *
 *    When an input file cannot be opened, the return value is
 *    dependent on the error.  If the error is due to being out of
 *    file handles or memory (EMFILE or ENOMEM), return -2; otherwise
 *    return -1.
 */
int appNextInput(rwIOStruct_t **rwios)
{
    static int counter = -1;
    int rv;

    if (counter < 0) {
        counter = ioISP->firstFile;
    } else {
        ++counter;
        if (counter == ioISP->fileCount) {
            /* no more input */
            return 1;
        }
    }

    /* create rwios and open file */
    errno = 0;
    if ((rv = rwioCreate(rwios, ioISP->fnArray[counter], SK_IO_READ))
        || (rv = rwioOpen(*rwios)))
    {
        if (errno == EMFILE || errno == ENOMEM) {
            /* decrement counter so we try to open this file again */
            --counter;
            rv = -2;
            PRINTDEBUG((stderr, "unable to open %s because of %s\n",
                        ioISP->fnArray[counter], strerror(errno)));
        } else {
            rwioPrintLastErr(*rwios, rv, &skAppPrintErr);
            rv = -1;
        }
        rwioDestroy(rwios);
        return rv;
    }

    skStreamSetCopyInput(*rwios, ioISP->inputCopyFD);

    return 0;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
