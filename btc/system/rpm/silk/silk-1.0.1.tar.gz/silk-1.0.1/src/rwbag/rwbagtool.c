/*
** Copyright (C) 2004-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**    rwbagtool performs various operations on bags.  It can add bags
**    together, subtract a subset of data from a bag, perform key
**    intersection with an IP set, extract the key list of a bag as an
**    IP set, or filter bag records based on their counter value.
**
*/


#include "silk.h"

RCSIDENT("$SiLK: rwbagtool.c 11324 2008-04-21 19:03:44Z mthomas $");

#include "utils.h"
#include "bagtree.h"
#include "iptree.h"
#include "sksite.h"


/* LOCAL DEFINES AND TYPEDEFS */

/* where to write --help output */
#define USAGE_FH stdout

/* What to do when malloc() fails */
#define EXIT_NO_MEMORY                                               \
    do {                                                             \
        skAppPrintErr("Out of memory at %s:%d", __FILE__, __LINE__); \
        exit(EXIT_FAILURE);                                          \
    } while(0)

/* the IDs for options.  we need this early */
typedef enum {
    OPT_ADD,
    OPT_INTERSECT,
    OPT_COMPLEMENT,
    OPT_DIVIDE,
    OPT_SUBTRACT,
    OPT_COVER_SET,
    OPT_INVERT,
    OPT_MINCOUNTER,
    OPT_MAXCOUNTER,
    OPT_MINKEY,
    OPT_MAXKEY,
    OPT_OUTPUT_PATH,
    OPT_OUTPUT_FILE
} appOptionsEnum;


/* LOCAL VARIABLES */

/* the output bag that we create */
static skBag_t *out_bag = NULL;

/* where to write the resulting bag */
static skstream_t *out_stream = NULL;

/* What action the user wants to take (add, intersect, etc).  The
 * variable 'user_action' should be a value between OPT_ADD and
 * OPT_COVER_SET.  Set 'user_action_none' to a value outside that
 * range; this denotes that the user did not choose a value.
 */
static const appOptionsEnum user_action_none = OPT_OUTPUT_PATH;
static appOptionsEnum user_action;

/* When writing the new bag, only output entries whose keys and/or
 * whose values lie between these limits.  Initialize these to their
 * opposites to know when they have been set by the user. */
static skBagCounter_t mincounter = SKBAG_COUNTER_MAX;
static skBagCounter_t maxcounter = SKBAG_COUNTER_MIN;

static skBagKey_t minkey = SKBAG_KEY_MAX;
static skBagKey_t maxkey = SKBAG_KEY_MIN;


 /* Index of current file argument in argv */
static int arg_index = 0;

/* the compression method to use when writing the file.
 * sksiteCompmethodOptionsRegister() will set this to the default or
 * to the value the user specifies. */
static sk_compmethod_t comp_method;

/* Set to use for intersect and complement intersect */
static skIPTree_t *mask_set = NULL;

/* whether the --note-strip flag was specified */
static int note_strip = 0;

/* The file from which to read that set */
static char *mask_set_path = NULL;


/* OPTIONS SETUP */

static struct option appOptions[] = {
    {"add",                  NO_ARG,       0, OPT_ADD},
    {"intersect",            REQUIRED_ARG, 0, OPT_INTERSECT},
    {"complement-intersect", REQUIRED_ARG, 0, OPT_COMPLEMENT},
    {"divide",               NO_ARG,       0, OPT_DIVIDE},
    {"subtract",             NO_ARG,       0, OPT_SUBTRACT},
    {"coverset",             NO_ARG,       0, OPT_COVER_SET},
    {"invert",               NO_ARG,       0, OPT_INVERT},
    {"mincounter",           REQUIRED_ARG, 0, OPT_MINCOUNTER},
    {"maxcounter",           REQUIRED_ARG, 0, OPT_MAXCOUNTER},
    {"minkey",               REQUIRED_ARG, 0, OPT_MINKEY},
    {"maxkey",               REQUIRED_ARG, 0, OPT_MAXKEY},
    {"output-path",          REQUIRED_ARG, 0, OPT_OUTPUT_PATH},
    {"output-file",          REQUIRED_ARG, 0, OPT_OUTPUT_FILE},
    {0,0,0,0}                /* sentinel entry */
};

static const char *appHelp[] = {
    "Add all bag files read from stdin and the command line",
    "Masks keys in bag file using IPs in given SET file",
    ("Masks keys in bag file using IPs NOT\n"
     "\tin given SET file"),
    "Divide the first bag by all subsequent bags",
    "Subtract from first bag file all subsequent bag files",
    "Extract the IPs from the bag file into a set file",
    "Count keys for each unique counter value",
    ("Output records whose counter is at least VALUE, an\n"
     "\tinteger.  Def. 1"),
    ("Output records whose counter is not more than VALUE, an\n"
     "\tinteger.  Def. 18446744073709551615"),
    ("Output records whose key is at least VALUE, an integer or an\n"
     "\tIP address.  Def. 0 or 0.0.0.0"),
    ("Output records whose key is not more than VALUE, an integer\n"
     "\tor an IP address. Def. 4294967295 or 255.255.255.255"),
    "Redirect output to specified file.",
    "Deprecated alias for --output-path",
    (char *)NULL
};

/* Allow --output to work as a shortcut */
static struct option outputOption[] = {
    {"output",               REQUIRED_ARG, 0, OPT_OUTPUT_PATH},
    {"outpu",                REQUIRED_ARG, 0, OPT_OUTPUT_PATH},
    {"outp",                 REQUIRED_ARG, 0, OPT_OUTPUT_PATH},
    {"out",                  REQUIRED_ARG, 0, OPT_OUTPUT_PATH},
    {"ou",                   REQUIRED_ARG, 0, OPT_OUTPUT_PATH},
    {"o",                    REQUIRED_ARG, 0, OPT_OUTPUT_PATH},
    {0,0,0,0}                /* sentinel entry */
};


/* LOCAL FUNCTION PROTOTYPES */

static void appUsageLong(void);
static void appTeardown(void);
static void appSetup(int argc, char **argv);
static int  appOptionsHandler(clientData cData, int opt_index, char *opt_arg);
static int  processBagDivide(skstream_t *stream);
static int  processBagSubtract(skstream_t *stream);
static int  writeOutput(void);


/* FUNCTION DEFINITIONS */

/*
 *  appUsageLong();
 *
 *    Print complete usage information to USAGE_FH.  Pass this
 *    function to skOptionsSetUsageCallback(); skOptionsParse() will
 *    call this funciton and then exit the program when the --help
 *    option is given.
 */
static void appUsageLong(void)
{
#define USAGE_MSG                                                          \
    ("[SWITCHES] BAG_FILE [BAG_FILES...]\n"                                \
     "\tPerform operations on bag files, creating a new bag file.\n"       \
     "\tRequires at least one bag file to be given on the command line\n"  \
     "\tor to be read from the standard input.  The resulting bag will\n"  \
     "\twill be written to the specified output file or to the standard\n" \
     "\toutput.\n")

    FILE *fh = USAGE_FH;

    skAppStandardUsage(fh, USAGE_MSG, appOptions, appHelp);
    skOptionsNotesUsage(fh);
    sksiteCompmethodOptionsUsage(fh);
}


/*
 *  appTeardown()
 *
 *    Teardown all modules, close all files, and tidy up all
 *    application state.
 *
 *    This function is idempotent.
 */
static void appTeardown(void)
{
    static int teardownFlag = 0;

    if (teardownFlag) {
        return;
    }
    teardownFlag = 1;

    /* free the output bag */
    if (out_bag) {
        skBagFree(out_bag);
    }
    if (out_stream) {
        skStreamDestroy(&out_stream);
    }

    if (mask_set) {
        skIPTreeDelete(&mask_set);
    }

    skAppUnregister();
}


/*
 *  appSetup(argc, argv);
 *
 *    Perform all the setup for this application include setting up
 *    required modules, parsing options, etc.  This function should be
 *    passed the same arguments that were passed into main().
 *
 *    Returns to the caller if all setup succeeds.  If anything fails,
 *    this function will cause the application to exit with a FAILURE
 *    exit status.
 */
static void appSetup(int argc, char **argv)
{
    int rv;

    /* verify same number of options and help strings */
    assert((sizeof(appHelp)/sizeof(char *)) ==
           (sizeof(appOptions)/sizeof(struct option)));

    /* register the application */
    skAppRegister(argv[0]);
    skOptionsSetUsageCallback(&appUsageLong);

    /* initialize globals */
    user_action = user_action_none;

    /* register the options */
    if (skOptionsRegister(appOptions, &appOptionsHandler, NULL)
        || skOptionsRegister(outputOption, &appOptionsHandler, NULL)
        || skOptionsNotesRegister(&note_strip)
        || sksiteCompmethodOptionsRegister(&comp_method))
    {
        skAppPrintErr("Unable to register options");
        exit(EXIT_FAILURE);
    }

    /* parse the options; returns the index into argv[] of the first
     * non-option or < 0 on error  May re-arrange argv[]. */
    arg_index = skOptionsParse(argc, argv);
    assert(arg_index <= argc);
    if (arg_index < 0) {
        /* options parsing should print error */
        skAppUsage();             /* never returns */
    }

    /* Make certain user selected some action to perform */
    if (user_action == user_action_none) {
        skAppPrintErr("One of --add, --subtract, --coverset, --intersect, "
                      "--divide, \n  --invert or --complement-intersect "
                      "must be specified.");
        skAppUsage();
    }

    /* set the minima and maxima */
    if (mincounter == SKBAG_COUNTER_MAX) {
        mincounter = SKBAG_COUNTER_MIN;
    }
    if (maxcounter == SKBAG_COUNTER_MIN) {
        maxcounter = SKBAG_COUNTER_MAX;
    }
    if (minkey == SKBAG_KEY_MAX) {
        minkey = SKBAG_KEY_MIN;
    }
    if (maxkey == SKBAG_KEY_MIN) {
        maxkey = SKBAG_KEY_MAX;
    }

    /* error if a minimum is greater than a maximum */
    if (mincounter > maxcounter) {
        skAppPrintErr(("Minimum counter greater than maximum: "
                       "%" PRIu64 " > %" PRIu64),
                      mincounter, maxcounter);
        exit(EXIT_FAILURE);
    }
    if (minkey > maxkey) {
        skAppPrintErr(("Minimum key greater than maximum: "
                       "%" PRIu32 " > %" PRIu32),
                      minkey, maxkey);
        exit(EXIT_FAILURE);
    }

    /* arg_index is looking at first file name to process.  We
     * require at least one bag file, either from stdin or from the
     * command line. */
    if ((arg_index == argc) && (FILEIsATty(stdin))) {
        skAppPrintErr("No input files on command line and"
                      " stdin is connected to a terminal");
        skAppUsage();
    }

    /* Set the default output location */
    if (out_stream == NULL) {
        if ((rv = skStreamCreate(&out_stream, SK_IO_WRITE, SK_CONTENT_SILK))
            || (rv = skStreamBind(out_stream, "stdout")))
        {
            skStreamPrintLastErr(out_stream, rv, &skAppPrintErr);
            skStreamDestroy(&out_stream);
            exit(EXIT_FAILURE);
        }
    }

    /* all arguments look good.  Set the atexit() handler */
    if (atexit(appTeardown) < 0) {
        skAppPrintErr("Unable to register appTeardown() with atexit()");
        appTeardown();
        exit(EXIT_FAILURE);
    }

    /* If action is intersect or complement intersect read the set
     * file */
    if (user_action == OPT_INTERSECT || user_action == OPT_COMPLEMENT) {
        if (skIPTreeLoad(&mask_set, mask_set_path)) {
            skAppPrintErr("Could not read %s IPset from file %s",
                          appOptions[user_action].name, mask_set_path);
            exit(EXIT_FAILURE);
        }
    }

    /* Open the output file */
    if ((rv = skStreamSetCompressionMethod(out_stream, comp_method))
        || (rv = skStreamOpen(out_stream)))
    {
        skStreamPrintLastErr(out_stream, rv, &skAppPrintErr);
        skStreamDestroy(&out_stream);
        exit(EXIT_FAILURE);
    }

    return;                     /* OK */
}


/*
 *  status = appOptionsHandler(cData, opt_index, opt_arg);
 *
 *    This function is passed to skOptionsRegister(); it will be called
 *    by skOptionsParse() for each user-specified switch that the
 *    application has registered; it should handle the switch as
 *    required---typically by setting global variables---and return 1
 *    if the switch processing failed or 0 if it succeeded.  Returning
 *    a non-zero from from the handler causes skOptionsParse() to return
 *    a negative value.
 *
 *    The clientData in 'cData' is typically ignored; 'opt_index' is
 *    the index number that was specified as the last value for each
 *    struct option in appOptions[]; 'opt_arg' is the user's argument
 *    to the switch for options that have a REQUIRED_ARG or an
 *    OPTIONAL_ARG.
 */
static int appOptionsHandler(
    clientData  UNUSED(cData),
    int         opt_index,
    char       *opt_arg)
{
    skipaddr_t ip;
    uint64_t val64;
    int rv;

    switch ((appOptionsEnum)opt_index) {
      case OPT_INTERSECT:
      case OPT_COMPLEMENT:
        mask_set_path = opt_arg;
        /* FALLTHROUGH */

      case OPT_ADD:
      case OPT_DIVIDE:
      case OPT_SUBTRACT:
      case OPT_COVER_SET:
      case OPT_INVERT:
        if (user_action != user_action_none) {
            skAppPrintErr("Switches --%s and --%s are incompatible",
                          appOptions[opt_index].name,
                          appOptions[user_action].name);
            return 1;
        }
        user_action = (appOptionsEnum)opt_index;
        break;

      case OPT_MINCOUNTER:
        rv = skStringParseUint64(&val64, opt_arg, 1, 0);
        if (rv) {
            goto PARSE_ERROR;
        }
        mincounter = (skBagCounter_t)val64;
        break;

      case OPT_MAXCOUNTER:
        rv = skStringParseUint64(&val64, opt_arg, 1, 0);
        if (rv) {
            goto PARSE_ERROR;
        }
        maxcounter = (skBagCounter_t)val64;
        break;

      case OPT_MINKEY:
        rv = skStringParseIP(&ip, opt_arg);
        if (rv) {
            goto PARSE_ERROR;
        }
#if SK_ENABLE_IPV6
        if (skipaddrIsV6(&ip)) {
            skAppPrintErr("Invalid %s '%s': IPv6 addresses not supported",
                          appOptions[opt_index].name, opt_arg);
            return 1;
        }
#endif /* SK_ENABLE_IPV6 */
        minkey = (skBagKey_t)skipaddrGetV4(&ip);
        break;

      case OPT_MAXKEY:
        rv = skStringParseIP(&ip, opt_arg);
        if (rv) {
            goto PARSE_ERROR;
        }
#if SK_ENABLE_IPV6
        if (skipaddrIsV6(&ip)) {
            skAppPrintErr("Invalid %s '%s': IPv6 addresses not supported",
                          appOptions[opt_index].name, opt_arg);
            return 1;
        }
#endif /* SK_ENABLE_IPV6 */
        maxkey = (skBagKey_t)skipaddrGetV4(&ip);
        break;

      case OPT_OUTPUT_PATH:
      case OPT_OUTPUT_FILE:
        if (out_stream) {
            skAppPrintErr("The --%s switch was given multiple times",
                          appOptions[opt_index].name);
            return 1;
        }
        if ((rv = skStreamCreate(&out_stream, SK_IO_WRITE, SK_CONTENT_SILK))
            || (rv = skStreamBind(out_stream, opt_arg)))
        {
            skStreamPrintLastErr(out_stream, rv, &skAppPrintErr);
            skStreamDestroy(&out_stream);
            return 1;
        }
        break;
    }

    return 0;                   /* OK */

  PARSE_ERROR:
    skAppPrintErr("Invalid %s '%s': %s",
                  appOptions[opt_index].name, opt_arg,
                  skStringParseStrerror(rv));
    return 1;
}


/*
 *  ok = processBagDivide(pathname);
 *
 *    Divide the values in the global 'output_bagfile' by the values
 *    found in the bag stored in 'pathname'.  The keys of the two bags
 *    must match exactly.  Return 0 on success; non-zero otherwise.
 */
static int processBagDivide(skstream_t *stream)
{
    skBag_t *in_bag;
    skBagIterator_t *divisor_iter = NULL;
    skBagIterator_t *dividend_iter = NULL;
    skBagErr_t rv_dividend_bag;
    skBagErr_t rv_divisor_bag;

    skBagKey_t dividend_key;
    skBagKey_t divisor_key;

    skBagCounter_t dividend_counter;
    skBagCounter_t divisor_counter;
    skBagCounter_t result_counter;

    skBagErr_t rv_bag;

    /* read the bag containing the divisors */
    rv_bag = skBagRead(&in_bag, stream);
    if (rv_bag != SKBAG_OK) {
        skAppPrintErr("Could not read Bag from '%s': %s",
                      skStreamGetPathname(stream), skBagStrerror(rv_bag));
        return 1;
    }

    /* Create an iterator to loop over the divisor bag */
    rv_bag = skBagAllocIterator(in_bag, &divisor_iter);
    if (rv_bag != SKBAG_OK) {
        divisor_iter = NULL;
        goto END;
    }

    /* Create an iterator to loop over the dividend bag */
    rv_bag = skBagAllocIterator(out_bag, &dividend_iter);
    if (rv_bag != SKBAG_OK) {
        dividend_iter = NULL;
        goto END;
    }

    do {
        rv_dividend_bag = skBagGetNext(dividend_iter, &dividend_key,
                                       &dividend_counter);

        rv_divisor_bag = skBagGetNext(divisor_iter, &divisor_key,
                                      &divisor_counter);

        if (rv_dividend_bag != SKBAG_OK || rv_divisor_bag != SKBAG_OK) {
            goto END;
        }

        if (dividend_key != divisor_key) {
            skAppPrintErr("Error dividing bags.  The keys in the two "
                          "bags do not match.");
            goto END;
        }

        if (dividend_counter < divisor_counter) {
            skAppPrintErr("Error dividing bags.  A divisor counter "
                          "is larger than a\n  dividend counter.");
            goto END;
        }

        result_counter = dividend_counter / divisor_counter;

        rv_bag = skBagSetCounter(out_bag, &dividend_key,
                                 &result_counter);
        if (rv_bag != SKBAG_OK) {
            skAppPrintErr("Unexpected error while setting counter after "
                          "division: %s", skBagStrerror(rv_bag));
            goto END;
        }

    } while (rv_dividend_bag == SKBAG_OK &&
             rv_divisor_bag == SKBAG_OK);

    /* We're either at the end of the bag or the getNext call failed */
    if (rv_dividend_bag == SKBAG_ERR_KEY_NOT_FOUND &&
        rv_divisor_bag == SKBAG_ERR_KEY_NOT_FOUND)
    {
        /* expected behavior: reached end of both bags at same time.
         * set rv_bag to SKBAG_OK */
        rv_bag = SKBAG_OK;
    } else if ((rv_dividend_bag == SKBAG_ERR_KEY_NOT_FOUND
                && rv_divisor_bag == SKBAG_OK)
               || (rv_dividend_bag == SKBAG_OK
                   && rv_divisor_bag == SKBAG_ERR_KEY_NOT_FOUND))
    {
        /* one bag terminated before the other */
        skAppPrintErr("Error dividing bags.  The keys in the two "
                      "bags do not match.");
        rv_bag = SKBAG_ERR_OP_BOUNDS;
    } else {
        if (rv_dividend_bag != SKBAG_OK) {
            skAppPrintErr("Error iterating over dividend bag: %s",
                          skBagStrerror(rv_dividend_bag));
            rv_bag = rv_dividend_bag;
        }

        if (rv_divisor_bag != SKBAG_OK) {
            skAppPrintErr("Error iterating over divisor bag: %s",
                          skBagStrerror(rv_divisor_bag));
            rv_bag = rv_divisor_bag;
        }
    }

  END:
    if (dividend_iter) {
        skBagFreeIterator(dividend_iter);
    }
    if (divisor_iter) {
        skBagFreeIterator(divisor_iter);
    }

    /* Blow the bag away. We're done with it */
    skBagFree(in_bag);

    return ((rv_bag == SKBAG_OK) ? 0 : -1);
}


/*
 *  ok = processBagSubtract(pathname);
 *
 *    Subtract the values found in the bag stored in 'pathname' from
 *    the values in the global 'output_bagfile'.  The keys of the two
 *    bags must match exactly.  Return 0 on success; non-zero
 *    otherwise.
 */
static int processBagSubtract(skstream_t *stream)
{
    skBag_t *in_bag;
    skBagIterator_t *iter = NULL;
    skBagKey_t key;
    skBagCounter_t counter;
    skBagErr_t rv_bag = SKBAG_OK;

    rv_bag = skBagRead(&in_bag, stream);
    if (rv_bag != SKBAG_OK) {
        skAppPrintErr("Could not read Bag from '%s': %s",
                      skStreamGetPathname(stream), skBagStrerror(rv_bag));
        return 1;
    }

    /* Create an iterator to loop over the bag */
    rv_bag = skBagAllocIterator(in_bag, &iter);
    if (rv_bag != SKBAG_OK) {
        goto END;
    }

    while (SKBAG_OK == (rv_bag = skBagGetNext(iter, &key, &counter))) {
        rv_bag = skBagSubtractFromCounter(out_bag, &key, &counter);
        if (rv_bag != SKBAG_OK) {
            if (rv_bag == SKBAG_ERR_OP_BOUNDS) {
                skAppPrintErr("Negative values in bag are not allowed;"
                              " key=%u", key);
            } else {
                skAppPrintErr("Error when subtracting from bag for key %u: %s",
                              key, skBagStrerror(rv_bag));
            }
            goto END;
        }
    }

    /* We're either at the end of the bag or the getNext call failed */
    if (rv_bag == SKBAG_ERR_KEY_NOT_FOUND) {
        /* expected behavior: reached end of bag.  reset rv_bag */
        rv_bag = SKBAG_OK;
    } else {
        /* unexpected error: print message and set rv to that error */
        skAppPrintErr("Error while iterating over bag: %s",
                      skBagStrerror(rv_bag));
    }

  END:
    if (iter) {
        skBagFreeIterator(iter);
    }
    /* Blow the bag away. We're done with it */
    skBagFree(in_bag);

    return ((rv_bag == SKBAG_OK) ? 0 : -1);
}


/*
 *  status = processBagInvert(bag);
 *
 *    Invert the Bag 'bag' in place.  Return 0 on success, or -1 on
 *    error.
 */
static int processBagInvert(skBag_t *bag)
{
    skBag_t *inv_bag = NULL;
    skBagIterator_t *iter;
    skBagKey_t key;
    skBagCounter_t counter;
    const skBagCounter_t zero_counter = 0;
    skBagErr_t rv_bag;
    int rv = -1;

    /* We can't actually invert the bag in place, so create a new
     * inverted bag.  Once we make a pass through the existing bag, we
     * make a pass over the inverted bag and set the values in the
     * original bag. */
    if (skBagCreate(&inv_bag) != SKBAG_OK) {
        goto END;
    }

    /* Run through the original bag */
    rv_bag = skBagAllocIterator(bag, &iter);
    if (rv_bag != SKBAG_OK) {
        goto END;
    }
    while ((rv_bag = skBagGetNext(iter, &key, &counter)) == SKBAG_OK) {
        /* remove this key from the bag--set its count to 0 */
        rv_bag = skBagSetCounter(bag, &key, &zero_counter);
        if (rv_bag != SKBAG_OK) {
            skAppPrintErr("Error when setting key %u in bag: %s",
                          key, skBagStrerror(rv_bag));
            goto END;
        }
        /* determine key to use in inverted bag, handing overflow */
        key = (skBagKey_t)((counter < UINT32_MAX) ? counter : UINT32_MAX);

        /* increment value in the inverted bag */
        rv_bag = skBagIncrCounter(inv_bag, &key);
        if (rv_bag != SKBAG_OK) {
            if (rv_bag == SKBAG_ERR_OP_BOUNDS) {
                skAppPrintErr("Overflow when inverting bag");
                goto END;
            }
            skAppPrintErr("Error when inverting bag: %s",
                          skBagStrerror(rv_bag));
            goto END;
        }

        skBagGetCounter(inv_bag, &key, &counter);
    }
    skBagFreeIterator(iter);

    /* Run through the inverted bag */
    rv_bag = skBagAllocIterator(inv_bag, &iter);
    if (rv_bag != SKBAG_OK) {
        goto END;
    }
    while ((rv_bag = skBagGetNext(iter, &key, &counter)) == SKBAG_OK) {
        rv_bag = skBagSetCounter(bag, &key, &counter);
        if (rv_bag != SKBAG_OK) {
            if (rv_bag == SKBAG_ERR_OP_BOUNDS) {
                skAppPrintErr("Overflow when inverting bag");
                goto END;
            }
            skAppPrintErr("Error when setting key %u in bag: %s",
                          key, skBagStrerror(rv_bag));
            goto END;
        }
    }
    skBagFreeIterator(iter);

    /* done */
    rv = 0;

  END:
    if (inv_bag) {
        skBagFree(inv_bag);
    }
    return rv;
}


/*
 *  status = processBagCoverSet(bag, &set);
 *
 *    Create an IPset at the location specified by '*set' and fill it
 *    with the keys in the Bag 'bag'.  Return 0 on success, or -1 on
 *    failure.
 */
static int processBagCoverSet(
    skBag_t        *bag,
    skIPTree_t    **set)
{
    skBagIterator_t *iter;
    skBagKey_t key;
    skBagCounter_t counter;
    skBagErr_t rv_bag;
    int rv = -1;

    assert(set);
    *set = NULL;

    /* Create the cover set */
    if (skIPTreeCreate(set)) {
        skAppPrintErr("Error creating cover set");
        goto END;
    }

    /* Run through the bag, adding items to the set */
    if (skBagAllocIterator(bag, &iter)) {
        goto END;
    }
    while ((rv_bag = skBagGetNext(iter, &key, &counter)) == SKBAG_OK) {
        skIPTreeAddAddress(*set, key);
    }
    if (rv_bag != SKBAG_ERR_KEY_NOT_FOUND) {
        /* unexpected error */
        skAppPrintErr("Error while interating over bag: %s",
                      skBagStrerror(rv_bag));
    }

    skBagFreeIterator(iter);

    /* done */
    rv = 0;

  END:
    if (rv != 0) {
        if (*set != NULL) {
            skIPTreeDelete(set);
        }
    }
    return rv;
}


/*
 *  ok = applyCutoffs(bag);
 *
 *    Run through the bag and zero out any entries not within range or
 *    which aren't in the masking set.  Return 0 on success, non-zero
 *    otherwise.
 *
 *    FIXME: We could do some of this during the insertion stage
 *    instead output to save ourselves some storage. This is not the
 *    most efficient implementation.
 */
static int applyCutoffs(skBag_t *bag)
{
    skBagIterator_t *iter = NULL;
    skBagKey_t key;
    skBagCounter_t counter;
    skBagErr_t rv_bag;

    /* Create an iterator to loop over the bag */
    rv_bag = skBagAllocIterator(bag, &iter);
    if (rv_bag != SKBAG_OK) {
        iter = NULL;
        goto END;
    }

    while ((rv_bag = skBagGetNext(iter, &key, &counter)) == SKBAG_OK) {
        if ((key < minkey)         || (key > maxkey)         ||
            (counter < mincounter) || (counter > maxcounter) ||
            ((user_action == OPT_INTERSECT) &&
             !skIPTreeCheckAddress(mask_set, key)) ||
            ((user_action == OPT_COMPLEMENT) &&
             skIPTreeCheckAddress(mask_set, key)))
        {
            counter = 0;
            rv_bag = skBagSetCounter(bag, &key, &counter);
            if (rv_bag != SKBAG_OK) {
                skAppPrintErr("Error setting key %u to zero in bag: %s",
                              key, skBagStrerror(rv_bag));
                goto END;
            }
        }
    }

    /* We're either at the end of the bag or the getNext call failed */
    if (rv_bag == SKBAG_ERR_KEY_NOT_FOUND) {
        /* expected behavior: reached end of bag.  reset rv_bag */
        rv_bag = SKBAG_OK;
    } else {
        /* unexpected error: print message and set rv to that error */
        skAppPrintErr("Error while interating over bag: %s",
                      skBagStrerror(rv_bag));
    }

  END:
    if (iter) {
        skBagFreeIterator(iter);
    }
    return ((rv_bag == SKBAG_OK) ? 0 : -1);
}


/*
 *  ok = writeOutput();
 *
 *    Generate the output as requested by the global 'user_action'
 *    variable.
 */
static int writeOutput(void)
{
    int rv;

    /* Remove anything that's not in range or not in the intersecting
     * set (or complement) as appropriate */
    applyCutoffs(out_bag);

    if (user_action == OPT_COVER_SET) {
        skIPTree_t *cover_set;

        if (processBagCoverSet(out_bag, &cover_set)) {
            return -1;
        }
        /* Write the set */
        if (skIPTreeWrite(cover_set, out_stream)) {
            skAppPrintErr("Error writing set file.");
            skIPTreeDelete(&cover_set);
            return -1;
        }
        skIPTreeDelete(&cover_set);
    } else {
        if (user_action == OPT_INVERT) {
            processBagInvert(out_bag);
        }

        /* add any notes (annotations) */
        rv = skOptionsNotesAddToStream(out_stream);
        if (rv) {
            skStreamPrintLastErr(out_stream, rv, &skAppPrintErr);
            return -1;
        }
        skOptionsNotesTeardown();

        if (SKBAG_OK != skBagWrite(out_bag, out_stream)) {
            skAppPrintErr("Error writing bag to output file '%s'",
                          skStreamGetPathname(out_stream));
            return -1;
        }
    }

    return 0;
}


/*
 *  ok = appNextInput(argc, argv, &stream);
 *
 *    Fill 'stream' with the the opened skStream object to next input
 *    file from the command line or the standard input if no files
 *    were given on the command line.
 *
 *    Return 1 if input is available, 0 if all input files have been
 *    processed, and -1 to indicate an error opening a file.
 */
static int appNextInput(
    int             argc,
    char          **argv,
    skstream_t    **stream)
{
    static int initialized = 0;
    const char *fname = NULL;
    sk_file_header_t *hdr = NULL;
    int rv;

    if (arg_index < argc) {
        /* get current file and prepare to get next */
        fname = argv[arg_index];
        ++arg_index;
    } else {
        if (initialized) {
            /* no more input */
            return 0;
        }
        /* input is from stdin */
        fname = "stdin";
    }

    initialized = 1;

    /* open the input stream */
    if ((rv = skStreamCreate(stream, SK_IO_READ, SK_CONTENT_SILK))
        || (rv = skStreamBind((*stream), fname))
        || (rv = skStreamOpen((*stream)))
        || (rv = skStreamReadSilkHeader((*stream), &hdr)))
    {
        skStreamPrintLastErr((*stream), rv, &skAppPrintErr);
        skStreamDestroy(stream);
        return -1;
    }

    /* copy notes (annotations) from the input files to the output file */
    if (!note_strip) {
        rv = skHeaderCopyEntries(skStreamGetSilkHeader(out_stream), hdr,
                                 SK_HENTRY_ANNOTATION_ID);
        if (rv) {
            skStreamPrintLastErr((*stream), rv, &skAppPrintErr);
            skStreamDestroy(&(*stream));
            return -1;
        }
    }

    return 1;
}


int main(int argc, char **argv)
{
    skstream_t *in_stream;
    int rv;

    appSetup(argc, argv);                       /* never returns on error */

    /* Read the first bag; this will be the basis of the output bag. */
    if (appNextInput(argc, argv, &in_stream) != 1) {
        return 1;
    }
    rv = skBagRead(&out_bag, in_stream);
    if (rv != SKBAG_OK) {
        skAppPrintErr("Could not read Bag from '%s': %s",
                      skStreamGetPathname(in_stream), skBagStrerror(rv));
        skStreamDestroy(&in_stream);
        return 1;
    }
    skStreamDestroy(&in_stream);

    /* Open up each remaining bag and process it appropriately */
    while (1 == appNextInput(argc, argv, &in_stream)) {
        switch (user_action) {
          case OPT_COMPLEMENT:
          case OPT_INTERSECT:
          case OPT_ADD:
          case OPT_COVER_SET:
          case OPT_INVERT:
            /* All of these require us to add all the bags */
            rv = skBagAddFromStream(out_bag, in_stream);
            if (rv != SKBAG_OK) {
                skAppPrintErr("Error when adding bags: %s",
                              skBagStrerror(rv));
                skStreamDestroy(&in_stream);
                return 1;
            }
            break;

          case OPT_DIVIDE:
            if (processBagDivide(in_stream)) {
                skStreamDestroy(&in_stream);
                return 1;
            }
            break;

          case OPT_SUBTRACT:
            if (processBagSubtract(in_stream)) {
                skStreamDestroy(&in_stream);
                return 1;
            }
            break;

          default:
            /* Processing options not handled in this switch require a
             * single bag file */
            skAppPrintErr("Option %d not handled in switch() at %s:%d",
                          user_action, __FILE__, __LINE__);
            assert(0);
            abort();
        }

        skStreamDestroy(&in_stream);
    }

    /* Write the output */
    if (writeOutput()) {
        return 1;
    }

    /* done */
    appTeardown();

    return 0;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
