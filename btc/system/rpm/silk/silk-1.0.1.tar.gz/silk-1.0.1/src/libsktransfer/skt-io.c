/*
** Copyright (C) 2004-2007 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  Implements low level interruptable, timeoutable read and write
**  primitives
**
*/


#include "silk.h"

RCSIDENT("$SiLK: skt-io.c 7708 2007-06-28 20:31:44Z mthomas $");

#include "skt-private.h"

#ifdef SKT_DEBUG
struct timeval skt_hang;
struct timeval skt_exit;
#endif

/* Read a number of bytes into a buffer, with an optional timeout and
shutdown control. */
static ssize_t skread_base(
    int             fd,
    void           *vbuf,
    size_t          count,
    int            *control,
    struct timeval *timeout,
    sktErr_t       *err,
    uint8_t         immediate_interrupt)
{
    struct timeval ct, to;
    struct timeval dt = {0, 0};
    long tusec;
    fd_set set;
    int max;
    int rv;
    uint8_t c;
    ssize_t length = 0;
    ssize_t size;
    uint8_t *buf = (uint8_t *)vbuf;

    /* Setup initial error value */
    if (err) {
        *err = SK_TRANSFER_ESUCCESS;
    }

#ifdef SKT_DEBUG
    if (timeout == &skt_hang) {
        while (1) {
            pause();
        }
        exit(255);
    }
    if (timeout == &skt_exit) {
        exit(255);
    }
#endif

    /* Calculate at what time of day we should timeout */
    if (timeout) {
        if (gettimeofday(&ct, NULL) == -1) {
            if (err) {
                *err = SK_TRANSFER_ESYSTEM;
            }
            return -1;
        }

        /* Calculate absolute trigger time */
        tusec = ct.tv_usec + timeout->tv_usec;
        dt.tv_sec = ct.tv_sec + timeout->tv_sec + tusec / 1000000;
        dt.tv_usec = tusec % 1000000;
    }

    /* While we still have stuff to read... */
    while (count) {

        /* Reinitialize the fd sets.  If there is a shutdown control fd,
        there are two descriptors, otherwise there is one. */
        FD_ZERO(&set);
        FD_SET(fd, &set);
        if (control) {
            FD_SET(*control, &set);
            max = ((fd > *control) ? fd : *control) + 1;
        } else {
            max = fd + 1;
        }

        /* Get the current time and calculate how much time until the
        timeout should trigger. */
        if (timeout) {
            if (gettimeofday(&ct, NULL) == -1) {
                if (err) {
                    *err = SK_TRANSFER_ESYSTEM;
                }
                return -1;
            }

            /* Calculate the timeout based on the current time */
            tusec = dt.tv_usec - ct.tv_usec;
            to.tv_sec = dt.tv_sec - ct.tv_sec - ((tusec < 0) ? 1 : 0);
            to.tv_usec = (tusec < 0) ? 1000000 + tusec : tusec;

            if (to.tv_sec < 0) {
                /* Timeout */
                if (err) {
                    *err = SK_TRANSFER_ETIMEOUT;
                }
                return length;
            }
        }

        /* Wait for something to happen: either some data is ready on the
        fd, a timeout happens, or a message is sent over the shutdown
        fd. */
        rv = select(max, &set, NULL, NULL, (timeout ? &to : NULL));
        if (rv == -1) {
            /* Error */
            if (errno == EINTR) {
                /* Interrupted by a signal, try again. */
                continue;
            }
            if (err) {
                *err = SK_TRANSFER_ESYSTEM;
            }
            return -1;
        }
        if (rv == 0) {
            /* Timeout */
            if (err) {
                *err = SK_TRANSFER_ETIMEOUT;
            }
            return length;
        }

        /* If data is on the control channel, stop if it is an abort. */
        if (control && FD_ISSET(*control, &set)) {
          reread_control:
            if (read(*control, &c, 1) == -1) {
                if (errno == EINTR) {
                    /* Interrupted by a signal, try again. */
                    goto reread_control;
                }
                if (err) {
                    *err = SK_TRANSFER_ESYSTEM;
                }
                return -1;
            }
            if (c == SKT_NOTIFY_ABORT) {
                /* This tells us to abort if we aren't doing anything.
                Check to see if we are immediately interruptable. */
                if (!immediate_interrupt || length != 0) {
                    /* We already have a partial read, or we aren't
                    interuptable, so ignore and continue. */
                    continue;
                }
            } else {
                assert(c == SKT_ABORT);
            }
            if (err) {
                *err = SK_TRANSFER_ESHUTDOWN_EXTERNAL;
            }
            return length;
        }

        /* Actually read the data */
      reread:
        if ((size = read(fd, buf, count)) == -1) {
            if (errno == EINTR) {
                /* Interrupted by a signal, try again. */
                goto reread;
            }
            if (err) {
                switch (errno) {
                  case EBADF:
                  case EPIPE:
                  case ECONNRESET:
                  case ETIMEDOUT:
                    *err = SK_TRANSFER_EFAILED_CLOSE;
                    break;
                  default:
                    *err = SK_TRANSFER_ESYSTEM;
                    break;
                }
            }
            return -1;
        }
        if (size == 0) {
            if (err) {
                *err = SK_TRANSFER_EFAILED_CLOSE;
            }
            errno = EPIPE;
            return -1;
        }

        /* Adjust counts based on actual read data */
        length += size;
        count -= size;
        buf += size;
    }

    return length;
}


/* Non-waiting read */
ssize_t skread(
    int             fd,
    void           *vbuf,
    size_t          count,
    int            *control,
    struct timeval *timeout,
    sktErr_t       *err)
{
    return skread_base(fd, vbuf, count, control, timeout, err, 1);
}

/* Waiting read */
ssize_t skread_waiting(
    int             fd,
    void           *vbuf,
    size_t          count,
    int            *control,
    struct timeval *timeout,
    sktErr_t       *err)
{
    return skread_base(fd, vbuf, count, control, timeout, err, 0);
}


/* Write a number of bytes from a buffer, with an optional timeout and
 * shutdown control. */
ssize_t skwrite(
    int             fd,
    void           *vbuf,
    size_t          count,
    int            *control,
    struct timeval *timeout,
    sktErr_t       *err)
{
    struct timeval ct, to;
    struct timeval dt = {0, 0};
    long tusec;
    fd_set rset, wset;
    int max;
    int rv;
    uint8_t c;
    ssize_t length = 0;
    ssize_t size;
    uint8_t *buf = (uint8_t *)vbuf;

    /* Setup initial error value */
    if (err) {
        *err = SK_TRANSFER_ESUCCESS;
    }

#ifdef SKT_DEBUG
    if (timeout == &skt_hang) {
        while (1) {
            pause();
        }
    }
    if (timeout == &skt_exit) {
        exit(255);
    }
#endif

    /* Calculate at what time of day we should timeout */
    if (timeout) {
        if (gettimeofday(&ct, NULL) == -1) {
            if (err) {
                *err = SK_TRANSFER_ESYSTEM;
            }
            return -1;
        }
        tusec = ct.tv_usec + timeout->tv_usec;
        dt.tv_sec = ct.tv_sec + timeout->tv_sec + tusec / 1000000;
        dt.tv_usec = tusec % 1000000;
    }

    /* While we still have stuff to write... */
    while (count) {

        /* Reinitialize the fd sets.  If there is a shutdown control fd,
        there are two descriptors, otherwise there is one. */
        FD_ZERO(&wset);
        FD_SET(fd, &wset);
        if (control) {
            FD_ZERO(&rset);
            FD_SET(*control, &rset);
            max = ((fd > *control) ? fd : *control) + 1;
        } else {
            max = fd + 1;
        }

        /* Get the current time and calculate how much time until the
        timeout should trigger. */
        if (timeout) {
            if (gettimeofday(&ct, NULL) == -1) {
                if (err) {
                    *err = SK_TRANSFER_ESYSTEM;
                }
                return -1;
            }
            tusec = dt.tv_usec - ct.tv_usec;
            to.tv_sec = dt.tv_sec - ct.tv_sec - ((tusec < 0) ? 1 : 0);
            to.tv_usec = (tusec < 0) ? 1000000 + tusec : tusec;

            if (to.tv_sec < 0) {
                /* Timeout */
                if (err) {
                    *err = SK_TRANSFER_ETIMEOUT;
                }
                return length;
            }
        }

        /* Wait for something to happen: either the output fd is ready for
        more data, a timeout happens, or a message is sent over the
        shutdown fd. */
        rv = select(max, (control ? &rset : NULL), &wset, NULL,
                    (timeout ? &to : NULL));
        if (rv == -1) {
            /* Error */
            if (errno == EINTR) {
                /* Interrupted by a signal, try again. */
                continue;
            }
            if (err) {
                *err = SK_TRANSFER_ESYSTEM;
            }
            return -1;
        }
        if (rv == 0) {
            /* Timeout */
            if (err) {
                *err = SK_TRANSFER_ETIMEOUT;
            }
            return length;
        }

        /* If data is on the control channel, stop. */
        if (control && FD_ISSET(*control, &rset)) {
          reread_control:
            if (read(*control, &c, 1) == -1) {
                if (errno == EINTR) {
                    /* Interrupted by a signal, try again. */
                    goto reread_control;
                }
                if (err) {
                    *err = SK_TRANSFER_ESYSTEM;
                }
                return -1;
            }
            if (c == SKT_NOTIFY_ABORT) {
                continue;
            }
            assert(c == SKT_ABORT);
            if (err) {
                *err = SK_TRANSFER_ESHUTDOWN_EXTERNAL;
            }
            return length;
        }

        /* Actually write the data */
      rewrite:
        if ((size = write(fd, buf, count)) == -1) {
            if (errno == EINTR) {
                /* Interrupted by a signal, try again. */
                goto rewrite;
            }
            if (err) {
                switch (errno) {
                  case EBADF:
                  case EPIPE:
                  case ECONNRESET:
                  case ETIMEDOUT:
                    *err = SK_TRANSFER_EFAILED_CLOSE;
                    break;
                  default:
                    *err = SK_TRANSFER_ESYSTEM;
                    break;
                }
            }
            return -1;
        }

        /* Adjust counts based on actual written data */
        length += size;
        count -= size;
        buf += size;
    }

    return length;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
