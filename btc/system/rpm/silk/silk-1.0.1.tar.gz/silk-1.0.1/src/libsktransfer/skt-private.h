/*
** Copyright (C) 2004-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/
#ifndef _SKT_PRIVATE_H
#define _SKT_PRIVATE_H

#include "silk.h"

RCSIDENTVAR(rcsID_SKT_PRIVATE_H, "$SiLK: skt-private.h 10004 2008-01-04 23:08:59Z mthomas $");


/*
**  skt-private.h
**
**  Add your description here
**
**
**/
#ifdef DEBUG
#define SKT_DEBUG 1
#endif

#include "sktransfer.h"

#define SKT_DEFAULT_ACK 3
#define SKT_DEFAULT_BAUD 2400

#define SKT_NOTIFY_ABORT '\0'
#define SKT_ABORT        '\1'

typedef void (*cleanup_handler_t)(void *);
typedef void *(*thread_function_t)(void *);
typedef void *(*skt_thread_function_t)(skTransfer_t);
typedef sktErr_t (*skt_setup_function_t)(skTransfer_t);

typedef enum {
    SKT_NOT_STARTED = 0,
    SKT_RUNNING,
    SKT_ENDED
} sk_transfer_state_t;

typedef struct sk_transfer_server_st {
    int port;
    uint16_t num_valid_clients;
    in_addr_t *valid_clients;
    in_addr_t server;
    uint8_t maxclients;
} sk_transfer_server_t;

typedef struct sk_transfer_st {
    /* Which thread is it? */
    skt_thread_function_t thread_function;
    /* Thread handle */
    pthread_t thread_handle;

    /* Current transfer thread status */
    sk_transfer_state_t status;

    /* Socket current operations are acting upon. */
    int sock;

    /* Set to one if beginning a new session */
    unsigned int newsession : 1;
    /* This is the socket for the new session */
    int newsession_sock;

    skDeque_t queue;
    char *where;
    skt_filename_fn_t filename_function;
    skt_fn_xform_fn_t fn_xform_function;
    skt_callback_t callback;
    skt_callback_t subcallback;

    skt_setup_function_t setup;
    sk_transfer_server_t *server;

    pthread_mutex_t mutex;
    pthread_cond_t cond;

    /* thread end flag */
    uint8_t done;

    /* quit flag */
    uint8_t quit_control;

    /* control pipes */
    int read_pipe;
    int write_pipe;

    /* in seconds */
    uint8_t ack_timeout;

    /* in bits-per-second */
    uint32_t minimum_baud;

    pthread_mutex_t *notify_mutex;
    pthread_cond_t *notify_cond;

    skt_logfn_t logfn;
} sk_transfer_t;


#ifdef SKT_DEBUG
extern struct timeval skt_hang;
extern struct timeval skt_exit;
#endif

ssize_t skread(
    int             fd,
    void           *vbuf,
    size_t          count,
    int            *control,
    struct timeval *timeout,
    sktErr_t       *err);
ssize_t skread_waiting(
    int             fd,
    void           *vbuf,
    size_t          count,
    int            *control,
    struct timeval *timeout,
    sktErr_t       *err);
ssize_t skwrite(
    int             fd,
    void           *vbuf,
    size_t          count,
    int            *control,
    struct timeval *timeout,
    sktErr_t       *err);

sktErr_t skRcvFileBase(
    int                 sock,
    char               *where,
    skRcvInfo_t        *file,
    skt_logfn_t         logfn,
    int                *control,
    uint32_t            baud,
    skt_fn_xform_fn_t   fn_xform_function,
    uint8_t             acktimeout);
sktErr_t skSendFileBase(
    int             sock,
    char           *path,
    char           *name,
    skt_logfn_t     logfn,
    int            *control,
    uint32_t        baud,
    uint8_t         acktimeout);

sktErr_t skCreateTransfer(
    skTransfer_t           *transfer,
    skt_thread_function_t   thread_function,
    int                     sock,
    skDeque_t               queue,
    skt_filename_fn_t       filename_function,
    skt_fn_xform_fn_t       fn_xform_function,
    int                     ack_timeout,
    int                     minimum_baud,
    const char             *where,
    skt_setup_function_t    setup,
    skt_callback_t          callback,
    skt_callback_t          subcallback,
    sk_transfer_server_t   *server,
    pthread_mutex_t        *notify_mutex,
    pthread_cond_t         *notify_cond,
    skt_logfn_t             logfn);

void *receiver_thread(
    skTransfer_t transfer);
void *sender_thread(
    skTransfer_t transfer);
void sk_end_thread(
    skTransfer_t transfer);
void skt_filename_identity(
    void *queueObject,
    char *path,
    char *name);
void skt_filename_xform_identity(
    char *oldname,
    char *newname);

#endif /* _SKT_PRIVATE_H */

/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
