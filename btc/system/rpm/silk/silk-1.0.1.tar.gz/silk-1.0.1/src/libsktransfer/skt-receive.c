/*
** Copyright (C) 2003-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  Implements receiving low-level primitives
**
*/

#include "silk.h"

RCSIDENT("$SiLK: skt-receive.c 10004 2008-01-04 23:08:59Z mthomas $");

/* Absolute minimum possible baud rate */
#define MIN_BAUD 300

#include "skt-protocol.h"
#include "skt-private.h"
#include "sktransfer.h"


#ifdef TEST_PRINTF_FORMATS
#  define IF_LOGFN(f)   printf
#else
#  define IF_LOGFN(f)   if (! f) { } else f
#endif


typedef struct memmap_st {
    uint32_t size;
    uint8_t *t;
} memmap_t;


typedef struct timerinfo_st {
    int secs;
    pthread_t thread;
} timerinfo_t;


sktErr_t skRcvHandshake(int sock, skt_logfn_t logfn, int *control)
{
#define LOG IF_LOGFN(logfn)
    sk_transfer_header_prologue_t handshake;
    ssize_t rv;
    sktErr_t err;
    int saveerrno;


    /* Read a handshake */
    if ((rv = skread(sock, &handshake, sizeof(handshake),
                     control, NULL, &err)) != sizeof(handshake))
    {
        switch (err) {
          case SK_TRANSFER_ESYSTEM:
            saveerrno = errno;
            LOG("Failed read in handshake");
            errno = saveerrno;
            break;
          case SK_TRANSFER_ESHUTDOWN_EXTERNAL:
            LOG("Connection shut down");
            break;
          default:
            LOG("Connection died");
        }
        return err;
    }
    /* Check handshake version */
    if (handshake.version != SK_TRANSFER_PROTOCOL_V1) {
        LOG("Unknown protocol version %d", handshake.version);
        return SK_TRANSFER_EFAILED_CLOSE;
    }
    /* Check handshake type */
    if (handshake.type != SK_TRANSFER_HANDSHAKE) {
        LOG("Bad handshake");
        return SK_TRANSFER_EFAILED_CLOSE;
    }
    /* We currently do not handle checksums */
    if (handshake.cksum_type != SK_TRANSFER_NONE)
    {
        LOG("Checksum not handled (%d)", handshake.cksum_type);
        return SK_TRANSFER_EFAILED_CLOSE;
    }
    return SK_TRANSFER_ESUCCESS;
#undef LOG
}


/* Used to close file handles by a cleanup routine */
static void closeHandle(void *handle)
{
    if (*(int *)handle != -1) {
        close(*(int *)handle);
        *(int *)handle = -1;
    }
}


/* Used to unmap maps by a cleanup routine */
static void closeMap(void *handle)
{
    memmap_t *m = (memmap_t *)handle;
    if (m->t != NULL) {
        munmap(m->t, m->size);
        m->t = NULL;
    }
}

#ifdef SKT_DEBUG
#define SKT_DEBUG_TIMEOUT(x)                            \
    do {                                                \
        char *dbg = getenv("SKT_DEBUG_" x);             \
        if (dbg) {                                      \
            if (strcmp(dbg, "hang") == 0) {             \
                timeout = &skt_hang;                    \
            } else if (strcmp(dbg, "exit") == 0) {      \
                timeout = &skt_exit;                    \
            } else if (atoi(dbg) != 0) {                \
                struct timespec slp = {0, 0};           \
                slp.tv_sec = random() % atoi(dbg);      \
                nanosleep(&slp, NULL);                  \
            } else {                                    \
                timeout = &skt_exit;                    \
            }                                           \
        }                                               \
    } while (0)
#else
#define SKT_DEBUG_TIMEOUT(x)
#endif

sktErr_t skRcvFileBase(
    int                 sock,
    char               *where,
    skRcvInfo_t        *file,
    skt_logfn_t         logfn,
    int                *control,
    uint32_t            baud,
    skt_fn_xform_fn_t   fn_xform_function,
    uint8_t             acktimeout)
{
#define LOG IF_LOGFN(logfn)
    ssize_t rv;
    sk_transfer_header_prologue_t prologue;
    sk_transfer_file_info_t info;
    memmap_t map = {0, NULL};
    sktErr_t retval = SK_TRANSFER_ESUCCESS;
    unsigned char ack = SK_TRANSFER_ACK;
    int saveerrno;
    struct timeval to;
    struct timeval *timeout = NULL;
    char path[PATH_MAX];

    /* Check for valid args */
    if (file == NULL || where == NULL) {
        retval = SK_TRANSFER_EBADARG;
        goto reset;
    }

    file->fd = -1;

    pthread_cleanup_push(closeHandle, (void *)&file->fd);
    pthread_cleanup_push(closeMap, (void *)&map);

    /* Read the file prologue */
    SKT_DEBUG_TIMEOUT("READ_PROLOGUE");
    if ((rv = skread_waiting(sock, &prologue, sizeof(prologue),
                             control, timeout, &retval)) !=
        sizeof(prologue))
    {
        switch (retval) {
          case SK_TRANSFER_ESYSTEM:
            saveerrno = errno;
            LOG("Failed read in prologue");
            errno = saveerrno;
            break;
          case SK_TRANSFER_ESHUTDOWN_EXTERNAL:
            LOG("Connection shut down");
            break;
          default:
            LOG("Connection died");
        }
        goto reset;
    }
    /* Check the protocol version */
    if (prologue.version != SK_TRANSFER_PROTOCOL_V1) {
        LOG("Unknown protocol version %d", prologue.version);
        retval = SK_TRANSFER_EFAILED_CLOSE;
        goto reset;
    }
    /* Check for a shutdown request */
    if (prologue.type == SK_TRANSFER_SHUTDOWN) {
        retval = SK_TRANSFER_ESHUTDOWN;
        goto reset;
    }
    /* Check the prologue type */
    if (prologue.type != SK_TRANSFER_FILETRANSFER) {
        LOG("Bad prologue");
        retval = SK_TRANSFER_EFAILED_CLOSE;
        goto reset;
    }
    /* Read the file info */
    SKT_DEBUG_TIMEOUT("READ_FILE_INFO");
    if ((rv = skread(sock, &info, sizeof(info),
                     control, timeout, &retval) != sizeof(info)))
    {
        switch (retval) {
          case SK_TRANSFER_ESYSTEM:
            saveerrno = errno;
            LOG("Bad file information");
            errno = saveerrno;
            break;
          case SK_TRANSFER_ESHUTDOWN_EXTERNAL:
            LOG("Connection shut down");
            break;
          default:
            LOG("Connection died");
        }
        goto reset;
    }
    info.size = ntohl(info.size);
    /* Verify a zero-terminated filename */
    if (!memchr(info.name, 0, sizeof(info.name))) {
        LOG("file name overflow in file information");
        retval = SK_TRANSFER_EFATAL_CLOSE;
        goto reset;
    }
    snprintf(path, sizeof(path), "%s/%s", where, info.name);
    file->path[0] = '\0';
    file->fd = -1;
    fn_xform_function(path, file->path);
    if (file->path[0] == '\0') {
        retval = SK_TRANSFER_EFATAL_CLOSE;
        goto reset;
    }

    /* open the file */
    if ((file->fd = open(file->path,
                         O_CREAT | O_TRUNC | O_RDWR,
                         S_IRUSR | S_IWUSR)) == -1) {
        retval = SK_TRANSFER_EFATAL_CLOSE;
        goto reset;
    }

    /* Preallocate the file to get ready for an mmap */
    if (lseek(file->fd, info.size - 1, SEEK_SET) < 0) {
        LOG("unable to seek %ld bytes for %s", (long)info.size, file->path);
        file->fd = -1;
        retval = SK_TRANSFER_EFATAL_CLOSE;
        goto reset;
    }
    if (write(file->fd, "", 1) == -1) {
        LOG("unable to preallocate %ld bytes for %s",
            (long)info.size, file->path);
        file->fd = -1;
        retval = SK_TRANSFER_EFATAL_CLOSE;
        goto reset;
    }

    /* Map the file */
    map.t = (uint8_t *)mmap(0, info.size, PROT_WRITE | PROT_READ,
                            MAP_SHARED, file->fd, 0);
    if (map.t == MAP_FAILED) {
        LOG("unable to map %s into memory", file->path);
        close(file->fd);
        map.t = NULL;
        retval = SK_TRANSFER_EFATAL_CLOSE;
        goto reset;
    }
    map.size = info.size;

    /* Close the file */
    close(file->fd);
    file->fd = -1;

    /* Calculate the amount of time we should spend waiting */
    to.tv_sec = map.size / baud * 8 + 10;
    to.tv_usec = 0;
    timeout = &to;

    /* Read the file and (because it it an mmap) write it to disk. */
    SKT_DEBUG_TIMEOUT("READ_FILE");
    if ((size_t)(rv = skread(sock, map.t, map.size,
                             control, timeout, &retval)) != map.size)
    {
        switch (retval) {
          case SK_TRANSFER_ESYSTEM:
            saveerrno = errno;
            LOG("Failed read in file transfer");
            errno = saveerrno;
            break;
          case SK_TRANSFER_ETIMEOUT:
            LOG("Transfer timed out.");
            break;
          case SK_TRANSFER_ESHUTDOWN_EXTERNAL:
            LOG("Connection shut down");
            break;
          default:
            LOG("Connection died");
        }
        goto reset;
    }

    /* Unmap the map */
    munmap(map.t, map.size);
    map.t = NULL;

    if (acktimeout) {
        to.tv_sec = acktimeout;
        to.tv_usec = 0;
    }
    timeout = acktimeout ? &to : NULL;

    /* Send back an ACK. */
    SKT_DEBUG_TIMEOUT("WRITE_ACK");
    if (skwrite(sock, &ack, 1, control, timeout, &retval) != 1) {
        switch (retval) {
          case SK_TRANSFER_ESYSTEM:
            saveerrno = errno;
            LOG("Failed write ACK in file transfer");
            errno = saveerrno;
            break;
          case SK_TRANSFER_ESHUTDOWN_EXTERNAL:
            LOG("Connection shut down");
            break;
          default:
            LOG("couldn't write ACK for %s back", info.name);
        }
        goto reset;
    }

  reset:
    /* Cleanup */
    saveerrno = errno;
    pthread_cleanup_pop(1);     /* unmap map */
    pthread_cleanup_pop(1);     /* close file */
    errno = saveerrno;

    return retval;
#undef LOG
}


/* For backwards compatability */
static void skt_tmpnam_xform(char *name, char *newname)
{
    int fd;

    snprintf(newname, PATH_MAX, "%s.XXXXXX", name);
    newname[PATH_MAX - 1] = '\0';
    if ((fd = mkstemp(newname)) == -1) {
        skt_filename_xform_identity(name, newname);
    } else {
        close(fd);
    }
}


sktErr_t skRcvFile(
    int             sock,
    char           *where,
    skRcvInfo_t    *file,
    skt_logfn_t     logfn,
    int            *control)
{
    return skRcvFileBase(sock, where, file, logfn, control,
                         300 /* min bps */,
                         skt_tmpnam_xform,
                         SK_TRANSFER_ACKTIMEOUT /* ack timeout */);
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
