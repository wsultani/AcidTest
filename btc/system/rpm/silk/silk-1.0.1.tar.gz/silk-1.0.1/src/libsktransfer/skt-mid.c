/*
** Copyright (C) 2004-2007 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  Implements mid-level sender and receiver transfer objects
**
*/


#include "silk.h"

RCSIDENT("$SiLK: skt-mid.c 9194 2007-10-02 16:13:07Z mthomas $");

#include "skt-private.h"

/* Identity function for filename extraction */
void skt_filename_identity(void *queueObject, char *path, char *name)
{
    strncpy(path, (char *)queueObject, PATH_MAX);
    name[0] = '\0';
}

void skt_filename_xform_identity(char *oldname, char *newname)
{
    strncpy(newname, oldname, PATH_MAX);
}

/* We enter this function with the mutex locked.  We wait for it to
   become unlocked, then call the main function. */
static void *thread_init_wrapper(void *vtransfer)
{
    skTransfer_t transfer = (skTransfer_t)vtransfer;
    sigset_t sigs;

    sigfillset(&sigs);
    sigdelset(&sigs, SIGPIPE);
    pthread_sigmask(SIG_SETMASK, &sigs, NULL); /* Only handle SIGPIPE */

    pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, NULL);
    pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);

    /* Wait for mutex to become unlocked. */
    pthread_mutex_lock(&transfer->mutex);
    /* We now no longer need it to be locked.  Continue. */
    pthread_mutex_unlock(&transfer->mutex);

    return (transfer->thread_function(transfer));
}

/* Fills in a skTransfer_t struct and creates the main thread */
sktErr_t skCreateTransfer(
    skTransfer_t           *transfer,
    skt_thread_function_t   thread_function,
    int                     sock,
    skDeque_t               queue,
    skt_filename_fn_t       filename_function,
    skt_fn_xform_fn_t       fn_xform_function,
    int                     ack_timeout,
    int                     minimum_baud,
    const char             *where,
    skt_setup_function_t    setup,
    skt_callback_t          callback,
    skt_callback_t          subcallback,
    sk_transfer_server_t   *server,
    pthread_mutex_t        *notify_mutex,
    pthread_cond_t         *notify_cond,
    skt_logfn_t             logfn)
{
    skTransfer_t t;
    int fd[2];

    if (transfer == NULL || thread_function == NULL) {
        return SK_TRANSFER_EBADARG;
    }

    t = (skTransfer_t)malloc(sizeof(sk_transfer_t));
    if (t == NULL) {
        return SK_TRANSFER_ESYSTEM;
    }

    if ((pipe(fd)) == -1) {
        free(t);
        return SK_TRANSFER_ESYSTEM;
    }

    t->thread_function = thread_function;

    /* The idea here is to intialize the socket.  */
    t->newsession = 1;
    t->newsession_sock = sock;
    t->sock = -1;

    t->queue = queue;
    t->filename_function = filename_function;
    t->fn_xform_function = fn_xform_function;
    t->setup = setup;
    t->callback = callback;
    t->subcallback = subcallback;
    t->server = server;
    t->quit_control = 0;
    t->done = 0;
    t->read_pipe = fd[0];
    t->write_pipe = fd[1];
    t->ack_timeout = ack_timeout;
    t->minimum_baud = minimum_baud;
    t->where = where ? strdup(where) : NULL;
    t->notify_mutex = notify_mutex;
    t->notify_cond = notify_cond;
    t->logfn = logfn;
    t->status = SKT_NOT_STARTED;
    pthread_mutex_init(&t->mutex, NULL);
    pthread_cond_init(&t->cond, NULL);

    *transfer = t;
    return SK_TRANSFER_ESUCCESS;
}


sktErr_t skTransferStart(skTransfer_t transfer)
{
    if (transfer == NULL || transfer->thread_function == NULL ||
        transfer->status != SKT_NOT_STARTED) {
        return SK_TRANSFER_EBADARG;
    }

    if (skTransferIsSender(transfer) && transfer->queue == NULL) {
        return SK_TRANSFER_EBADARG;
    }

    /* Locking this mutex assures that t->thread_handle gets set before
       thread_function is executed. */
    pthread_mutex_lock(&transfer->mutex);

    if (pthread_create(&transfer->thread_handle, NULL,
                       thread_init_wrapper, transfer))
    {
        pthread_mutex_unlock(&transfer->mutex);
        return SK_TRANSFER_ESYSTEM_THREAD;
    }

    transfer->status = SKT_RUNNING;

    /* Unlocking this mutex allows thread_function to execute. */
    pthread_mutex_unlock(&transfer->mutex);

    return SK_TRANSFER_ESUCCESS;
}

/* Sender thread */
void *sender_thread(skTransfer_t transfer)
{
    void *obj;
    sktErr_t err;
    skDQErr_t qErr;
    char filepath[PATH_MAX];
    char filename[PATH_MAX];
    uint8_t stable = 1;

    if (transfer->quit_control == 0 && transfer->setup) {
        transfer->setup(transfer);
    }

    /* Send files */
    while (stable && transfer->quit_control == 0) {
        uint8_t change = 0;

        /* Change socket if requested */
        pthread_cleanup_push((cleanup_handler_t)pthread_mutex_unlock,
                             (void *)&transfer->mutex);
        pthread_mutex_lock(&transfer->mutex);
        if (transfer->newsession) {
            transfer->newsession = 0;
            transfer->sock = transfer->newsession_sock;
            change = 1;
        }
        pthread_cleanup_pop(1);
        if (change) {
            if (transfer->sock == -1) {
                if (transfer->callback) {
                    transfer->callback(NULL, NULL, SK_TRANSFER_EFAILED_CLOSE,
                                       transfer);
                }
            }

            /* Send a handshake */
            else if ((err = skSendHandshake(transfer->sock,
                                            transfer->logfn,
                                            &transfer->read_pipe))
                     != SK_TRANSFER_ESUCCESS)
            {
                if (transfer->callback) {
                    transfer->callback(NULL, NULL, err, transfer);
                }
                stable = 0;
            }
            continue;
        }

        /* Get a object to send */
        if ((qErr = skDequePopBack(transfer->queue, &obj)) != SKDQ_SUCCESS) {
            continue;
        }

        /* Get the path of the file to send */
        transfer->filename_function(obj, filepath, filename);
        if (filepath[0] == '\0') {
            if (transfer->logfn) {
                transfer->logfn("Transfer queue object contained "
                                "invalid filename");
                if (transfer->callback) {
                    transfer->callback(NULL, NULL, SK_TRANSFER_EBADARG,
                                       transfer);
                }
            }
            stable = 0;
            break;              /* Exits toplevel loop */
        }
        if (filename[0] == '\0') {
            char *slash = strrchr(filepath, '/');
            if (slash == NULL) {
                strncpy(filename, filepath, PATH_MAX);
            } else {
                strncpy(filename, slash + 1, PATH_MAX);
            }
        }

        /* Send the file */
        if ((err = skSendFileBase(transfer->sock, filepath, filename,
                                  transfer->logfn, &transfer->read_pipe,
                                  transfer->minimum_baud,
                                  transfer->ack_timeout))
            != SK_TRANSFER_ESUCCESS)
        {
            if (transfer->callback) {
                transfer->callback(filepath, obj, err, transfer);
            }
            if (transfer->newsession) {
                continue;
            }
            if (err != SK_TRANSFER_EFAILED && err != SK_TRANSFER_EFATAL) {
                stable = 0;
            }
            continue;                   /* To toplevel loop */
        }

        if (transfer->callback) {
            transfer->callback(filepath, obj, err, transfer);
        }
    }

    /* Send shutdown if in stable state */
    if (stable) {
        /* Send a shutdown */
        if ((err = skSendShutdown(transfer->sock, transfer->logfn,
                                  &transfer->read_pipe))
            != SK_TRANSFER_ESUCCESS) {
            if (transfer->callback) {
                transfer->callback(NULL, NULL, err, transfer);
            }
        }
    }

    sk_end_thread(transfer);

    return NULL;
}

/* receiver thread */
void *receiver_thread(skTransfer_t transfer)
{
    skRcvInfo_t file;
    char *filepath;
    skDQErr_t qErr;
    sktErr_t err;

    while (transfer->quit_control == 0) {
        uint8_t change = 0;

        /* Change socket if requested */
        pthread_cleanup_push((cleanup_handler_t)pthread_mutex_unlock,
                             (void *)&transfer->mutex);
        pthread_mutex_lock(&transfer->mutex);
        if (transfer->newsession) {
            transfer->newsession = 0;
            transfer->sock = transfer->newsession_sock;
            change = 1;
        }
        pthread_cleanup_pop(1);
        if (change) {
            if (transfer->sock == -1) {
                if (transfer->callback) {
                    transfer->callback(NULL, NULL, SK_TRANSFER_EFAILED_CLOSE,
                                       transfer);
                }
            }
            /* Receive a handshake */
            else {
                static int on = 1;

                if ((err = skRcvHandshake(transfer->sock,
                                          transfer->logfn,
                                          &transfer->read_pipe))
                    != SK_TRANSFER_ESUCCESS)
                {
                    if (transfer->callback) {
                        transfer->callback(NULL, NULL, err, transfer);
                    }
                } else {
                    /* Turn off the Nagle algorithm for receivers,
                       since it could impact ACK transfer.  (Actually,
                       further examination of the algorithm seems to
                       indicate that this would have little to no
                       effect, but it can't hurt anything, at least on
                       the receiver side. */

                    setsockopt(transfer->sock, IPPROTO_TCP, TCP_NODELAY,
                               &on, sizeof(on));
                }
            }
            continue;
        }

        file.path[0] = '\0';
        file.fd = -1;
        /* Receive the file */
        err = skRcvFileBase(transfer->sock, transfer->where, &file,
                            transfer->logfn, &transfer->read_pipe,
                            transfer->minimum_baud,
                            transfer->fn_xform_function,
                            transfer->ack_timeout);
        /* The skRcvFileBase function returns an open file handle.  It
           is still around for backward compatability, but we do not
           want it. */
        if (file.fd != -1) {
            close(file.fd);
        }
        filepath = file.path[0] ? strdup(file.path) : NULL;
        /* Add the file to the queue */
        if (filepath &&
            (transfer->queue &&
             (qErr =
              skDequePushFront(transfer->queue, filepath)) != SKDQ_SUCCESS))
        {
            if (transfer->callback) {
                transfer->callback(filepath, NULL, SK_TRANSFER_EBADARG,
                                   transfer);
            }
            break;                      /* Exits toplevel loop */
        }

        /* Call the callback function */
        if (transfer->callback) {
            transfer->callback(filepath, NULL, err, transfer);
        }

        /* Quit is the error was too bad */
        if (err != SK_TRANSFER_ESUCCESS &&
            err != SK_TRANSFER_EFAILED && err != SK_TRANSFER_EFATAL)
        {
            /* We get here in non-recoverable error conditions, or a
               standard shutdown. */
            if (transfer->newsession) {
                continue;
            }
            break;                      /* Exits toplevel loop */
        }
    }

    sk_end_thread(transfer);

    return NULL;
}

/* Change socket function */
sktErr_t skTransferChangeSock(skTransfer_t transfer, int sock)
{
    /* Only works on the mid-level functions */
    if (transfer == NULL || transfer->server) {
        return SK_TRANSFER_EBADARG;
    }

    pthread_cleanup_push((cleanup_handler_t)pthread_mutex_unlock,
                         (void *)&transfer->mutex);
    pthread_mutex_lock(&transfer->mutex);
    transfer->newsession = 1;
    transfer->newsession_sock = sock;
    pthread_cleanup_pop(1);
    return SK_TRANSFER_ESUCCESS;
}

/* create sender thread */
sktErr_t skCreateSender(
    skTransfer_t *sender,       /* returns sender handle */
    int sock                    /* Socket to create sender on */
    )
{
    return skCreateTransfer(sender, sender_thread, sock, NULL,
                            skt_filename_identity, NULL, SKT_DEFAULT_ACK,
                            SKT_DEFAULT_BAUD, NULL, NULL,
                            NULL, NULL, NULL, NULL,
                            NULL, NULL);
}

/* create receiver thread */
sktErr_t skCreateReceiver(
    skTransfer_t *receiver,     /* returns receiver handle */
    int sock,                   /* Socket to create receiver on */
    const char *where           /* Where to place files */
    )
{
    if (where == NULL) {
        return SK_TRANSFER_EBADARG;
    }

    return skCreateTransfer(receiver, receiver_thread, sock, NULL,
                            NULL, skt_filename_xform_identity,
                            SKT_DEFAULT_ACK, SKT_DEFAULT_BAUD, where,
                            NULL, NULL, NULL, NULL, NULL, NULL, NULL);
}

void sk_end_thread(skTransfer_t transfer)
{
    pthread_mutex_lock(&transfer->mutex);
    transfer->done = 1;
    transfer->status = SKT_ENDED;

    /* Notify skTransferStop that we have finished */
    pthread_cond_signal(&transfer->cond);

    /* Notify our parent transfer server (if any) that we have finished */
    if (transfer->notify_mutex && transfer->notify_cond) {
         pthread_mutex_lock(transfer->notify_mutex);
         pthread_cond_signal(transfer->notify_cond);
         pthread_mutex_unlock(transfer->notify_mutex);
    }

    pthread_mutex_unlock(&transfer->mutex);
}

sktErr_t skTransferStop(skTransfer_t transfer, uint32_t timeout)
{
    char c;
    struct timespec to;
    struct timeval now;
    int rv = 0;

    if (!transfer || transfer->status != SKT_RUNNING) {
        return SK_TRANSFER_EBADARG;
    }

    pthread_mutex_lock(&transfer->mutex);

    /* signal the thread to wake up and exit */
    transfer->quit_control = 1; /* Set quit request */
    if (transfer->queue) {
        skDequeUnblock(transfer->queue); /* Unblock the queue */
    }

    /* Wait for the thread to exit */
    gettimeofday(&now, NULL);
    to.tv_sec = now.tv_sec + timeout;
    to.tv_nsec = now.tv_usec * 1000;

    /* Let the thread know we are going to abort, so it can exit
       without waiting if it knows it isn't waiting for anything in
       particular. */
    c = SKT_NOTIFY_ABORT;
    write(transfer->write_pipe, &c, 1);

    /* Wait for the thread to exit. */
    while (!transfer->done && rv != ETIMEDOUT) {
        rv = pthread_cond_timedwait(&transfer->cond, &transfer->mutex, &to);
    }

    /* If the thread did not exit on its own, let's help it out. */
    if (!transfer->done) {

        /* Get it out of any blocking reads or writes */
        c = SKT_ABORT;
        write(transfer->write_pipe, &c, 1);
        /* Get it out of any waiting condition variables */
        pthread_cond_signal(&transfer->cond);

        gettimeofday(&now, NULL);
        to.tv_sec = now.tv_sec + 1;     /* 1 extra second to death */
        to.tv_nsec = now.tv_usec * 1000;
        while (!transfer->done && rv != ETIMEDOUT) {
            rv = pthread_cond_timedwait(&transfer->cond, &transfer->mutex,
                                        &to);
        }
        if (!transfer->done) {
            /* Even our extra 1 second wasn't enough.  Kill it. */
            transfer->done = 1;
            pthread_cancel(transfer->thread_handle);
        }
    }
    pthread_mutex_unlock(&transfer->mutex);

    /* Accept the dead thread. */
    if ((rv = pthread_join(transfer->thread_handle, NULL)) != 0) {
        errno = rv;
        return SK_TRANSFER_ESYSTEM_THREAD;
    }

    transfer->status = SKT_ENDED;

    return SK_TRANSFER_ESUCCESS;
}



sktErr_t skDestroyTransfer(skTransfer_t transfer)
{
    sktErr_t err;

    if (!transfer) {
        return SK_TRANSFER_EBADARG;
    }

    if (transfer->status == SKT_RUNNING) {
        err = skTransferStop(transfer, 0);
        if (err != SK_TRANSFER_ESUCCESS) {
            return err;
        }
    }

    /* Free everything */
    if (transfer->server) {
        if (transfer->server->valid_clients) {
            free(transfer->server->valid_clients);
        }
        free(transfer->server);
    }
    if (transfer->where) {
        free(transfer->where);
    }

    pthread_cond_destroy(&transfer->cond);
    pthread_mutex_destroy(&transfer->mutex);

    free(transfer);

    return SK_TRANSFER_ESUCCESS;
}


sktErr_t skTransferSetQueue(skTransfer_t transfer, skDeque_t queue)
{
    if (transfer == NULL || transfer->status != SKT_NOT_STARTED) {
        return SK_TRANSFER_EBADARG;
    }

    transfer->queue = queue;

    return SK_TRANSFER_ESUCCESS;
}


sktErr_t skTransferSetMinimumBitrate(skTransfer_t transfer, uint32_t bitrate)
{
    if (transfer == NULL || transfer->status != SKT_NOT_STARTED) {
        return SK_TRANSFER_EBADARG;
    }

    transfer->minimum_baud = bitrate;

    return SK_TRANSFER_ESUCCESS;
}


sktErr_t skTransferSetAckTimeout(skTransfer_t transfer, uint8_t timeout)
{
    if (transfer == NULL || transfer->status != SKT_NOT_STARTED) {
        return SK_TRANSFER_EBADARG;
    }

    transfer->ack_timeout = timeout;

    return SK_TRANSFER_ESUCCESS;
}

sktErr_t skTransferSetLogFn(skTransfer_t transfer, skt_logfn_t logfn)
{
    if (transfer == NULL || transfer->status != SKT_NOT_STARTED) {
        return SK_TRANSFER_EBADARG;
    }

    transfer->logfn = logfn;

    return SK_TRANSFER_ESUCCESS;
}

sktErr_t skTransferSetCallback(skTransfer_t transfer, skt_callback_t callback)
{
    if (transfer == NULL || transfer->status != SKT_NOT_STARTED) {
        return SK_TRANSFER_EBADARG;
    }

    /* Ugh. */
    if (skTransferIsClient(transfer)) {
        transfer->subcallback = callback;
    } else {
        transfer->callback = callback;
    }

    return SK_TRANSFER_ESUCCESS;
}



sktErr_t skSenderSetFilenameFn(
    skTransfer_t transfer,
    skt_filename_fn_t filename_fn)
{
    if (transfer == NULL || transfer->status != SKT_NOT_STARTED ||
        !skTransferIsSender(transfer))
    {
        return SK_TRANSFER_EBADARG;
    }

    transfer->filename_function = filename_fn;

    return SK_TRANSFER_ESUCCESS;
}


sktErr_t skReceiverSetTransformFn(
    skTransfer_t transfer,
    skt_fn_xform_fn_t fn_xform_function)
{
    if (transfer == NULL || transfer->status != SKT_NOT_STARTED ||
        !skTransferIsReceiver(transfer))
    {
        return SK_TRANSFER_EBADARG;
    }

    transfer->fn_xform_function = fn_xform_function;

    return SK_TRANSFER_ESUCCESS;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
