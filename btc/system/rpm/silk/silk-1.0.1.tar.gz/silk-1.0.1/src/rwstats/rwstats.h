/*
** Copyright (C) 2001-2007 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/
#ifndef _RWSTATS_H
#define _RWSTATS_H

#include "silk.h"

RCSIDENTVAR(rcsID_RWSTATS_H, "$SiLK: rwstats.h 9194 2007-10-02 16:13:07Z mthomas $");


/*
**  rwstats.h
**
**  Header file for the rwstats application.  See rwstats.c for a full
**  explanation.
**
*/

#include "interval.h"
#include "utils.h"
#include "hashlib.h"
#include "rwpack.h"
#include "sksite.h"
#include "skstream.h"


/* Where to write usage (--help) output */
#define USAGE_FH stdout

/* Where to write filenames if --print-file specified */
#define PRINT_FILENAMES_FH  stderr


/* Whether to print input filenames */
extern int8_t g_print_filenames;

/* Whether to suppress column and section titles */
extern int8_t g_no_titles;

/* The delimiter string to print between columns */
extern char g_delim;

/* the final delimiter on each line */
extern char g_final_delim[];

/* Whether to print IP addrs as integers */
extern int8_t g_integer_ips;

/* CIDR block mask for src and dest ips.  If 0, use all bits;
 * otherwise, the IP address should be bitwised ANDed with this
 * value. */
extern uint32_t g_cidr_src;
extern uint32_t g_cidr_dest;

extern uint64_t g_limit;


/* What key to use; keep these (except the pairs) in same order as
 * appOptionsEnum */
typedef enum {
    KEY_SIP, KEY_DIP,
    KEY_SPORT, KEY_DPORT,
    KEY_PROTO, KEY_ICMP,
    KEY_IP_PAIR, KEY_PORT_PAIR
} stat_key_type_t;

/* What value to use; keep these in same order as appOptionsEnum */
typedef enum {
    VAL_FLOWS, VAL_PACKETS, VAL_BYTES
} stat_val_type_t;

/* Top or bottom; keep these in same order as appOptionsEnum */
typedef enum {
    BT_TOP, BT_BOTTOM
} stat_bt_type_t;

/* What type of cutoff to use; keep these in same order as appOptionsEnum */
typedef enum {
    STATS_COUNT, STATS_THRESHOLD, STATS_PERCENTAGE
} stat_stats_type_t;

extern stat_key_type_t key_type;
extern stat_val_type_t val_type;
extern stat_stats_type_t stats_type;
extern stat_bt_type_t top_or_btm;

extern int arg_index;

/* Where to copy the input to */
extern rwIOStruct_t *g_copy_input;

/* Where to write the ASCII output */
extern skstream_t *outstream;


enum width_type {
    WIDTH_KEY, WIDTH_VAL, WIDTH_INTVL, WIDTH_PCT
};

/* output column widths.  mapped to width_type */
extern int g_width[6];


/* from rwstatsutils.c */

/* Option indentifiers.  Keep in sync with appOptions.  Need option
 * identifiers in the header so legacy options can invoke them. */
typedef enum {
    OPT_OVERALL_STATS, OPT_DETAIL_PROTO_STATS,

    /* keep these in same order as stat_key_type_t */
    OPT_SIP,
    OPT_DIP,
    OPT_SPORT,
    OPT_DPORT,
    OPT_PROTOCOL,
    OPT_ICMP,

    /* keep these in same order as stat_val_type_t */
    OPT_FLOWS,
    OPT_PACKETS,
    OPT_BYTES,

    /* keep these in same order as stat_stat_type_t */
    OPT_COUNT,
    OPT_THRESHOLD,
    OPT_PERCENTAGE,

    /* keep these in same order as stat_bt_type_t */
    OPT_TOP,
    OPT_BOTTOM,

    OPT_INTEGER_IPS,
    OPT_NO_TITLES, OPT_NO_COLUMNS, OPT_COLUMN_SEPARATOR,
    OPT_NO_FINAL_DELIMITER, OPT_DELIMITED,
    OPT_PRINT_FILENAMES,
    OPT_OUTPUT_PATH, OPT_COPY_INPUT, OPT_PAGER,

    OPT_LEGACY_HELP
} appOptionsEnum;


int appOptionsHandler(
    clientData  cData,
    int         opt_index,
    char       *opt_arg);


void appSetup(int argc, char **argv);
void appTeardown(void);

extern int g_proto_stats;


/* rwstats.c: Functions for Top-N type output */

int  setupTopn(void);
int  processFileTopn(rwIOStruct_t *rwIOS);
void printResultsTopn(void);
void teardownTopn(void);


/* rwstatsproto.c: Functions for detailed protocol statistics */

int  parseProtos(const char *arg);
int  setupProtoStats(void);
int  processFileProtoStats(rwIOStruct_t *rwIOS);
void printResultsProtoStats(void);
void teardownProtoStats(void);


/* from rwstatslegacy.c */

int  legAppOptionsSetup(void);
void legAppOptionsUsage(FILE *fh);



#endif /* _RWSTATS_H */

/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
