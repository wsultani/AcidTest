/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  rwstatsutils.c
**
**  utility functions for the rwstats application.  See rwstats.c for
**  a full explanation.
**
*/

#include "silk.h"

RCSIDENT("$SiLK: rwstatslegacy.c 11248 2008-04-11 19:07:39Z mthomas $");

#include "utils.h"
#include "rwstats.h"


/* OPTIONS SETUP */

typedef enum {
    LEGOPT_SIP_TOP_N, LEGOPT_SIP_TOP_THRESHOLD, LEGOPT_SIP_TOP_PCT,
    LEGOPT_SIP_BTM_N, LEGOPT_SIP_BTM_THRESHOLD, LEGOPT_SIP_BTM_PCT,

    LEGOPT_DIP_TOP_N, LEGOPT_DIP_TOP_THRESHOLD, LEGOPT_DIP_TOP_PCT,
    LEGOPT_DIP_BTM_N, LEGOPT_DIP_BTM_THRESHOLD, LEGOPT_DIP_BTM_PCT,

    LEGOPT_PAIR_TOP_N, LEGOPT_PAIR_TOP_THRESHOLD, LEGOPT_PAIR_TOP_PCT,
    LEGOPT_PAIR_BTM_N, LEGOPT_PAIR_BTM_THRESHOLD, LEGOPT_PAIR_BTM_PCT,

    LEGOPT_SPORT_TOP_N, LEGOPT_SPORT_TOP_THRESHOLD, LEGOPT_SPORT_TOP_PCT,
    LEGOPT_SPORT_BTM_N, LEGOPT_SPORT_BTM_THRESHOLD, LEGOPT_SPORT_BTM_PCT,

    LEGOPT_DPORT_TOP_N, LEGOPT_DPORT_TOP_THRESHOLD, LEGOPT_DPORT_TOP_PCT,
    LEGOPT_DPORT_BTM_N, LEGOPT_DPORT_BTM_THRESHOLD, LEGOPT_DPORT_BTM_PCT,

    LEGOPT_PORTPAIR_TOP_N, LEGOPT_PORTPAIR_TOP_THRESHOLD,
    LEGOPT_PORTPAIR_TOP_PCT, LEGOPT_PORTPAIR_BTM_N,
    LEGOPT_PORTPAIR_BTM_THRESHOLD, LEGOPT_PORTPAIR_BTM_PCT,

    LEGOPT_PROTO_TOP_N, LEGOPT_PROTO_TOP_THRESHOLD, LEGOPT_PROTO_TOP_PCT,
    LEGOPT_PROTO_BTM_N, LEGOPT_PROTO_BTM_THRESHOLD, LEGOPT_PROTO_BTM_PCT,

    LEGOPT_CIDR_SRC, LEGOPT_CIDR_DEST
} legAppOptionsEnum;

static struct option legAppOptions[] = {
    {"sip-topn",               REQUIRED_ARG, 0, LEGOPT_SIP_TOP_N},
    {"sip-top-threshold",      REQUIRED_ARG, 0, LEGOPT_SIP_TOP_THRESHOLD},
    {"sip-top-pct",            REQUIRED_ARG, 0, LEGOPT_SIP_TOP_PCT},
    {"sip-btmn",               REQUIRED_ARG, 0, LEGOPT_SIP_BTM_N},
    {"sip-btm-threshold",      REQUIRED_ARG, 0, LEGOPT_SIP_BTM_THRESHOLD},
    {"sip-btm-pct",            REQUIRED_ARG, 0, LEGOPT_SIP_BTM_PCT},

    {"dip-topn",               REQUIRED_ARG, 0, LEGOPT_DIP_TOP_N},
    {"dip-top-threshold",      REQUIRED_ARG, 0, LEGOPT_DIP_TOP_THRESHOLD},
    {"dip-top-pct",            REQUIRED_ARG, 0, LEGOPT_DIP_TOP_PCT},
    {"dip-btmn",               REQUIRED_ARG, 0, LEGOPT_DIP_BTM_N},
    {"dip-btm-threshold",      REQUIRED_ARG, 0, LEGOPT_DIP_BTM_THRESHOLD},
    {"dip-btm-pct",            REQUIRED_ARG, 0, LEGOPT_DIP_BTM_PCT},

    {"pair-topn",              REQUIRED_ARG, 0, LEGOPT_PAIR_TOP_N},
    {"pair-top-threshold",     REQUIRED_ARG, 0, LEGOPT_PAIR_TOP_THRESHOLD},
    {"pair-top-pct",           REQUIRED_ARG, 0, LEGOPT_PAIR_TOP_PCT},
    {"pair-btmn",              REQUIRED_ARG, 0, LEGOPT_PAIR_BTM_N},
    {"pair-btm-threshold",     REQUIRED_ARG, 0, LEGOPT_PAIR_BTM_THRESHOLD},
    {"pair-btm-pct",           REQUIRED_ARG, 0, LEGOPT_PAIR_BTM_PCT},

    {"sport-topn",             REQUIRED_ARG, 0, LEGOPT_SPORT_TOP_N},
    {"sport-top-threshold",    REQUIRED_ARG, 0, LEGOPT_SPORT_TOP_THRESHOLD},
    {"sport-top-pct",          REQUIRED_ARG, 0, LEGOPT_SPORT_TOP_PCT},
    {"sport-btmn",             REQUIRED_ARG, 0, LEGOPT_SPORT_BTM_N},
    {"sport-btm-threshold",    REQUIRED_ARG, 0, LEGOPT_SPORT_BTM_THRESHOLD},
    {"sport-btm-pct",          REQUIRED_ARG, 0, LEGOPT_SPORT_BTM_PCT},

    {"dport-topn",             REQUIRED_ARG, 0, LEGOPT_DPORT_TOP_N},
    {"dport-top-threshold",    REQUIRED_ARG, 0, LEGOPT_DPORT_TOP_THRESHOLD},
    {"dport-top-pct",          REQUIRED_ARG, 0, LEGOPT_DPORT_TOP_PCT},
    {"dport-btmn",             REQUIRED_ARG, 0, LEGOPT_DPORT_BTM_N},
    {"dport-btm-threshold",    REQUIRED_ARG, 0, LEGOPT_DPORT_BTM_THRESHOLD},
    {"dport-btm-pct",          REQUIRED_ARG, 0, LEGOPT_DPORT_BTM_PCT},

    {"portpair-topn",          REQUIRED_ARG, 0, LEGOPT_PORTPAIR_TOP_N},
    {"portpair-top-threshold", REQUIRED_ARG, 0, LEGOPT_PORTPAIR_TOP_THRESHOLD},
    {"portpair-top-pct",       REQUIRED_ARG, 0, LEGOPT_PORTPAIR_TOP_PCT},
    {"portpair-btmn",          REQUIRED_ARG, 0, LEGOPT_PORTPAIR_BTM_N},
    {"portpair-btm-threshold", REQUIRED_ARG, 0, LEGOPT_PORTPAIR_BTM_THRESHOLD},
    {"portpair-btm-pct",       REQUIRED_ARG, 0, LEGOPT_PORTPAIR_BTM_PCT},

    {"proto-topn",             REQUIRED_ARG, 0, LEGOPT_PROTO_TOP_N},
    {"proto-top-threshold",    REQUIRED_ARG, 0, LEGOPT_PROTO_TOP_THRESHOLD},
    {"proto-top-pct",          REQUIRED_ARG, 0, LEGOPT_PROTO_TOP_PCT},
    {"proto-btmn",             REQUIRED_ARG, 0, LEGOPT_PROTO_BTM_N},
    {"proto-btm-threshold",    REQUIRED_ARG, 0, LEGOPT_PROTO_BTM_THRESHOLD},
    {"proto-btm-pct",          REQUIRED_ARG, 0, LEGOPT_PROTO_BTM_PCT},

    {"cidr-src",               REQUIRED_ARG, 0, LEGOPT_CIDR_SRC},
    {"cidr-dest",              REQUIRED_ARG, 0, LEGOPT_CIDR_DEST},

    {0,0,0,0}                  /* sentinel entry */
};

static const char *legAppHelp[] = {
    /* add help strings here for the applications options */
    ("Use: --sip --top --flows --count=N\n"
     "\tPrint topN (by rec-count) src ips"),
    ("Use: --sip --top --flows --threshold=N\n"
     "\tPrint src ips with rec-count >= top-threshold"),
    ("Use: --sip --top --flows --percentage=N\n"
     "\tPrint src ips with %of-rec-count >= top-pct"),
    ("Use: --sip --bottom --flows --count=N\n"
     "\tPrint bottomN (by rec-count) src ips."),
    ("Use: --sip --bottom --flows --threshold=N\n"
     "\tPrint src ips with rec-count <= btm-threshold"),
    ("Use: --sip --bottom --flows --percentage=N\n"
     "\tPrint src ips with %of-rec-count <= btm-pct"),

    ("Use: --dip --top --flows --count=N\n"
     "\tPrint topN (by rec-count) dest ips"),
    ("Use: --dip --top --flows --threshold=N\n"
     "\tPrint dest ips with rec-count >= top-threshold"),
    ("Use: --dip --top --flows --percentage=N\n"
     "\tPrint dest ips with %of-rec-count >= top-pct"),
    ("Use: --dip --bottom --flows --count=N\n"
     "\tPrint bottomN (by rec-count) dest ips."),
    ("Use: --dip --bottom --flows --threshold=N\n"
     "\tPrint dest ips with rec-count <= btm-threshold"),
    ("Use: --dip --bottom --flows --percentage=N\n"
     "\tPrint dest ips with %of-rec-count <= btm-pct"),

    ("Use: --sip --dip --top --flows --count=N\n"
     "\tPrint topN (by rec-count) src+dest ip pairs"),
    ("Use: --sip --dip --top --flows --threshold=N\n"
     "\tPrint src+dest ip pairs with rec-count >= top-threshold"),
    ("Use: --sip --dip --top --flows --percentage=N\n"
     "\tPrint src+dest ip pairs with %of-rec-count >= top-pct"),
    ("Use: --sip --dip --bottom --flows --count=N\n"
     "\tPrint bottomN (by rec-count) src+dest ip pairs."),
    ("Use: --sip --dip --bottom --flows --threshold=N\n"
     "\tPrint src+dest ip pairs with rec-count <= btm-threshold"),
    ("Use: --sip --dip --bottom --flows --percentage=N\n"
     "\tPrint src+dest ip pairs with %of-rec-count <= btm-pct"),

    ("Use: --sport --top --flows --count=N\n"
     "\tPrint topN (by rec-count) src ports"),
    ("Use: --sport --top --flows --threshold=N\n"
     "\tPrint src ports with rec-count >= top-threshold"),
    ("Use: --sport --top --flows --percentage=N\n"
     "\tPrint src ports with %of-rec-count >= top-pct"),
    ("Use: --sport --bottom --flows --count=N\n"
     "\tPrint bottomN (by rec-count) src ports."),
    ("Use: --sport --bottom --flows --threshold=N\n"
     "\tPrint src ports with rec-count <= btm-threshold"),
    ("Use: --sport --bottom --flows --percentage=N\n"
     "\tPrint src ports with %of-rec-count <= btm-pct"),

    ("Use: --dport --top --flows --count=N\n"
     "\tPrint topN (by rec-count) dest ports"),
    ("Use: --dport --top --flows --threshold=N\n"
     "\tPrint dest ports with rec-count >= top-threshold"),
    ("Use: --dport --top --flows --percentage=N\n"
     "\tPrint dest ports with %of-rec-count >= top-pct"),
    ("Use: --dport --bottom --flows --count=N\n"
     "\tPrint bottomN (by rec-count) dest ports."),
    ("Use: --dport --bottom --flows --threshold=N\n"
     "\tPrint dest ports with rec-count <= btm-threshold"),
    ("Use: --dport --bottom --flows --percentage=N\n"
     "\tPrint dest ports with %of-rec-count <= btm-pct"),

    ("Use: --sport --dport --top --count=N\n"
     "\tPrint topN (by rec-count) sPort+dPort pairs"),
    ("Use: --sport --dport --top --threshold=N\n"
     "\tPrint sPort+dPort pairs with rec-count >= top-threshold"),
    ("Use: --sport --dport --top --percentage=N\n"
     "\tPrint sPort+dPort pairs with %of-rec-count >= top-pct"),
    ("Use: --sport --dport --bottom --count=N\n"
     "\tPrint bottomN (by rec-count) sPort+dPort pairs."),
    ("Use: --sport --dport --bottom --threshold=N\n"
     "\tPrint sPort+dPort pairs with rec-count <= btm-threshold"),
    ("Use: --sport --dport --bottom --percentage=N\n"
     "\tPrint sPort+dPort pairs with %of-rec-count <= btm-pct"),

    ("Use: --protocol --top --flows --count=N\n"
     "\tPrint topN (by rec-count) protos"),
    ("Use: --protocol --top --flows --threshold=N\n"
     "\tPrint protos with rec-count >= top-threshold"),
    ("Use: --protocol --top --flows --percentage=N\n"
     "\tPrint protos with %of-rec-count >= top-pct"),
    ("Use: --protocol --bottom --flows --count=N\n"
     "\tPrint bottomN (by rec-count) protos."),
    ("Use: --protocol --bottom --flows --threshold=N\n"
     "\tPrint protos with rec-count <= btm-threshold"),
    ("Use: --protocol --bottom --flows --percentage=N\n"
     "\tPrint protos with %of-rec-count <= btm-pct"),

    ("Use: --sip=N\n"
     "\tConsider first N bits of src ip (sip-* & pair-* opts). Def. 32"),
    ("Use: --dip=N\n"
     "\tConsider first N bits of dest ip (dip-* & pair-* opts). Def. 32"),

    (char *)NULL
};


/* LOCAL FUNCTION PROTOTYPES */

static int legAppOptionsHandler(
    clientData  cData,
    int         opt_index,
    char       *opt_arg);


/* FUNCTION DEFINITIONS */

/*
 *  legAppOptionsSetup(void);
 *
 *    Register the legacy options.
 */
int legAppOptionsSetup(void)
{
    assert((sizeof(legAppHelp)/sizeof(char *)) ==
           (sizeof(legAppOptions)/sizeof(struct option)));

    /* register the options */
    if (skOptionsRegister(legAppOptions, &legAppOptionsHandler, NULL))
    {
        skAppPrintErr("Unable to register legacy options");
        return 1;
    }

    return 0;
}


/*
 *  legAppOptionsUsage(fh);
 *
 *    Print the usage information for the legacy options to the named
 *    file handle.
 */
void legAppOptionsUsage(FILE *fh)
{
    int i;

    fprintf(fh, "\nLEGACY SWITCHES:\n");
    for (i = 0; legAppOptions[i].name; i++ ) {
        fprintf(fh, "--%s %s. %s\n", legAppOptions[i].name,
                SK_OPTION_HAS_ARG(legAppOptions[i]), legAppHelp[i]);
    }
}


/*
 *  status = legAppOptionsHandler(cData, opt_index, opt_arg);
 *
 *    Process the legacy versions of the switches by calling the real
 *    appOptionsHandler().
 */
static int legAppOptionsHandler(
    clientData  UNUSED(cData),
    int         opt_index,
    char       *opt_arg)
{
    static int been_here = -1;

    /* Handle CIDR blocks since they don't affect been_here */
    if (opt_index == LEGOPT_CIDR_SRC) {
        return appOptionsHandler(cData, OPT_SIP, opt_arg);
    } else if (opt_index == LEGOPT_CIDR_DEST) {
        return appOptionsHandler(cData, OPT_DIP, opt_arg);
    }

    if (been_here != -1) {
        skAppPrintErr(("%s no longer supports multiple analyses in one run.\n"
                       "\tMay only specify one of "
                       "--sip-*, --dip-*, --sport-*, --dport-*,\n"
                       "\t--proto-*, --pair-*, or --portpair*."),
                      skAppName());
        return 1;
    }
    been_here = opt_index;

    switch ((legAppOptionsEnum)opt_index) {
      case LEGOPT_SIP_TOP_N:
        if (appOptionsHandler(cData, OPT_SIP, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_COUNT, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_SIP_TOP_THRESHOLD:
        if (appOptionsHandler(cData, OPT_SIP, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_THRESHOLD, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_SIP_TOP_PCT:
        if (appOptionsHandler(cData, OPT_SIP, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_PERCENTAGE, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_SIP_BTM_N:
        if (appOptionsHandler(cData, OPT_SIP, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_COUNT, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_SIP_BTM_THRESHOLD:
        if (appOptionsHandler(cData, OPT_SIP, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_THRESHOLD, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_SIP_BTM_PCT:
        if (appOptionsHandler(cData, OPT_SIP, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_PERCENTAGE, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_DIP_TOP_N:
        if (appOptionsHandler(cData, OPT_DIP, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_COUNT, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_DIP_TOP_THRESHOLD:
        if (appOptionsHandler(cData, OPT_DIP, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_THRESHOLD, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_DIP_TOP_PCT:
        if (appOptionsHandler(cData, OPT_DIP, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_PERCENTAGE, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_DIP_BTM_N:
        if (appOptionsHandler(cData, OPT_DIP, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_COUNT, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_DIP_BTM_THRESHOLD:
        if (appOptionsHandler(cData, OPT_DIP, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_THRESHOLD, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_DIP_BTM_PCT:
        if (appOptionsHandler(cData, OPT_DIP, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_PERCENTAGE, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PAIR_TOP_N:
        if (appOptionsHandler(cData, OPT_SIP, NULL)
            || appOptionsHandler(cData, OPT_DIP, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_COUNT, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PAIR_TOP_THRESHOLD:
        if (appOptionsHandler(cData, OPT_SIP, NULL)
            || appOptionsHandler(cData, OPT_DIP, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_THRESHOLD, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PAIR_TOP_PCT:
        if (appOptionsHandler(cData, OPT_SIP, NULL)
            || appOptionsHandler(cData, OPT_DIP, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_PERCENTAGE, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PAIR_BTM_N:
        if (appOptionsHandler(cData, OPT_SIP, NULL)
            || appOptionsHandler(cData, OPT_DIP, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_COUNT, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PAIR_BTM_THRESHOLD:
        if (appOptionsHandler(cData, OPT_SIP, NULL)
            || appOptionsHandler(cData, OPT_DIP, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_THRESHOLD, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PAIR_BTM_PCT:
        if (appOptionsHandler(cData, OPT_SIP, NULL)
            || appOptionsHandler(cData, OPT_DIP, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_PERCENTAGE, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_SPORT_TOP_N:
        if (appOptionsHandler(cData, OPT_SPORT, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_COUNT, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_SPORT_TOP_THRESHOLD:
        if (appOptionsHandler(cData, OPT_SPORT, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_THRESHOLD, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_SPORT_TOP_PCT:
        if (appOptionsHandler(cData, OPT_SPORT, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_PERCENTAGE, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_SPORT_BTM_N:
        if (appOptionsHandler(cData, OPT_SPORT, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_COUNT, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_SPORT_BTM_THRESHOLD:
        if (appOptionsHandler(cData, OPT_SPORT, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_THRESHOLD, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_SPORT_BTM_PCT:
        if (appOptionsHandler(cData, OPT_SPORT, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_PERCENTAGE, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_DPORT_TOP_N:
        if (appOptionsHandler(cData, OPT_DPORT, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_COUNT, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_DPORT_TOP_THRESHOLD:
        if (appOptionsHandler(cData, OPT_DPORT, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_THRESHOLD, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_DPORT_TOP_PCT:
        if (appOptionsHandler(cData, OPT_DPORT, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_PERCENTAGE, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_DPORT_BTM_N:
        if (appOptionsHandler(cData, OPT_DPORT, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_COUNT, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_DPORT_BTM_THRESHOLD:
        if (appOptionsHandler(cData, OPT_DPORT, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_THRESHOLD, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_DPORT_BTM_PCT:
        if (appOptionsHandler(cData, OPT_DPORT, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_PERCENTAGE, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PORTPAIR_TOP_N:
        if (appOptionsHandler(cData, OPT_SPORT, NULL)
            || appOptionsHandler(cData, OPT_DPORT, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_COUNT, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PORTPAIR_TOP_THRESHOLD:
        if (appOptionsHandler(cData, OPT_SPORT, NULL)
            || appOptionsHandler(cData, OPT_DPORT, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_THRESHOLD, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PORTPAIR_TOP_PCT:
        if (appOptionsHandler(cData, OPT_SPORT, NULL)
            || appOptionsHandler(cData, OPT_DPORT, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_PERCENTAGE, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PORTPAIR_BTM_N:
        if (appOptionsHandler(cData, OPT_SPORT, NULL)
            || appOptionsHandler(cData, OPT_DPORT, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_COUNT, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PORTPAIR_BTM_THRESHOLD:
        if (appOptionsHandler(cData, OPT_SPORT, NULL)
            || appOptionsHandler(cData, OPT_DPORT, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_THRESHOLD, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PORTPAIR_BTM_PCT:
        if (appOptionsHandler(cData, OPT_SPORT, NULL)
            || appOptionsHandler(cData, OPT_DPORT, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_PERCENTAGE, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PROTO_TOP_N:
        if (appOptionsHandler(cData, OPT_PROTOCOL, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_COUNT, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PROTO_TOP_THRESHOLD:
        if (appOptionsHandler(cData, OPT_PROTOCOL, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_THRESHOLD, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PROTO_TOP_PCT:
        if (appOptionsHandler(cData, OPT_PROTOCOL, NULL)
            || appOptionsHandler(cData, OPT_TOP, NULL)
            || appOptionsHandler(cData, OPT_PERCENTAGE, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PROTO_BTM_N:
        if (appOptionsHandler(cData, OPT_PROTOCOL, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_COUNT, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PROTO_BTM_THRESHOLD:
        if (appOptionsHandler(cData, OPT_PROTOCOL, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_THRESHOLD, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_PROTO_BTM_PCT:
        if (appOptionsHandler(cData, OPT_PROTOCOL, NULL)
            || appOptionsHandler(cData, OPT_BOTTOM, NULL)
            || appOptionsHandler(cData, OPT_PERCENTAGE, opt_arg))
        {
            return 1;
        }
        break;

      case LEGOPT_CIDR_SRC:
      case LEGOPT_CIDR_DEST:
        /* should have been handled above */
        assert(0);
        break;
    }

    return 0;                   /* OK */
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
