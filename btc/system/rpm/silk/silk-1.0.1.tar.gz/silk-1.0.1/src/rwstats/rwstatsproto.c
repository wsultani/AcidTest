/*
** Copyright (C) 2001-2007 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  rwstats.c
**
**  Implementation of the rwstats suite application.
**
**  Reads packed files or reads the output from rwfilter and can
**  compute a battery of characterizations and statistics:
**
**  -- Top N or Bottom N SIPs with counts; count of unique SIPs
**  -- Top N or Bottom N DIPs with counts; count of unique DIPs
**  -- Top N or Bottom N SIP/DIP pairs with counts; count of unique
**     SIP/DIP pairs (for a limited number of records)
**  -- Top N or Bottom N Src Ports with counts; count of unique Src Ports
**  -- Top N or Bottom N Dest Ports with counts; count of unique Dest Ports
**  -- Top N or Bottom N Protocols with counts; count of unique protocols
**  -- For more continuous variables (bytes, packets, bytes/packet)
**     provide statistics such as min, max, quartiles, and intervals
**
**  Instead of specifying a Top N or Bottom N as an absolute number N,
**  the user may specify a cutoff threshold.  In this case, the Top N
**  or Bottom N required to print all counts meeting the threshold is
**  computed by the application.
**
**  Instead of specifying the threshold as an absolute count, the user
**  may specify the threshold as percentage of all input records.  For
**  this case, the absolute threshold is calculated and then that is
**  used to calculate the Top N or Bottom N.
**
**  The application will only do calculations and produce output when
**  asked to do so.  At least one argument is required to tell the
**  application what to do.
**
**  Ideas for expansion
**  -- Similarly for other variables, e.g., country code.
**  -- Output each type of data to its own file
**  -- Save intermediate data in files for faster reprocessing by this
**     application
**  -- Save intermediate data in files for processing by other
**     applications
**
*/

#include "silk.h"

RCSIDENT("$SiLK: rwstatsproto.c 9952 2007-12-21 16:36:55Z mthomas $");

#include "rwstats.h"

/*
**  IMPLEMENTATION NOTES
**
**  For each input type (source ip, dest ip, source port, proto, etc),
**  there are two globals: g_limit_<type> contains the value the user
**  entered for the input type, and g_wanted_stat_<type> is a member
**  of the wanted_stat_type and says what the g_limit_<type> value
**  represents---e.g., the Top N, the bottom threshold percentage, etc.
**
**  The application takes input (either from stdin or as files on
**  command line) and calls processFile() on each.  A count of each
**  unique source IP addresses is stored in the IpCounter hash table
**  g_counter_src_ip; Destinations IPs in g_counter_dest_ip; data for
**  flow between a Source IP and Destination IP pair are stored in
**  g_counter_pair_ip.
**
**  Since there are relatively few ports and protocols, two
**  65536-elements arrays, g_src_port_array and g_dest_port_array are
**  used to store a count of the records for each source and
**  destination port, respectively, and a 256-element array,
**  g_proto_array, is used to store a count of each protocol.
**
**  Minima, maxima, quartile, and interval data are stored for each of
**  bytes, packets, and bytes-per-packet for all flows--regardless of
**  protocol--and detailed for a limited number (RWSTATS_NUM_PROTO-1)
**  of protocols..  The minima and maxima are each stored in arrays
**  for each of bytes, packets, bpp.  For example g_bytes_min[0]
**  stores the smallest byte count regardless of protocol (ie, over
**  all protocols), and g_pkts_max[1] stores the largest packet count
**  for the first protocol the user specified.  The mapping from
**  protocol to array index is given by g_proto_to_stats_idx[], where
**  the index into g_proto_to_stats_idx[] returns an integer that is
**  the index into g_bytes_min[].  Data for the intervals is stored in
**  two dimensional arrays, where the first dimension is the same as
**  for the minima and maxima, and the second dimension is the number
**  of intervals, NUM_INTERVALS.
**
**  Once data is collected, it is processed.
**
**  For the IPs, the user is interested the number of unique IPs and
**  the IPs with the topN counts (things are similar for the bottomN,
**  but we use topN in this dicussion to keep things more clear).  In
**  the printTopIps() function, an array with 2*topN elements is
**  created and passed to calcTopIps(); that array will be the result
**  array and it will hold the topN IpAddr and IpCount pairs in sorted
**  order.  In calcTopIps(), a working array of 2*topN elements and a
**  Heap data structure with topN nodes are created.  The topN
**  IpCounts seen are stored as IpCount/IpAddr pairs in the
**  2*topN-element array (but not in sorted order), and the heap
**  stores pointers into that array with the lowest IpCount at the
**  root of the heap.  As the function iterates over the hash table,
**  it compares the IpCount of the current hash-table element with the
**  IpCount at the root of the heap.  When the IpCount of the
**  hash-table element is larger, the root of the heap is removed, the
**  IpCount/IpAddr pair pointed to by the former heap-root is removed
**  from the 2*topN-element array and replaced with the new
**  IpCount/IpAddr pair, and finally a new node is added to the heap
**  that points to the new IpCount/IpAddr pair.  This continues until
**  all hash-table entries are processed.  To get the list of topN IPs
**  from highest to lowest, calcTopIps() removes elements from the
**  heap and stores them in the result array from position N-1 to
**  position 0.
**
**  Finding the topN source ports, topN destination ports, and topN
**  protocols are similar to finding the topN IPs, except the ports
**  and protocols are already stored in an array, so pointers directly
**  into the g_src_port_array, g_dest_port_array, and g_proto_array
**  are stored in the heap.  When generating output, the number of the
**  port or protocol is determined by the diffence between the pointer
**  into the g_*_port_array or g_proto_array and its start.
**
**  Instead of specifying a topN, the user may specify a cutoff
**  threshold.  In this case, the topN required to print all counts
**  meeting the threshold is computed by looping over the IP
**  hash-table or port/protocol arrays and finding all entries with at
**  least threshold hits.
**
**  The user may specify a percentage threshold instead of an absolute
**  threshold.  Once all records are read, the total record count is
**  multiplied by the percentage threshold to get the absolute
**  threshold cutoff, and that is used to calculate the topN as
**  described in the preceeding paragraph.
**
**  For the continuous variables bytes, packets, bpp, most of the work
**  was done while reading the data, so processing is minimal.  Only
**  the quartiles must be calculated.
*/



/* local functions */

/* Functions that handle input */
static void printIntervals(int proto_idx, const char *col_title);
static void updateStatistics(int proto_idx, const rwRec *rwrec);


/* Functions for statistics computing */


/* Statistics (min, max, quartiles, intervals) for "continuous" values
 * (bytes, packets, bpp) can be computed over all protocols, and the
 * can be broken out for a limited number of specific protocols.  This
 * defines the size of the data structures to hold these statistics.
 * This is one more that the number of specific protocols allowed. */



#define NUM_STATS 3
#define BYTE 0
#define PKT 1
#define BPP 2


/* These arrays hold the statistics.  Position 0 is for the
 * combination of all statistics. */
static uint64_t *g_count; /* record count per protocol */
static uint32_t *g_min;
static uint32_t *g_max;
static uint32_t (*g_intervals)[NUM_INTERVALS];
static uint32_t **g_interval_defn;

#define MK_IDX(type, idx) ((type) + (NUM_STATS * (idx)))


/* This maps the protocol number to the index in the above statistics
 * arrays.  If the value for a protocol is 0, the user did not request
 * detailed specs on that protocol. */
static int16_t g_proto_to_stats_idx[256];


/* FUNCTION DEFINITIONS */


/*
 * parseProtos
 *      Discover which protos the user wants detailed stats for
 * Arguments:
 *      arg -the command line argument
 * Returns:
 *      0 if OK; 1 if error
 * Side Effects:
 *      Sets values in the global g_proto_to_stats_idx[]
 */
int parseProtos(const char *arg)
{
    uint32_t i;
    uint32_t count;
    uint32_t *parsed_list;
    int32_t proto_idx = 1; /* 0 is global stats */
    int rv;

    rv = skStringParseNumberList(&parsed_list, &count, arg, 0, 255, 0);
    if (rv) {
        skAppPrintErr("Invalid protocol list '%s': %s",
                      arg, skStringParseStrerror(rv));
        return 1;
    }

    for (i = 0; i < count; ++i) {
        if (0 != g_proto_to_stats_idx[parsed_list[i]]) {
            skAppPrintErr("Duplicate protocol %u ignored",
                          parsed_list[i]);
        } else {
            g_proto_to_stats_idx[parsed_list[i]] = proto_idx;
            ++proto_idx;
        }
    }

    free(parsed_list);
    return 0;
}


int setupProtoStats(void)
{
    int proto_idx = 1; /* ALL stats */
    int i, j;

    for (i = 0; i < 256; ++i) {
        if (g_proto_to_stats_idx[i]) {
            ++proto_idx;
        }
    }

    /* Allocate space for all the stats */
    g_count = calloc(proto_idx, sizeof(uint64_t));
    g_min = malloc(NUM_STATS * proto_idx * sizeof(uint32_t));
    g_max = calloc(NUM_STATS * proto_idx, sizeof(uint32_t));
    g_intervals = calloc(NUM_STATS * proto_idx * NUM_INTERVALS,
                         sizeof(uint32_t*));
    g_interval_defn = calloc(NUM_STATS * proto_idx, sizeof(uint32_t*));

    if (!g_min || !g_max || !g_intervals || !g_interval_defn) {
        skAppPrintErr("Cannot allocate space for protocol statistics");
        teardownProtoStats();
        return 1;
    }

    /* Set the minima to a big value, like INT_MAX */
    for (i = 0; i < proto_idx; ++i) {
        for (j = 0; j < NUM_STATS; ++j) {
            g_min[MK_IDX(j, i)] = INT_MAX;
        }
    }

    /* Set the interval definitions for TCP */
    i = g_proto_to_stats_idx[6];
    if (i != 0) {
        g_interval_defn[MK_IDX(BYTE, i)] = tcpByteIntervals;
        g_interval_defn[MK_IDX(PKT,  i)] = tcpPktIntervals;
        g_interval_defn[MK_IDX(BPP,  i)] = tcpBppIntervals;
    }

    /* Since TCP is dominate protocol; use the TCP interval
     * definitions for stats across ALL protocols. */
    g_interval_defn[MK_IDX(BYTE, 0)] = tcpByteIntervals;
    g_interval_defn[MK_IDX(PKT,  0)] = tcpPktIntervals;
    g_interval_defn[MK_IDX(BPP,  0)] = tcpBppIntervals;

    /* Set all other interval definitions to UDP */
    for (i = 1; i < proto_idx; ++i) {
        if (i != g_proto_to_stats_idx[6]) {
            g_interval_defn[MK_IDX(BYTE, i)] = udpByteIntervals;
            g_interval_defn[MK_IDX(PKT,  i)] = udpPktIntervals;
            g_interval_defn[MK_IDX(BPP,  i)] = udpBppIntervals;
        }
    }

    return 0;
}


void teardownProtoStats(void)
{
    if (g_count) {
        free(g_count);
        g_count = NULL;
    }
    if (g_min) {
        free(g_min);
        g_min = NULL;
    }
    if (g_max) {
        free(g_max);
        g_max = NULL;
    }
    if (g_intervals) {
        free(g_intervals);
        g_intervals = NULL;
    }
    if (g_interval_defn) {
        free(g_interval_defn);
        g_interval_defn = NULL;
    }
}


/*
 * processFile:
 *      Read rwRec's from the named file and update the counters
 * Arguments:
 *      curFName -name of file to process
 * Returns: NONE.
 * Side Effects:
 *      Global counters, minima, maxima, intervals are modified.
 */
int processFileProtoStats(rwIOStruct_t *rwIOS)
{
    rwRec rwrec;
    int proto_idx;

    while (rwRead(rwIOS, &rwrec)) {
        /* Statistics across ALL protocols */
        updateStatistics(0, &rwrec);

        /* Compute statistics for specific protocol if requested */
        proto_idx = g_proto_to_stats_idx[rwRecGetProto(&rwrec)];
        if (proto_idx) {
            updateStatistics(proto_idx, &rwrec);
        }

    } /* while rwRead() */

    return 0;
}


/*
 * updateStatistics:
 *      Update the minima, maxima, and intervals for bytes, packets,
 *      and bytes-per-packet for the specified protocol.
 * Arguments:
 *      proto -number of the protocol to be updated.  Used to
 *              determine which intervals to use.  This is equal to
 *              256 for the overall stats
 *      proto_idx -the index---determined by proto---into the
 *              various g_*_min, g_*_max, and g_*_intervals arrays.
 *      rwrecPtr -the rwrec data
 * Returns: NONE.
 * Side Effects:
 *      Global counters, minima, maxima, intervals are modified.
 */
static void updateStatistics(
    int             proto_idx,
    const rwRec    *rwrec)
{
    uint32_t stat_src[NUM_STATS];
    int i;
    int s;

    /* Update count */
    ++g_count[proto_idx];

    stat_src[BYTE] = rwRecGetBytes(rwrec);
    stat_src[PKT]  = rwRecGetPkts(rwrec);
    stat_src[BPP]  = rwRecGetBytes(rwrec) / rwRecGetPkts(rwrec);

    /* Find min/max/intervals for bytes, packets, bpp */
    for (s = 0; s < NUM_STATS; ++s) {
        if (stat_src[s] < g_min[MK_IDX(s, proto_idx)]) {
            g_min[MK_IDX(s, proto_idx)] = stat_src[s];
            if (0 == g_max[MK_IDX(s, proto_idx)]) {
                g_max[MK_IDX(s, proto_idx)] = stat_src[s];
            }
        } else if (stat_src[s] > g_max[MK_IDX(s, proto_idx)]) {
            g_max[MK_IDX(s, proto_idx)] = stat_src[s];
        }
        for (i = 0; i < NUM_INTERVALS; ++i) {
            if (stat_src[s] <= g_interval_defn[MK_IDX(s, proto_idx)][i])
            {
                g_intervals[s + NUM_STATS * proto_idx][i]++;
                break;
            }
        }
    }
}


/*
 * rwstatsGenerateOutput
 *      Print the output
 * Arguments: NONE.
 * Returns: NONE
 * Side Effects: NONE.
 */
void printResultsProtoStats(void)
{
    int proto;
    int proto_idx;
    int print_all_protos = 1;

    if (g_count[0] > 0) {
        /* Check to see if a single protocol has all the flows.  If
         * so, do not print the all-protos stats, since it will be
         * identical to the single-proto stats. */
        for (proto = 0; proto < 256; ++proto) {
            proto_idx = g_proto_to_stats_idx[proto];
            if (proto_idx == 0) {
                continue;
            }
            if (g_count[proto_idx] == g_count[0]) {
                print_all_protos = 0;
                break;
            }
        }
    }

    /* Print all proto stats only when there are multiple protocols. */
    if (print_all_protos) {
        skStreamPrint(outstream, "FLOW STATISTICS--ALL PROTOCOLS:  ");
        printIntervals(0, "%_of_input");
    }

    /* Return if no records were read */
    if (0 == g_count[0]) {
        return;
    }

    for (proto = 0; proto < 256; ++proto) {
        proto_idx = g_proto_to_stats_idx[proto];
        if (proto_idx == 0) {
            /* nothing to do for this protocol */
            continue;
        }

        skStreamPrint(outstream, "\nFLOW STATISTICS--PROTOCOL %d:  ", proto);
        printIntervals(proto_idx, "%_of_proto");
    }
}


/*
 * printIntervals
 *      Print min, max, and intervals for bytes, packets, and bpp for
 *      the given protocol
 * Arguments:
 *      proto - the protocol to print
 *      proto_idx - the index to use into the g_*_min, g_*_max,
 *              g_*_interval arrays to access data for this protocol
 * Returns: NONE
 * Side Effects:
 *      Prints output to outstream
 */
static void printIntervals(int proto_idx, const char *col_title)
{
    static const char *stat_name[] = {"BYTES", "PACKETS", "BYTES/PACKET"};
    double *quartiles;
    int i;
    int s;
    double percent;
    double cumul_pct;

    skStreamPrint(outstream, ("%" PRIu64), g_count[proto_idx]);
    if (proto_idx != 0) {
        skStreamPrint(outstream, ("/%" PRIu64), g_count[0]);
    }
    skStreamPrint(outstream, " records\n");

    if (0 == g_count[proto_idx]) {
        /* no records, so no data to print */
        return;
    }

    for (s = 0; s < NUM_STATS; ++s) {
        /* Print title and min, max */
        skStreamPrint(outstream, "*%s min %u; max %u\n",
                      stat_name[s], g_min[MK_IDX(s, proto_idx)],
                      g_max[MK_IDX(s, proto_idx)]);

        /* Compute and print quartitles */
        quartiles = intervalQuartiles(g_intervals[MK_IDX(s, proto_idx)],
                                      g_interval_defn[MK_IDX(s, proto_idx)],
                                      NUM_INTERVALS);
        skStreamPrint(outstream,
                      "  quartiles LQ %.5f Med %.5f UQ %.5f UQ-LQ %.5f\n",
                      quartiles[0], quartiles[1], quartiles[2],
                      (quartiles[2] - quartiles[0]));

        /* Column titles for intervals */
        if (!g_no_titles) {
            skStreamPrint(outstream, "%*s%c%*s%c%*s%c%*s%s\n",
                          g_width[WIDTH_KEY],   "interval_max", g_delim,
                          g_width[WIDTH_INTVL], "count<=max", g_delim,
                          g_width[WIDTH_PCT],   col_title, g_delim,
                          g_width[WIDTH_PCT],   "cumul_%", g_final_delim);
        }

        /* Print intervals and percentages */
        cumul_pct = 0.0;
        for (i = 0; i < NUM_INTERVALS; ++i) {
            percent = (100.0 * (double)g_intervals[MK_IDX(s, proto_idx)][i]
                       / (double)g_count[proto_idx]);
            cumul_pct += percent;

            skStreamPrint(outstream, "%*u%c%*u%c%*.6f%c%*.6f%s\n",
                          g_width[WIDTH_KEY],
                          g_interval_defn[MK_IDX(s, proto_idx)][i], g_delim,
                          g_width[WIDTH_INTVL],
                          g_intervals[MK_IDX(s, proto_idx)][i], g_delim,
                          g_width[WIDTH_PCT], percent, g_delim,
                          g_width[WIDTH_PCT], cumul_pct, g_final_delim);
        }
    }
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
