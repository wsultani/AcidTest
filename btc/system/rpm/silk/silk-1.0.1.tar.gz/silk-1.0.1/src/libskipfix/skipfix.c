/*
** skipfix.c
** SiLK rwio IPFIX translation core
**
** ------------------------------------------------------------------------
** Copyright (C) 2007-2008 Carnegie Mellon University. All Rights Reserved.
** ------------------------------------------------------------------------
** Authors: Brian Trammell <bht@cert.org>
** ------------------------------------------------------------------------
** GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
** ------------------------------------------------------------------------
** $SiLK: skipfix.c 10947 2008-03-18 15:41:44Z mthomas $
** ------------------------------------------------------------------------
*/

#define _SKIPFIX_SOURCE_

#include "silk.h"

RCSIDENT("$SiLK: skipfix.c 10947 2008-03-18 15:41:44Z mthomas $");

#include "skipfix.h"


/* IPFIX information elements in 6871 space for SiLK */
static fbInfoElement_t ski_info_elements[] = {
    FB_IE_INIT("initialTCPFlags", 6871, 14, 1,
               FB_IE_F_ENDIAN | FB_IE_F_REVERSIBLE),
    FB_IE_INIT("unionTCPFlags", 6871, 15, 1,
               FB_IE_F_ENDIAN | FB_IE_F_REVERSIBLE),
    FB_IE_INIT("reverseFlowDeltaMilliseconds", 6871, 21, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("silkFlowType", 6871, 30, 1, FB_IE_F_ENDIAN),
    FB_IE_INIT("silkFlowSensor", 6871, 31, 2, FB_IE_F_ENDIAN),
    FB_IE_INIT("silkTCPState", 6871, 32, 1, FB_IE_F_ENDIAN),
    FB_IE_INIT("silkAppLabel", 6871, 33, 2, FB_IE_F_ENDIAN),
    FB_IE_NULL
};

static fbInfoElement_t ski_init_flags_ie =
    FB_IE_INIT("initialTCPFlags", 6871, 14, 1, FB_IE_F_ENDIAN);

/* Keep this in sync with the rwIpfixRec_V3 below. Pad to 64bits */
static fbInfoElementSpec_t ski_flow_spec[] = {
    /* Millisecond start and end (epoch) (native time) */
    { "flowStartMilliseconds",              0, 0 },
    { "flowEndMilliseconds",                0, 0 },
    /* 4-tuple */
    { "sourceIPv6Address",                  0, 0 },
    { "destinationIPv6Address",             0, 0 },
    { "sourceIPv4Address",                  0, 0 },
    { "destinationIPv4Address",             0, 0 },
    { "sourceTransportPort",                0, 0 },
    { "destinationTransportPort",           0, 0 },
    /* Router interface information */
    { "ipNextHopIPv4Address",               0, 0 },
    { "ipNextHopIPv6Address",               0, 0 },
    { "ingressInterface",                   0, 0 },
    { "egressInterface",                    0, 0 },
    /* Counters (reduced length encoding for SiLK) */
    { "packetDeltaCount",                   0, 0 },
    { "octetDeltaCount",                    0, 0 },
    /* Protocol; sensor information */
    { "protocolIdentifier",                 0, 0 },
    { "silkFlowType",                       0, 0 },
    { "silkFlowSensor",                     0, 0 },
    /* Flags */
    { "tcpControlBits",                     0, 0 },
    { "initialTCPFlags",                    0, 0 },
    { "unionTCPFlags",                      0, 0 },
    { "silkTCPState",                       0, 0 },
    { "silkAppLabel",                       0, 0 },
    /* pad record to 64-bit boundary */
    { "paddingOctets",                      6, 0 },
    FB_IESPEC_NULL
};

/* Keep this in sync with the ski_flow_spec above.. Pad to 64bits */
typedef struct rwIpfixRec_V3_st {
    uint64_t        flowStartMilliseconds;          /*   0-  7 */
    uint64_t        flowEndMilliseconds;            /*   8- 15 */

    uint8_t         sourceIPv6Address[16];          /*  16- 31 */
    uint8_t         destinationIPv6Address[16];     /*  32- 47 */

    uint32_t        sourceIPv4Address;              /*  48- 51 */
    uint32_t        destinationIPv4Address;         /*  52- 55 */

    uint16_t        sourceTransportPort;            /*  56- 57 */
    uint16_t        destinationTransportPort;       /*  58- 59 */

    uint32_t        ipNextHopIPv4Address;           /*  60- 63 */
    uint8_t         ipNextHopIPv6Address[16];       /*  64- 79 */
    uint32_t        ingressInterface;               /*  80- 83 */
    uint32_t        egressInterface;                /*  84- 87 */

    uint64_t        packetDeltaCount;               /*  88- 95 */
    uint64_t        octetDeltaCount;                /*  96-103 */

    uint8_t         protocolIdentifier;             /* 104     */
    flowtypeID_t    silkFlowType;                   /* 105     */
    sensorID_t      silkFlowSensor;                 /* 106-107 */

    uint8_t         tcpControlBits;                 /* 108     */
    uint8_t         initialTCPFlags;                /* 109     */
    uint8_t         unionTCPFlags;                  /* 110     */
    uint8_t         silkTCPState;                   /* 111     */
    uint16_t        silkAppLabel;                   /* 112-113 */
    uint8_t         pad[6];                         /* 114-119 */
} rwIpfixRec_V3_t;

static fbInfoElementSpec_t ski_extflow_spec[] = {
    /* Total counter support */
    { "packetTotalCount",                   0, 0 },
    { "octetTotalCount",                    0, 0 },
    /* Reverse counter support */
    { "reversePacketTotalCount",            0, 0 },
    { "reverseOctetTotalCount",             0, 0 },
    /* Microsecond start and end (RFC1305-style) (extended time) */
    { "flowStartMicroseconds",              0, 0 },
    { "flowEndMicroseconds",                0, 0 },
    /* Second start and end (extended time) */
    { "flowStartSeconds",                   0, 0 },
    { "flowEndSeconds",                     0, 0 },
    /* Flow durations (extended time) */
    { "flowDurationMicroseconds",           0, 0 },
    { "flowDurationMilliseconds",           0, 0 },
    /* Microsecond delta start and end (extended time) */
    { "flowStartDeltaMicroseconds",         0, 0 },
    { "flowEndDeltaMicroseconds",           0, 0 },
    /* Initial packet roundtrip */
    { "reverseFlowDeltaMilliseconds",       0, 0 },
    /* Reverse flags */
    { "reverseTcpControlBits",              0, 0 },
    { "reverseInitialTCPFlags",             0, 0 },
    { "reverseUnionTCPFlags",               0, 0 },
    /* End reason */
    { "flowEndReason",                      0, 0 },
    FB_IESPEC_NULL
};

typedef struct rwIpfixExtRec_V3_st {
    rwIpfixRec_V3_t rw;

    uint64_t        packetTotalCount;
    uint64_t        octetTotalCount;
    uint64_t        reversePacketTotalCount;
    uint64_t        reverseOctetTotalCount;

    /* Time can be represented in many different formats: */

    /* start time as NTP (RFC1305); may either have end Time in same
     * format or as an flowDurationMicroseconds value. */
    uint64_t        flowStartMicroseconds;
    uint64_t        flowEndMicroseconds;

    /* start time and end times as seconds since UNIX epoch. no
     * flowDuration field */
    uint32_t        flowStartSeconds;
    uint32_t        flowEndSeconds;

    /* elapsed time as either microsec or millisec.  used when the
     * flowEnd time is not given. */
    uint32_t        flowDurationMicroseconds;
    uint32_t        flowDurationMilliseconds;

    /* start time as delta (negative microsec offsets) from the export
     * time; may either have end time in same format or a
     * flowDurationMicroseconds value */
    uint32_t        flowStartDeltaMicroseconds;
    uint32_t        flowEndDeltaMicroseconds;

    /* start time of reverse flow, as millisec offset from start time
     * of forward flow */
    uint32_t        reverseFlowDeltaMilliseconds;

    /* Flags for the reverse flow: */
    uint8_t         reverseTcpControlBits;
    uint8_t         reverseInitialTCPFlags;
    uint8_t         reverseUnionTCPFlags;

    uint8_t         flowEndReason;
} rwIpfixExtRec_V3_t;

#define SKI_END_IDLE            1
#define SKI_END_ACTIVE          2
#define SKI_END_CLOSED          3
#define SKI_END_FORCED          4
#define SKI_END_RESOURCE        5
#define SKI_END_MASK            0x7f
#define SKI_END_ISCONT          0x80


static uint8_t zero_ipv6[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

#define IPV6_HAS_VALUE(ip)  memcmp((ip), zero_ipv6, sizeof(zero_ipv6))

static fbInfoModel_t *ski_model = NULL;




static fbInfoModel_t *skiInfoModel(void)
{
    if (!ski_model) {
        ski_model = fbInfoModelAlloc();
        fbInfoModelAddElementArray(ski_model, ski_info_elements);
    }

    return ski_model;
}

static void skiInfoModelFree(void)
{
    if (ski_model) {
        fbInfoModelFree(ski_model);
        ski_model = NULL;
    }
}


void skiCheckDataStructure(FILE *fh)
{
    unsigned long pos;

#define PRINT_TITLE(s_)                                         \
    fprintf(fh, "===> %s\n%5s|%5s|%5s|%5s|%5s|%s\n", #s_,       \
            "begin", "end", "size", "alerr", "hole", "member")

#define PRINT_OFFSET(pos_, s_, mem_)                                    \
    {                                                                   \
        s_ x;                                                           \
        unsigned long off_ = (unsigned long)offsetof(s_, mem_);         \
        unsigned long sz_  = (unsigned long)sizeof(x.mem_);             \
        unsigned long end_ = off_ + sz_ - 1;                            \
        int align_ = ((off_ % sz_) == 0);                               \
        int hole_ = (pos_ != off_);                                     \
        pos_ += sz_;                                                    \
        fprintf(fh, "%5lu|%5lu|%5lu|%5s|%5s|%s\n",                      \
                off_, end_, sz_, (align_ ? "" : "alerr"),               \
                (hole_ ? "hole" : ""), #mem_);                          \
    }

    pos = 0;
    PRINT_TITLE(rwIpfixRec_V3_t);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, flowStartMilliseconds);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, flowEndMilliseconds);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, sourceIPv6Address);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, destinationIPv6Address);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, sourceIPv4Address);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, destinationIPv4Address);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, sourceTransportPort);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, destinationTransportPort);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, ipNextHopIPv4Address);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, ipNextHopIPv6Address);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, ingressInterface);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, egressInterface);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, packetDeltaCount);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, octetDeltaCount);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, protocolIdentifier);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, silkFlowType);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, silkFlowSensor);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, tcpControlBits);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, initialTCPFlags);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, unionTCPFlags);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, silkTCPState);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, silkAppLabel);
    PRINT_OFFSET(pos, rwIpfixRec_V3_t, pad);

    pos = 0;
    PRINT_TITLE(rwIpfixExtRec_V3_t);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, rw);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, packetTotalCount);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, octetTotalCount);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, reversePacketTotalCount);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, reverseOctetTotalCount);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, flowStartMicroseconds);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, flowEndMicroseconds);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, flowStartSeconds);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, flowEndSeconds);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, flowDurationMicroseconds);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, flowDurationMilliseconds);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, flowStartDeltaMicroseconds);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, flowEndDeltaMicroseconds);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, reverseFlowDeltaMilliseconds);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, reverseTcpControlBits);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, reverseInitialTCPFlags);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, reverseUnionTCPFlags);
    PRINT_OFFSET(pos, rwIpfixExtRec_V3_t, flowEndReason);
}


fbListener_t *skiCreateListener(
    fbConnSpec_t            *spec,
    fbListenerAppInit_fn    appinit,
    fbListenerAppFree_fn    appfree,
    GError                  **err)
{
    fbInfoModel_t   *model = skiInfoModel();
    fbSession_t     *session = NULL;
    fbTemplate_t    *tmpl = NULL;
    fbListener_t    *listener = NULL;

    /* Allocate a session */
    session = fbSessionAlloc(model);

    /* Add the full record template */
    tmpl = fbTemplateAlloc(model);
    if (!fbTemplateAppendSpecArray(tmpl, ski_flow_spec, 0, err)) {
        goto err;
    }
    if (!fbSessionAddTemplate(session, TRUE, SKI_FLOW_TID, tmpl, err)) {
        goto err;
    }

    /* Add the extended record template */
    tmpl = fbTemplateAlloc(model);
    if (!fbTemplateAppendSpecArray(tmpl, ski_flow_spec, 0, err)) {
        goto err;
    }
    if (!fbTemplateAppendSpecArray(tmpl, ski_extflow_spec, 0, err)) {
        goto err;
    }
    if (!fbSessionAddTemplate(session, TRUE, SKI_EXTFLOW_TID, tmpl, err)) {
        goto err;
    }

    /* Allocate a listener */
    if (!(listener = fbListenerAlloc(spec, session, appinit, appfree, err))) {
        goto err;
    }

    return listener;

  err:
    fbTemplateFreeUnused(tmpl);
    if (session) {
        fbSessionFree(session);
    }
    return NULL;
}


fBuf_t *skiCreateReadBuffer(
    fbCollector_t   *collector,
    GError          **err)
{
    fbInfoModel_t   *model = skiInfoModel();
    fbSession_t     *session = NULL;
    fbTemplate_t    *tmpl = NULL;
    fBuf_t          *fbuf = NULL;

    /* Allocate a session */
    session = fbSessionAlloc(model);

    /* Add the full record template */
    tmpl = fbTemplateAlloc(model);
    if (!fbTemplateAppendSpecArray(tmpl, ski_flow_spec, 0, err)) {
        goto err;
    }
    if (!fbSessionAddTemplate(session, TRUE, SKI_FLOW_TID, tmpl, err)) {
        goto err;
    }

    /* Add the extended record template */
    tmpl = fbTemplateAlloc(model);
    if (!fbTemplateAppendSpecArray(tmpl, ski_flow_spec, 0, err)) {
        goto err;
    }
    if (!fbTemplateAppendSpecArray(tmpl, ski_extflow_spec, 0, err)) {
        goto err;
    }
    if (!fbSessionAddTemplate(session, TRUE, SKI_EXTFLOW_TID, tmpl, err)) {
        goto err;
    }

    /* Create a buffer with the session and supplied collector */
    fbuf = fBufAllocForCollection(session, collector);

    /* done */
    return fbuf;

  err:
    if (fbuf) {
        fBufFree(fbuf);
    } else {
        fbTemplateFreeUnused(tmpl);
        if (session) {
            fbSessionFree(session);
        }
    }
    return NULL;
}


fBuf_t *skiCreateReadBufferForFP(
    FILE            *fp,
    GError          **err)
{
    return skiCreateReadBuffer(fbCollectorAllocFP(NULL, fp), err);
}


fBuf_t *skiCreateWriteBuffer(
    fbExporter_t    *exporter,
    uint32_t        domain,
    GError          **err)
{
    fbInfoModel_t   *model = skiInfoModel();
    fbSession_t     *session = NULL;
    fbTemplate_t    *tmpl = NULL;
    fBuf_t          *fbuf = NULL;

    /* Allocate a session */
    session = fbSessionAlloc(model);

    /* set observation domain */
    fbSessionSetDomain(session, domain);

    /* Add the full record template */
    tmpl = fbTemplateAlloc(model);
    if (!fbTemplateAppendSpecArray(tmpl, ski_flow_spec, 0, err)) {
        goto err;
    }
    if (!fbSessionAddTemplate(session, TRUE, SKI_FLOW_TID, tmpl, err)) {
        goto err;
    }
    if (!fbSessionAddTemplate(session, FALSE, SKI_FLOW_TID, tmpl, err)) {
        goto err;
    }

    /* Create a buffer with the session and supplied exporter */
    fbuf = fBufAllocForExport(session, exporter);

    /* write RW base flow template */
    if (!fbSessionExportTemplates(session, err)) {
        goto err;
    }

    /* set default templates */
    if (!fBufSetInternalTemplate(fbuf, SKI_FLOW_TID, err)) {
        goto err;
    }
    if (!fBufSetExportTemplate(fbuf, SKI_FLOW_TID, err)) {
        goto err;
    }

    /* done */
    return fbuf;

  err:
    if (fbuf) {
        fBufFree(fbuf);
    } else {
        fbTemplateFreeUnused(tmpl);
        if (session) {
            fbSessionFree(session);
        }
    }
    return NULL;
}


fBuf_t *skiCreateWriteBufferForFP(
    FILE            *fp,
    uint32_t        domain,
    GError          **err)
{
    return skiCreateWriteBuffer(fbExporterAllocFP(fp), domain, err);
}


void skiTeardown(void)
{
    skiInfoModelFree();
}


/* Convert an NTP timestamp (RFC1305) to epoch millisecond */
static uint64_t skiNTPDecode(
    uint64_t        ntp)
{
    double          dntp;
    uint64_t        millis;

    if (!ntp) {
        return 0;
    }

    dntp = (ntp & 0xFFFFFFFF00000000LL) >> 32;
    dntp += ((ntp & 0x00000000FFFFFFFFLL) * 1.0) / (2LL << 32);
    millis = dntp * 1000;
    return millis;
}


gboolean skiRwNextRecord(
    fBuf_t      *fbuf,
    rwRec       *rec,
    rwRec       *revRec,
    GError      **err)
{
    rwIpfixExtRec_V3_t  fixrec;
    size_t              len;
    uint64_t            sTime, eTime;
    uint64_t            pkts, bytes;

    /* Set internal template to read an extended flow record */
    if (!fBufSetInternalTemplate(fbuf, SKI_EXTFLOW_TID, err)) {
        return FALSE;
    }

    /* Clear out the records */
    RWREC_CLEAR(rec);
    RWREC_CLEAR(revRec);

    /* Read a record; for IPv4 only, read until we get a v4 rec. */
#if !SK_ENABLE_IPV6
  get_rec:
#endif
    len = sizeof(fixrec);
    if (!fBufNext(fbuf, (uint8_t *)&fixrec, &len, err)) {
        return FALSE;
    }

    /* Handle the IP addresses */
    if (IPV6_HAS_VALUE(fixrec.rw.sourceIPv6Address)
        || IPV6_HAS_VALUE(fixrec.rw.destinationIPv6Address))
    {
#if !SK_ENABLE_IPV6
        /* ignore this record */
        goto get_rec;
#else
        /* Value in IPv6 addresses--use it */
        rwRecSetIPv6(rec);
        rwRecMemSetSIPv6(rec, &fixrec.rw.sourceIPv6Address);
        rwRecMemSetDIPv6(rec, &fixrec.rw.destinationIPv6Address);
        rwRecMemSetNhIPv6(rec, &fixrec.rw.ipNextHopIPv6Address);
#endif /* SK_ENABLE_IPV6 */
    } else {
        /* Take values from IPv4 */
        rwRecSetSIPv4(rec, fixrec.rw.sourceIPv4Address);
        rwRecSetDIPv4(rec, fixrec.rw.destinationIPv4Address);
        rwRecSetNhIPv4(rec, fixrec.rw.ipNextHopIPv4Address);
    }

    /* Run the Gauntlet of Time - convert all the various ways an IPFIX
     * record's time could be represented into start and elapsed times. */
    if (fixrec.rw.flowStartMilliseconds) {
        /* Flow start time in epoch milliseconds */
        rwRecSetStartTime(rec, (sktime_t)fixrec.rw.flowStartMilliseconds);
        if (fixrec.rw.flowEndMilliseconds >= fixrec.rw.flowStartMilliseconds) {
            /* Flow end time in epoch milliseconds */
            rwRecSetElapsed(rec,(uint32_t)(fixrec.rw.flowEndMilliseconds
                                           -fixrec.rw.flowStartMilliseconds));
        } else {
            /* Flow duration in milliseconds */
            rwRecSetElapsed(rec, fixrec.flowDurationMilliseconds);
        }
    } else if (fixrec.flowStartMicroseconds) {
        /* Flow start time in NTP microseconds */
        sTime = skiNTPDecode(fixrec.flowStartMicroseconds);
        rwRecSetStartTime(rec, (sktime_t)sTime);
        if (fixrec.flowEndMicroseconds >= fixrec.flowStartMicroseconds) {
            /* Flow end time in NTP microseconds */
            rwRecSetElapsed(rec,
                            (uint32_t)(skiNTPDecode(fixrec.flowEndMicroseconds)
                                       - sTime));
        } else {
            /* Flow duration in microseconds */
            rwRecSetElapsed(rec, (fixrec.flowDurationMicroseconds / 1000));
        }
    } else if (fixrec.flowStartSeconds) {
        /* Seconds? Sure, why not. */
        rwRecSetStartTime(rec, (sktime_t)1000 * fixrec.flowStartSeconds);
        rwRecSetElapsed(rec, ((sktime_t)1000 * (fixrec.flowEndSeconds
                                                - fixrec.flowStartSeconds)));
    } else if (fixrec.flowStartDeltaMicroseconds) {
        /* Flow start time in delta microseconds */
        sTime = (fBufGetExportTime(fbuf) * 1000
                 - fixrec.flowStartDeltaMicroseconds / 1000);
        rwRecSetStartTime(rec, (sktime_t)sTime);
        if (fixrec.flowEndDeltaMicroseconds
            && (fixrec.flowEndDeltaMicroseconds
                <= fixrec.flowStartDeltaMicroseconds))
        {
            /* Flow end time in delta microseconds */
            eTime = (fBufGetExportTime(fbuf) * 1000
                     - fixrec.flowEndDeltaMicroseconds / 1000);
            rwRecSetElapsed(rec, (uint32_t)(eTime - sTime));
        } else {
            /* Flow duration in microseconds */
            rwRecSetElapsed(rec, (fixrec.flowDurationMicroseconds / 1000));
        }
    } else {
        /* No per-flow time information.
         * Assume message export is flow end time. */
        if (fixrec.flowDurationMilliseconds) {
            /* Flow duration in milliseconds */
            rwRecSetElapsed(rec, fixrec.flowDurationMilliseconds);
        } else if (fixrec.flowDurationMicroseconds) {
            /* Flow duration in microseconds */
            rwRecSetElapsed(rec, (fixrec.flowDurationMicroseconds / 1000));
        } else {
            /* Presume zero duration flow */
            rwRecSetElapsed(rec, 0);
        }
        /* Set start time based on export and elapsed time */
        rwRecSetStartTime(rec, ((sktime_t)1000 * (fBufGetExportTime(fbuf)
                                                  - rwRecGetElapsed(rec))));
    }

    /* Use either delta or total count for bytes and packets */
    pkts = fixrec.rw.packetDeltaCount;
    if (!pkts) {
        pkts = fixrec.packetTotalCount;
    }
    bytes = fixrec.rw.octetDeltaCount;
    if (!bytes) {
        bytes = fixrec.octetTotalCount;
    }

    /* Clamp packet and bytes counts to 32 bits. */
    rwRecSetPkts(rec, ((pkts > UINT32_MAX) ? UINT32_MAX : pkts));
    rwRecSetBytes(rec, ((bytes > UINT32_MAX) ? UINT32_MAX : bytes));

    /* Copy the rest of the record */
    rwRecSetSPort(rec, fixrec.rw.sourceTransportPort);
    rwRecSetDPort(rec, fixrec.rw.destinationTransportPort);
    rwRecSetInput(rec, (uint16_t)fixrec.rw.ingressInterface);
    rwRecSetOutput(rec, (uint16_t)fixrec.rw.egressInterface);
    rwRecSetProto(rec, fixrec.rw.protocolIdentifier);
    rwRecSetFlowType(rec, fixrec.rw.silkFlowType);
    rwRecSetSensor(rec, fixrec.rw.silkFlowSensor);
    rwRecSetFlags(rec, fixrec.rw.tcpControlBits);
    rwRecSetInitFlags(rec, fixrec.rw.initialTCPFlags);
    rwRecSetRestFlags(rec, fixrec.rw.unionTCPFlags);
    rwRecSetTcpState(rec, fixrec.rw.silkTCPState);
    rwRecSetApplication(rec, fixrec.rw.silkAppLabel);

    /* Generate full flags from initial and rest if necessary */
    if (!rwRecGetFlags(rec)) {
        rwRecSetFlags(rec, rwRecGetInitFlags(rec) | rwRecGetRestFlags(rec));
    }

    /* Convert TCP state info */
    if (!rwRecGetTcpState(rec)) {
        /* Note expanded flags */
        uint8_t tcp_state = 0;
        if ((rwRecGetInitFlags(rec) | rwRecGetRestFlags(rec)) ||
            fbTemplateContainsElement(fBufGetCollectionTemplate(fbuf, NULL),
                                      &ski_init_flags_ie))
        {
            tcp_state |= SK_TCPSTATE_EXPANDED;
        }
        /* Note active timeout */
        if ((fixrec.flowEndReason & SKI_END_MASK) == SKI_END_ACTIVE) {
            tcp_state |= SK_TCPSTATE_TIMEOUT_KILLED;
        }
        /* Note continuation */
        if (fixrec.flowEndReason & SKI_END_ISCONT) {
            tcp_state |= SK_TCPSTATE_TIMEOUT_STARTED;
        }
        rwRecSetTcpState(rec, tcp_state);
    }

    /* Fill in reverse record if available */
    if (revRec) {
        if (fixrec.reverseOctetTotalCount) {
            /* Start with the forward record */
            memcpy(revRec, rec, sizeof(*rec));

            /* Reverse the key */
#if SK_ENABLE_IPV6
            if (rwRecIsIPv6(rec)) {
                uint8_t ip[16];
                rwRecMemGetSIPv6(rec, ip);
                rwRecMemSetDIPv6(revRec, ip);
                rwRecMemGetDIPv6(rec, ip);
                rwRecMemSetSIPv6(revRec, ip);
            } else
#endif
            {
                rwRecSetSIPv4(revRec, rwRecGetDIPv4(rec));
                rwRecSetDIPv4(revRec, rwRecGetSIPv4(rec));
            }

            rwRecSetSPort(revRec, rwRecGetDPort(rec));
            rwRecSetDPort(revRec, rwRecGetSPort(rec));

            /* Calculate reverse start time from reverse RTT */

            /* Reverse flow's start time must be increased and its
             * duration decreased by its offset from the forward
             * record  */
            rwRecSetStartTime(revRec, (rwRecGetStartTime(rec)
                                       + fixrec.reverseFlowDeltaMilliseconds));
            rwRecSetElapsed(revRec, (rwRecGetElapsed(rec)
                                     - fixrec.reverseFlowDeltaMilliseconds));

            /* Get reverse counters from the IPFIX record */
            /* FIXME need to try to use reverse delta counts
             * too now that we have them.
             */
            rwRecSetPkts(revRec, ((fixrec.reversePacketTotalCount > UINT32_MAX)
                                  ? UINT32_MAX
                                  : fixrec.reversePacketTotalCount));
            rwRecSetBytes(revRec, ((fixrec.reverseOctetTotalCount > UINT32_MAX)
                                   ? UINT32_MAX
                                   : fixrec.reverseOctetTotalCount));

            /* Get reverse TCP flags from the IPFIX record */
            rwRecSetFlags(revRec, fixrec.reverseTcpControlBits);
            rwRecSetInitFlags(revRec, fixrec.reverseInitialTCPFlags);
            rwRecSetRestFlags(revRec, fixrec.reverseUnionTCPFlags);

            /* Generate full flags from initial and rest if necessary */
            if (!rwRecGetFlags(revRec)) {
                rwRecSetFlags(revRec, (rwRecGetInitFlags(revRec)
                                       | rwRecGetRestFlags(revRec)));
            }
        } else {
            /* Zero the reverse record if we don't have one. */
            memset(revRec, 0, sizeof(*revRec));
        }
    }

    /* all done */
    return TRUE;
}


gboolean skiRwAppendRecord(
    fBuf_t      *fbuf,
    const rwRec *rec,
    GError     **err)
{
    rwIpfixRec_V3_t     fixrec;

    /* Convert time from start/elapsed to start and end epoch millis. */
    fixrec.flowStartMilliseconds = (uint64_t)rwRecGetStartTime(rec);
    fixrec.flowEndMilliseconds = ((uint64_t)fixrec.flowStartMilliseconds
                                  + rwRecGetElapsed(rec));

    /* Handle IP addresses */
#if SK_ENABLE_IPV6
    if (rwRecIsIPv6(rec)) {
        rwRecMemGetSIPv6(rec, fixrec.sourceIPv6Address);
        rwRecMemGetDIPv6(rec, fixrec.destinationIPv6Address);
        rwRecMemGetNhIPv6(rec, fixrec.ipNextHopIPv6Address);
        fixrec.sourceIPv4Address = 0;
        fixrec.destinationIPv4Address = 0;
        fixrec.ipNextHopIPv4Address = 0;
    } else
#endif
    {
        memset(fixrec.sourceIPv6Address, 0,
               sizeof(fixrec.sourceIPv6Address));
        memset(fixrec.destinationIPv6Address, 0,
               sizeof(fixrec.destinationIPv6Address));
        memset(fixrec.ipNextHopIPv6Address, 0,
               sizeof(fixrec.ipNextHopIPv6Address));
        fixrec.sourceIPv4Address = rwRecGetSIPv4(rec);
        fixrec.destinationIPv4Address = rwRecGetDIPv4(rec);
        fixrec.ipNextHopIPv4Address = rwRecGetNhIPv4(rec);
    }

    /* Copy rest of record */
    fixrec.sourceTransportPort = rwRecGetSPort(rec);
    fixrec.destinationTransportPort = rwRecGetDPort(rec);
    fixrec.ingressInterface = rwRecGetInput(rec);
    fixrec.egressInterface = rwRecGetOutput(rec);
    fixrec.packetDeltaCount = rwRecGetPkts(rec);
    fixrec.octetDeltaCount = rwRecGetBytes(rec);
    fixrec.protocolIdentifier = rwRecGetProto(rec);
    fixrec.silkFlowType = rwRecGetFlowType(rec);
    fixrec.silkFlowSensor = rwRecGetSensor(rec);
    fixrec.tcpControlBits = rwRecGetFlags(rec);
    fixrec.initialTCPFlags = rwRecGetInitFlags(rec);
    fixrec.unionTCPFlags = rwRecGetRestFlags(rec);
    fixrec.silkTCPState = rwRecGetTcpState(rec);
    fixrec.silkAppLabel = rwRecGetApplication(rec);

    /* Append the record to the buffer */
    if (!fBufAppend(fbuf, (uint8_t *)&fixrec, sizeof(fixrec), err)) {
        return FALSE;
    }

    /* all done */
    return TRUE;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
