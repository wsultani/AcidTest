/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/
#ifndef _RWCUT_H
#define _RWCUT_H

#include "silk.h"

RCSIDENTVAR(rcsID_RWCUT_H, "$SiLK: rwcut.h 10004 2008-01-04 23:08:59Z mthomas $");

/*
**  cut.h
**
**  Header file for the rwcut application.  See rwcut.c for a full
**  explanation.
**
*/

#include "utils.h"
#include "rwpack.h"
#include "iochecks.h"
#include "dynlib.h"
#include "skvector.h"
#include "skstringmap.h"
#include "sksite.h"


/* TYPEDEFS AND DEFINES */

/* Maximum column width */
#define RWCUT_MAX_COLUMN_WIDTH  256


/* User options */
typedef struct cut_opt_flags_st {
    unsigned integer_ips        :1;
    unsigned zero_pad_ips       :1;
    unsigned no_titles          :1;
    unsigned fromEOF            :1;
    unsigned printFileName      :1;
    unsigned no_final_delimiter :1;
    unsigned no_columns         :1;
    unsigned icmpTandC          :1;
    unsigned integerSensor      :1;
    unsigned dry_run            :1;
} cut_opt_flags_t;

/* record counter */
typedef struct countersStruct_st {
    uint32_t firstRec;
    uint32_t lastRec;
    uint32_t numRecs;
} countersStruct;

/* function that plugins must supply */
typedef int (*cutf_t)(unsigned int, char *, size_t, rwRec *);

/* Internal interface to libdynlib */
typedef struct app_dynlib_st {
    dynlibInfoStruct   *dlisp;  /* the libdynlib object */
    unsigned int        offset; /* number of field just before this dynlib */
    cutf_t              fxn;    /* function to get output from dynlib */
} app_dynlib_t;

/*
 * Structure describing the output functions for printing the fields.
 * Only one of 'a_stream' or 'cutf_wrap' is used: Fields that are part
 * of the standard rwrec are printed with an rwAsciiStream_t; those
 * that come from a plug-in must be determined by calling the
 * plug-in's cut() function, which the cutf_wrap has a reference
 * to.
 *
 * A union may make logical sense here, but we don't really gain
 * anything by using one.
 */
typedef struct out_stream_st {
    /* Call rwAsciiPrintRec() with this stream as first arg */
    rwAsciiStream_t *a_stream;
    /* Call the cut_fxn below with field_id as the first arg */
    struct cutf_wrap_st {
        cutf_t  cut_fxn;
        int     field_id;
        int     field_width;
    } cutf_wrap;
} out_stream_t;


/* rwcut.c */

/* The output stream: where to print the records */
extern FILE *stream_out;

/* rw-file that is currently been read */
extern rwIOStruct_t *rwIOS;

/* interface to the iochecks library */
extern iochecksInfoStruct_t *ioISP;

/* global limits */
extern countersStruct globalCounters;

/* user's options */
extern cut_opt_flags_t cut_opts;

/* delimiter between columns */
extern char delimiter;

/* how to handle IPv6 flows */
extern sk_ipv6policy_t ipv6_policy;

/* how to print timesamps */
extern uint32_t time_flags;

/* available fields */
extern sk_stringmap_t *field_map;

/* Array of out_stream_t* */
extern out_stream_t **outputs;

/* Count of 'outputs' */
extern size_t output_count;

/* Maximum number of dynamic libraries that rwcut can open */
#define APP_MAX_DYNLIBS 8

/* List of dynamic libraries to attempt to open at startup */
extern const char *app_dynlib_names[];

/* Dynamic libraries we actually opened */
extern app_dynlib_t app_dynlib_list[APP_MAX_DYNLIBS];

/* Number of dynamic libraries actually opened */
extern int app_dynlib_count;


void appTeardown(void);
void appSetup(int argc, char **argv);
void writeColTitles(void);


#endif /* _RWCUT_H */

/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
