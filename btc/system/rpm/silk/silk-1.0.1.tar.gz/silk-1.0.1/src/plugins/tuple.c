/*
** Copyright (C) 2006-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

#include "silk.h"

RCSIDENT("$SiLK: tuple.c 11248 2008-04-11 19:07:39Z mthomas $");

#include "rwpack.h"
#include "dynlib.h"
#include "skvector.h"
#include "skstream.h"
#include "redblack.h"


/* EXPORTED FUNCTIONS */

/* The dynamic library glue code calls these */
int dynlib_api_version(void);
int setup(dynlibInfoStruct *dlISP, dynlibSymbolId appType);
void teardown(dynlibSymbolId appType);
void optionsUsage(dynlibSymbolId appType, FILE *fh);
int initialize(dynlibInfoStruct *dlISP, dynlibSymbolId appType);
int check(rwRec *rwrec);


/* DEFINES AND TYPEDEFS */

/* Whether we should use this plug-in to replace the --ipport and
 * --ippair plug-ins.  The one difficulty is that if the user has used
 * TABS to separate the two fields, the tuple code will not see a
 * delimiter between the two columns and complain. */
#ifndef TUPLE_IMPLEMENTS_IPP
#  define TUPLE_IMPLEMENTS_IPP 1
#endif



/* Maximum number of fields we support */
#define TUPLE_MAX  5

/*
 *  As we read the user's text file, we create nodes and hand pointers
 *  those nodes to the redblack tree.  We want to avoid doing an
 *  allocation for every node, but we cannot create a large memory
 *  block and realloc() it later since that will make redblack's
 *  pointers invalid.  Instead, we'll use a vector of array of nodes,
 *  where each array contains NODE_ARRAY_SIZE nodes.
 */
#define NODE_ARRAY_SIZE  65536

/* the possible direction(s) for the user's test */
#define  TUPLE_FORWARD   (1 << 0)
#define  TUPLE_REVERSE   (1 << 1)

/* a CIDR block, used for sip and dip */
typedef struct tuple_cidr_st {
    skIPWildcard_t          ipwild;
    skIPWildcardIterator_t  iter;
} tuple_cidr_t;

/* a list of numbers, used for ports and protocols */
typedef struct number_list_st {
    /* the number list */
    uint32_t   *list;
    /* the length of the list */
    uint32_t    count;
    /* the current index into that list */
    uint32_t    idx;
} number_list_t;


/* LOCAL VARIABLES */

/* the name of this plugin */
static const char *pluginName = "tuple";

/* the vector of node arrays */
static sk_vector_t *array_vec;

/* the redblack tree */
static struct rbtree *rb = NULL;

/* the direction to test;  */
static int direction = TUPLE_FORWARD;

/* available directions, used when parsing */
static const sk_stringmap_entry_t direction_list[] = {
    {"forward",  TUPLE_FORWARD},
    {"reverse",  TUPLE_REVERSE},
    {"both",     TUPLE_FORWARD | TUPLE_REVERSE},
    {0,0}       /* sentinel */
};

/* the delimiter between columns */
static char delimiter = '|';

/* the name of the file to process */
static const char *input_file = NULL;

/* the number of fields in each input line */
static uint32_t num_fields = 0;

/* the total length of the byte-array for each node */
static size_t node_length = 0;

/* data about each field in the node */
static struct field_st {
    /* the type of this field (SIP, DIP, etc) */
    uint32_t    type;
    /* byte offset of this field from start of the node */
    size_t      offset;
    /* byte length of this field */
    size_t      length;
} field[TUPLE_MAX];

/* the field map is used when parsing field names */
static sk_stringmap_t *field_map = NULL;

/* the list of fields we support.  copied from rwascii.c. */
static const sk_stringmap_entry_t field_map_entries[] = {
    {"sIP",          RWREC_FIELD_SIP},
    {"sip",          RWREC_FIELD_SIP},
    {"1",            RWREC_FIELD_SIP},
    {"dIP",          RWREC_FIELD_DIP},
    {"dip",          RWREC_FIELD_DIP},
    {"2",            RWREC_FIELD_DIP},
    {"sPort",        RWREC_FIELD_SPORT},
    {"sport",        RWREC_FIELD_SPORT},
    {"3",            RWREC_FIELD_SPORT},
    {"dPort",        RWREC_FIELD_DPORT},
    {"dport",        RWREC_FIELD_DPORT},
    {"4",            RWREC_FIELD_DPORT},
    {"protocol",     RWREC_FIELD_PROTO},
    {"5",            RWREC_FIELD_PROTO}
};

static const size_t field_map_count = (sizeof(field_map_entries)
                                       / sizeof(sk_stringmap_entry_t));


/*
 * Options that get added to rwfilter.
 */
typedef enum {
    OPT_TUPLE_FILE, OPT_TUPLE_FIELDS,
    OPT_TUPLE_DIRECTION, OPT_TUPLE_DELIMITER
#if  TUPLE_IMPLEMENTS_IPP
    ,OPT_IPPAIR_ANY, OPT_IPPORT_ANY
#endif
} filterOptionsEnum;

static struct option filterOptions[] = {
    {"tuple-file",          REQUIRED_ARG, 0, OPT_TUPLE_FILE},
    {"tuple-fields",        REQUIRED_ARG, 0, OPT_TUPLE_FIELDS},
    {"tuple-direction",     REQUIRED_ARG, 0, OPT_TUPLE_DIRECTION},
    {"tuple-delimiter",     REQUIRED_ARG, 0, OPT_TUPLE_DELIMITER},
#if  TUPLE_IMPLEMENTS_IPP
    {"ippair-any",          REQUIRED_ARG, 0, OPT_IPPAIR_ANY},
    {"ipport-any",          REQUIRED_ARG, 0, OPT_IPPORT_ANY},
#endif
    {0, 0, 0, 0}            /* sentinel */
};

static const char *filterOptionsHelp[] = {
    ("File containing 1 to 5 columns (fields) from the set\n"
     "\t{sIP,dIP,sPort,dPort,proto} to compare against each record. Pass the\n"
     "\trecord if it matches"),
    "Field(s) in input. List fields separated by commas:",
    "Specify how the fields map to the records:",
    "Character separating the input fields. Def. '|'",
#if  TUPLE_IMPLEMENTS_IPP
    ("The (sIP,dIP) pair or (dIP,sIP) pair appears in the\n"
     "\tlist of IP-pairs read from the named text file. DEPRECATED"),
    ("Wanted file of IP addresses and ports.\n"
     "\tPass the record if its IP / port is in this list. DEPRECATED"),
#endif
    (char*)NULL
};


/* LOCAL FUNCTION DECLARATIONS */

static int compare(const void *pa, const void *pb, const void *config);
static uint8_t *growMemory(void);
static int initializeMemory(void);
static int optionsHandler(clientData cData, int opt_index, char *opt_arg);
static int parsefile(void);
static int parseFieldNames(const char *field_string);
static int parseDirection(const char *direction_str);


/* FUNCTION DEFINITIONS */


/*
 *  int dynlib_api_version(void);
 *
 *    Return the dynlib API version that this plugin was compiled
 *    against.
 */
int dynlib_api_version(void)
{
    return DYNLIB_API_VERSION;
}


/*
 *  setup
 *      Called by dynlib interface code to setup this plugin.  This
 *      routine should set up options handling, if required.
 *  Arguments:
 *      --pointer to the dynamic library interface structure
 *      --Application type that is using this plugin.
 *  Returns:
 *      DYNLIB_FAILED - if processing fails
 *      DYNLIB_WONTPROCESS - if application should do normal output
 *      DYNLIB_WILLPROCESS - if this plugin takes over output
 *  Side Effects:
 */
int setup(
    dynlibInfoStruct   *dlISP,
    dynlibSymbolId      appType)
{
    /* verify same number of options and help strings */
    assert((sizeof(filterOptions)/sizeof(struct option))
           == (sizeof(filterOptionsHelp)/sizeof(char*)));

    /* Make the plugin use the application's context, so we can add
     * options to main app. */
    skAppContextSet(dynlibGetAppContext(dlISP));

    /* initialize data */
    array_vec = NULL;

    /* this plug-in only supports rwfilter */
    switch (appType) {
      case DYNLIB_SHAR_FILTER:
      case DYNLIB_EXCL_FILTER:
        if (skOptionsRegister(filterOptions,&optionsHandler,(clientData)dlISP))
        {
            skAppPrintErr("Unable to register options for %s plugin",
                          pluginName);
            return 1;
        }
        break;

      default:
        skAppPrintErr("Cannot use %s plug-in with %s application",
                      pluginName, skAppName());
        return 1;
    }

    /* Create the mapping of field names to value */
    if (SKSTRINGMAP_OK != skStringMapCreate(&field_map)) {
        return 1;
    }
    /* add entries */
    if (skStringMapAddIDArray(field_map, field_map_count, field_map_entries)
        != SKSTRINGMAP_OK)
    {
        return 1;
    }

    /* we're only a pass/fail plug-in */
    return DYNLIB_WONTPROCESS;
}


/*
 *  teardown
 *      Called by dynlib interface code to tear down this plugin.
 *  Arguments:
 *      --Application type that is using this plugin
 *  Returns:
 *      None.
 */
void teardown(
    dynlibSymbolId      UNUSED(appType))
{
    static int teardownFlag = 0;
    size_t i;
    void *a;

    if (teardownFlag) {
        return;
    }
    teardownFlag = 1;

    /* destroy the string map */
    if (field_map) {
        skStringMapDestroy(field_map);
        field_map = NULL;
    }

    /* destroy the redblack trees */
    if (rb) {
        rbdestroy(rb);
        rb = NULL;
    }

    /* destroy the vector of array of nodes */
    if (array_vec) {
        for (i = 0; i < skVectorGetCount(array_vec); ++i) {
            skVectorGetValue(&a, array_vec, i);
            free(a);
        }
        skVectorDestroy(array_vec);
        array_vec = NULL;
    }

    return;
}


/*
 *  optionsUsage
 *      Called by dynlib interface code to allow this plugin to print
 *      the options it accepts.
 *  Arguments:
 *      --Application type that is using this plugin
 *  Returns:
 *      None.
 *  Side Effects:
 *      None.
 */
void optionsUsage(dynlibSymbolId UNUSED(appType), FILE *fh)
{
    int i;
    int j;

    for (i = 0; filterOptions[i].name != NULL; ++i) {
        fprintf(fh, "--%s %s. ", filterOptions[i].name,
                SK_OPTION_HAS_ARG(filterOptions[i]));
        switch (filterOptions[i].val) {
          case OPT_TUPLE_FIELDS:
            fprintf(fh, "%s\n", filterOptionsHelp[i]);
            rwAsciiFieldMapPrintUsage(fh, field_map);
            break;

          case OPT_TUPLE_DIRECTION:
            fprintf(fh, "%s\n", filterOptionsHelp[i]);
            for (j = 0; direction_list[j].name; ++j) {
                fprintf(fh, "\t%-8s- ", direction_list[j].name);
                if (direction_list[j].id == TUPLE_FORWARD) {
                    fprintf(fh, ("Map sIP,sPort to sIP,sPort;"
                                 " dIP,dPort to dIP,dPort. [Def]"));
                } else if (direction_list[j].id == TUPLE_REVERSE) {
                    fprintf(fh, ("Map sIP,sPort to dIP,dPort;"
                                 " dIP,dPort to sIP,sPort"));
                } else {
                    fprintf(fh,"Map sIP,sPort to sIP,sPort or dIP,dPort; etc");
                }
                fprintf(fh, "\n");
            }
            break;

          default:
            fprintf(fh, "%s\n", filterOptionsHelp[i]);
            break;
        }
    }
}


/*
 *  optionsHandler
 *      Called by options parser to handle one user option
 *  Arguments:
 *      clientData cData: the dynamic lib interface struct pointer
 *      int index: index into appOptions of the specific option
 *      char *optarg: the argument; 0 if no argument was required/given.
 * Returns:
 *      0 if OK. 1 else.
 * Side Effects:
 *      Relevant options are set.
 */
static int optionsHandler(clientData cData, int opt_index, char *opt_arg)
{
#if  TUPLE_IMPLEMENTS_IPP
    static int ippair = 0;
    static int ipport = 0;

    if (ippair) {
        if (opt_index == OPT_IPPAIR_ANY) {
            skAppPrintErr("The --%s switch was specified multiple times",
                          filterOptions[opt_index].name);
        } else {
            skAppPrintErr("Cannot use both --%s and --%s switches",
                          filterOptions[opt_index].name,
                          filterOptions[OPT_IPPAIR_ANY].name);
        }
        return 1;
    }
    if (ipport) {
        if (opt_index == OPT_IPPORT_ANY) {
            skAppPrintErr("The --%s switch was specified multiple times",
                          filterOptions[opt_index].name);
        } else {
            skAppPrintErr("Cannot use both --%s and --%s switches",
                          filterOptions[opt_index].name,
                          filterOptions[OPT_IPPORT_ANY].name);
        }
        return 1;
    }
#endif  /* TUPLE_IMPLEMENTS_IPP */

    switch (opt_index) {
      case OPT_TUPLE_FILE:
        if (input_file) {
            skAppPrintErr("The --%s switch was specified multiple times",
                          filterOptions[opt_index].name);
            return 1;
        }
        input_file = opt_arg;
        break;

      case OPT_TUPLE_DIRECTION:
        if (parseDirection(opt_arg)) {
            skAppPrintErr("Invalid --%s value: '%s'",
                          filterOptions[opt_index].name, opt_arg);
            return 1;
        }
        break;

      case OPT_TUPLE_DELIMITER:
        delimiter = opt_arg[0];
        if (delimiter == '\0') {
            skAppPrintErr("The empty string is not a valid delimiter");
            return 1;
        }
        break;

      case OPT_TUPLE_FIELDS:
        if (num_fields > 0) {
            skAppPrintErr("The --%s switch was specified multiple times",
                          filterOptions[opt_index].name);
            return 1;
        }
        if (parseFieldNames(opt_arg)) {
            return 1;
        }
        break;

#if  TUPLE_IMPLEMENTS_IPP
      case OPT_IPPAIR_ANY:
        input_file = opt_arg;
        delimiter = ' ';
        direction = TUPLE_FORWARD | TUPLE_REVERSE;
        parseFieldNames("sIP,dIP");
        break;

      case OPT_IPPORT_ANY:
        input_file = opt_arg;
        delimiter = ' ';
        direction = TUPLE_FORWARD | TUPLE_REVERSE;
        parseFieldNames("sIP,sPort");
        break;
#endif  /* TUPLE_IMPLEMENTS_IPP */
    }

    /* Tell the dynlib glue-code that we are active. */
    dynlibMakeActive((dynlibInfoStruct*)cData);

    return 0;
}


int initialize(
    dynlibInfoStruct    UNUSED(*dlISP),
    dynlibSymbolId      UNUSED(appType))
{
    /* Verify that we have a file name */
    if (input_file == NULL || input_file[0] == '\0') {
        skAppPrintErr("Expected name of %s file",
                      filterOptions[OPT_TUPLE_FILE].name);
        return 1;
    }

    if (initializeMemory()) {
        return 1;
    }

    if (parsefile()) {
        return 1;
    }

    return 0;
}


/*
 *  check
 *      Called by dynlib interface code to filter records
 *  Arguments:
 *      a RW record
 *  Returns:
 *      0 to accept the record, 1 to reject the record
 */
int check(
    rwRec              *rwrec)
{
    uint8_t key[SK_MAX_RECORD_SIZE];
    uint32_t i;

    if (direction & TUPLE_FORWARD) {
        for (i = 0; i < num_fields; ++i) {
            switch (field[i].type) {
              case RWREC_FIELD_SIP:
#if SK_ENABLE_IPV6
                rwRecMemGetSIPv6(rwrec, key + field[i].offset);
#else
                rwRecMemGetSIPv4(rwrec, key + field[i].offset);
#endif
                break;

              case RWREC_FIELD_DIP:
#if SK_ENABLE_IPV6
                rwRecMemGetDIPv6(rwrec, key + field[i].offset);
#else
                rwRecMemGetDIPv4(rwrec, key + field[i].offset);
#endif
                break;

              case RWREC_FIELD_SPORT:
                rwRecMemGetSPort(rwrec, key + field[i].offset);
                break;

              case RWREC_FIELD_DPORT:
                rwRecMemGetDPort(rwrec, key + field[i].offset);
                break;

              case RWREC_FIELD_PROTO:
                rwRecMemGetProto(rwrec, key + field[i].offset);
                break;

              default:
                skAppPrintErr("Found unsupported field value %d",
                              field[i].type);
                abort();
            }
        }

        if (rbfind(&key, rb) != NULL) {
            /* found it */
            return 0;
        }
    }

    if (direction & TUPLE_REVERSE) {
        for (i = 0; i < num_fields; ++i) {
            switch (field[i].type) {
              case RWREC_FIELD_SIP:
#if SK_ENABLE_IPV6
                rwRecMemGetDIPv6(rwrec, key + field[i].offset);
#else
                rwRecMemGetDIPv4(rwrec, key + field[i].offset);
#endif
                break;

              case RWREC_FIELD_DIP:
#if SK_ENABLE_IPV6
                rwRecMemGetSIPv6(rwrec, key + field[i].offset);
#else
                rwRecMemGetSIPv4(rwrec, key + field[i].offset);
#endif
                break;

              case RWREC_FIELD_SPORT:
                rwRecMemGetDPort(rwrec, key + field[i].offset);
                break;

              case RWREC_FIELD_DPORT:
                rwRecMemGetSPort(rwrec, key + field[i].offset);
                break;

              case RWREC_FIELD_PROTO:
                rwRecMemGetProto(rwrec, key + field[i].offset);
                break;

              default:
                skAppPrintErr("Found unsupported field value %d",
                              field[i].type);
                abort();
            }
        }

        if (rbfind(&key, rb) != NULL) {
            /* found it */
            return 0;
        }
    }

    /* no match */
    return 1;
}


/*
 *  gt_lt_eq = compare(key_a, key_b, config);
 *
 *    Comparison function for the redblack tree; compares the
 *    keyortpair_t's key_a and key_b, returning -1 if key_a comes
 *    before key_b.
 */
static int compare(
    const void         *pa,
    const void         *pb,
    const void  UNUSED(*config))
{
    return memcmp(pa, pb, node_length);
}


/*
 *  new_mem = growMemory();
 *
 *    Create a new array of nodes for the redblack tree, put a pointer
 *    to that array into the global 'array_vec', and return the array.
 *    Return NULL for an allocation error.
 */
static uint8_t *growMemory(void)
{
    uint8_t *new_mem;

    assert(array_vec != NULL);
    new_mem = calloc(NODE_ARRAY_SIZE, node_length);
    if (new_mem == NULL) {
        return NULL;
    }

    if (skVectorAppendValue(array_vec, &new_mem)) {
        free(new_mem);
        return NULL;
    }

    return new_mem;
}


/*
 *  ok = initializeMemory();
 *
 *    Create a redblack tree to hold information about the tuples.
 *
 *    Create the global 'array_vec' that is used to store pointers to
 *    arrays of nodes that we feed to redblack.
 *
 *    Return 0 on success, or non-zero on allocation failure.
 */
static int initializeMemory(void)
{
    /* Create the vectory to store the array of nodes */
    array_vec = skVectorNew(sizeof(uint8_t**));
    if (array_vec == NULL) {
        skAppPrintErr("Insufficient memory to create vector");
        return -1;
    }

    /* Create the redblack tree */
    rb = rbinit(&compare, NULL);
    if (rb == NULL) {
        skAppPrintErr("Insufficient memory to create redblack tree");
        return -1;
    }

    return 0;
}


/* parse the user's direction string */
static int parseDirection(const char *direction_str)
{
    sk_stringmap_t *str_map = NULL;
    sk_stringmap_status_t rv_map;
    sk_stringmap_entry_t *map_entry;
    int rv = -1;

    /* create a stringmap of the available entries */
    if (SKSTRINGMAP_OK != skStringMapCreate(&str_map)) {
        skAppPrintErr("Unable to create stringmap");
        goto END;
    }
    if (skStringMapAddIDArray(str_map, -1, direction_list) != SKSTRINGMAP_OK)
    {
        goto END;
    }

    /* attempt to match */
    rv_map = skStringMapGetEntry(&map_entry, str_map, direction_str);
    switch (rv_map) {
      case SKSTRINGMAP_OK:
        direction = map_entry->id;
        rv = 0;
        break;

      case SKSTRINGMAP_PARSE_AMBIGUOUS:
        skAppPrintErr("The %s value '%s' is ambiguous",
                      filterOptions[OPT_TUPLE_DIRECTION].name, direction_str);
        goto END;

      case SKSTRINGMAP_PARSE_NO_MATCH:
        skAppPrintErr(("The %s value '%s' is not complete path and\n"
                       "\tdoesn't match known keys"),
                      filterOptions[OPT_TUPLE_DIRECTION].name, direction_str);
        goto END;

      default:
        skAppPrintErr("Unexpected return value from string-map parser (%d)",
                      rv_map);
        goto END;
    }

  END:
    if (str_map) {
        skStringMapDestroy(str_map);
    }
    return rv;
}


/*
 *  status = parseFieldNames(fields_string);
 *
 *    Parse the user's option for the --fields switch (or the fields
 *    determined from the first line of input) and fill in the global
 *    'field[]' array and 'num_fields' variables with the result.
 *    This function will also set the values in the
 *    'rwrec_offset_fwd[]' and 'rwrec_offset_rev[]' arrays.
 *
 *    Return 0 on success; -1 on failure.
 */
static int parseFieldNames(const char *field_string)
{
    uint32_t *field_list = NULL;
    uint32_t i;
    int rv = -1;

    if (field_string == NULL || field_string[0] == '\0') {
        skAppPrintErr("Missing --fields value");
        goto END;
    }

    if (rwAsciiFieldMapParseFields(&field_list, &num_fields, field_string,
                                   field_map, RW_ASCII_DUPES_ERROR))
    {
        /* library printed the error */
        goto END;
    }

    if (num_fields > TUPLE_MAX) {
        skAppPrintErr("Only %d fields are supported in the tuple plug-in",
                      TUPLE_MAX);
        goto END;
    }

    for (i = 0; i < num_fields; ++i) {
        field[i].type = field_list[i];

        switch (field[i].type) {
          case RWREC_FIELD_SIP:
          case RWREC_FIELD_DIP:
#if SK_ENABLE_IPV6
            field[i].length = RWREC_SIZEOF_SIPv6;
#else
            field[i].length = RWREC_SIZEOF_SIPv4;
#endif
            break;

          case RWREC_FIELD_SPORT:
          case RWREC_FIELD_DPORT:
            field[i].length = RWREC_SIZEOF_SPORT;
            break;

          case RWREC_FIELD_PROTO:
            field[i].length = RWREC_SIZEOF_PROTO;
            break;

          default:
            skAppPrintErr("Found unsupported field value %d",
                          field[i].type);
            abort();
        }

        field[i].offset = node_length;
        node_length += field[i].length;
    }

    rv = 0;

  END:
    if (field_list) {
        free(field_list);
    }
    return rv;
}


/*
 *  ok = getFieldsFromFirstLine(firstline);
 *
 *    Determine the fields in the data stream by parsing the first
 *    line of the input contained in the C-string 'firstline'.  Return
 *    0 if we are able to parse the fields, and -1 otherwise.
 *
 *    This function calls parseFieldNames() to do the parsing of the
 *    names.
 */
static int getFieldsFromFirstLine(
    char               *first_line)
{
    char *cp = first_line;
    char *ep = first_line;

    /* need to get fields from the first line. convert the first line
     * in place to a list of fields by converting the delimiter to a
     * comma and removing whitespace.  if the delimiter is whitespace,
     * we will get a lot of extra commas in the input, but
     * parseFieldNames() will just ignore them. */
    while (*cp) {
        if (*cp == delimiter) {
            /* convert delimiter to comma for parseFieldNames() */
            *ep++ = ',';
            ++cp;
        } else if (isspace((int)*cp)) {
            /* ignore spaces */
            ++cp;
        } else {
            /* copy character */
            *ep++ = *cp++;
        }
    }
    /* copy the '\0' */
    *ep = *cp;

    /* attempt to parse */
    if (parseFieldNames(first_line)) {
        skAppPrintErr("Unable to guess fields from first line of file");
        return -1;
    }

    return 0;
}


/*
 *  is_title = firstLineIsTitle(first_string_array);
 *
 *    Determine if the input line in the first line of input is a
 *    title line.  This function gets an array of C-string pointers,
 *    with one pointing to each field from first line of input.  That
 *    array will hold 'num_fields' values.
 *
 *    Return 1 this line looks like a title, or 0 if it is not.
 */
static int firstLineIsTitle(
    char              *field_val[])
{
    sk_stringmap_entry_t *entry;
    uint32_t i;
    char *cp;
    int is_title = 0;

    for (i = 0; i < num_fields; ++i) {
        /* see if the value in this column maps to the name of a valid
         * stringmap-entry; if so, assume the row is a title row */
        cp = field_val[i];
        while (isdigit((int)*cp) || isspace((int)*cp)) {
            /* don't allow a value to be treated as a field */
            ++cp;
        }
        if (*cp) {
            if (skStringMapGetEntry(&entry, field_map, field_val[i])
                == SKSTRINGMAP_OK)
            {
                is_title = 1;
                break;
            }
        }
    }

    return is_title;
}


/*
 *  ok = processFields(field_string);
 *
 *    Parse the fields whose C-string values are given in the
 *    'field_string' array.  That array will hold 'num_fields' values.
 *
 *    Return 0 on success, non-zero on failure.
 */
static int processFields(
    char              *field_val[])
{
    static uint8_t *node_array = NULL;
    static uint8_t *cur_node = NULL;
    static uint8_t *final_node = NULL;
    const uint8_t *dup_check;
    uint32_t cidr;
    uint32_t i;
    tuple_cidr_t sip;
    tuple_cidr_t dip;
    number_list_t sport;
    number_list_t dport;
    number_list_t proto;
    skipaddr_t sip_cur;
    skipaddr_t dip_cur;
    uint16_t sport_cur, dport_cur;
    uint8_t proto_cur;
    uint32_t incremented;
    int rv = -1;
#if !SK_ENABLE_IPV6
    uint32_t ipv4;
#endif

    memset(&sport, 0, sizeof(number_list_t));
    memset(&dport, 0, sizeof(number_list_t));
    memset(&proto, 0, sizeof(number_list_t));

    if (node_array == NULL) {
        /* create an array of nodes */
        node_array = growMemory();
        if (node_array == NULL) {
            skAppPrintErr("Cannot create array of nodes");
            return -1;
        }
        cur_node = node_array;
        final_node = node_array + (NODE_ARRAY_SIZE * node_length);
    }

    /* parse the fields */
    for (i = 0; i < num_fields; ++i) {

        switch (field[i].type) {
          case RWREC_FIELD_SIP:
            /* parse as CIDR notation since that is the only format
             * supported, but then parse again as an IP wildcard,
             * since IP wildcards provide us with iteration. */
            if (skStringParseCIDR(&sip_cur, &cidr, field_val[i])) {
                return 1;
            }
            if (skStringParseIPWildcard(&sip.ipwild, field_val[i])) {
                return 1;
            }
#if SK_ENABLE_IPV6
            /* force addresses to be IPv6 */
            skIPWildcardIteratorBindV6(&sip.iter, &sip.ipwild);
#else
            skIPWildcardIteratorBind(&sip.iter, &sip.ipwild);
#endif
            skIPWildcardIteratorNext(&sip.iter, &sip_cur);
            break;

          case RWREC_FIELD_DIP:
            if (skStringParseCIDR(&dip_cur, &cidr, field_val[i])) {
                return 1;
            }
            if (skStringParseIPWildcard(&dip.ipwild, field_val[i])) {
                return 1;
            }
#if SK_ENABLE_IPV6
            /* force addresses to be IPv6 */
            skIPWildcardIteratorBindV6(&dip.iter, &dip.ipwild);
#else
            skIPWildcardIteratorBind(&dip.iter, &dip.ipwild);
#endif
            skIPWildcardIteratorNext(&dip.iter, &dip_cur);
            break;

          case RWREC_FIELD_SPORT:
            if (skStringParseNumberList(&sport.list, &sport.count,
                                        field_val[i], 0, UINT16_MAX, 0))
            {
                return 3;
            }
            sport.idx = 0;
            sport_cur = (uint16_t)(sport.list[sport.idx]);
            break;

          case RWREC_FIELD_DPORT:
            if (skStringParseNumberList(&dport.list, &dport.count,
                                        field_val[i], 0, UINT16_MAX, 0))
            {
                return 4;
            }
            dport.idx = 0;
            dport_cur = (uint16_t)(dport.list[dport.idx]);
            break;

          case RWREC_FIELD_PROTO:
            if (skStringParseNumberList(&proto.list, &proto.count,
                                        field_val[i], 0, UINT8_MAX, 0))
            {
                return 5;
            }
            proto.idx = 0;
            proto_cur = (uint8_t)(proto.list[proto.idx]);
            break;

          default:
            skAppPrintErr("Found unsupported field value %d",
                          field[i].type);
            abort();
        }
    }

    /* now create the entries from the parsed values */
    do {
        /* To see all permutations, each of the following checks
         * whether incremented has been set.  If so, it does nothing.
         * Else, it tries to increment its counter and sets
         * incremented if it can, but if its counter is at its max, it
         * resets itself and does not set incremented.  We exit the
         * loop when no one is able to increment. */
        incremented = 0;

        for (i = 0; i < num_fields; ++i) {
            switch (field[i].type) {
              case RWREC_FIELD_SIP:
#if SK_ENABLE_IPV6
                skipaddrGetV6(&sip_cur, cur_node + field[i].offset);
#else
                ipv4 = skipaddrGetV4(&sip_cur);
                memcpy(cur_node + field[i].offset, &ipv4, field[i].length);
#endif
                if (incremented == 0) {
                    if (skIPWildcardIteratorNext(&sip.iter, &sip_cur)
                        == SK_ITERATOR_OK)
                    {
                        incremented = 1;
                    } else {
                        skIPWildcardIteratorReset(&sip.iter);
                        skIPWildcardIteratorNext(&sip.iter, &sip_cur);
                    }
                }
                break;

              case RWREC_FIELD_DIP:
#if SK_ENABLE_IPV6
                skipaddrGetV6(&dip_cur, cur_node + field[i].offset);
#else
                ipv4 = skipaddrGetV4(&dip_cur);
                memcpy(cur_node + field[i].offset, &ipv4, field[i].length);
#endif
                if (incremented == 0) {
                    if (skIPWildcardIteratorNext(&dip.iter, &dip_cur)
                        == SK_ITERATOR_OK)
                    {
                        incremented = 2;
                    } else {
                        skIPWildcardIteratorReset(&dip.iter);
                        skIPWildcardIteratorNext(&dip.iter, &dip_cur);
                    }
                }
                break;

              case RWREC_FIELD_SPORT:
                memcpy(cur_node + field[i].offset, &sport_cur,field[i].length);
                if (incremented == 0 && sport.count != 1) {
                    ++sport.idx;
                    if (sport.idx == sport.count) {
                        /* reset */
                        sport.idx = 0;
                    } else {
                        incremented = 3;
                    }
                }
                sport_cur = (uint16_t)(sport.list[sport.idx]);
                break;

              case RWREC_FIELD_DPORT:
                memcpy(cur_node + field[i].offset, &dport_cur,field[i].length);
                if (incremented == 0 && dport.count != 1) {
                    ++dport.idx;
                    if (dport.idx == dport.count) {
                        /* reset */
                        dport.idx = 0;
                    } else {
                        incremented = 4;
                    }
                }
                dport_cur = (uint16_t)(dport.list[dport.idx]);
                break;

              case RWREC_FIELD_PROTO:
                memcpy(cur_node + field[i].offset, &proto_cur,field[i].length);
                if (incremented == 0 && proto.count != 1) {
                    ++proto.idx;
                    if (proto.idx == proto.count) {
                        /* reset */
                        proto.idx = 0;
                    } else {
                        incremented = 5;
                    }
                }
                proto_cur = (uint16_t)(proto.list[proto.idx]);
                break;

              default:
                skAppPrintErr("Found unsupported field value %d",
                              field[i].type);
                abort();
            } /* switch */
        }

        dup_check = rbsearch(cur_node, rb);
        if (dup_check == cur_node) {
            /* new node added */
            cur_node += node_length;

            if (cur_node >= final_node) {
                assert(cur_node == final_node);

                /* need more entries */
                node_array = growMemory();
                if (node_array == NULL) {
                    skAppPrintErr("Cannot create array of nodes");
                    goto END;
                }
                cur_node = node_array;
                final_node = node_array + (NODE_ARRAY_SIZE * node_length);
            }


        }
        /* else key was duplicate and we ignore it */

    } while (incremented != 0);

    rv = 0;

  END:
    if (sport.list) {
        free(sport.list);
    }
    if (dport.list) {
        free(dport.list);
    }
    if (proto.list) {
        free(proto.list);
    }

    return rv;
}


/*
 *  ok = parsefile();
 *
 *    Parse the file contained in the global 'input_path' variable.
 *
 *    This functions opens the file, then reads lines from it, parsing
 *    the lines into fields.  It calls processFields() to parse each
 *    individual field.
 *
 *    Return 0 on success, or non-zero otherwise.
 */
static int parsefile(void)
{
#define MAX_ERRORS 12
    static const char *field_name[TUPLE_MAX+1] = {
        "","sIP","dIP","sPort","dPort","proto"
    };
    char line_buf[1024];
    char *field_string[TUPLE_MAX];
    char *cp;
    char *ep;
    int lc = 0;
    int err_count = 0;
    uint32_t i;
    skstream_t *stream;
    int rv;
    int saw_title = 0;

    rv = dynlibOpenDataInputStream(&stream, SK_CONTENT_TEXT, input_file);
    if (rv == -1) {
        skAppPrintErr("Problem with input file %s", input_file);
        return 1;
    }
    if (rv == 1) {
        /* Ignore the file */
        return 0;
    }

    if ((rv = skStreamSetCommentStart(stream, "#"))) {
        goto END;
    }

    /* read until end of file */
    while (((rv = skStreamGetLine(stream, line_buf, sizeof(line_buf), &lc))
            != SKSTREAM_ERR_EOF)
           && (err_count < MAX_ERRORS))
    {
        switch (rv) {
          case SKSTREAM_OK:
            /* good, we got our line */
            break;
          case SKSTREAM_ERR_LONG_LINE:
            /* bad: line was longer than sizeof(line_buf) */
            skAppPrintErr("Input line %s:%d too long. ignored",
                          input_file, lc);
            continue;
          default:
            /* unexpected error */
            skStreamPrintLastErr(stream, rv, &skAppPrintErr);
            goto END;
        }

        if (num_fields == 0) {
            /* must determine fields from first line of input */
            assert(saw_title == 0);
            saw_title = getFieldsFromFirstLine(line_buf);
            if (saw_title < 0) {
                /* error */
                return 1;
            }
            saw_title = 1;
            continue;
        }

        /* We have a line; process it */
        cp = line_buf;
        i = 0;

        /* find each field and set pointers in field_string[] to the
         * field's text */
        while (*cp) {
            /* eat any leading whitespace in case whitespace is the
             * delimiter */
            while (isspace((int)*cp)) {
                ++cp;
            }
            if (*cp == '\0') {
                break;
            }
            field_string[i] = cp;
            ++i;

            /* find end of current field */
            ep = strchr(cp, delimiter);
            if (ep) {
                *ep = '\0';
            }

            if (NULL == ep) {
                /* at end of line; break out of while() */
                break;
            }

            /* we saw a delimiter earlier; goto next field */
            cp = ep + 1;
        } /* inner while over fields */

        if (i != num_fields) {
            skAppPrintErr("Too %s fields (found %u, expected %u) at %s:%d",
                          ((i < num_fields) ? "few" : "many"),
                          i, num_fields, input_file, lc);
            ++err_count;
            continue;
        }

        if (saw_title == 0) {
            assert(num_fields > 0);
            /* the user already provided us with the fields, so we
             * just need to determine if we should ignore the first
             * line of input because it contains the titles. */
            if (firstLineIsTitle(field_string)) {
                continue;
            }
            saw_title = 1;
        }

        /* process fields */
        rv = processFields(field_string);
        if (rv != 0) {
            if (rv > 0) {
                skAppPrintErr("Error parsing %s field at %s:%d",
                              field_name[rv], input_file, lc);
                ++err_count;
            } else {
                /* fatal */
                ++err_count;
                goto END;
            }
        }
    }

  END:
    skStreamDestroy(&stream);
    /* return error code if we did not get to the end of the stream */
    if (rv != SKSTREAM_ERR_EOF) {
        return -1;
    }
    /* return error code if we encountered errors */
    if (err_count) {
        return -1;
    }
    /* return error code if we do not have any entries */
    if (array_vec == NULL
        || 0 == skVectorGetCount(array_vec))
    {
        skAppPrintErr("No valid entries read from input file '%s'",
                      input_file);
        return -1;
    }
    return 0;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
