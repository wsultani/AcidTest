/*
** Copyright (C) 2003-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

#include "silk.h"

RCSIDENT("$SiLK: flowcapsetup.c 11248 2008-04-11 19:07:39Z mthomas $");

#include "utils.h"
#include "flowcap.h"
#include "sksite.h"
#include "skdeque.h"
#include "sklog.h"
#include "skdaemon.h"
#include "sktransfer.h"
#include "skiobuf.h"
#include "skheader.h"


/* TYPEDEFS AND DEFINES */

/* Where to print --help output */
#define USAGE_FH stdout


/* LOCAL VARIABLES */

/* Name of sensor configuration file */
static const char *sensor_configuration = NULL;

/* Amount of disk space allocated for flowcap files {DISK, RAM} */
static uint64_t maxSpace[2];

/* Stashed probe list */
static char *probe_list = NULL;


/* OPTIONS SETUP */

typedef enum {
    OPT_SENSOR_CONFIG, OPT_MAX_FILE_SIZE,
    OPT_TIMEOUT, OPT_PROBES, OPT_FC_VERSION,
    OPT_DESTINATION_DIR
#ifdef HAVE_STATVFS
    , OPT_FREESPACE_MINIMUM, OPT_SPACE_MAXIMUM_PERCENT
#endif
} appOptionsEnum;

static struct option appOptions[] = {
    {"sensor-configuration",  REQUIRED_ARG, 0, OPT_SENSOR_CONFIG},
    {"max-file-size",         REQUIRED_ARG, 0, OPT_MAX_FILE_SIZE},
    {"timeout",               REQUIRED_ARG, 0, OPT_TIMEOUT},
    {"probes",                REQUIRED_ARG, 0, OPT_PROBES},
    {"fc-version",            REQUIRED_ARG, 0, OPT_FC_VERSION},
    {"destination-directory", REQUIRED_ARG, 0, OPT_DESTINATION_DIR},
#ifdef HAVE_STATVFS
    {"freespace-minimum",     REQUIRED_ARG, 0, OPT_FREESPACE_MINIMUM},
    {"space-maximum-percent", REQUIRED_ARG, 0, OPT_SPACE_MAXIMUM_PERCENT},
#endif
    {0,0,0,0}                 /* sentinel entry */
};

static appOptionsEnum firstNonServerOption = OPT_DESTINATION_DIR;

static const char *appHelp[] = {
    ("Read sensor configuration from named file."),
    ("Close the aggregated flow file when it reaches this\n"
     "\tsize (in bytes) so it can be sent to the packer.  Append k, m, g, t\n"
     "\tfor kilo-, mega-, giga-, tera-bytes, respectively."),
    ("Close the aggregated flow file when it reaches this\n"
     "\tage (in seconds) so it can be sent to the packer. Def. 60"),
    ("Ignore all probes in the sensor-configuration file except\n"
     "\tfor these, a comma separated list of probe names. Def. Use all probes"),
    NULL, /* generate dynamically */
    ("Store aggregated packed flow files in this\n"
     "\tdirectory for processing by rwsender."),
#ifdef HAVE_STATVFS
    ("Set the minimum free space (in bytes) to maintain\n"
     "\ton the filesystem. Accepts k,m,g,t suffix. Def. "
     DEFAULT_FREESPACE_MINIMUM),
    ("Set the maximum percentage of the disk to\n"
     "\tuse. Def." /* valued added in usage */),
#endif /* HAVE_STATVFS */
    (char *)NULL
};

static sk_bitmap_t *appOptUsed;


typedef enum {
    OPT_DISK_DIRECTORY, OPT_DISK_SPACE, OPT_FC_PORT, OPT_CLIENT_ADDRESS,
    OPT_RAM_DIRECTORY, OPT_RAM_SPACE, OPT_ACK_TIMEOUT
} appServerOptionsEnum;

static struct option appServerOptions[] = {
    {"disk-directory",       REQUIRED_ARG, 0, OPT_DISK_DIRECTORY},
    {"disk-space",           REQUIRED_ARG, 0, OPT_DISK_SPACE},
    {"fc-port",              REQUIRED_ARG, 0, OPT_FC_PORT},
    {"client-address",       REQUIRED_ARG, 0, OPT_CLIENT_ADDRESS},
    {"ram-directory",        REQUIRED_ARG, 0, OPT_RAM_DIRECTORY},
    {"ram-space",            REQUIRED_ARG, 0, OPT_RAM_SPACE},
    {"ack-timeout",          REQUIRED_ARG, 0, OPT_ACK_TIMEOUT},
    {0,0,0,0}                /* sentinel entry */
};

static const char *appServerHelp[] = {
    ("Store aggregated flow files in this directory\n"
     "\twhile they are waiting to be requested by rwflowpack."),
    ("Allocate this amount of space for disk-based files, in\n"
     "\tbytes. Append k, m, g, t for kilo-, mega-, giga-, tera-bytes."),
    ("Listen on this port for connections from rwflowpack."),
    ("Allow this internet address to connect to the flowcap\n"
     "\tport. Def. any"),
    ("Use this mount point for a RAM disk. Def. none"),
    ("Allocate this amount of space allotted for ramdisk-based\n"
     "\tfile. Accepts k,m,g,t suffix.  Def. 0"),
    ("How long (in seconds) to wait for an ack from\n"
     "\trwflowpack. Def. 10"),
    (char *)NULL
};

static sk_bitmap_t *appServerOptUsed;


/* LOCAL FUNCTION PROTOTYPES */

static void appUsageLong(void);
static int  appOptionsHandler(clientData cData, int opt_index, char *opt_arg);
static int  appServerOptionsHandler(
    clientData  cData,
    int         opt_index,
    char       *opt_arg);
static void validateOptions(void);
static int  parseProbeList(void);


/* FUNCTION DEFINITIONS */

/*
 *  appUsageLong();
 *
 *    Print complete usage information to USAGE_FH.  Pass this
 *    function to skOptionsSetUsageCallback(); skOptionsParse() will
 *    call this funciton and then exit the program when the --help
 *    option is given.
 */
static void appUsageLong(void)
{
#define USAGE_MSG                                                           \
    ("<SWITCHES>\n"                                                         \
     "\tflowcap is a daemon which listens to devices which produce flow\n"  \
     "\tdata (flow sources), homogenizes the data, stores it, and\n"        \
     "\tforwards as a compressed stream to a flowcap client program.\n")

    FILE *fh = USAGE_FH;
    int i;

    fprintf(fh, "%s %s", skAppName(), USAGE_MSG);
    fprintf(fh, "\nSWITCHES:\n");
    skOptionsDefaultUsage(fh);
    sksiteOptionsUsage(fh);

    for (i = 0; appOptions[i].name; i++ ) {
        if (appOptions[i].val == OPT_DESTINATION_DIR) {
            fprintf(fh, ("\n"
                         "LOCAL STORAGE MODE: Write files locally for"
                         " pickup by separate rwsender\n"));
        }

        fprintf(fh, "--%s %s. ", appOptions[i].name,
                SK_OPTION_HAS_ARG(appOptions[i]));
        switch ((appOptionsEnum)appOptions[i].val) {
          case OPT_FC_VERSION:
            fprintf(fh,
                    "Version of flowcap protocol to use: %d-%d. Def. %d",
                    FC_VERSION_MIN, FC_VERSION_MAX, flowcap_version);
            break;
#ifdef HAVE_STATVFS
          case OPT_SPACE_MAXIMUM_PERCENT:
            fprintf(fh, "%s %.2f%%", appHelp[i],
                    DEFAULT_SPACE_MAXIMUM_PERCENT);
            break;
#endif
          default:
            fprintf(fh, "%s", appHelp[i]);
            break;
        }
        fprintf(fh, "\n");
    }

    fprintf(fh, ("\n"
                 "SERVER MODE: Send files directly to an rwflowpack"
                 " client that connects\n"));
    for (i = 0; appServerOptions[i].name; i++ ) {
        fprintf(fh, "--%s %s. ", appServerOptions[i].name,
                SK_OPTION_HAS_ARG(appServerOptions[i]));
        fprintf(fh, "%s", appServerHelp[i]);
        fprintf(fh, "\n");
    }

    fprintf(fh, "\nLogging and daemonization switches:\n");
    skdaemonOptionsUsage(fh);
}


/*
 *  status = appOptionsHandler(cData, opt_index, opt_arg);
 *
 *    Called by skOptionsParse(), this handles a user-specified switch
 *    that the application has registered, typically by setting global
 *    variables.  Returns 1 if the switch processing failed or 0 if it
 *    succeeded.  Returning a non-zero from from the handler causes
 *    skOptionsParse() to return a negative value.
 *
 *    The clientData in 'cData' is typically ignored; 'opt_index' is
 *    the index number that was specified as the last value for each
 *    struct option in appOptions[]; 'opt_arg' is the user's argument
 *    to the switch for options that have a REQUIRED_ARG or an
 *    OPTIONAL_ARG.
 */
static int appOptionsHandler(
    clientData  UNUSED(cData),
    int         opt_index,
    char       *opt_arg)
{
    uint32_t tmp_32;
    uint64_t tmp_64;
    int rv;

    skBitmapSetBit(appOptUsed, (uint32_t)opt_index);

    switch ((appOptionsEnum)opt_index) {
      case OPT_SENSOR_CONFIG:
        sensor_configuration = opt_arg;
        break;

      case OPT_MAX_FILE_SIZE:
        rv = skStringParseHumanUint64(&tmp_64, opt_arg, SK_HUMAN_NORMAL);
        if (rv) {
            goto PARSE_ERROR;
        }
        if (tmp_64 > UINT32_MAX) {
            skAppPrintErr("Invalid %s '%s': Value is above the maximum %u",
                          appOptions[opt_index].name, opt_arg, UINT32_MAX);
        }
        maxFileSize = tmp_64;
        break;

      case OPT_TIMEOUT:
        rv = skStringParseUint32(&tmp_32, opt_arg, 0, 0xFFFFFFFE);
        if (rv) {
            goto PARSE_ERROR;
        }
        writeTimeout = tmp_32;
        break;

      case OPT_PROBES:
        probe_list = opt_arg;
        break;

      case OPT_FC_VERSION:
        rv = skStringParseUint32(&tmp_32, opt_arg,
                                 FC_VERSION_MIN, FC_VERSION_MAX);
        if (rv) {
            goto PARSE_ERROR;
        }
        flowcap_version = tmp_32;
        break;

      case OPT_DESTINATION_DIR:
        if (skOptionsCheckDirectory(opt_arg, appOptions[opt_index].name)) {
            return 1;
        }
        if (strlen(opt_arg) > PATH_MAX - FC_NAME_MAX) {
            skAppPrintErr("The --%s name is too long '%s'",
                          appOptions[opt_index].name, opt_arg);
            return 1;
        }
        destDirs[FC_DISK] = strdup(opt_arg);
        break;

#ifdef HAVE_STATVFS
      case OPT_FREESPACE_MINIMUM:
        rv = skStringParseHumanUint64(&tmp_64, opt_arg, SK_HUMAN_NORMAL);
        if (rv) {
            goto PARSE_ERROR;
        }
        freespace_minimum = (int64_t)tmp_64;
        break;

      case OPT_SPACE_MAXIMUM_PERCENT:
        rv = skStringParseDouble(&space_maximum_percent, opt_arg, 0.0, 100.0);
        if (rv) {
            goto PARSE_ERROR;
        }
        break;
#endif /* HAVE_STATVFS */

    } /* switch */

    return 0;

  PARSE_ERROR:
    skAppPrintErr("Invalid %s '%s': %s",
                  appOptions[opt_index].name, opt_arg,
                  skStringParseStrerror(rv));
    return 1;
}


/*
 *  status = appServerOptionsHandler(cData, opt_index, opt_arg);
 *
 *    As appOptionsHandler(), except for appServerOptions[].
 */
static int appServerOptionsHandler(
    clientData  UNUSED(cData),
    int         opt_index,
    char       *opt_arg)
{
    const char *errmsg;
    struct in_addr addr;
    uint32_t tmp_number;
    uint64_t tmp_64;
    int rv;

    skBitmapSetBit(appServerOptUsed, (uint32_t)opt_index);

    switch ((appServerOptionsEnum)opt_index) {

      case OPT_CLIENT_ADDRESS:
        errmsg = skNameToAddr(opt_arg, &addr);
        if (errmsg) {
            skAppPrintErr("Illegal --%s address '%s': %s",
                          appServerOptions[opt_index].name, opt_arg, errmsg);
            return 1;
        }
        memcpy(&fc_client_addr, &(addr.s_addr), sizeof(in_addr_t));
        break;

      case OPT_FC_PORT:
        rv = skStringParseUint32(&tmp_number, opt_arg, 0, 0xFFFE);
        if (rv) {
            goto PARSE_ERROR;
        }
        fc_listen_port = (uint16_t)tmp_number;
        break;

      case OPT_RAM_DIRECTORY:
        if (skOptionsCheckDirectory(opt_arg,appServerOptions[opt_index].name)){
            return 1;
        }
        if (strlen(opt_arg) > PATH_MAX - FC_NAME_MAX) {
            skAppPrintErr("The --%s name is too long '%s'",
                          appServerOptions[opt_index].name, opt_arg);
            return 1;
        }
        destDirs[FC_RAM] = strdup(opt_arg);
        break;

      case OPT_DISK_DIRECTORY:
        if (skOptionsCheckDirectory(opt_arg,appServerOptions[opt_index].name)){
            return 1;
        }
        if (strlen(opt_arg) > PATH_MAX - FC_NAME_MAX) {
            skAppPrintErr("The --%s name is too long '%s'",
                          appServerOptions[opt_index].name, opt_arg);
            return 1;
        }
        destDirs[FC_DISK] = strdup(opt_arg);
        break;

      case OPT_DISK_SPACE:
        rv = skStringParseHumanUint64(&tmp_64, opt_arg, SK_HUMAN_NORMAL);
        if (rv) {
            goto PARSE_ERROR;
        }
        maxSpace[FC_DISK] = tmp_64;
        break;

      case OPT_RAM_SPACE:
        rv = skStringParseHumanUint64(&tmp_64, opt_arg, SK_HUMAN_NORMAL);
        if (rv) {
            goto PARSE_ERROR;
        }
        maxSpace[FC_RAM] = tmp_64;
        break;

      case OPT_ACK_TIMEOUT:
        rv = skStringParseUint32(&ack_timeout, opt_arg, 0, 0);
        if (rv) {
            goto PARSE_ERROR;
        }
        break;

    } /* switch */

    return 0;

  PARSE_ERROR:
    skAppPrintErr("Invalid %s '%s': %s",
                  appServerOptions[opt_index].name, opt_arg,
                  skStringParseStrerror(rv));
    return 1;
}


/*
 *  appSetup(argc, argv);
 *
 *    Perform all the setup for this application include setting up
 *    required modules, parsing options, etc.  This function should be
 *    passed the same arguments that were passed into main().
 *
 *    Returns to the caller if all setup succeeds.  If anything fails,
 *    this function will cause the application to exit with a FAILURE
 *    exit status.
 */
void appSetup(int32_t argc, char **argv)
{
    int32_t arg_index;
    int rv;

    /* verify same number of options and help strings */
    assert((sizeof(appHelp)/sizeof(char *)) ==
           (sizeof(appOptions)/sizeof(struct option)));
    assert((sizeof(appServerHelp)/sizeof(char *)) ==
           (sizeof(appServerOptions)/sizeof(struct option)));

    /* register the application */
    skAppRegister(argv[0]);
    skOptionsSetUsageCallback(&appUsageLong);

    /* register the options */
    if (skOptionsRegister(appOptions, &appOptionsHandler, NULL)
        || skOptionsRegister(appServerOptions, &appServerOptionsHandler, NULL)
        || sksiteOptionsRegister(SK_SITE_FLAG_CONFIG_FILE))
    {
        skAppPrintErr("Unable to register options");
        exit(EXIT_FAILURE);
    }

    /* flowcap runs as a daemon; use the threaded logger */
    if (skdaemonSetup((SKLOG_FEATURE_LEGACY | SKLOG_FEATURE_SYSLOG),
                      argc, argv)
        || sklogEnableThreadedLogging())
    {
        exit(EXIT_FAILURE);
    }

    /* initialize globals */
    memset(maxSpace, 0, sizeof(maxSpace));
    memset(unallocated_space, 0, sizeof(unallocated_space));
    rv = skBitmapCreate(&appOptUsed, sizeof(appOptions)/sizeof(struct option));
    if (rv != 0) {
        skAppPrintErr("Could not allocate bitmap");
        exit(EXIT_FAILURE);
    }
    rv = skBitmapCreate(&appServerOptUsed,
                        sizeof(appServerOptions)/sizeof(struct option));
    if (rv != 0) {
        skAppPrintErr("Could not allocate bitmap");
        exit(EXIT_FAILURE);
    }
#ifdef HAVE_STATVFS
    {
        uint64_t tmp_64;
        rv = skStringParseHumanUint64(&tmp_64, DEFAULT_FREESPACE_MINIMUM,
                                     SK_HUMAN_NORMAL);
        if (rv) {
            skAppPrintErr("Bad default value for freespace_minimum: '%s': %s",
                          DEFAULT_FREESPACE_MINIMUM,skStringParseStrerror(rv));
            exit(EXIT_FAILURE);
        }
        freespace_minimum = (int64_t)tmp_64;
    }
#endif /* HAVE_STATVFS */

    probe_vec = skVectorNew(sizeof(skpc_probe_t *));
    if (probe_vec == NULL) {
        skAppPrintErr("Vector create failed");
        exit(EXIT_FAILURE);
    }

    /* parse options. If OK, arg_index is the first arg not used up */
    arg_index = skOptionsParse(argc, argv);
    if (arg_index < 0) {
        skAppUsage();/* never returns */
    }

    validateOptions();

    /* Check that there aren't any extraneous arguments */
    if (arg_index != argc) {
        skAppPrintErr("Too many or unrecognized argument specified '%s'",
                      argv[arg_index]);
        skAppUsage();             /* never returns */
    }

    /* if no probes were specified on the command line, use all probes */
    if (skVectorGetCount(probe_vec) == 0) {
        skpc_probe_iter_t iter;
        const skpc_probe_t *probe;

        skpcProbeIteratorBind(&iter);
        while (skpcProbeIteratorNext(&iter, &probe)) {
            rv = skVectorAppendValue(probe_vec, &probe);
            if (rv == -1) {
                skAppPrintErr("Vector append failed");
                exit(EXIT_FAILURE);
            }
        }
    }

    /* this should never happen */
    if (skVectorGetCount(probe_vec) < 1) {
        skAppPrintErr("No probes are available");
        exit(EXIT_FAILURE);
    }

    skBitmapDestroy(&appOptUsed);
    skBitmapDestroy(&appServerOptUsed);

    return;
} /* appSetup */


static void validateOptions(void)
{
    unsigned int i;
    int error = 0;

    /* ensure the site config is available */
    if (sksiteConfigure(1)) {
        ++error;
    }

    /* check for required arguments */
    if (sensor_configuration == NULL) {
        skAppPrintErr("The --%s option is required",
                      appOptions[OPT_SENSOR_CONFIG].name);
        ++error;
    }
    if (!skBitmapGetBit(appOptUsed, OPT_MAX_FILE_SIZE)) {
        skAppPrintErr("The --%s switch is required",
                      appOptions[OPT_MAX_FILE_SIZE].name);
        ++error;
    }

    /*
     * Allow for a file to be larger than the maximum file size.
     *
     * Assume a compressed block could be 15% larger than the standard
     * block size---libz is 10%, lzo1x is 6%.
     *
     * We're using the default block size from skiobuf.h, so we assume
     * that skstream doesn't use a different block size.
     */
    allocFileSize = maxFileSize + (double)SKIOBUF_DEFAULT_BLOCKSIZE * 0.15;


    /* parse the probe configuration file and verify that it has probes */
    if (skpcSetup() != 0) {
        skAppPrintErr("Unable to setup probe configuration handler");
        ++error;
    }
    if (skpcParse(sensor_configuration, NULL) != 0) {
        skAppPrintErr("Error in sensor configuration file.");
        ++error;
    }
    if (skpcCountProbes() == 0) {
        skAppPrintErr("The sensor configuration file has no probes within it");
        ++error;
    }

    /* parse the list of probes */
    if (probe_list) {
        if (parseProbeList()) {
            ++error;
        }
    }

    /* verify the required options for logging */
    if (skdaemonOptionsVerify()) {
        ++error;
    }

    /* must have some destination */
    if ( !skBitmapGetBit(appOptUsed, OPT_DESTINATION_DIR)
         && !skBitmapGetBit(appServerOptUsed, OPT_DISK_DIRECTORY))
    {
        skAppPrintErr("Either the --%s or --%s switch\n\tis required",
                      appOptions[OPT_DESTINATION_DIR].name,
                      appServerOptions[OPT_DISK_DIRECTORY].name);
        exit(EXIT_FAILURE);
    }

    /* server mode */
    if (skBitmapGetHighCount(appServerOptUsed)) {
        int required_switches[] = {
            OPT_DISK_DIRECTORY,
            OPT_FC_PORT,
            OPT_DISK_SPACE,
            -1/* sentinel */
        };

        /* use send_files mode */
        server_mode_flag = 1;

        /* check for incompatible switches */
        for (i = firstNonServerOption; appOptions[i].name; ++i) {
            if (skBitmapGetBit(appOptUsed, i)) {
                unsigned int j;
                for (j = 0; appServerOptions[j].name; ++j) {
                    if (skBitmapGetBit(appServerOptUsed, j)) {
                        skAppPrintErr(("Cannot mix the local storage mode"
                                       " with the server mode switches:\n"
                                       "\tBoth --%s and --%s given"),
                                      appOptions[i].name,
                                      appServerOptions[j].name);
                    }
                }
                exit(EXIT_FAILURE);
            }
        }

        /* make certain we got our required switches */
        for (i = 0; required_switches[i] != -1; ++i) {
            if (!skBitmapGetBit(appServerOptUsed, i)) {
                skAppPrintErr("The --%s switch is required in Server Mode",
                              appServerOptions[i].name);
                ++error;
            }
        }

        unallocated_space[FC_DISK] = maxSpace[FC_DISK];
        unallocated_space[FC_RAM] = maxSpace[FC_RAM];

        if (skBitmapGetBit(appServerOptUsed, OPT_RAM_SPACE)
            && !skBitmapGetBit(appServerOptUsed, OPT_RAM_DIRECTORY))
        {
            skAppPrintErr("Use of --%s requires the --%s switch",
                          appServerOptions[OPT_RAM_SPACE].name,
                          appServerOptions[OPT_RAM_DIRECTORY].name);
            ++error;
        }

        if (maxSpace[FC_RAM] > maxSpace[FC_DISK]) {
            skAppPrintErr("Space given by --%s is greater than --%s",
                          appServerOptions[OPT_RAM_SPACE].name,
                          appServerOptions[OPT_DISK_SPACE].name);
            ++error;
        }
        maxSpace[FC_DISK] -= maxSpace[FC_RAM]; /* Adjust */

    } else {
        /* we are not sending files */
        int required_switches[] = {OPT_DESTINATION_DIR, -1/* sentinel */};

        /* make certain we got our required switches */
        for (i = 0; required_switches[i] != -1; ++i) {
            if (!skBitmapGetBit(appOptUsed, i)) {
                skAppPrintErr(("The --%s switch is required in"
                               " Local Storage Mode"),
                              appOptions[i].name);
                exit(EXIT_FAILURE);
            }
        }
    }

    /* exit if we got an error */
    if (error) {
        exit(EXIT_FAILURE);
    }
}


/*
 *    Parse the global 'probe_list' string and add named probes to the
 *    global 'probe_vec'.  Return 0 on success, or -1 if we do not
 *    find a probe with the specified name.
 */
static int parseProbeList(void)
{
    const skpc_probe_t *probe;
    int error_count = 0;
    char *cp;
    char *ep;

    cp = probe_list;
    while (*cp) {
        /* 'cp' at start of token, find where it ends */
        ep = strchr(cp, ',');
        if (ep == cp) {
            /* double comma, ignore */
            ++cp;
            continue;
        }
        if (ep == NULL) {
            /* no more commas, set 'ep' to end of string */
            ep = cp + strlen(cp);
        } else {
            /* end this token, move 'ep' to start of next token */
            *ep = '\0';
            ep++;
        }

        /* search for the probe */
        probe = skpcProbeLookupByName(cp);
        if (probe) {
            /* add it */
            skVectorAppendValue(probe_vec, &probe);
        } else {
            /* error */
            skAppPrintErr("No probes have the name '%s'", cp);
            ++error_count;
        }

        /* move to next token */
        cp = ep;
    }

    return ((error_count == 0) ? 0 : -1);
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
