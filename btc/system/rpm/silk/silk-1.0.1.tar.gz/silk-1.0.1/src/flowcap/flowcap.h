/*
** Copyright (C) 2004-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/
#ifndef _FLOWCAP_H
#define _FLOWCAP_H

#include "silk.h"

RCSIDENTVAR(rcsID_FLOWCAP_H, "$SiLK: flowcap.h 10004 2008-01-04 23:08:59Z mthomas $");

/*
**  flowcap.h
**
**  Common information between flowcap objects
**
**/

#include "rwpack.h"
#include "skdeque.h"
#include "sktimer.h"
#include "pdusource.h"
#if SK_ENABLE_IPFIX
#include "ipfixsource.h"
#endif
#include "probeconf.h"


/*
 *  For debugging.  Argument should be surrounded by double-parens:
 *      LOGDEBUG(("My value is %d", value));
 */
#ifdef DEBUG
#  define LOGDEBUG(args) DEBUGMSG args
#endif
#ifndef LOGDEBUG
#  define LOGDEBUG(args)
#endif

/* Whether a probe's priority is high */
#define FC_PROBE_IS_HIGH_PRIORITY(probe)        \
    (skpcProbeGetPriority(probe) > 50)

/* Max timestamp length (YYYYMMDDhhmmss) */
#define FC_TIMESTAMP_MAX 15
/* Maximum sensor size (including either trailing zero or preceeding hyphen) */
#define FC_SENSOR_MAX (SK_MAX_STRLEN_SENSOR + 1)
/* Maximum probe size (including either trailing zero or preceeding hyphen) */
#define FC_PROBE_MAX (SK_MAX_STRLEN_SENSOR + 1)
/* Size of uniquness extension */
#define FC_UNIQUE_MAX 7
/* Previous two, plus hyphen */
#define FC_NAME_MAX                                     \
    (FC_TIMESTAMP_MAX + FC_SENSOR_MAX +                 \
     FC_PROBE_MAX + FC_UNIQUE_MAX)


/* Minimum flowcap version */
/* We no longer support flowcap version 1 */
#define FC_VERSION_MIN 2

/* Maximum flowcap version */
#define FC_VERSION_MAX 5

/* Default version of flowcap to produce */
#define FC_VERSION_DEFAULT 5

/* Indexes for DISK and RAM related pairs. */
#define FC_DISK 0
#define FC_RAM 1

/* minimum number of bytes to leave free on the data disk.  File
 * distribution will stop when the freespace on the disk reaches or
 * falls below this mark.  This value is parsed by
 * skStringParseHumanUint64(). */
#define DEFAULT_FREESPACE_MINIMUM   "1g"

/* maximum percentage of disk space to take */
#define DEFAULT_SPACE_MAXIMUM_PERCENT  ((double)98.00)



typedef void (*cleanupHandler)(void *); /* Type of cleanup handlers */

typedef struct fileStruct_st fileStruct_t;

struct fileStruct_st {
    int64_t         size;           /* size of the file */
    fileStruct_t   *next;           /* next in queue */
    uint32_t        startTime;      /* epoch at start */
    uint32_t        endTime;        /* epoch at end of writing */
    uint32_t        sendStartTime;  /* epoch at beginning of sending */
    uint32_t        sentTime;       /* epoch at end of sending */
    uint8_t         isRamDisk;      /* 1 if ram disk file */
    uint8_t         sendingTries;   /* number of times we tried to send file */
    char            fName[128];     /* file basename */
};

typedef struct writeFileStruct_st {
    /* probe that this file is capturing */
    const skpc_probe_t *probe;

    /* the source of data for the probe */
    union {
        pduSource_t   pdu;
#if SK_ENABLE_IPFIX
        ipfixSource_t ipfix;
#endif
    }                   source;

    /* the ioStream that is used for writing */
    rwIOStruct_t       *ios;

    /* which file we are writing to*/
    fileStruct_t       *fPtr;

    /* send timer handle */
    skTimer_t           timerHandle;

    /* High Water Mark: file size send limit */
    uint32_t            HWM;

    pthread_mutex_t     mutex;
    pthread_t           reader_thread;

    /* number of records written */
    uint32_t            records;

    /* Version of flowcap to write */
    uint8_t             version;

    /* Whether this file is due to be closed. */
    unsigned            close       : 1;

    /* Whether this file is in the process of being closed. */
    unsigned            closing     : 1;
    unsigned            valid_source: 1;
    unsigned            running     : 1;
} writeFileStruct_t;

/* imported functions and variables */
void appSetup(int argc, char **argv);

void closeWFile(writeFileStruct_t *wfPtr, uint8_t open_new);

void loadFiles(void);
void unloadFiles(void);
void addToLowPriorityQueue(fileStruct_t *fptr);
void addToHighPriorityQueue(fileStruct_t *fptr);
void addToSendQueue(fileStruct_t *fptr);
void addToFreeQueue(fileStruct_t *fPtr);
void initQueues(void);
void destroyQueues(void);
void dumpQueueLengths(void);
void broadcastFreeSpace(writeFileStruct_t *wfPtr, off_t size);
fileStruct_t *getFileStructServer(void);
int  startSender(void);
void stopSender(void);

int  startReader(void);
void stopReader(void);


/* Amount of disk space which has not already been allocated to files
 * {DISK, RAM} */
extern uint64_t unallocated_space[2];

/* High (RAM) and low (DISK) speed disk locations {DISK, RAM} */
extern char *destDirs[2];

/* File write timeout in seconds.  A file will be closed out if this
 * amount of time passes without getting too large. */
extern uint32_t writeTimeout;

/* ACK timout in seconds. */
extern uint32_t ack_timeout;

/* Address of the flowcap client (consumer). */
extern in_addr_t fc_client_addr;

/* Port upon which flowcap listens for connecting clients (consumers). */
extern uint16_t fc_listen_port;

/* Files will be split into multiple files if they reach this size. */
extern uint32_t maxFileSize;

/* Amount of disk space to set aside for a file before we know its
 * actual size. */
extern uint64_t allocFileSize;

/* The version of flowcap to produce */
extern uint8_t flowcap_version;

/* The list of probes we care about */
extern sk_vector_t *probe_vec;

/* Whether to send files at all */
extern int server_mode_flag;

#ifdef HAVE_STATVFS
/* leave at least this much free space on the disk; specified by
 * --freespace-minimum */
extern int64_t freespace_minimum;

/* take no more that this amount of the disk; as a percentage.
 * specified by --space-maximum-percent */
extern double space_maximum_percent;
#endif /* HAVE_STATVFS */


#endif /* _FLOWCAP_H */

/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
