/*
** Copyright (C) 2003-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

#include "silk.h"

RCSIDENT("$SiLK: append.c 11232 2008-04-09 17:36:44Z mthomas $");

#include "sendrcv.h"
#include "sksite.h"
#include "sklog.h"


/* Exported variables */
append_options_t append_opt = {APPEND_ENDIAN_AS_IS, SK_INVALID_COMPMETHOD};


/*
 *  status = create_hourly(out_ios, hourly_file, in_hdr)
 *
 *    Given the SiLK Flow stream connected to an incremental file
 *    whose SiLK header is in 'in_hdr', create a new hourly file at
 *    the location specified by 'hourly_file' of the same type and
 *    version (RWSPLIT, etc) to hold the data in the incremental file.
 *    The new stream is put into the value pointed at by 'out_ios'.
 *
 *    The version of the new file is determined by the
 *    'append_opt.mustPad' variable; the endianness of the new file
 *    is determined by the 'append_opt.endian' variable.
 *
 *    Returns 0 on success.  On error, prints a message to the log and
 *    returns -1.
 */
static int create_hourly(
    rwIOStruct            **out_ios,
    const char             *hourly_file,
    const sk_file_header_t *in_hdr)
{
    int rv = RWIO_OK;
    silk_endian_t out_endian;
    sk_compmethod_t out_compmethod;
    sk_file_header_t *out_hdr;

    /* Determine the byte order for the new file */
    switch (append_opt.endian) {
      case APPEND_ENDIAN_AS_IS:
        out_endian = skHeaderGetByteOrder(in_hdr);
        break;
      case APPEND_ENDIAN_LITTLE:
        out_endian = SILK_ENDIAN_LITTLE;
        break;
      case APPEND_ENDIAN_BIG:
        out_endian = SILK_ENDIAN_BIG;
        break;
      case APPEND_ENDIAN_NATIVE:
      default:
        CRITMSG("Unexpected value '%d' in endian switch", append_opt.endian);
        return -1;
    }

    if (append_opt.comp_method == SK_INVALID_COMPMETHOD) {
        /* if user didn't set the value, use that from the file we
         * received */
        out_compmethod = skHeaderGetCompressionMethod(in_hdr);
    } else {
        /* use the value the user specified */
        out_compmethod = append_opt.comp_method;
    }

    /* Create the output stream object and set its attributes */
    rv = skStreamCreate(out_ios, SK_IO_WRITE, SK_CONTENT_SILK_FLOW);
    if (rv == RWIO_OK) {
        rv = skStreamBind(*out_ios, hourly_file);
    }
    if (rv == RWIO_OK) {
        rv = skStreamMakeDirectory(*out_ios);
    }
    if (rv == RWIO_OK) {
        out_hdr = skStreamGetSilkHeader(*out_ios);
        rv = skHeaderCopy(out_hdr, in_hdr,
                          (SKHDR_CP_ALL
                           & ~(SKHDR_CP_ENDIAN | SKHDR_CP_COMPMETHOD)));
    }
    if (rv == RWIO_OK) {
        rv = skHeaderSetCompressionMethod(out_hdr, out_compmethod);
    }
    if (rv == RWIO_OK) {
        rv = skHeaderSetByteOrder(out_hdr, out_endian);
    }

    /* Open the file */
    if (rv == RWIO_OK) {
        rv = skStreamOpen(*out_ios);
    }

    /* Write the header to avoid zero-length files in the data
     * store. */
    if (rv == RWIO_OK) {
        rv = skStreamWriteSilkHeader(*out_ios);
    }

    if (rv == RWIO_OK) {
        /* Success! */
        return 0;
    }

    skStreamPrintLastErr(*out_ios, rv, &WARNINGMSG);
    skStreamDestroy(out_ios);
    return -1;
}


/*
 *  status = append_data(in_path, out_path, &out_pos);
 *
 *    Given the names of an incremental source file, 'in_path', and an
 *    hourly destination file 'out_path', append the data in the
 *    incremental file to the destination file, creating a new
 *    destination file if it does not exist.
 *
 *    The function will set 'out_pos' to the position in the hourly
 *    file where thew new incremental data begins (i.e., the size of
 *    the file before the append); this will be 0 for a newly created
 *    file.
 *
 *    If all goes well, return 0.  If an error occurs, write an error
 *    to the log buffer and return non-zero.  A return value of -1
 *    indicates that no data was appended; 1 indicates that data was
 *    appended at 'out_pos'---indicating that the data file may now be
 *    corrupt.
 */
int append_data(
    const char     *in_path,
    const char     *out_path,
    off_t          *out_pos)
{
    uint32_t long_duration = 0;
    skstream_t *in_ios = NULL;
    skstream_t *out_ios = NULL;
    sk_file_header_t *in_hdr;
    sk_file_header_t *out_hdr;
    int ret_val = -1;
    int rwio_rv;
    int close_rv;
    rwRec rwrec;

    *out_pos = 0;

    /* Open input file */
    if ((rwio_rv = skStreamCreate(&in_ios, SK_IO_READ, SK_CONTENT_SILK))
        || (rwio_rv = skStreamBind(in_ios, in_path))
        || (rwio_rv = skStreamOpen(in_ios))
        || (rwio_rv = skStreamReadSilkHeader(in_ios, &in_hdr)))
    {
        skStreamPrintLastErr(in_ios, rwio_rv, &WARNINGMSG);
        goto END;
    }

    /* Open or create a new file as necessary, protecting against a
     * zero-length file in the data store.  These zero-length files
     * should be a rare occurrence.  Note that skFileSize() also
     * returns 0 for non-existent files. */
    if (0 == skFileSize(out_path)) {
        if (skFileExists(out_path)) {
            /* Remove the zero-length file noisily */
            NOTICEMSG("Removing zero length file '%s'", out_path);
            if (unlink(out_path) == -1) {
                WARNINGMSG("Cannot remove '%s': %s",
                           out_path, strerror(errno));
                goto END;
            }
        }
        /* Create new output file */
        if (0 != create_hourly(&out_ios, out_path, in_hdr)) {
            goto END;
        }
    } else {
        /* Open existing output file */
        if ((rwio_rv = skStreamCreate(&out_ios, SK_IO_APPEND, SK_CONTENT_SILK))
            || (rwio_rv = skStreamBind(out_ios, out_path))
            || (rwio_rv = skStreamOpen(out_ios))
            || (rwio_rv = skStreamReadSilkHeader(out_ios, &out_hdr)))
        {
            skStreamPrintLastErr(out_ios, rwio_rv, &WARNINGMSG);
            goto END;
        }
        *out_pos = skStreamTell(out_ios);

        {
            /* Sanity check that the times in the headers of the two
             * files are the same. */
            union h_un {
                sk_header_entry_t          *he;
                sk_hentry_packedfile_t     *pf;
            } h_in, h_out;
            sktime_t in_time;
            sktime_t out_time;
            char inbuf[SKTIMESTAMP_STRLEN];
            char outbuf[SKTIMESTAMP_STRLEN];

            h_in.he = skHeaderGetFirstMatch(in_hdr, SK_HENTRY_PACKEDFILE_ID);
            h_out.he = skHeaderGetFirstMatch(out_hdr, SK_HENTRY_PACKEDFILE_ID);
            if (h_in.he && h_out.he) {
                in_time = skHentryPackedfileGetStartTime(h_in.pf);
                out_time = skHentryPackedfileGetStartTime(h_out.pf);
                if (in_time != out_time) {
                    NOTICEMSG(("StartTime mismatch in files: "
                               "incremental %s (%s), output %s %s"),
                              in_path, sktimestamp_r(inbuf, in_time, 0),
                              out_path, sktimestamp_r(outbuf, out_time, 0));
                    goto END;
                }
            }
        }
    }

    /* read the first record from the input */
    rwio_rv = rwioReadRecord(in_ios, &rwrec);
    switch (rwio_rv) {
      case RWIO_OK:
        break;

      case RWIO_ERR_READ_EOF:
        INFOMSG("Incremental file '%s' has no records", in_path);
        ret_val = 0;
        goto END;

      default:
        NOTICEMSG("Could not read first record from '%s'", in_path);
        skStreamPrintLastErr(in_ios, rwio_rv, &WARNINGMSG);
        goto END;
    }

    /* we're about to modify the output file; adjust return value */
    ret_val = 1;

    do {
        rwio_rv = rwioWriteRecord(out_ios, &rwrec);
        if (rwio_rv != RWIO_OK) {
            if (RWIO_ERROR_IS_FATAL(rwio_rv)) {
                skStreamPrintLastErr(out_ios, rwio_rv, &WARNINGMSG);
                goto END;
            }

            if ((rwio_rv == SKSTREAM_ERR_ELPSD_OVRFLO)
                && (rwRecGetElapsed(&rwrec) > (1000 * 0x03FF)))
            {
                /* try to handle case of an overflow in the elapsed
                 * time---our formats changed from 11 bits to 12 bits,
                 * but we may be trying to write new 12b into old 11b.
                 */
                ++long_duration;
                rwRecSetElapsed(&rwrec, 1000 * 0x03FF);
                rwio_rv = rwWrite(out_ios, &rwrec);
            }
            if (rwio_rv != RWIO_OK) {
                /* either error wasn't elapsed overflow, or the above
                 * fix didn't help */
                skStreamPrintLastErr(out_ios, rwio_rv, &WARNINGMSG);
            }
        }
    } while (rwRead(in_ios, &rwrec));

    /* log about truncating the elapsed time field */
    if (long_duration > 0) {
        INFOMSG("Truncated elapsed time for %u records in file %s",
                long_duration, rwGetFileName(in_ios));
    }

    /* close the output file.  If we encountered an error
     * previously, leave rwio_rv alone, else set it to the status
     * of the close. */
    close_rv = skStreamClose(out_ios);
    if (close_rv) {
        skStreamPrintLastErr(out_ios, close_rv, &WARNINGMSG);
        /* make this RV the exit status if we were o.k. until here */
        if (rwio_rv == RWIO_OK) {
            rwio_rv = close_rv;
        }
    }

    /* close input */
    close_rv = skStreamClose(in_ios);
    if (close_rv) {
        skStreamPrintLastErr(in_ios, close_rv, &INFOMSG);
    }

    /* everything worked; set output status to success */
    if (rwio_rv == RWIO_OK) {
        ret_val = 0;
    }

  END:
    (void)skStreamDestroy(&out_ios);
    (void)skStreamDestroy(&in_ios);

    return ret_val;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
