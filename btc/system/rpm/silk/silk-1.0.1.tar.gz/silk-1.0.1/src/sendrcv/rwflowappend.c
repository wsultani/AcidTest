/*
** Copyright (C) 2006-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  Daemon that appends rw files to hourly files.
**
*/


#include "silk.h"

RCSIDENT("$SiLK: rwflowappend.c 11232 2008-04-09 17:36:44Z mthomas $");

#include "utils.h"
#include "skpolldir.h"
#include "sksite.h"
#include "sendrcv.h"
#include "sklog.h"
#include "skdaemon.h"


/* LOCAL DEFINES AND TYPEDEFS */

/* where to write --help output */
#define USAGE_FH stdout

/* Default number of seconds between which to poll for new files */
#define AD_DEFAULT_POLL_INTERVAL 15
#define AD_DEFAULT_POLL_INTERVAL_STRING "15"

/* Default location for data */
#ifndef APPEND_ROOT
#  ifdef SILK_DATA_ROOTDIR
#    define APPEND_ROOT SILK_DATA_ROOTDIR
#  else
#    define APPEND_ROOT "/data"
#  endif
#endif


/* LOCAL VARIABLES */

static volatile int shuttingdown = 0;
static skPollDir_t polldir = NULL;
static skPollDirQueue_t pdq = NULL;
static uint32_t polling_interval = AD_DEFAULT_POLL_INTERVAL;
static const char *incoming_dir = NULL;
static const char *root_dir = NULL;
static const char *archive_dir = NULL;
static const char *error_dir = NULL;
static pthread_t filehandler;
static int filehandler_started = 0;
static const char *post_command = NULL;
static const char *hour_file_command = NULL;

/* Options for byte-order switch */
static struct {
    const char     *name;
    silk_endian_t   value;
} byte_order_opts[] = {
    {"as-is",  SILK_ENDIAN_ANY},
    {"native", SILK_ENDIAN_NATIVE},
    {"little", SILK_ENDIAN_LITTLE},
    {"big",    SILK_ENDIAN_BIG},
    {NULL,     SILK_ENDIAN_ANY} /* sentinel */
};


/* OPTIONS SETUP */

typedef enum {
    OPT_INCOMING_DIRECTORY, OPT_ROOT_DIRECTORY,
    OPT_ARCHIVE_DIRECTORY, OPT_ERROR_DIRECTORY,
    OPT_POLLING_INTERVAL,
    OPT_BYTE_ORDER, OPT_PAD_HEADER,
    OPT_POST_COMMAND, OPT_HOUR_FILE_COMMAND
} appOptionsEnum;

static struct option appOptions[] = {
    {"incoming-directory",  REQUIRED_ARG, 0, OPT_INCOMING_DIRECTORY},
    {"root-directory",      REQUIRED_ARG, 0, OPT_ROOT_DIRECTORY},
    {"archive-directory",   REQUIRED_ARG, 0, OPT_ARCHIVE_DIRECTORY},
    {"error-directory",     REQUIRED_ARG, 0, OPT_ERROR_DIRECTORY},
    {"polling-interval",    REQUIRED_ARG, 0, OPT_POLLING_INTERVAL},
    {"byte-order",          REQUIRED_ARG, 0, OPT_BYTE_ORDER},
    {"pad-header",          NO_ARG,       0, OPT_PAD_HEADER},
    {"post-command",        REQUIRED_ARG, 0, OPT_POST_COMMAND},
    {"hour-file-command",   REQUIRED_ARG, 0, OPT_HOUR_FILE_COMMAND},
    {0,0,0,0}               /* sentinel entry */
};

static const char *appHelp[] = {
    ("Watch this directory for new incremental files to\n"
     "\tappend to hourly files"),
    ("Append to/Create hourly files in this directory tree"),
    ("Archive into this directory tree incremental files\n"
     "\tthat were successfully appended to an hourly file. Def. No archive"),
    ("Store in this directory incremental files\n"
     "\tthat were NOT successfully appended to an hourly file"),
    ("Check the incoming-directory this often for new\n"
     "\tincremental files (in seconds). Def. "
     AD_DEFAULT_POLL_INTERVAL_STRING),
    ("Create new hourly files in this byte order. Def. 'as-is'.\n"
     "\tChoices: 'as-is'=same as incremental file, 'native', 'little', 'big'"),
    ("Pad the header of new hourly files so it is a multiple of\n"
     "\tthe record size. Def. No"),
    ("Run this command on incremental file after successfully\n"
     "\tappending. Def. None.  \"%s\" in the command will be substituted\n"
     "\tby the incremental file's name. Requires use of --archive-directory."),
    ("Run this command on new hourly files upon their\n"
     "\tcreation.  Def. None.  \"%s\" in the command is substituted by the\n"
     "\thourly file's name."),
    (char *)NULL
};


/* LOCAL FUNCTION PROTOTYPES */

static void appUsageLong(void);
static void appTeardown(void);
static void appSetup(int argc, char **argv);
static int  appOptionsHandler(clientData cData, int opt_index, char *opt_arg);
static int  byteOrderParse(const char *endian_string);


/* FUNCTION DEFINITONS */

/*
 *  appUsageLong();
 *
 *    Print complete usage information to USAGE_FH.  Pass this
 *    function to skOptionsSetUsageCallback(); skOptionsParse() will
 *    call this funciton and then exit the program when the --help
 *    option is given.
 */
static void appUsageLong(void)
{
#define USAGE_MSG                                                          \
    ("<SWITCHES>\n"                                                        \
     "\tWatches a directory for files containing small numbers of SiLK\n"  \
     "\tflow records (incremental files) and appends those records to\n"   \
     "\thourly files stored in a directory tree creating subdirectories\n" \
     "\tand new hourly files as required.\n")

    FILE *fh = USAGE_FH;

    skAppStandardUsage(fh, USAGE_MSG, appOptions, appHelp);
    sksiteOptionsUsage(fh);
    sksiteCompmethodOptionsUsage(fh);

    fprintf(fh, "\nLogging and daemon switches:\n");
    skdaemonOptionsUsage(fh);
}


/*
 *  appTeardown()
 *
 *    Teardown all modules, close all files, and tidy up all
 *    application state.
 *
 *    This function is idempotent.
 */
static void appTeardown(void)
{
    static int teardownFlag = 0;

    if (teardownFlag) {
        return;
    }
    teardownFlag = 1;
    shuttingdown = 1;

    INFOMSG("Shutting down...");

    if (polldir) {
        skPollDirDestroy(polldir);
    }
    if (pdq) {
        skPollDirQueueDestroy(pdq);
    }

    if (filehandler_started) {
        pthread_join(filehandler, NULL);
    }

    INFOMSG("Finished shutting down.");

    skdaemonTeardown();
    skAppUnregister();
}


/*
 *  appSetup(argc, argv);
 *
 *    Perform all the setup for this application include setting up
 *    required modules, parsing options, etc.  This function should be
 *    passed the same arguments that were passed into main().
 *
 *    Returns to the caller if all setup succeeds.  If anything fails,
 *    this function will cause the application to exit with a FAILURE
 *    exit status.
 */
static void appSetup(int argc, char **argv)
{
    int arg_index;
    int error_count = 0;

    /* verify same number of options and help strings */
    assert((sizeof(appHelp)/sizeof(char *)) ==
           (sizeof(appOptions)/sizeof(struct option)));

    /* register the application */
    skAppRegister(argv[0]);
    skOptionsSetUsageCallback(&appUsageLong);

    /* register the options */
    if (skOptionsRegister(appOptions, &appOptionsHandler, NULL)
        || sksiteOptionsRegister(SK_SITE_FLAG_CONFIG_FILE))
    {
        skAppPrintErr("Unable to register options");
        exit(EXIT_FAILURE);
    }

    /* Add the --compression-method switch.  This call will cause us
     * to use the compression method set at compile time if the user
     * doesn't provide the switch.  Since we want to default to using
     * the compression on the incremental files, reset the comp_method
     * variable to "invalid". */
    if (sksiteCompmethodOptionsRegister(&(append_opt.comp_method))) {
        skAppPrintErr("Unable to register options");
        exit(EXIT_FAILURE);
    }
    append_opt.comp_method = SK_INVALID_COMPMETHOD;

    /* rcvdaemon runs as a daemon; use the threaded logger */
    if (skdaemonSetup((SKLOG_FEATURE_LEGACY | SKLOG_FEATURE_SYSLOG),
                      argc, argv)
        || sklogEnableThreadedLogging())
    {
        exit(EXIT_FAILURE);
    }

    /* parse the options */
    arg_index = skOptionsParse(argc, argv);
    if (arg_index < 0) {
        /* options parsing should print error */
        skAppUsage();           /* never returns */
    }

    /* Ensure the site config file is available */
    if (sksiteConfigure(1)) {
        ++error_count;
    }

    /* Check directories */
    if (NULL == incoming_dir) {
        skAppPrintErr("Must supply the --%s switch",
                      appOptions[OPT_INCOMING_DIRECTORY].name);
        ++error_count;
    }
    if (NULL == root_dir) {
        skAppPrintErr("Must supply the --%s switch",
                      appOptions[OPT_ROOT_DIRECTORY].name);
        ++error_count;
    }
    if (NULL == error_dir) {
        skAppPrintErr("Must supply the --%s switch",
                      appOptions[OPT_ERROR_DIRECTORY].name);
        ++error_count;
    }

    /* When post-command is given, verify that archive_dir is set. */
    if ((post_command != NULL) && (archive_dir == NULL)) {
        skAppPrintErr("Must specify --%s when using the --%s switch",
                      appOptions[OPT_ARCHIVE_DIRECTORY].name,
                      appOptions[OPT_POST_COMMAND].name);
        ++error_count;
    }

    /* verify the required options for logging */
    if (skdaemonOptionsVerify()) {
        ++error_count;
    }

    /* check for extraneous arguments */
    if (arg_index != argc) {
        skAppPrintErr("Too many arguments or unrecognized switch '%s'",
                      argv[arg_index]);
        ++error_count;
    }

    if (error_count) {
        skAppUsage();             /* never returns */
    }

    /* set root directory */
    if (sksiteSetRootDir(root_dir)) {
        exit(EXIT_FAILURE);
    }

    if (atexit(appTeardown) < 0) {
        skAppPrintErr("Unable to register appTeardown() with atexit()");
        appTeardown();
        exit(EXIT_FAILURE);
    }

    return;  /* OK */
}


/*
 *  status = appOptionsHandler(cData, opt_index, opt_arg);
 *
 *    This function is passed to skOptionsRegister(); it will be called
 *    by skOptionsParse() for each user-specified switch that the
 *    application has registered; it should handle the switch as
 *    required---typically by setting global variables---and return 1
 *    if the switch processing failed or 0 if it succeeded.  Returning
 *    a non-zero from from the handler causes skOptionsParse() to return
 *    a negative value.
 *
 *    The clientData in 'cData' is typically ignored; 'opt_index' is
 *    the index number that was specified as the last value for each
 *    struct option in appOptions[]; 'opt_arg' is the user's argument
 *    to the switch for options that have a REQUIRED_ARG or an
 *    OPTIONAL_ARG.
 */
static int appOptionsHandler(
    clientData  UNUSED(cData),
    int         opt_index,
    char       *opt_arg)
{
    int rv;

    switch ((appOptionsEnum)opt_index) {
      case OPT_INCOMING_DIRECTORY:
        if (skOptionsCheckDirectory(opt_arg, appOptions[opt_index].name)) {
            return 1;
        }
        incoming_dir = opt_arg;
        break;

      case OPT_ROOT_DIRECTORY:
        if (skOptionsCheckDirectory(opt_arg, appOptions[opt_index].name)) {
            return 1;
        }
        root_dir = opt_arg;
        break;

      case OPT_ARCHIVE_DIRECTORY:
        if (skOptionsCheckDirectory(opt_arg, appOptions[opt_index].name)) {
            return 1;
        }
        archive_dir = opt_arg;
        break;

      case OPT_ERROR_DIRECTORY:
        if (skOptionsCheckDirectory(opt_arg, appOptions[opt_index].name)) {
            return 1;
        }
        error_dir = opt_arg;
        break;

      case OPT_POLLING_INTERVAL:
        rv = skStringParseUint32(&polling_interval, opt_arg, 1, 0);
        if (rv) {
            goto PARSE_ERROR;
        }
        break;

      case OPT_PAD_HEADER:
        break;

      case OPT_BYTE_ORDER:
        if (byteOrderParse(opt_arg)) {
            return 1;
        }
        break;

      case OPT_POST_COMMAND:
        post_command = opt_arg;
        break;

      case OPT_HOUR_FILE_COMMAND:
        hour_file_command = opt_arg;
        break;
    }

    return 0;  /* OK */

  PARSE_ERROR:
    skAppPrintErr("Invalid %s '%s': %s",
                  appOptions[opt_index].name, opt_arg,
                  skStringParseStrerror(rv));
    return 1;
}


/*
 *  ok = byteOrderParse(argument)
 *
 *    parse the argument to the --byte-order switch
 */
static int byteOrderParse(const char *endian_string)
{
    static int option_seen = 0;
    int i;
    size_t len;
    silk_endian_t byte_order = SILK_ENDIAN_ANY;

    /* only process option one time */
    if (option_seen != 0) {
        skAppPrintErr("Option %s given multiple times",
                      appOptions[OPT_BYTE_ORDER].name);
        return 1;
    }
    option_seen = 1;

    len = strlen(endian_string);
    if (len == 0) {
        skAppPrintErr("Invalid %s: Empty string",
                      appOptions[OPT_BYTE_ORDER].name);
        return 1;
    }

    /* parse user's input */
    for (i = 0; byte_order_opts[i].name; ++i) {
        if ((len <= strlen(byte_order_opts[i].name))
            && (0 == strncmp(byte_order_opts[i].name, endian_string, len)))
        {
            byte_order = byte_order_opts[i].value;
            option_seen = 2;
            break;
        }
    }

    if (option_seen != 2) {
        skAppPrintErr("Invalid %s '%s': Unrecognized value",
                      appOptions[OPT_BYTE_ORDER].name, endian_string);
        return 1;
    }

    switch (byte_order) {
      case SILK_ENDIAN_ANY:
        append_opt.endian = APPEND_ENDIAN_AS_IS;
        break;

      case SILK_ENDIAN_NATIVE:
#if IS_LITTLE_ENDIAN
        append_opt.endian = APPEND_ENDIAN_LITTLE;
#else
        append_opt.endian = APPEND_ENDIAN_BIG;
#endif
        break;

      case SILK_ENDIAN_LITTLE:
        append_opt.endian = APPEND_ENDIAN_LITTLE;
        break;

      case SILK_ENDIAN_BIG:
        append_opt.endian = APPEND_ENDIAN_BIG;
        break;
    }

    return 0;
}


/*
 *  THREAD ENTRY POINT
 *
 *  appendCommandThread((void*)cmd);
 *
 *    Run 'cmd' as a system command in a detached thread then exit the
 *    thread.
 */
static void *appendCommandThread(void *vcommand)
{
    char *cmd = (char *)vcommand;
    int rv;

    assert(cmd);
    pthread_detach(pthread_self());
    rv = system(cmd);
    if (rv == -1) {
        WARNINGMSG("Could not fork to execute postprocessing command.");
        exit(EXIT_FAILURE);
    }
    if (WEXITSTATUS(rv) != 0) {
        INFOMSG("Return value %d from \"%s\"", WEXITSTATUS(rv), cmd);
    }
#ifdef DEBUG
    else {
        INFOMSG("Return value %d from \"%s\"", WEXITSTATUS(rv), cmd);
    }
#endif
    free(cmd);

    return NULL;
}


/*
 *  appendDoCommand(command, filename);
 *
 *    Prepare to run the command specified in 'command'
 *    on the 'filename'; then create a thread and run it.
 */
static void appendDoCommand(const char *command, const char *file)
{
    size_t len = strlen(command);
    size_t file_len = strlen(file);
    const char *fp;
    const char *pcp;
    char *cmd;
    char *cp;
    pthread_t thread;
    int rv;

    /* determine length of buffer needed to hold command and allocate
     * it. */
    pcp = command;
    while (NULL != (fp = strstr(pcp, "%s"))) {
        len += file_len - 2;
        pcp = fp + 2;
    }
    cmd = malloc(len + 1);
    if (cmd == NULL) {
        WARNINGMSG("Unable to allocate memory for postprocessing command");
        return;
    }

    /* copy command into buffer; replacing %s with 'file' */
    pcp = command;
    cp = cmd;
    while (NULL != (fp = strstr(pcp, "%s"))) {
        strncpy(cp, pcp, fp - pcp);
        cp += (fp - pcp);
        strcpy(cp, file);
        cp += file_len;
        pcp = fp + 2;
    }
    strcpy(cp, pcp);
    cp[len] = '\0';

    /* Create the thread */
    rv = pthread_create(&thread, NULL, appendCommandThread, cmd);
    if (rv != 0) {
        WARNINGMSG("Unable to create a thread to run postprocessing command.");
        exit(EXIT_FAILURE);
    }
}


/*
 *  THREAD ENTRY POINT
 *
 *  This is the entry point for the filehandler thread.
 *
 *  This function waits for files to appear on the valid file deque
 *  (validQ).  When files appear, they are popped off the queue and
 *  processed.
 */
static void *handleFileThread(void UNUSED(*dummy))
{
    sigset_t sigs;
    char temp[PATH_MAX];
    char in_path[PATH_MAX];
    char out_path[PATH_MAX];
    char *in_basename;
    char *out_basename;
    char *relative_dir;
    off_t pos;
    int rv;

    sigfillset(&sigs);
    pthread_sigmask(SIG_SETMASK, &sigs, NULL);

    pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, NULL);
    pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);

    INFOMSG("Starting file handling thread.");

    while (!shuttingdown) {
        /* Get the next incremental file name from the polling
         * directory; this is the full path to the file. */
        rv = skPollDirGetNextFile(pdq, in_path, &in_basename);
        if (rv == -1) {
            if (skPollDirGetError(polldir) != PDERR_NONE) {
                ERRMSG("Fatal polling error.");
                exit(EXIT_FAILURE);
            }
            break;
        } else if (rv != 0) {
            continue;
        }

        /* Break the pathname of the incremental file into pieces and
         * determine the pathname of the hourly file to which the
         * incremental file will be appended. */
        if ( !sksiteParseGeneratePath(out_path, sizeof(out_path),
                                      in_path, "", /* no suffix */
                                      &relative_dir,
                                      &out_basename))
        {
            WARNINGMSG("Could not parse filename '%s'.", in_path);

            /* Move to error directory */
            snprintf(temp, sizeof(temp), "%s/%s",
                     error_dir, in_basename);
            rv = skMoveFile(in_path, temp);
            if (rv) {
                WARNINGMSG("Could not move bad data %s to error dir %s: %s",
                           in_path, temp, strerror(rv));
            }
            continue;
        }

        /* Append incremental file to hourly file. */
        rv = append_data(in_path, out_path, &pos);
        if (rv != 0) {
            /* Failed */
            if (rv == -1) {
                WARNINGMSG("APPEND FAILED %s to %s\nnothing written",
                           in_basename, out_path);
            } else {
                WARNINGMSG(("APPEND FAILED %s to %s @ %" PRId64),
                           in_basename, out_path,
                           (int64_t)pos);
            }

            /* Move to error directory */
            snprintf(temp, sizeof(temp), "%s/%s",
                     error_dir, in_basename);
            report("rwflowappend append failure",
                   "Could not append data. Moving to '%s'", temp);
            rv = skMoveFile(in_path, temp);
            if (rv) {
                WARNINGMSG("Could not move bad data %s to error dir %s: %s",
                           in_path, temp, strerror(rv));
            }
            ERRMSG("Aborting due to append error.");
            exit(EXIT_FAILURE);
        }

        /* Success */
        INFOMSG(("APPEND OK %s to %s @ %" PRId64),
                in_basename, out_path, (int64_t)pos);

        /* Run command if this is a new hourly file */
        if (pos == 0 && hour_file_command) {
            appendDoCommand(hour_file_command, out_path);
        }

        /* If the --archive-directory was not specified, delete the
         * incremental file.  Otherwise, achive the incremental file
         * and and run the --post-command on it. */
        if (archive_dir == NULL) {
            /* Remove file */
            if (unlink(in_path) == -1) {
                WARNINGMSG("Could not remove '%s': %s",
                           in_path, strerror(errno));
            }
        } else {
            /* modify out_path so it terminates just after the
             * relative directory and before the basename. */
            *(out_basename - 1) = '\0';

            /* Create archive directory */
            snprintf(temp, sizeof(temp), "%s/%s",
                     archive_dir, relative_dir);
            if (skMakeDir(temp)) {
                WARNINGMSG("Could not create archive directory %s: %s",
                           temp, strerror(errno));
                continue;
            }

            /* Move to archive directory */
            snprintf(temp, sizeof(temp), "%s/%s/%s",
                     archive_dir, relative_dir, in_basename);
            rv = skMoveFile(in_path, temp);
            if (rv) {
                WARNINGMSG("Could not move %s to %s: %s",
                           in_path, temp, strerror(rv));
                continue;
            }

            /* Run post-command on archived file */
            if (post_command) {
                appendDoCommand(post_command, temp);
            }
        }
    }

    INFOMSG("Exiting file handling thread.");

    return NULL;
}


int main(int argc, char **argv)
{
    appSetup(argc, argv);       /* never returns on error */

    /* start the logger and become a daemon */
    if (skdaemonize(&shuttingdown, NULL) == -1) {
        exit(EXIT_FAILURE);
    }

    /* Set up directory polling */
    pdq = skPollDirQueueCreate();
    if (NULL == pdq) {
        skAppPrintErr("Could not create a polldir queue.");
        ERRMSG("Could not create a polldir queue.");
        exit(EXIT_FAILURE);
    }
    polldir = skPollDirCreate(incoming_dir, polling_interval, pdq);
    if (NULL == polldir) {
        skAppPrintErr("Could not initiate polling on %s", incoming_dir);
        ERRMSG("Could not initiate polling on %s", incoming_dir);
        exit(EXIT_FAILURE);
    }

    /* Start the appending thread. */
    if (pthread_create(&filehandler, NULL, handleFileThread, NULL)) {
        skAppPrintErr("Failed to start file handling thread.");
        ERRMSG("Failed to start file handling thread.");
        exit(EXIT_FAILURE);
    }
    filehandler_started = 1;

    /* Any additional errors go to the log */
    skAppSetFuncPrintErr(&WARNINGMSG_v);

    while (!shuttingdown) {
        pause();
    }

    /* done */
    appTeardown();
    return 0;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
