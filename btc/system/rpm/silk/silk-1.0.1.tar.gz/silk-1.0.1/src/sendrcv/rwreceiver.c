/*
** Copyright (C) 2006-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  SiLK file transfer program (receiver)
**
**  Michael Welsh Duggan
**  December 2006
*/


#include "silk.h"

RCSIDENT("$SiLK: rwreceiver.c 11244 2008-04-11 15:38:16Z mthomas $");

#include "utils.h"
#include "skdaemon.h"
#include "sklog.h"
#include "skmsg.h"
#include "rwtransfer.h"

/* LOCAL DEFINES AND TYPEDEFS */

/* where to write --help output */
#define USAGE_FH stdout

#define RWRECEIVER_PASSWORD_ENV ("RWRECEIVER" PASSWORD_ENV_POSTFIX)

/* EXPORTED VARIABLE DEFINITIONS */

/* Set to non-zero when shutting down. */
int shuttingdown;

/* Per-sender data */
struct rbtree *transfers;

/* Local-side and remote-side version type identifiers */
skm_type_t local_version_check = CONN_RECEIVER_VERSION;
skm_type_t remote_version_check = CONN_SENDER_VERSION;

/* Password environment variable name */
const char *password_env = RWRECEIVER_PASSWORD_ENV;

/* LOCAL VARIABLE DEFINITIONS */

/* Destination directory */
static char *destination_dir;


/* OPTIONS SETUP */

typedef enum {
    /* App specific options */
    OPT_DESTINATION_DIR
} appOptionsEnum;

static struct option appOptions[] = {
    {"destination-directory", REQUIRED_ARG, 0, OPT_DESTINATION_DIR},
    {0,0,0,0}           /* sentinel entry */
};

static const char *appHelp[] = {
    ("Directory in which to drop incoming files"),
    (char *)NULL
};


/* LOCAL FUNCTION PROTOTYPES */

static void appUsageLong(void);
static void appTeardown(void);
static void appSetup(int argc, char **argv);
static int  appOptionsHandler(clientData cData, int opt_index, char *opt_arg);
static void rwreceiverVerifyOptions(void);


/* FUNCTION DEFINITIONS */

/*
 *  appUsageLong();
 *
 *    Print complete usage information to USAGE_FH.  This function is
 *    passed to optionsSetup(); skOptionsParse() will call this funciton
 *    and then exit the program when the --help option is given.
 */
static void appUsageLong(void)
{
#define USAGE_MSG                                                       \
    ("<SWITCHES>\n"                                                     \
     "\tAccepts files from one or more sender daemons (rwsender)\n"     \
     "\tand places them in a given directory.\n")

    transferUsageLong(USAGE_FH, USAGE_MSG, appOptions, appHelp);
}


/*
 *  appTeardown()
 *
 *    Teardown all modules, close all files, and tidy up all
 *    application state.
 *
 *    This function is idempotent.
 */
static void appTeardown(void)
{
    static int teardownFlag = 0;
    RBLIST *iter;
    transfer_t *sndr;

    if (teardownFlag) {
        return;
    }
    teardownFlag = 1;

    NOTICEMSG("Shutting down");

    transferShutdown();
    transferTeardown();

    /* Destroy stuff */
    iter = rbopenlist(transfers);
    CHECK_ALLOC(iter);
    while ((sndr = (transfer_t *)rbreadlist(iter)) != NULL) {

        if (sndr->ident != NULL) {
            free(sndr->ident);
        }
        free(sndr);
    }
    rbcloselist(iter);
    rbdestroy(transfers);

    NOTICEMSG("Finished shutting down");

    skdaemonTeardown();
    skAppUnregister();
}


/*
 *  appSetup(argc, argv);
 *
 *    Perform all the setup for this application include setting up
 *    required modules, parsing options, etc.  This function should be
 *    passed the same arguments that were passed into main().
 *
 *    Returns to the caller if all setup succeeds.  If anything fails,
 *    this function will cause the application to exit with a FAILURE
 *    exit status.
 */
static void appSetup(int argc, char **argv)
{
    int arg_index;

    /* check that we have the same number of options entries and help*/
    assert((sizeof(appHelp)/sizeof(char *)) ==
           (sizeof(appOptions)/sizeof(struct option)));

    /* register the application */
    skAppRegister(argv[0]);
    skOptionsSetUsageCallback(&appUsageLong);

    /* initialize globals */
    shuttingdown          = 0;
    destination_dir       = NULL;

    transfers = transferIdentTreeCreate();
    if (transfers == NULL) {
        skAppPrintErr("Unable to allocate reciever data structure");
        exit(EXIT_FAILURE);
    }

    /* register the options and handler */
    if (skOptionsRegister(appOptions, &appOptionsHandler, NULL))
    {
        skAppPrintErr("Unable to register application options");
        exit(EXIT_FAILURE);
    }

    /* Register the other transfer options */
    if (transferSetup()) {
        exit(EXIT_FAILURE);
    }

    /* senddaemon runs as a daemon */
    if (skdaemonSetup((SKLOG_FEATURE_LEGACY | SKLOG_FEATURE_SYSLOG),
                      argc, argv)
        || sklogEnableThreadedLogging())
    {
        exit(EXIT_FAILURE);
    }

    /* parse the options */
    arg_index = skOptionsParse(argc, argv);
    if (arg_index < 0) {
        /* options parsing should print error */
        skAppUsage();           /* never returns */
    }

    /* Verify the options */
    rwreceiverVerifyOptions();

    /* verify the required options for logging */
    if (skdaemonOptionsVerify()) {
        skAppUsage();           /* never returns */
    }

    /* check for extraneous arguments */
    if (arg_index != argc) {
        skAppPrintErr("Too many arguments or unrecognized switch --%s",
                      argv[arg_index]);
        skAppUsage();           /* never returns */
    }

    /* Identify the main thread */
    skthread_init("main");

    return;  /* OK */
}


/*
 *  status = appOptionsHandler(cData, opt_index, opt_arg);
 *
 *    This function is passed to skOptionsRegister(); it will be called
 *    by skOptionsParse() for each user-specified switch that the
 *    application has registered; it should handle the switch as
 *    required---typically by setting global variables---and return 1
 *    if the switch processing failed or 0 if it succeeded.  Returning
 *    a non-zero from from the handler causes skOptionsParse() to return
 *    a negative value.
 *
 *    The clientData in 'cData' is typically ignored; 'opt_index' is
 *    the index number that was specified as the last value for each
 *    struct option in appOptions[]; 'opt_arg' is the user's argument
 *    to the switch for options that have a REQUIRED_ARG or an
 *    OPTIONAL_ARG.
 */
static int appOptionsHandler(
    clientData  UNUSED(cData),
    int         opt_index,
    char       *opt_arg)
{
    switch ((appOptionsEnum)opt_index) {

      case OPT_DESTINATION_DIR:
        if (skOptionsCheckDirectory(opt_arg, appOptions[opt_index].name)) {
            return 1;
        }
        destination_dir = opt_arg;
        break;
    }

    return 0;  /* OK */
}



static void rwreceiverVerifyOptions(void)
{
    int rv;

    /* Verify the transfer options */
    rv = transferVerifyOptions();
    if (rv != 0) {
        skAppUsage();           /* never returns */
    }

    /* Check for the existance of destination_dir */
    if (destination_dir == NULL) {
        skAppPrintErr("A destination directory is required");
        skAppUsage();           /* never returns */
    }
}


int transferUnblock(transfer_t *UNUSED(item))
{
    return 0;
}


void transferFiles(
    sk_msg_queue_t *q,
    skm_channel_t channel,
    transfer_t *sndr)
{
    file_info_t *finfo;
    block_info_t *block;
    int fd = -1;
    int dotfd = -1;
    uint64_t offset;
    uint64_t size = 0;
    uint8_t *map = NULL;
    off_t offrv;
    char *name = NULL;
    char *dotname = NULL;
    char path[PATH_MAX];
    char dotpath[PATH_MAX];
    uint32_t len;
    sk_msg_t *msg;
    int proto_err;
    int rv;
    mode_t mode;
    enum transfer_state {File_info, File_info_ack,
                         Send_file, Complete_ack, Error} state;

    state = File_info;
    proto_err = 0;
    path[0] = '\0';
    dotpath[0] = '\0';

    while (!shuttingdown && !proto_err && !sndr->disconnect
           && state != Error)
    {
        /* Handle reads */
        switch (state) {
          case File_info:
          case Send_file:
            rv = skMsgQueueGetMessage(q, &msg);
            if (rv == -1) {
                ASSERT_ABORT(shuttingdown);
                continue;
            }
            if (handleDisconnect(msg, sndr->ident)) {
                state = Error;
                continue;
            }
            break;
          case Error:
            ASSERT_ABORT(0);
            break;
          default:
            msg = NULL;
        }

        /* Handle all states */
        switch (state) {
          case File_info:
            if ((proto_err = checkMsg(msg, q, CONN_NEW_FILE))) {
                break;
            }
            DEBUG_PRINT1("Received CONN_NEW_FILE");
            finfo = (file_info_t *)skMsgMessage(msg);
            size = (uint64_t)ntohl(finfo->high_filesize) << 32 |
                   ntohl(finfo->low_filesize);
            /* blocksize = ntohl(finfo->block_size); --- UNUSED */
            mode = ntohl(finfo->mode) & 0777;
            len = skMsgLength(msg) - offsetof(file_info_t, filename);
            dotname = (char *)calloc(1, len + 1);
            CHECK_ALLOC(dotname);
            name = dotname + 1;
            dotname[0] = '.';
            memcpy(name, finfo->filename, len);
            if (!memchr(name, '\0', len)) {
                sendString(q, channel, EXTERNAL, CONN_DISCONNECT,
                           LOG_WARNING, "Illegal filename (from %s)",
                           sndr->ident);
                state = Error;
                break;
            }

            INFOMSG("Receiving %s", name);

            /* Create the filename and .filename */
            rv = snprintf(dotpath, sizeof(dotpath), "%s/%s",
                          destination_dir, dotname);
            if ((size_t)rv >= sizeof(path)) {
                sendString(q, channel, EXTERNAL, CONN_DISCONNECT,
                           LOG_WARNING, "Filename too long (from %s)",
                           sndr->ident);
                state = Error;
                break;
            }
            rv = snprintf(path, sizeof(path), "%s/%s", destination_dir, name);
            assert((size_t)rv < sizeof(path));

            fd = open(path, O_CREAT | O_EXCL, 0);
            if (fd == -1) {
                if (errno == EEXIST) {
                    path[0] = dotpath[0] = '\0';
                    sendString(q, channel, EXTERNAL, CONN_DISCONNECT,
                               LOG_WARNING,
                               "Filename already exists (from %s)",
                               sndr->ident);
                    state = Error;
                    break;
                }
                CRITMSG("Could not create %s: %s", path, strerror(errno));
                threadExit(EXIT_FAILURE, NULL);
            }
            DEBUGMSG("Created %s", path);

            rv = close(fd);
            fd = -1;
            if (rv == -1) {
                CRITMSG("Could not close file descriptor for %s: %s", path,
                        strerror(errno));
                threadExit(EXIT_FAILURE, NULL);
            }

            dotfd = open(dotpath, O_RDWR | O_CREAT | O_EXCL, mode);
            if (dotfd == -1) {
                CRITMSG("Could not create %s: %s", dotpath, strerror(errno));
                dotpath[0] = '\0';
                unlink(path);
                threadExit(EXIT_FAILURE, NULL);
            }
            DEBUGMSG("Created %s", dotpath);

            /* Allocate space */
            offrv = lseek(dotfd, size - 1, SEEK_SET);
            if (offrv == -1) {
                CRITMSG("Could not allocate disk space for %s: %s", dotpath,
                        strerror(errno));
                unlink(path);
                unlink(dotpath);
                threadExit(EXIT_FAILURE, NULL);
            }
            rv = write(dotfd, "", 1);
            if (rv == -1) {
                CRITMSG("Could not allocate disk space for %s: %s", dotpath,
                        strerror(errno));
                unlink(path);
                unlink(dotpath);
                threadExit(EXIT_FAILURE, NULL);
            }

            /* Map space */
            map = (uint8_t *)mmap(0, size, PROT_READ | PROT_WRITE, MAP_SHARED,
                                  dotfd, 0);
            if ((void *)map == MAP_FAILED) {
                CRITMSG("Could not map %s: %s", dotpath,
                        strerror(errno));
                unlink(path);
                unlink(dotpath);
                threadExit(EXIT_FAILURE, NULL);
            }
            rv = close(dotfd);
            dotfd = -1;
            if (rv == -1) {
                CRITMSG("Could not close file descriptor for %s: %s", dotpath,
                        strerror(errno));
                unlink(path);
                unlink(dotpath);
                threadExit(EXIT_FAILURE, NULL);
            }

            state = File_info_ack;
            break;

          case File_info_ack:
            DEBUG_PRINT1("Sending CONN_NEW_FILE_READY");
            proto_err = skMsgQueueSendMessage(q, channel,
                                              CONN_NEW_FILE_READY, NULL, 0);
            state = Send_file;
            break;

          case Send_file:
            if (skMsgType(msg) != CONN_FILE_BLOCK) {
                if ((proto_err = checkMsg(msg, q, CONN_FILE_COMPLETE))) {
                    break;
                }
                DEBUG_PRINT1("Received CONN_FILE_COMPLETE");
                state = Complete_ack;
                break;
            }

            block = (block_info_t *)skMsgMessage(msg);
            len = skMsgLength(msg) - offsetof(block_info_t, block);
            offset = (uint64_t)ntohl(block->high_offset) << 32 |
                     ntohl(block->low_offset);
            DEBUG_MSG_PRINT("Receiving offset == %" PRIu64 "  len == %" PRIu32,
                            offset, len);
            if (offset + len > size) {
                sendString(q, channel, EXTERNAL, CONN_DISCONNECT,
                           LOG_WARNING,
                           ("Illegal block (offset/size %" PRIu64
                            "/%" PRIu32 ")"), offset, len);
                state = Error;
                break;
            }
            memcpy(map + offset, block->block, len);
            break;

          case Complete_ack:
            rv = munmap(map, size);
            map = NULL;
            if (rv == -1) {
                CRITMSG("Could not unmap file %s: %s",
                        dotpath, strerror(errno));
                threadExit(EXIT_FAILURE, NULL);
            }
            DEBUGMSG("Renaming %s to %s", dotpath, path);
            rv = rename(dotpath, path);
            if (rv == -1) {
                int tmperr = errno;
                DEBUGMSG("Failed rename.  Removing %s", dotpath);
                rv = unlink(dotpath);
                if (rv == -1) {
                    CRITMSG("Could not rename or remove %s: %s", dotpath,
                            strerror(tmperr));
                    threadExit(EXIT_FAILURE, NULL);
                }
                path[0] = dotpath[0] = '\0';
                sendString(q, channel, EXTERNAL, CONN_DISCONNECT,
                           LOG_WARNING, "File creation error for %s from %s",
                           name, sndr->ident);
                state = Error;
                break;
            }
            dotpath[0] = '\0';

            DEBUG_PRINT1("Sending CONN_FILE_COMPLETE");
            proto_err = skMsgQueueSendMessage(q, channel,
                                              CONN_FILE_COMPLETE, NULL, 0);
            if (proto_err == 0) {
                path[0] = '\0';
                INFOMSG("Finished receiving %s", name);
                free(dotname);
                dotname = NULL;
            }
            state = File_info;
            break;

          case Error:
            ASSERT_ABORT(0);
        }

        if (msg != NULL) {
            skMsgDestroy(msg);
        }
    }

    if (fd != -1) {
        close(fd);
    }
    if (dotfd != -1) {
        close(fd);
    }
    if (map != NULL) {
        munmap(map, size);
    }
    if (dotname != NULL) {
        free(dotname);
    }
    if (dotpath[0] != '\0') {
        DEBUGMSG("Removing %s", dotpath);
        unlink(dotpath);
    }
    if (path[0] != '\0') {
        DEBUGMSG("Removing %s", path);
        unlink(path);
    }
}


int main(int argc, char **argv)
{
    int rv;

    appSetup(argc, argv);       /* never returns on error */

    /* start the logger and become a daemon */
    rv = skdaemonize(&shuttingdown, &appTeardown);
    if (rv == -1) {
        exit(EXIT_FAILURE);
    }

    /* Run in client or server mode */
    rv = startTransferDaemon();
    if (rv != 0) {
        exit(EXIT_FAILURE);
    }

    /* We now run forever, accepting signals */
    while (!shuttingdown) {
        pause();
    }

    /* done */
    appTeardown();
    return main_retval;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
