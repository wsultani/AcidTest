/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/
#ifndef _SNDRCV_H
#define _SNDRCV_H

#include "silk.h"

RCSIDENTVAR(rcsID_SNDRCV_H, "$SiLK: sendrcv.h 11232 2008-04-09 17:36:44Z mthomas $");

#include "utils.h"
#include "rwpack.h"

/* handle the old logging mechanism in deprecated rcvdaemon and senddaemon */
#define logMsg  INFOMSG
#define vlogMsg INFOMSG_v


typedef enum {
    APPEND_ENDIAN_AS_IS,  /* Don't mess with the byte order of received file */
    APPEND_ENDIAN_NATIVE, /* Write received file in native endian */
    APPEND_ENDIAN_LITTLE, /* Write received file in little (vax) endian */
    APPEND_ENDIAN_BIG     /* Write received file in big (network) endian */
} append_endian_t;


/* options required by append.c that both rcv_main.c and rwcopyd.c
 * need to set */
typedef struct append_options_st {
    /* byte order of the files we generate; default is to use the
     * order of the files we receive */
    append_endian_t endian;
    /* compression method of the files we generate; default is to use
     * the method of the files we receive */
    sk_compmethod_t comp_method;
} append_options_t;


/* *****    append.c    ***** */

int append_data(
    const char     *in_path,
    const char     *out_path,
    off_t          *out_pos);

extern append_options_t append_opt;


/* *****    naming.c    ***** */

/* Structure to hold an input pathname and it's corresponding output
 * location; directory sub-paths are available. */
typedef struct file_names_st {
    /* The pathname we get from the transfer library; this is the
     * incremental file. */
    char   *input_path;
    /* A copy of 'input_path' used for next two values; embedded
     * NULs are used to set next two values. */
    char    _input_copy[PATH_MAX];
    /* Pointer into _input_copy that points at first character. */
    char   *input_dirname;
    /* Pointer into _input_copy that points at base file name */
    char   *input_basename;

    /* Where to write the contents of the incremental file; this is
     * the hourly file. */
    char    output_path[PATH_MAX];
    /* A copy of the 'output_path'; embedded NULs are used to set the
     * next three values. */
    char    _output_copy[PATH_MAX];
    /* Pointer into _output_copy that points at first character. */
    char   *data_rootdir;
    /* Pointer into _output_copy that points at end of the root_dir. */
    char   *relative_dir;
    /* Pointer into _output_copy that points at the base file name;
     * this value will be similar to the value in 'input_basename'
     * except that any .XXXXXX suffix added by mkstemp() will have
     * been removed. */
    char   *output_file;
} file_names_t;


void namingSetDataRootdir(const char *fName);
/*
 *    Set the root of data directory to 'fName'.
 *
 *    For the rcvdaemon, this is the directory where the analysis
 *    applications expect the data files to live, and the directory to
 *    which the receiver ultimately writes its data files.
 *
 *    For the senddaemon, this is the 'stash_directory'.
 */


const char *namingGetDataRootdir(void);
/*
 *    Return the root of data directory as set in a previous call to
 *    namingSetDataRootdir().  The caller should not modify nor free
 *    the returned value.
 */


int parsePath(file_names_t *fnames);
/*
 *    The caller should pass in a pointer to a file_names_t structure
 *    with the 'input_path' field pointing to a character array that
 *    contains the path to a standard SiLK packed data file---e.g.,
 *    "in-S001_20040506.07" where "in" is the prefix, "S001" the
 *    sensor, "2004" the year, "05" the month, "06" the date, and "07"
 *    the hour.  The 'input_path' MUST include a slash ('/')
 *    character.
 *
 *    The routine will break the input name into its directory and
 *    basename components---filling input_dirname and input_basename.
 *
 *    Based on the root directory that was passed to
 *    namingSetDataRootdir(), the routine will determine the complete
 *    path to the file's output location and set the 'output_path'
 *    field to that value.  The 'data_rootdir' field contains the
 *    value passed to namingSetDataRootdir(); the 'relative_dir'
 *    contains the relative directory based on flow-type and date
 *    (e.g., "in/2004/05/06"); the 'output_file' field contains the
 *    filename which will be the same as the 'input_basename' except
 *    that any ".XXXXXX" suffix added by mkstemp() will be removed.
 *
 *    Return 0 on success, or -1 on error: namingSetDataRootdir() has
 *    not been called; the input_path does not contain a '/'; the file
 *    name does not match the standard packed data file pattern.
 *
 *    This function works with C-strings, it does not check that any
 *    input or output location or directory exists.  The function
 *    allocates no memory; in particular, it does not create a copy of
 *    'input_path'.
 */


/* *****    sender2.c    ***** */

extern void *connectAndSend(void *);


#endif /* _SNDRCV_H */

/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
