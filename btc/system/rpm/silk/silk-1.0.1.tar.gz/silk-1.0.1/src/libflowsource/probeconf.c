/*
** Copyright (C) 2004-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

#include "silk.h"

RCSIDENT("$SiLK: probeconf.c 11040 2008-03-25 13:59:42Z mthomas $");

#include "probeconf.h"
#include "probeconfscan.h"
#include "libflowsource.h"
#include "sklog.h"
#include "sksite.h"

/*
 *  *****  Flow Type  **************************************************
 *
 *
 *  The probe is used to determine the flow-type---as defined by in
 *  the silk.conf file---of a flow record (rwRec) read from that
 *  probe.
 *
 *  The skpcProbeDetermineFlowtype() function is defined in the
 *  probeconf-<$SILK_SITE>.c file.
 *
 */




/* LOCAL DEFINES AND TYPEDEFS */

#define SKAPP_PRINT_NO_MEM \
    skAppPrintErr("Out of memory at %s:%d", __FILE__, __LINE__)

/* Maximum valid value for a port 2^16 - 1 */
#define PORT_VALID_MAX 0xFFFF

/* Set ports to this invalid value initially */
#define PORT_NOT_SET   0xFFFFFFFF

/* Value to use for remaining IPs to say that it hasn't been set */
#define REMAINDER_NOT_SET  INT8_MAX


/* a map between probe types and printable names */
static struct probe_type_name_map_st {
    const char         *name;
    skpc_probetype_t    value;
} probe_type_name_map[PROBE_TYPE_COUNT] = {
    {"netflow",  PROBE_ENUM_NETFLOW},
    {"ipfix",    PROBE_ENUM_IPFIX},
    {"silk",     PROBE_ENUM_SILK}
};


/* a map between protocols and printable names */
static struct skpc_protocol_name_map_st {
    const char     *name;
    uint8_t         num;
    skpc_proto_t    value;
} skpc_protocol_name_map[SKPC_PROTOCOL_COUNT] = {
    {"sctp", 132, SKPC_PROTO_SCTP},
    {"tcp",    6, SKPC_PROTO_TCP},
    {"udp",   17, SKPC_PROTO_UDP}
};


/* LOCAL VARIABLES */

/* The probes that have been created and verified */
static sk_vector_t *skpc_probes = NULL;

/* The sensors that have been created and verified */
static sk_vector_t *skpc_sensors = NULL;

/* The networks that have been created */
static sk_vector_t *skpc_networks = NULL;


/* LOCAL FUNCTION PROTOTYPES */


/* FUNCTION DEFINITIONS */


/*
 *  *****  Probe configuration  **************************************
 */

/* setup the probes */
int skpcSetup(void)
{
    assert(PROBE_ENUM_INVALID == PROBE_TYPE_COUNT);
    assert(SKPC_PROTO_UNSET == SKPC_PROTOCOL_COUNT);

    if (NULL == skpc_probes) {
        skpc_probes = skVectorNew(sizeof(skpc_probe_t*));
        if (NULL == skpc_probes) {
            goto ERROR;
        }
    }

    if (NULL == skpc_sensors) {
        skpc_sensors = skVectorNew(sizeof(skpc_sensor_t*));
        if (NULL == skpc_sensors) {
            goto ERROR;
        }
    }

    if (NULL == skpc_networks) {
        skpc_networks = skVectorNew(sizeof(skpc_network_t));
        if (NULL == skpc_networks) {
            goto ERROR;
        }
    }

    if (skpcParseSetup()) {
        goto ERROR;
    }

    return 0;

  ERROR:
    if (skpc_probes) {
        skVectorDestroy(skpc_probes);
    }
    if (skpc_sensors) {
        skVectorDestroy(skpc_sensors);
    }
    if (skpc_networks) {
        skVectorDestroy(skpc_networks);
    }
    return -1;
}


/* destroy everything */
void skpcTeardown(void)
{
    skpc_network_t *nwp;
    skpc_probe_t **probe;
    skpc_sensor_t **sensor;
    size_t i;

    /* clean up the parser */
    skpcParseTeardown();

    /* Free all the networks */
    if (skpc_networks) {
        for (i = 0;
             NULL != (nwp = skVectorGetValuePointer(skpc_networks, i));
             ++i)
        {
            free(nwp->name);
        }

        /* destroy the vector itself */
        skVectorDestroy(skpc_networks);
        skpc_networks = NULL;
    }

    /* Free all the sensors */
    if (skpc_sensors) {
        for (i = 0;
             NULL != (sensor = skVectorGetValuePointer(skpc_sensors, i));
             ++i)
        {
            skpcSensorDestroy(sensor);
        }

        /* destroy the vector itself */
        skVectorDestroy(skpc_sensors);
        skpc_sensors = NULL;
    }

    /* Free all the probes */
    if (skpc_probes) {
        for (i = 0;
             NULL != (probe = skVectorGetValuePointer(skpc_probes, i));
             ++i)
        {
            skpcProbeDestroy(probe);
        }

        /* destroy the vector itself */
        skVectorDestroy(skpc_probes);
        skpc_probes = NULL;
    }
}


/* return a count of verified probes */
size_t skpcCountProbes(void)
{
    assert(skpc_probes);
    return skVectorGetCount(skpc_probes);
}


int skpcProbeIteratorBind(
    skpc_probe_iter_t  *probe_iter)
{
    if (probe_iter == NULL || skpc_probes == NULL) {
        return -1;
    }
    probe_iter->cur = 0;
    return 0;
}


int skpcProbeIteratorNext(
    skpc_probe_iter_t      *probe_iter,
    const skpc_probe_t    **probe)
{
    if (probe_iter == NULL || probe == NULL) {
        return -1;
    }

    if (0 != skVectorGetValue((void*)probe, skpc_probes, probe_iter->cur)) {
        return 0;
    }

    ++probe_iter->cur;
    return 1;
}


/* return a probe having the given probe-name. */
const skpc_probe_t *skpcProbeLookupByName(
    const char *probe_name)
{
    const skpc_probe_t **probe;
    size_t i;

    assert(skpc_probes);

    /* check input */
    if (probe_name == NULL) {
        return NULL;
    }

    /* loop over all probes until we find one with given name */
    for (i = 0;
         NULL != (probe = skVectorGetValuePointer(skpc_probes, i));
         ++i)
    {
        if (0 == strcmp(probe_name, (*probe)->probe_name)) {
            return *probe;
        }
    }

    return NULL;
}


/* return a count of verified sensors */
size_t skpcCountSensors(void)
{
    assert(skpc_sensors);
    return skVectorGetCount(skpc_sensors);
}


int skpcSensorIteratorBind(
    skpc_sensor_iter_t *sensor_iter)
{
    if (sensor_iter == NULL || skpc_sensors == NULL) {
        return -1;
    }
    sensor_iter->cur = 0;
    return 0;
}


int skpcSensorIteratorNext(
    skpc_sensor_iter_t     *sensor_iter,
    const skpc_sensor_t   **sensor)
{
    if (sensor_iter == NULL || sensor == NULL) {
        return -1;
    }

    if (0 != skVectorGetValue((void*)sensor, skpc_sensors, sensor_iter->cur)) {
        return 0;
    }

    ++sensor_iter->cur;
    return 1;
}


/* return a sensor having the given sensor-name. */
const skpc_sensor_t *skpcSensorLookupByName(
    const char *sensor_name)
{
    const skpc_sensor_t **sensor;
    size_t i;

    assert(skpc_sensors);

    /* check input */
    if (sensor_name == NULL) {
        return NULL;
    }

    /* loop over all sensors until we find one with given name */
    for (i = 0;
         NULL != (sensor = skVectorGetValuePointer(skpc_sensors, i));
         ++i)
    {
        if (0 == strcmp(sensor_name, (*sensor)->sensor_name)) {
            return *sensor;
        }
    }

    return NULL;
}


const skpc_sensor_t *skpcSensorLookupByID(
    sensorID_t  sensor_id)
{
    const skpc_sensor_t **sensor;
    size_t i;

    assert(skpc_sensors);

    /* loop over all sensors until we find one with given id */
    for (i = 0;
         NULL != (sensor = skVectorGetValuePointer(skpc_sensors, i));
         ++i)
    {
        if (sensor_id == (*sensor)->sensor_id) {
            return *sensor;
        }
    }

    return NULL;
}


/*
 *  *****  Network  ****************************************************
 */

/* Add a new id->name pair to the list of networks */
int skpcNetworkAdd(
    uint32_t    id,
    const char *name)
{
    skpc_network_t *nwp;
    skpc_network_t nw;
    size_t i;

    assert(skpc_networks);

    /* check for  */
    for (i = 0;
         NULL != (nwp = skVectorGetValuePointer(skpc_networks, i));
         ++i)
    {
        if (id == nwp->id) {
            /* duplicate id */
            return -2;
        }
        if (0 == strcmp(name, nwp->name)) {
            /* duplicate name */
            return -3;
        }
    }

    /* create network and add it to the vector */
    nw.id = id;
    nw.name = strdup(name);
    if (nw.name == NULL) {
        return -1;
    }
    if (skVectorAppendValue(skpc_networks, &nw)) {
        free(nw.name);
        return -1;
    }

    return 0;
}


/* Find the network that has the given name 'name' */
const skpc_network_t *skpcNetworkLookupByName(const char *name)
{
    skpc_network_t *nwp;
    size_t i;

    assert(skpc_networks);

    for (i = 0;
         NULL != (nwp = skVectorGetValuePointer(skpc_networks, i));
         ++i)
    {
        if (0 == strcmp(name, nwp->name)) {
            return nwp;
        }
    }
    return NULL;
}


/* Find the network that has the given ID 'id' */
const skpc_network_t *skpcNetworkLookupByID(uint32_t id)
{
    skpc_network_t *nwp;
    size_t i;

    assert(skpc_networks);

    for (i = 0;
         NULL != (nwp = skVectorGetValuePointer(skpc_networks, i));
         ++i)
    {
        if (id == nwp->id) {
            return nwp;
        }
    }
    return NULL;
}



/*
 *  *****  Probes  *****************************************************
 */

/* Create a probe */
int skpcProbeCreate(skpc_probe_t **probe)
{
    assert(probe);

    (*probe) = calloc(1, sizeof(skpc_probe_t));
    if (NULL == (*probe)) {
        return -1;
    }

    (*probe)->accept_from_addr = INADDR_ANY;
    (*probe)->listen_as_addr = INADDR_ANY;
    (*probe)->listen_on_port = PORT_NOT_SET;
    (*probe)->probe_type = PROBE_ENUM_NETFLOW;
    (*probe)->protocol = SKPC_PROTO_UNSET;
    (*probe)->priority = PROBE_MIN_PRIORITY;
    (*probe)->log_flags = SOURCE_LOG_ALL;

    return 0;
}


/* Destroy a probe and free all memory associated with it */
void skpcProbeDestroy(skpc_probe_t **probe)
{
    if (!probe || !(*probe)) {
        return;
    }

    if ((*probe)->unix_domain_path) {
        free((*probe)->unix_domain_path);
    }
    if ((*probe)->file_source) {
        free((*probe)->file_source);
    }
    if ((*probe)->poll_directory) {
        free((*probe)->poll_directory);
    }

    free(*probe);
    *probe = NULL;
}


/* Get and set the name of probe */
const char *skpcProbeGetName(const skpc_probe_t *probe)
{
    assert(probe);
    return probe->probe_name;
}

int skpcProbeSetName(skpc_probe_t *probe, const char *name)
{
    const char *cp;
    char *copy;

    assert(probe);
    if (name == NULL || name[0] == '\0') {
        return -1;
    }

    /* check for illegal characters */
    cp = name;
    while (*cp) {
        if (*cp == '/' || isspace((int)*cp)) {
            return -1;
        }
        ++cp;
    }

    copy = strdup(name);
    if (copy == NULL) {
        return -1;
    }
    if (probe->probe_name) {
        free(probe->probe_name);
    }
    probe->probe_name = copy;
    return 0;
}


/* Get and set probe priority */
probe_priority_t skpcProbeGetPriority(const skpc_probe_t *probe)
{
    assert(probe);
    return probe->priority;
}

int skpcProbeSetPriority(
    skpc_probe_t       *probe,
    probe_priority_t    priority)
{
    assert(probe);
    if (priority < PROBE_MIN_PRIORITY || priority > PROBE_MAX_PRIORITY) {
        return -1;
    }
    probe->priority = priority;
    return 0;
}


/* Get and set the probe type */
skpc_probetype_t skpcProbeGetType(
    const skpc_probe_t *probe)
{
    assert(probe);
    return probe->probe_type;
}

int skpcProbeSetType(
    skpc_probe_t       *probe,
    skpc_probetype_t    probe_type)
{
    assert(probe);
    if (probe_type == PROBE_ENUM_INVALID || probe_type > PROBE_TYPE_COUNT) {
        return -1;
    }
    probe->probe_type = probe_type;
    return 0;
}


/* Get and set the probe's protocol */
skpc_proto_t skpcProbeGetProtocol(
    const skpc_probe_t *probe)
{
    assert(probe);
    return probe->protocol;
}

int skpcProbeSetProtocol(
    skpc_probe_t       *probe,
    skpc_proto_t        probe_protocol)
{
    assert(probe);
    if (probe_protocol == SKPC_PROTO_UNSET
        || probe_protocol > SKPC_PROTOCOL_COUNT)
    {
        return -1;
    }
    probe->protocol = probe_protocol;
    return 0;
}


/* Get and set probe log-flags */
uint8_t skpcProbeGetLogFlags(const skpc_probe_t *probe)
{
    assert(probe);
    return probe->log_flags;
}

int skpcProbeSetLogFlags(
    skpc_probe_t       *probe,
    uint32_t            log_flags)
{
    assert(probe);
    if (log_flags > SOURCE_LOG_ALL) {
        return -1;
    }
    probe->log_flags = (uint8_t)(log_flags & 0xFF);
    return 0;
}


/* Get and set host:port to listen on. */
int skpcProbeGetListenAsHost(
    const skpc_probe_t *probe,
    uint32_t           *out_addr,
    uint16_t           *out_port)
{
    assert(probe);
    if (probe->listen_on_port == PORT_NOT_SET) {
        return -1;
    }

    if (out_addr) {
        *out_addr = probe->listen_as_addr;
    }
    if (out_port) {
        *out_port = (uint16_t)probe->listen_on_port;
    }
    return 0;
}

int skpcProbeSetListenAsAddr(
    skpc_probe_t   *probe,
    uint32_t        addr)
{
    assert(probe);

    if (addr == 0) {
        return -1;
    }

    probe->listen_as_addr = addr;
    return 0;
}

int skpcProbeSetListenOnPort(
    skpc_probe_t   *probe,
    uint32_t        port)
{
    assert(probe);
    if (port > PORT_VALID_MAX) {
        return -1;
    }

    probe->listen_on_port = port;
    return 0;
}


/* Get and set the unix domain socket on which to listen. */
const char *skpcProbeGetListenOnUnixDomainSocket(const skpc_probe_t *probe)
{
    assert(probe);
    return probe->unix_domain_path;
}

int skpcProbeSetListenOnUnixDomainSocket(
    skpc_probe_t       *probe,
    const char         *u_socket)
{
    char *copy;

    assert(probe);
    if (u_socket == NULL || u_socket[0] == '\0') {
        return -1;
    }

    copy = strdup(u_socket);
    if (copy == NULL) {
        return -1;
    }
    if (probe->unix_domain_path) {
        free(probe->unix_domain_path);
    }
    probe->unix_domain_path = copy;

    return 0;
}


/* Get and set the file name to read data from */
const char *skpcProbeGetFileSource(const skpc_probe_t *probe)
{
    assert (probe);
    return probe->file_source;
}

int skpcProbeSetFileSource(
    skpc_probe_t       *probe,
    const char         *pathname)
{
    char *copy;

    assert(probe);
    if (pathname == NULL || pathname[0] == '\0') {
        return -1;
    }

    copy = strdup(pathname);
    if (copy == NULL) {
        return -1;
    }
    if (probe->file_source) {
        free(probe->file_source);
    }
    probe->file_source = copy;

    return 0;
}


/* Get and set the name of the directory to poll for new files */
const char *skpcProbeGetPollDirectory(const skpc_probe_t *probe)
{
    assert (probe);
    return probe->poll_directory;
}

int skpcProbeSetPollDirectory(
    skpc_probe_t       *probe,
    const char         *pathname)
{
    char *copy;

    assert(probe);
    if (pathname == NULL || pathname[0] == '\0') {
        return -1;
    }

    copy = strdup(pathname);
    if (copy == NULL) {
        return -1;
    }

    if (probe->poll_directory) {
        free(probe->poll_directory);
    }
    probe->poll_directory = copy;

    return 0;
}


/* Get and set host to accept connections from */
int skpcProbeGetAcceptFromHost(
    const skpc_probe_t *probe,
    uint32_t           *out_addr)
{
    assert(probe);
    if (out_addr) {
        *out_addr = probe->accept_from_addr;
    }
    return 0;
}

int skpcProbeSetAcceptFromHost(
    skpc_probe_t       *probe,
    uint32_t            host_addr)
{
    assert(probe);
    if (host_addr == 0) {
        return -1;
    }

    probe->accept_from_addr = host_addr;
    return 0;
}


size_t skpcProbeGetSensorCount(
    const skpc_probe_t *probe)
{
    assert(probe);
    return probe->sensor_count;
}


static int skpcProbeAddSensor(
    skpc_probe_t   *probe,
    skpc_sensor_t  *sensor)
{
    size_t i;

    /* each sensor may only appear on a probe one time */
    for (i = 0; i < probe->sensor_count; ++i) {
        if (skpcSensorGetID(probe->sensor_list[i])
            == skpcSensorGetID(sensor))
        {
            return -1;
        }
    }

    if (probe->sensor_list == NULL) {
        assert(probe->sensor_count == 0);
        probe->sensor_list = malloc(sizeof(skpc_sensor_t*));
        if (probe->sensor_list == NULL) {
            return -1;
        }
    } else {
        skpc_sensor_t **old = probe->sensor_list;

        probe->sensor_list = realloc(probe->sensor_list,
                                     ((1 + probe->sensor_count)
                                      * sizeof(skpc_sensor_t*)));
        if (probe->sensor_list == NULL) {
            probe->sensor_list = old;
            return -1;
        }
    }
    probe->sensor_list[probe->sensor_count] = sensor;
    ++probe->sensor_count;

    return 0;
}


/*
 *  *****  Verification  ***********************************************
 */



#if SK_ENABLE_IPFIX
/*
 *  is_valid = skpcProbeVerifyIPFIX(p);
 *
 *    Verify that probe has everything required to collect IPFIX data.
 */
static int skpcProbeVerifyIPFIX(skpc_probe_t *probe)
{
    /* IPFIX does not support reading from files */
    if (probe->file_source != NULL) {
        skAppPrintErr(("Error verifying probe %s:\n"
                       "\tType '%s' probes do not support"
                       " reading data from files"),
                      probe->probe_name,
                      skpcProbetypeEnumtoName(probe->probe_type));
        return -1;
    }

    /* IPFIX does not support unix sockets */
    if (probe->unix_domain_path != NULL) {
        skAppPrintErr(("Error verifying probe %s:\n"
                       "\tType '%s' probes do not support"
                       "listening on a UNIX domain socket"),
                      probe->probe_name,
                      skpcProbetypeEnumtoName(probe->probe_type));
        return -1;
    }

    /* IPFIX does not support directory polling */
    if (probe->poll_directory != NULL) {
        skAppPrintErr(("Error verifying probe %s:\n"
                       "\tType '%s' probes do not support"
                       " polling a directory for files"),
                      probe->probe_name,
                      skpcProbetypeEnumtoName(probe->probe_type));
        return -1;
    }

    /* IPFIX requires a port to listen upon */
    if (probe->listen_on_port == PORT_NOT_SET) {
        skAppPrintErr(("Error verifying probe %s:\n"
                       "\tType '%s' require a port upon which"
                       " to listen for IPFIX connections"),
                      probe->probe_name,
                      skpcProbetypeEnumtoName(probe->probe_type));
        return -1;
    }

    /* Our IPFIX  support only allows UDP and TCP and has no default */
    switch (probe->protocol) {
      case SKPC_PROTO_UDP:
      case SKPC_PROTO_TCP:
        break;
      case SKPC_PROTO_UNSET:
        skAppPrintErr(("Error verifying probe %s:\n"
                       "\tType '%s' probes must set"
                       " the protocol to 'tcp' or 'udp'"),
                      probe->probe_name,
                      skpcProbetypeEnumtoName(probe->probe_type));
        return -1;
      default:
        skAppPrintErr(("Error verifying probe %s:\n"
                       "\tType '%s' probes only support"
                       " the UDP or TCP protocol"),
                      probe->probe_name,
                      skpcProbetypeEnumtoName(probe->probe_type));
        return -1;
    }

    return 0;
}
#endif  /* SK_ENABLE_IPFIX */


/*
 *  is_valid = skpcProbeVerifyNetflow(p);
 *
 *    Verify that probe has everything required to collect netflow
 *    data.
 */
static int skpcProbeVerifyNetflow(skpc_probe_t *probe)
{
    /* Netflow does not support unix sockets */
    if (probe->unix_domain_path != NULL) {
        skAppPrintErr(("Error verifying probe %s:\n"
                       "\tType '%s' probes do not support"
                       "listening on a UNIX domain socket for PDUs"),
                      probe->probe_name,
                      skpcProbetypeEnumtoName(probe->probe_type));
        return -1;
    }

    /* Netflow does not yet support directory polling */
    if (probe->poll_directory != NULL) {
        skAppPrintErr(("Error verifying probe %s:\n"
                       "\tType '%s' probes do not support"
                       " polling a directory for PDU files"),
                      probe->probe_name,
                      skpcProbetypeEnumtoName(probe->probe_type));
        return -1;
    }

    /* Netflow only supports the UDP protocol */
    if ((probe->listen_on_port != PORT_NOT_SET)
        && (probe->protocol != SKPC_PROTO_UDP))
    {
        skAppPrintErr(("Error verifying probe %s:\n"
                       "\tType '%s' probes only support"
                       " the UDP protocol"),
                      probe->probe_name,
                      skpcProbetypeEnumtoName(probe->probe_type));
        return -1;
    }

    return 0;
}


/*
 *  is_valid = skpcProbeVerifySilk(p);
 *
 *    Verify that probe has everything required to re-pack SiLK flow
 *    files.
 */
static int skpcProbeVerifySilk(skpc_probe_t *probe)
{
    /* When re-packing SiLK Flow files, we only support single files
     * or a directory to poll.  */
    if (probe->unix_domain_path != NULL) {
        skAppPrintErr(("Error verifying probe %s:\n"
                       "\tType '%s' probes do not support"
                       " listening on UNIX sockets for SiLK Flows"),
                      probe->probe_name,
                      skpcProbetypeEnumtoName(probe->probe_type));
        return -1;
    }
    if (probe->listen_on_port != PORT_NOT_SET) {
        skAppPrintErr(("Error verifying probe %s:\n"
                       "\tType '%s' probes do not support"
                       " listening on a TCP socket for SiLK Flows"),
                      probe->probe_name,
                      skpcProbetypeEnumtoName(probe->probe_type));
        return -1;
    }

    return 0;
}


/* Has probe been verified? */
int skpcProbeIsVerified(
    const skpc_probe_t *probe)
{
    assert(probe);
    return probe->verified;
}


/*
 *    Verify that 'p' is a valid probe.
 */
int skpcProbeVerify(
    skpc_probe_t   *probe,
    int             is_ephemeral)
{
    size_t count;

    assert(probe);
    assert(skpc_probes);

    /* check name */
    if ('\0' == probe->probe_name[0]) {
        skAppPrintErr("Error verifying probe:\n\tProbe has no name.");
        return -1;
    }

    /* verify type is not invalid */
    if (probe->probe_type == PROBE_ENUM_INVALID) {
        skAppPrintErr(("Error verifying probe %s:\n"
                       "\tProbe's type is INVALID."),
                      probe->probe_name);
        return -1;
    }

    /* this type is not yet supported */
    if (probe->probe_type == PROBE_ENUM_SILK) {
        skAppPrintErr(("Error verifying probe %s:\n"
                       "\tThere is no support for 'silk' probes yet."),
                      probe->probe_name);
        return -1;
    }

    /* if is_ephemeral is specified, add it to the global list of
     * probes but don't mark it as verified */
    if (is_ephemeral) {
        return skVectorAppendValue(skpc_probes, &probe);
    }

    /* check that one and only one of port, unix socket,
     * file-source, and poll-directory were given */
    count = 0;
    if (probe->listen_on_port != PORT_NOT_SET) {
        ++count;
    }
    if (probe->unix_domain_path != NULL) {
        ++count;
    }
    if (probe->file_source != NULL) {
        ++count;
    }
    if (probe->poll_directory != NULL) {
        ++count;
    }

    if (count != 1) {
        if (count == 0) {
            skAppPrintErr(("Error verifying probe %s:\n"
                           "\tProbe needs a collection source. Must give one"
                           " of listen-on-port,\n\tread-from-file,"
                           " listen-on-unix-socket, or poll-directory."),
                          probe->probe_name);
        } else {
            skAppPrintErr(("Error verifying probe %s:\n"
                           "\tMultiple collection sources. Must give only one"
                           " of listen-on-port,\n\tread-from-file,"
                           " listen-on-unix-socket, or poll-directory."),
                          probe->probe_name);
        }
        return -1;
    }

    /* when listen-on-port is specifed, the protocol is also required */
    if ((probe->listen_on_port != PORT_NOT_SET)
        && (probe->protocol == SKPC_PROTO_UNSET))
    {
        skAppPrintErr(("Error verifying probe %s:\n"
                       "The protocol statement is required when"
                       " listen-on-port is specified"),
                      probe->probe_name);
        return -1;
    }

    /* verify the probe by its type */
    switch (probe->probe_type) {
      case PROBE_ENUM_NETFLOW:
        if (0 != skpcProbeVerifyNetflow(probe)) {
            return -1;
        }
        break;


      case PROBE_ENUM_IPFIX:
#if !SK_ENABLE_IPFIX
        skAppPrintErr(("Error verifying probe %s:\n"
                       "\tIPFIX support was not included at compile time"),
                      probe->probe_name);
        return -1;
#else
        if (0 != skpcProbeVerifyIPFIX(probe)) {
            return -1;
        }
        break;
#endif /* SK_ENABLE_IPFIX */

      case PROBE_ENUM_SILK:
        if (0 != skpcProbeVerifySilk(probe)) {
            return -1;
        }
        break;

      case PROBE_ENUM_INVALID:
        /* should have caught this above */
        assert(0);
        abort();
    }

    /* make certain no other probe has this name */
    if (skpcProbeLookupByName(probe->probe_name)) {
        skAppPrintErr(("Error verifying probe %s:\n"
                       "\tA probe with this name is already defined"),
                      probe->probe_name);
        return -1;
    }

    /* probe is valid; add it to the global vector of probes */
    if (skVectorAppendValue(skpc_probes, &probe)) {
        return -1;
    }

    probe->verified = 1;
    return 0;
}


/*
 *  *****  Sensors  *****************************************************
 */

/* Create a sensor */
int skpcSensorCreate(skpc_sensor_t **sensor)
{
    assert(sensor);

    (*sensor) = calloc(1, sizeof(skpc_sensor_t));
    if (NULL == (*sensor)) {
        return -1;
    }

    (*sensor)->sensor_id = SK_INVALID_SENSOR;

    /* create the decider array; one for each network */
    (*sensor)->decider_count = skVectorGetCount(skpc_networks);
    if ((*sensor)->decider_count) {
        (*sensor)->decider = calloc((*sensor)->decider_count,
                                    sizeof(skpc_netdecider_t));
        if ((*sensor)->decider == NULL) {
            free(*sensor);
            return -1;
        }
    }

    return 0;
}


void skpcSensorDestroy(skpc_sensor_t **sensor)
{
    size_t i, j;
    skIPWildcard_t **ipwild_list;

    for (i = 0; i < (*sensor)->decider_count; ++i) {
        switch ((*sensor)->decider[i].nd_type) {
          case SKPC_UNSET:
            break;

          case SKPC_INTERFACE:
          case SKPC_REMAIN_INTERFACE:
            skBitmapDestroy(&((*sensor)->decider[i].nd_value.map));
            (*sensor)->decider[i].nd_value.map = NULL;
            break;

          case SKPC_IPBLOCK:
          case SKPC_NEG_IPBLOCK:
            ipwild_list = (*sensor)->decider[i].nd_value.ipblock;
            for (j = 0; ipwild_list[j]; ++j) {
                free(ipwild_list[j]);
                ipwild_list[j] = NULL;
            }
            free(ipwild_list);
            (*sensor)->decider[i].nd_value.ipblock = NULL;
            break;

          case SKPC_REMAIN_IPBLOCK:
            /* the decider that holds the remaining IPs just holds
             * references to existing IPs, so it should not free them;
             * we will just set them all to NULL */
            ipwild_list = (*sensor)->decider[i].nd_value.ipblock;
            (*sensor)->decider[i].nd_value.ipblock = NULL;
            if (ipwild_list) {
                for (j = 0; ipwild_list[j]; ++j) {
                    ipwild_list[j] = NULL;
                }
                free(ipwild_list);
            }
            break;
        }
    }

    /* destroy the probe list */
    if ((*sensor)->probe_list) {
        free((*sensor)->probe_list);
        (*sensor)->probe_list = NULL;
        (*sensor)->probe_count = 0;
    }

    if ((*sensor)->isp_ip_count) {
        free((*sensor)->isp_ip_list);
        (*sensor)->isp_ip_list = NULL;
        (*sensor)->isp_ip_count = 0;
    }
}

/* Get and set the name of this sensor. */
sensorID_t skpcSensorGetID(const skpc_sensor_t *sensor)
{
    assert(sensor);
    return sensor->sensor_id;
}

const char *skpcSensorGetName(const skpc_sensor_t *sensor)
{
    assert(sensor);
    return sensor->sensor_name;
}

int skpcSensorSetName(skpc_sensor_t *sensor, const char *name)
{
    char *copy;

    assert(sensor);
    if (name == NULL || name[0] == '\0') {
        return -1;
    }

    copy = strdup(name);
    if (copy == NULL) {
        return -1;
    }
    if (sensor->sensor_name) {
        free(sensor->sensor_name);
    }
    sensor->sensor_name = copy;

    sensor->sensor_id = sksiteSensorLookup(name);
    return 0;
}


/*
 *  count = skpcSensorCountNetflowInterfaces(sensor, ignored_network_id);
 *
 *    Count the number of SNMP interfaces that have been mapped to a
 *    flowtype on 'sensor'.  Will exclude the network ID
 *    'ignored_network_id'; pass a negative value in that parameter to
 *    ensure that all SNMP interfaces are counted.
 */
uint32_t skpcSensorCountNetflowInterfaces(
    const skpc_sensor_t    *sensor,
    int                     ignored_network_id)
{
    uint32_t ifcount = 0;
    size_t i;

    for (i = 0; i < sensor->decider_count; ++i) {
        if (ignored_network_id == (int)i) {
            continue;
        }
        if (((sensor->decider[i].nd_type == SKPC_INTERFACE)
             || (sensor->decider[i].nd_type == SKPC_REMAIN_INTERFACE))
            && (sensor->decider[i].nd_value.map != NULL))
        {
            ifcount += skBitmapGetHighCount(sensor->decider[i].nd_value.map);
        }
    }
    return ifcount;
}


/* Test rwrec against the interfaces (either SNMP or IP block) on the
 * sensor. */
int skpcSensorTestFlowInterfaces(
    const skpc_sensor_t    *sensor,
    const rwRec            *rwrec,
    size_t                  network_id,
    rec_direction_t         rec_dir)
{
    skipaddr_t ip;
    skIPWildcard_t **ipwild_list;
    int i;
    int found = 0;

    assert(sensor);
    assert(rwrec);

    switch (sensor->decider[network_id].nd_type) {
      case SKPC_UNSET:
        break;

      case SKPC_INTERFACE:
      case SKPC_REMAIN_INTERFACE:
        /* An SNMP interface list was set for the network_id.  Test
         * the record's SNMP value against it.  Whether incoming or
         * outgoing depends on 'rec_dir'. */
        if (rec_dir == REC_DIR_FROM) {
            /* look where the record is coming from: its input SNMP
             * interface */
            if (skBitmapGetBit(sensor->decider[network_id].nd_value.map,
                               rwRecGetInput(rwrec)))
            {
                return 1;
            }
        } else {
            /* look where the record is going to: output SNMP */
            assert(rec_dir == REC_DIR_TO);
            if (skBitmapGetBit(sensor->decider[network_id].nd_value.map,
                               rwRecGetOutput(rwrec)))
            {
                return 1;
            }
        }
        return -1;

      case SKPC_NEG_IPBLOCK:
      case SKPC_REMAIN_IPBLOCK:
        /* want to find whether the IP is NOT in the list */
        found = 1;
        /* FALLTHROUGH */

      case SKPC_IPBLOCK:
        /* An IP block was set for 'network_id'.  Test the record's IP
         * against it.  Whether source IP or dest IP depends on
         * 'rec_dir'. */
        if (rec_dir == REC_DIR_FROM) {
            /* look where the record is coming from: its source IP */
            rwRecMemGetSIP(rwrec, &ip);
        } else {
            /* look where the record is going to: destination IP */
            assert(rec_dir == REC_DIR_TO);
            rwRecMemGetDIP(rwrec, &ip);
        }

        ipwild_list = sensor->decider[network_id].nd_value.ipblock;
        for (i = 0; ipwild_list[i]; ++i) {
            if (skIPWildcardCheckIp(ipwild_list[i], &ip)) {
                found = !found;
                break;
            }
        }
        return ((found == 0) ? -1 : 1);
    }

    return 0;
}


/* Set the list of IP blocks that represent a network */
int skpcSensorSetIpBlocks(
    skpc_sensor_t      *sensor,
    size_t              network_id,
    const sk_vector_t  *ipblock_vec,
    int                 is_negatated)
{
    size_t count;
    skIPWildcard_t **ipwild_list;
    const skpc_network_t *network;

    /* check input */
    assert(sensor);
    if (ipblock_vec == NULL) {
        return -1;
    }

    /* check that vector has data of the correct type */
    count = skVectorGetCount(ipblock_vec);
    if ((count == 0)
        || (skVectorGetElementSize(ipblock_vec) != sizeof(skIPWildcard_t*)))
    {
        return -1;
    }

    /* get network */
    network = skpcNetworkLookupByID(network_id);
    if (network == NULL) {
        return -1;
    }

    assert(network->id < sensor->decider_count);

    /* check that we're not attempting to change an existing value */
    if (sensor->decider[network->id].nd_type != SKPC_UNSET) {
        skAppPrintErr(("Error setting IP block on sensor %s:\n"
                       "\tCannot overwrite existing %s network value"),
                      sensor->sensor_name, network->name);
        return -1;
    }

    /* allocate memory for the list of ip-wildcards; include an extra
     * value to NULL-terminate the list */
    ipwild_list = malloc((count+1) * sizeof(skIPWildcard_t*));
    if (NULL == ipwild_list) {
        return -1;
    }
    sensor->decider[network->id].nd_value.ipblock = ipwild_list;

    /* convert vector to an array */
    skVectorToArray(ipwild_list, ipblock_vec);
    ipwild_list[count] = NULL;

    sensor->decider[network->id].nd_type =
        (is_negatated ? SKPC_NEG_IPBLOCK : SKPC_IPBLOCK);

    return 0;
}


/* Set the specified interface to all IPs not covered by other interfaces */
int skpcSensorSetToRemainderIpBlocks(
    skpc_sensor_t      *sensor,
    size_t              network_id)
{
    const skpc_network_t *network;

    assert(sensor);

    /* get network */
    network = skpcNetworkLookupByID(network_id);
    if (network == NULL) {
        return -1;
    }

    assert(network->id < sensor->decider_count);

    /* check that we're not attempting to change an existing value */
    if (sensor->decider[network->id].nd_type != SKPC_UNSET) {
        skAppPrintErr(("Error setting IP block on sensor %s:\n"
                       "\tCannot overwrite existing %s network value"),
                      sensor->sensor_name, network->name);
        return -1;
    }

    sensor->decider[network->id].nd_type = SKPC_REMAIN_IPBLOCK;

    return 0;
}


int skpcSensorSetDefaultNonrouted(
    skpc_sensor_t      *sensor,
    size_t              network_id)
{
    sk_vector_t *ifvec;
    const uint32_t default_nonrouted = 0;
    int rv = -1;

    ifvec = skVectorNew(sizeof(uint32_t));
    if (skpc_probes == NULL) {
        goto END;
    }
    if (skVectorAppendValue(ifvec, &default_nonrouted)) {
        goto END;
    }

    rv = skpcSensorSetInterfaces(sensor, network_id, ifvec);
  END:
    if (ifvec) {
        skVectorDestroy(ifvec);
    }
    return rv;
}


/* Set the list of SNMP interfaces on the specified interface group */
int skpcSensorSetInterfaces(
    skpc_sensor_t      *sensor,
    size_t              network_id,
    const sk_vector_t  *if_vec)
{
    size_t count, i;
    uint32_t val;
    const skpc_network_t *network;

    /* check input */
    assert(sensor);
    if (if_vec == NULL) {
        return -1;
    }

    /* check that vector has data of the correct type */
    count = skVectorGetCount(if_vec);
    if ((count == 0) || (skVectorGetElementSize(if_vec) != sizeof(uint32_t))) {
        return -1;
    }

    /* get network */
    network = skpcNetworkLookupByID(network_id);
    if (network == NULL) {
        return -1;
    }

    assert(network->id < sensor->decider_count);
    /* check that we're not attempting to change an existing value */
    if (sensor->decider[network->id].nd_type != SKPC_UNSET) {
        skAppPrintErr(("Error setting IP block on sensor %s:\n"
                       "\tCannot overwrite existing %s network value"),
                      sensor->sensor_name, network->name);
        return -1;
    }

    if (skBitmapCreate(&sensor->decider[network->id].nd_value.map,
                       SK_SNMP_INDEX_LIMIT))
    {
        SKAPP_PRINT_NO_MEM;
        return -1;
    }

    for (i = 0; i < count; ++i) {
        skVectorGetValue(&val, if_vec, i);
        skBitmapSetBit(sensor->decider[network->id].nd_value.map, val);
    }

    sensor->decider[network->id].nd_type = SKPC_INTERFACE;

    return 0;
}


/* Set the SNMP interface list for the specified 'network' to all
 * interfaces not mentioned in other lists. */
int skpcSensorSetToRemainderInterfaces(
    skpc_sensor_t      *sensor,
    size_t              network_id)
{
    const skpc_network_t *network;

    assert(sensor);

    /* get network */
    network = skpcNetworkLookupByID(network_id);
    if (network == NULL) {
        return -1;
    }

    assert(network->id < sensor->decider_count);

    /* check that we're not attempting to change an existing value */
    if (sensor->decider[network->id].nd_type != SKPC_UNSET) {
        skAppPrintErr(("Error setting IP block on sensor %s:\n"
                       "\tCannot overwrite existing %s network value"),
                      sensor->sensor_name, network->name);
        return -1;
    }

    sensor->decider[network->id].nd_type = SKPC_REMAIN_INTERFACE;

    return 0;
}


static int skpcSensorComputeRemainingInterfaces(
    skpc_sensor_t          *sensor)
{
    size_t i;
    size_t remain_network = UINT32_MAX;

    for (i = 0; i < sensor->decider_count; ++i) {
        if (sensor->decider[i].nd_type == SKPC_REMAIN_INTERFACE) {
            if (remain_network != UINT32_MAX) {
                /* cannot have more than one "remainder" */
                skAppPrintErr(("Cannot verify sensor %s:\n"
                               "\tMultiple network values claim 'remainder'"),
                              sensor->sensor_name);
                return -1;
            }
            remain_network = i;
        }
    }

    if (remain_network == UINT32_MAX) {
        /* no one is set to remainder; return */
        return 0;
    }

    /* create a bitmap */
    if (skBitmapCreate(&sensor->decider[remain_network].nd_value.map,
                       SK_SNMP_INDEX_LIMIT))
    {
        SKAPP_PRINT_NO_MEM;
        return -1;
    }

    /* generate the union of all interface-map lists */
    for (i = 0; i < sensor->decider_count; ++i) {
        if (sensor->decider[i].nd_type == SKPC_INTERFACE) {
            skBitmapUnion(sensor->decider[remain_network].nd_value.map,
                          sensor->decider[i].nd_value.map);
        }
    }

    /* take the complement of it */
    skBitmapComplement(sensor->decider[remain_network].nd_value.map);

    return 0;
}


static int skpcSensorComputeRemainingIpBlocks(
    skpc_sensor_t          *sensor)
{
    size_t remain_network = UINT32_MAX;
    skIPWildcard_t **ipwild_list;
    skIPWildcard_t **ipwl;
    size_t ipblock_count = 0;
    size_t i;
    size_t j;

    /* determine what value has the remainder.  at the same time,
     * count the number of ipwildcards that are set across all
     * deciders */
    for (i = 0; i < sensor->decider_count; ++i) {
        if (sensor->decider[i].nd_type == SKPC_REMAIN_IPBLOCK) {
            if (remain_network != UINT32_MAX) {
                /* cannot have more than one "remainder" */
                skAppPrintErr(("Cannot verify sensor %s:\n"
                               "\tMultiple network values claim 'remainder'"),
                              sensor->sensor_name);
                return -1;
            }
            remain_network = i;
        }
        if (sensor->decider[i].nd_type == SKPC_IPBLOCK) {
            ipwild_list = sensor->decider[i].nd_value.ipblock;
            for (j = 0; ipwild_list[j]; ++j) {
                ++ipblock_count;
            }
        }
    }

    if (remain_network == UINT32_MAX) {
        /* no one is set to remainder; return */
        return 0;
    }

    /* need to have existing IPblocks to set a remainder */
    if (ipblock_count == 0) {
        const skpc_network_t *network = skpcNetworkLookupByID(remain_network);
        skAppPrintErr(("Cannot verify sensor %s:\n"
                       "\tCannot set %s-ipblocks to remaining IP because\n"
                       "\tno other interfaces hold IP blocks"),
                      sensor->sensor_name, network->name);
        return -1;
    }

    /* allocate memory to hold a reference to every ipwildcard that
     * exists on other deciders; include an extra value to
     * NULL-terminate the list */
    ipwild_list = malloc((ipblock_count+1) * sizeof(skIPWildcard_t*));
    if (NULL == ipwild_list) {
        SKAPP_PRINT_NO_MEM;
        return -1;
    }
    sensor->decider[remain_network].nd_value.ipblock = ipwild_list;

    /* for every ipblock list on all other deciders, add a reference
     * to it on the remain_network decider */
    ipblock_count = 0;
    for (i = 0; i < sensor->decider_count; ++i) {
        if (sensor->decider[i].nd_type == SKPC_IPBLOCK) {
            ipwl = sensor->decider[i].nd_value.ipblock;
            for (j = 0; ipwl[j]; ++j) {
                ipwild_list[ipblock_count] = ipwl[j];
                ++ipblock_count;
            }
        }
    }
    ipwild_list[ipblock_count] = NULL;

    return 0;
}


/* Get and set the list of IPs of the ISP */
uint32_t skpcSensorGetIspIps(
    const skpc_sensor_t    *sensor,
    const uint32_t        **out_ip_list)
{
    assert(sensor);

    if (sensor->isp_ip_count > 0) {
        if (out_ip_list != NULL) {
            *out_ip_list = sensor->isp_ip_list;
        }
    }
    return sensor->isp_ip_count;
}

int skpcSensorSetIspIps(
    skpc_sensor_t      *sensor,
    const sk_vector_t  *isp_ip_vec)
{
    size_t count;
    uint32_t *copy;

    /* check input */
    assert(sensor);
    if (isp_ip_vec == NULL) {
        return -1;
    }
    count = skVectorGetCount(isp_ip_vec);
    if (count == 0) {
        return -1;
    }

    /* copy the values out of the vector */
    copy = malloc(count * skVectorGetElementSize(isp_ip_vec));
    if (copy == NULL) {
        SKAPP_PRINT_NO_MEM;
        return -1;
    }
    skVectorToArray(copy, isp_ip_vec);

    /* free the existing list and set value on the sensor */
    if (sensor->isp_ip_count) {
        free(sensor->isp_ip_list);
    }
    sensor->isp_ip_list = copy;
    sensor->isp_ip_count = count;

    return 0;
}


uint32_t skpcSensorGetProbes(
    const skpc_sensor_t    *sensor,
    sk_vector_t            *out_probe_vec)
{
    assert(sensor);

    if (sensor->probe_count != 0 && out_probe_vec != NULL) {
        if (skVectorAppendFromArray(out_probe_vec, sensor->probe_list,
                                    sensor->probe_count))
        {
            SKAPP_PRINT_NO_MEM;
            return 0;
        }
    }
    return sensor->probe_count;
}

int skpcSensorSetProbes(
    skpc_sensor_t      *sensor,
    const sk_vector_t  *probe_vec)
{
    size_t count;
    void *copy;

    /* check input */
    assert(sensor);
    if (probe_vec == NULL) {
        return -1;
    }
    count = skVectorGetCount(probe_vec);
    if (count == 0) {
        return -1;
    }

    /* copy the values out of the vector */
    copy = malloc(count * skVectorGetElementSize(probe_vec));
    if (copy == NULL) {
        SKAPP_PRINT_NO_MEM;
        return -1;
    }
    skVectorToArray(copy, probe_vec);

    /* free the existing list and set value on the sensor */
    if (sensor->probe_count) {
        free(sensor->probe_list);
    }
    sensor->probe_list = copy;
    sensor->probe_count = count;

    return 0;
}


int skpcSensorVerify(
    skpc_sensor_t      *sensor,
    int               (*site_sensor_verify_fn)(skpc_sensor_t *sensor))
{
    uint32_t i;

    assert(sensor);

    if (sensor->sensor_id == SK_INVALID_SENSOR) {
        skAppPrintErr(("Error verifying sensor '%s'\n"
                       "\tSensor is not defined in site file silk.conf"),
                      sensor->sensor_name);
        return -1;
    }

    /* make certain no other sensor has this name */
    if (skpcSensorLookupByName(sensor->sensor_name)) {
        skAppPrintErr(("Error verifying sensor %s:\n"
                       "\tA sensor with this name is already defined"),
                      sensor->sensor_name);
        return -1;
    }

    /* verifying the sensor for this site (i.e., by its class) */
    if (site_sensor_verify_fn != NULL) {
        if (0 != site_sensor_verify_fn(sensor)) {
            return -1;
        }
    }

    /* if any network decider is set to 'remainder', update the sensor */
    if (skpcSensorComputeRemainingInterfaces(sensor)) {
        return -1;
    }
    if (skpcSensorComputeRemainingIpBlocks(sensor)) {
        return -1;
    }

    /* add a link on each probe to this sensor */
    for (i = 0; i < sensor->probe_count; ++i) {
        if (skpcProbeAddSensor(sensor->probe_list[i], sensor)) {
            skAppPrintErr(("Error verifying sensor %s:\n"
                           "\tCannot link probe %s to this sensor"),
                          sensor->sensor_name,
                          sensor->probe_list[i]->probe_name);
            return -1;
        }
    }

    /* sensor is valid; add it to the global vector of sensors */
    if (skVectorAppendValue(skpc_sensors, &sensor)) {
        SKAPP_PRINT_NO_MEM;
        return -1;
    }

    return 0;
}


/*
 *  *****  Probes Types  *****************************************************
 */

/* return an enum value given a probe type name */
skpc_probetype_t skpcProbetypeNameToEnum(
    const char *name)
{
    int i;

    if (NULL != name) {
        for (i = 0; i < PROBE_TYPE_COUNT; ++i) {
            if (0 == strcmp(name, probe_type_name_map[i].name)) {
                return probe_type_name_map[i].value;
            }
        }
    }

    return PROBE_ENUM_INVALID;
}


/* return the name given a probe type number */
const char *skpcProbetypeEnumtoName(
    skpc_probetype_t    type)
{
    int i;

    for (i = 0; i < PROBE_TYPE_COUNT; ++i) {
        if (type == probe_type_name_map[i].value) {
            return probe_type_name_map[i].name;
        }
    }

    return NULL;
}


/*
 *  *****  Probes Protocols  *************************************************
 */

/* return an protocol enum value given a probe protocol name */
skpc_proto_t skpcProtocolNameToEnum(const char *name)
{
    uint32_t num;
    int i;

    if (NULL != name) {
        if (isdigit((int)*name)) {
            /* parse as a number */
            if (skStringParseUint32(&num, name, 0, 255)) {
                return SKPC_PROTO_UNSET;
            }
            for (i = 0; i < SKPC_PROTOCOL_COUNT; ++i) {
                if (num == skpc_protocol_name_map[i].num) {
                    return skpc_protocol_name_map[i].value;
                }
            }
        } else {
            for (i = 0; i < SKPC_PROTOCOL_COUNT; ++i) {
                if (0 == strcmp(name, skpc_protocol_name_map[i].name)) {
                    return skpc_protocol_name_map[i].value;
                }
            }
        }
    }

    return SKPC_PROTO_UNSET;
}


/* return a name given a probe protocol enum */
const char *skpcProtocolEnumToName(skpc_proto_t protocol)
{
    int i;

    for (i = 0; i < SKPC_PROTOCOL_COUNT; ++i) {
        if (protocol == skpc_protocol_name_map[i].value) {
            return skpc_protocol_name_map[i].name;
        }
    }

    return NULL;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
