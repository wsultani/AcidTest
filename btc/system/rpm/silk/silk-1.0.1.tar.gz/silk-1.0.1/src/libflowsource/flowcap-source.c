/*
** Copyright (C) 2005-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  Interface to pull a single flow from a flowcap file.
**
*/

#include "silk.h"

RCSIDENT("$SiLK: flowcap-source.c 10960 2008-03-19 19:08:22Z mthomas $");

#include "rwpack.h"
#include "sklog.h"
#include "flowcap-source.h"


typedef struct flowcap_source_st {
    rwIOStruct_t       *rwio;
    const skpc_probe_t *probe;
    uint32_t            recs;
} flowcap_source_t;


flowcapSource_t flowcapSourceCreateFromFile(
    const char     *path)
{
    flowcapSource_t source = NULL;
    rwIOStruct_t *rwio = NULL;
    const skpc_probe_t *probe = NULL;
    sk_file_header_t *hdr;
    sk_hentry_probename_t *sp_hdr;
    const char *probe_name;
    int rv;

    /* Argument checking */
    if (path == NULL) {
        ERRMSG("NULL path passed to flowcapSourceCreateFromFile.");
        return NULL;
    }

    /* Valid file checking */
    rv = rwioCreate(&rwio, path, SK_IO_READ);
    if (rv == RWIO_OK) {
        rv = rwioOpen(rwio);
    }
    if (rv) {
        CRITMSG("Unable to open %s for reading.", path);
        rwioPrintLastErr(rwio, rv, &ERRMSG);
        goto error;
    }

    /*
     * File should have a Probename header
     *
     * Flowcap V16 files have the probe name in the header.
     *
     * Flowcap Files V2-V5 have a separate sensor name and probe name
     * in the header.  In SiLK 1.0, these get mapped to the single
     * probe name "<sensor>_<probe>".
     *
     * Flowcap Files V1 have no probe information and are not
     * supported.
     */
    hdr = rwGetHeader(rwio);
    sp_hdr = ((sk_hentry_probename_t*)
              skHeaderGetFirstMatch(hdr, SK_HENTRY_PROBENAME_ID));
    if (sp_hdr == NULL) {
        CRITMSG("No probename header in %s.", path);
        goto error;
    }

    probe_name = skHentryProbenameGetProbeName(sp_hdr);
    if (probe_name == NULL || probe_name[0] == '\0') {
        CRITMSG("Unable to get probename from flowcap file '%s'.",
                path);
        goto error;
    }

    /* Use the probe_name to find the skpc_probe_t object. */
    probe = skpcProbeLookupByName(probe_name);
    if (probe == NULL) {
        CRITMSG("The sensor configuration file does not define probe '%s'",
                probe_name);
        goto error;
    }

    /* File has been validated.  Create and fill in source. */
    source = (flowcapSource_t)calloc(1, sizeof(flowcap_source_t));
    if (source == NULL) {
        CRITMSG("Unable to allocate memory for a flowSource.");
        goto error;
    }

    source->rwio = rwio;
    source->probe = probe;

    return source;

  error:
    if (source) {
        free(source);
    }
    rwioDestroy(&rwio);
    return NULL;
}


const char *flowcapSourceFileName(const flowcapSource_t source)
{
    if (source == NULL) {
        return NULL;
    }
    return rwGetFileName(source->rwio);
}


const skpc_probe_t *flowcapSourceGetProbe(const flowcapSource_t source)
{
    if (source == NULL) {
        return NULL;
    }
    return source->probe;
}


uint32_t flowcapSourceNumRecs(const flowcapSource_t source)
{
    if (source == NULL) {
        return 0;
    }
    return source->recs;
}


int flowcapSourceClose(flowcapSource_t source)
{
    int rv;

    if (source == NULL || source->rwio == NULL) {
        return -1;
    }
    rv = rwioClose(source->rwio);
    return ((rv == 0) ? 0 : -1);
}


void flowcapSourceDestroy(flowcapSource_t source)
{
    if (source == NULL) {
        return;
    }
    if (source->rwio) {
        rwioDestroy(&source->rwio);
        source->rwio = NULL;
    }
    free(source);
}


int flowcapSourceGetGeneric(
    flowcapSource_t source,
    rwRec          *rwrec)
{
    int rv;

    if (source == NULL || source->rwio == NULL) {
        return -1;
    }

    rv = rwioReadRecord(source->rwio, rwrec);
    if (rv == RWIO_OK) {
        source->recs++;
        return 0;               /* Success */
    }

    if (rv == RWIO_ERR_READ_EOF) {
        /* Reached end of file */
        return -1;
    }

    /* Unexpected error */
    rwioPrintLastErr(source->rwio, rv, &WARNINGMSG);
    return -1;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
