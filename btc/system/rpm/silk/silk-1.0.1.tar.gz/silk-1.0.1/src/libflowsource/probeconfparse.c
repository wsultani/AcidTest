/* A Bison parser, made by GNU Bison 1.875.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ACCEPT_FROM_HOST_T = 258,
     COMMA = 259,
     END_PROBE_T = 260,
     END_SENSOR_T = 261,
     EOL = 262,
     INCLUDE_T = 263,
     ISP_IP_T = 264,
     LISTEN_AS_HOST_T = 265,
     LISTEN_ON_PORT_T = 266,
     LISTEN_ON_USOCKET_T = 267,
     LOG_FLAGS_T = 268,
     POLL_DIRECTORY_T = 269,
     PRIORITY_T = 270,
     PROBE_T = 271,
     PROTOCOL_T = 272,
     READ_FROM_FILE_T = 273,
     REMAINDER_T = 274,
     SENSOR_T = 275,
     ID = 276,
     INTERFACE = 277,
     IPBLOCK = 278,
     PROBES = 279,
     QUOTED_STRING = 280,
     ERR_STR_TOO_LONG = 281
   };
#endif
#define ACCEPT_FROM_HOST_T 258
#define COMMA 259
#define END_PROBE_T 260
#define END_SENSOR_T 261
#define EOL 262
#define INCLUDE_T 263
#define ISP_IP_T 264
#define LISTEN_AS_HOST_T 265
#define LISTEN_ON_PORT_T 266
#define LISTEN_ON_USOCKET_T 267
#define LOG_FLAGS_T 268
#define POLL_DIRECTORY_T 269
#define PRIORITY_T 270
#define PROBE_T 271
#define PROTOCOL_T 272
#define READ_FROM_FILE_T 273
#define REMAINDER_T 274
#define SENSOR_T 275
#define ID 276
#define INTERFACE 277
#define IPBLOCK 278
#define PROBES 279
#define QUOTED_STRING 280
#define ERR_STR_TOO_LONG 281




/* Copy the first part of user declarations.  */
#line 1 "probeconfparse.y"

/*
** Copyright (C) 2005-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  Parser for probe configuration file
**
*/

#include "silk.h"

RCSIDENT("$SiLK: probeconfparse.y 11252 2008-04-11 19:11:14Z mthomas $");

#include "probeconf.h"
#include "probeconfscan.h"
#include "libflowsource.h"
#include "sklog.h"
#include "sksite.h"


/* LOCAL DEFINES AND TYPEDEFS */

/* Set DEBUG to 1 to enable debugging printf messasges, 0 otherwise.
 * Generally best to leave this commented out so gcc -DDEBUG=1 will
 * work */
/* #define DEBUG 1 */

/* Verify DEBUG is set */
#ifndef DEBUG
#  define DEBUG 0
#endif

/* For printing messages when DEBUG is non-zero.  Use as:
 *    DEBUG_PRINTF(("x is %d\n", x));
 * Note ((double parens)) */
#if DEBUG
#  define DEBUG_PRINTF(x) printf x
#else
#  define DEBUG_PRINTF(x)
#endif


/* magic value used to denote that a uint16_t---which are stored in
 * uint32_t's in the parser---has not yet been given a value. */
#define UINT16_NO_VALUE  0x10000  /* 0xFFFF + 1 */

/*
 * sk_vector_t of IDs are created as they are needed, but to avoid
 * repeatedly creating and destroying the vectors, "deleted" vectors are
 * added to a pool.  When creating a vector, the code will check the
 * pool before allocating.  This macro is the size of the pool; if a
 * vector is "deleted" and the pool is full, the vector is free()ed.
 */
#define VECTOR_POOL_CAPACITY  16


typedef struct vector_pool_st {
    sk_vector_t    *pool[VECTOR_POOL_CAPACITY];
    size_t          element_size;
    int             count;
} vector_pool_t;


/* LOCAL VARIABLES */

/* number of errors in current defn */
static int defn_errors = 0;

/* the vector pools */
static vector_pool_t ptr_vector_pool;
static vector_pool_t *ptr_pool = &ptr_vector_pool;
static vector_pool_t u32_vector_pool;
static vector_pool_t *u32_pool = &u32_vector_pool;

/* The parser works on a single global probe or sensor */
static skpc_probe_t *probe = NULL;
static skpc_sensor_t *sensor = NULL;


/* LOCAL FUNCTION PROTOTYPES */

static sk_vector_t *vectorPoolGet(vector_pool_t *pool);
static void vectorPoolPut(vector_pool_t *pool, sk_vector_t *v);
static void vectorPoolEmpty(vector_pool_t *pool);


static void missing_value(void);


/* include a file */
static void include_file(char *name);

/* functions to set attributes of a probe_attr_t */
static void probe_begin(
    char   *probe_name,
    char   *probe_type);
static void probe_end(void);
static void probe_priority(sk_vector_t *v);
static void probe_protocol(sk_vector_t *v);
static void probe_listen_as_host(sk_vector_t *v);
static void probe_listen_on_port(sk_vector_t *v);
static void probe_listen_on_usocket(sk_vector_t *v);
static void probe_read_from_file(sk_vector_t *v);
static void probe_poll_directory(sk_vector_t *v);
static void probe_accept_from_host(sk_vector_t *v);
static void probe_log_flags(uint32_t n);

static void sensor_begin(
    char   *sensor_name);
static void sensor_end(void);
static void sensor_isp_ip(sk_vector_t *v);
static void sensor_interface(char *name, sk_vector_t *list);
static void sensor_ipblock(
    char           *name,
    sk_vector_t    *wl,
    int             negated);
static void sensor_probes(char *probe_type, sk_vector_t *v);


/* functions to convert string input to another form */
static uint32_t parse_int_u16(char *s);
static int vectorSingleString(sk_vector_t *v, char **s);
static int parse_ip_addr(char *s, uint32_t *ip);
static skIPWildcard_t *parse_wildcard_addr(char *s);
static uint32_t parse_log_flag(char *s);

/* add a new flag to the log flags */
static uint32_t log_flags_add_flag(uint32_t old_val, uint32_t value);




/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 181 "probeconfparse.y"
typedef union YYSTYPE {
    char               *string;
    sk_vector_t        *vector;
    uint32_t            u32;
    skpc_probetype_t    p_type;
} YYSTYPE;
/* Line 186 of yacc.c.  */
#line 315 "probeconfparse.c"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 214 of yacc.c.  */
#line 327 "probeconfparse.c"

#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# if YYSTACK_USE_ALLOCA
#  define YYSTACK_ALLOC alloca
# else
#  ifndef YYSTACK_USE_ALLOCA
#   if defined (alloca) || defined (_ALLOCA_H)
#    define YYSTACK_ALLOC alloca
#   else
#    ifdef __GNUC__
#     define YYSTACK_ALLOC __builtin_alloca
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  16
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   121

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  27
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  28
/* YYNRULES -- Number of rules. */
#define YYNRULES  69
/* YYNRULES -- Number of states. */
#define YYNSTATES  114

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   281

#define YYTRANSLATE(YYX) 						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned char yyprhs[] =
{
       0,     0,     3,     5,     7,     9,    12,    15,    18,    20,
      24,    27,    31,    36,    40,    43,    46,    47,    50,    52,
      54,    56,    58,    60,    62,    64,    66,    68,    70,    74,
      77,    81,    84,    88,    91,    95,    98,   102,   105,   109,
     112,   116,   119,   123,   126,   130,   133,   137,   138,   141,
     143,   145,   147,   149,   151,   155,   158,   161,   164,   168,
     172,   176,   180,   184,   188,   190,   193,   197,   199,   202
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const yysigned_char yyrhs[] =
{
      28,     0,    -1,    30,    -1,    44,    -1,    29,    -1,    28,
      30,    -1,    28,    44,    -1,    28,    29,    -1,     1,    -1,
       8,    25,     7,    -1,     8,     7,    -1,    31,    33,    32,
      -1,    16,    21,    21,     7,    -1,    16,    21,     7,    -1,
       5,     7,    -1,     6,     7,    -1,    -1,    33,    34,    -1,
      35,    -1,    36,    -1,    37,    -1,    38,    -1,    39,    -1,
      40,    -1,    41,    -1,    42,    -1,    43,    -1,     1,    -1,
      15,    53,     7,    -1,    15,     7,    -1,    17,    53,     7,
      -1,    17,     7,    -1,    10,    53,     7,    -1,    10,     7,
      -1,    11,    53,     7,    -1,    11,     7,    -1,    12,    53,
       7,    -1,    12,     7,    -1,    18,    53,     7,    -1,    18,
       7,    -1,    14,    53,     7,    -1,    14,     7,    -1,     3,
      53,     7,    -1,     3,     7,    -1,    13,    54,     7,    -1,
      13,     7,    -1,    47,    45,    48,    -1,    -1,    45,    46,
      -1,    49,    -1,    50,    -1,    51,    -1,    52,    -1,     1,
      -1,    20,    21,     7,    -1,    20,     7,    -1,     6,     7,
      -1,     5,     7,    -1,     9,    53,     7,    -1,    22,    53,
       7,    -1,    22,    19,     7,    -1,    23,    53,     7,    -1,
      23,    19,     7,    -1,    24,    53,     7,    -1,    21,    -1,
      53,    21,    -1,    53,     4,    21,    -1,    21,    -1,    54,
      21,    -1,    54,     4,    21,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short yyrline[] =
{
       0,   224,   224,   225,   226,   227,   228,   229,   230,   240,
     244,   254,   257,   261,   267,   271,   278,   279,   282,   283,
     284,   285,   286,   287,   288,   289,   290,   291,   298,   302,
     307,   311,   316,   320,   325,   329,   334,   338,   343,   347,
     352,   356,   361,   365,   371,   375,   385,   388,   389,   392,
     393,   394,   395,   396,   403,   407,   412,   416,   422,   427,
     431,   436,   440,   445,   456,   463,   469,   481,   485,   491
};
#endif

#if YYDEBUG || YYERROR_VERBOSE
/* YYTNME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "ACCEPT_FROM_HOST_T", "COMMA", 
  "END_PROBE_T", "END_SENSOR_T", "EOL", "INCLUDE_T", "ISP_IP_T", 
  "LISTEN_AS_HOST_T", "LISTEN_ON_PORT_T", "LISTEN_ON_USOCKET_T", 
  "LOG_FLAGS_T", "POLL_DIRECTORY_T", "PRIORITY_T", "PROBE_T", 
  "PROTOCOL_T", "READ_FROM_FILE_T", "REMAINDER_T", "SENSOR_T", "ID", 
  "INTERFACE", "IPBLOCK", "PROBES", "QUOTED_STRING", "ERR_STR_TOO_LONG", 
  "$accept", "input", "include_stmt", "probe_defn", "probe_begin", 
  "probe_end", "probe_stmts", "probe_stmt", "stmt_priority", 
  "stmt_protocol", "stmt_listen_host", "stmt_listen_port", 
  "stmt_listen_usocket", "stmt_read_file", "stmt_poll_directory", 
  "stmt_accept_host", "stmt_log_flags", "sensor_defn", "sensor_stmts", 
  "sensor_stmt", "sensor_begin", "sensor_end", "stmt_isp_ip", 
  "stmt_interface", "stmt_ipblock", "stmt_probes", "id_list", "log_flags", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned char yyr1[] =
{
       0,    27,    28,    28,    28,    28,    28,    28,    28,    29,
      29,    30,    31,    31,    32,    32,    33,    33,    34,    34,
      34,    34,    34,    34,    34,    34,    34,    34,    35,    35,
      36,    36,    37,    37,    38,    38,    39,    39,    40,    40,
      41,    41,    42,    42,    43,    43,    44,    45,    45,    46,
      46,    46,    46,    46,    47,    47,    48,    48,    49,    50,
      50,    51,    51,    52,    53,    53,    53,    54,    54,    54
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     1,     1,     1,     2,     2,     2,     1,     3,
       2,     3,     4,     3,     2,     2,     0,     2,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     3,     2,
       3,     2,     3,     2,     3,     2,     3,     2,     3,     2,
       3,     2,     3,     2,     3,     2,     3,     0,     2,     1,
       1,     1,     1,     1,     3,     2,     2,     2,     3,     3,
       3,     3,     3,     3,     1,     2,     3,     1,     2,     3
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned char yydefact[] =
{
       0,     8,     0,     0,     0,     0,     4,     2,    16,     3,
      47,    10,     0,     0,    55,     0,     1,     7,     5,     6,
       0,     0,     9,    13,     0,    54,    27,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    11,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    53,
       0,     0,     0,     0,     0,     0,    48,    46,    49,    50,
      51,    52,    12,    43,    64,     0,    14,    15,    33,     0,
      35,     0,    37,     0,    45,    67,     0,    41,     0,    29,
       0,    31,     0,    39,     0,    57,    56,     0,     0,     0,
       0,     0,     0,     0,    42,    65,    32,    34,    36,     0,
      44,    68,    40,    28,    30,    38,    58,    60,    59,    62,
      61,    63,    66,    69
};

/* YYDEFGOTO[NTERM-NUM]. */
static const yysigned_char yydefgoto[] =
{
      -1,     5,     6,     7,     8,    38,    20,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,     9,    21,    56,
      10,    57,    58,    59,    60,    61,    65,    76
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -31
static const yysigned_char yypact[] =
{
      19,   -31,    -4,   -11,    12,    18,   -31,   -31,   -31,   -31,
     -31,   -31,     8,    25,   -31,    10,   -31,   -31,   -31,   -31,
      39,     7,   -31,   -31,    21,   -31,   -31,    78,    29,    30,
      90,    91,    93,    94,    95,    98,    99,   100,   -31,   -31,
     -31,   -31,   -31,   -31,   -31,   -31,   -31,   -31,   -31,   -31,
      40,    41,    -7,   -10,    22,    -7,   -31,   -31,   -31,   -31,
     -31,   -31,   -31,   -31,   -31,    51,   -31,   -31,   -31,    55,
     -31,    56,   -31,    57,   -31,   -31,    61,   -31,    62,   -31,
      63,   -31,    67,   -31,    82,   -31,   -31,    83,    66,    87,
      68,    88,    89,    58,   -31,   -31,   -31,   -31,   -31,    59,
     -31,   -31,   -31,   -31,   -31,   -31,   -31,   -31,   -31,   -31,
     -31,   -31,   -31,   -31
};

/* YYPGOTO[NTERM-NUM].  */
static const yysigned_char yypgoto[] =
{
     -31,   -31,    76,   108,   -31,   -31,   -31,   -31,   -31,   -31,
     -31,   -31,   -31,   -31,   -31,   -31,   -31,   112,   -31,   -31,
     -31,   -31,   -31,   -31,   -31,   -31,   -30,   -31
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -1
static const unsigned char yytable[] =
{
      69,    71,    73,    11,    78,    80,    82,    84,    49,    88,
      13,    64,    50,    51,    64,    22,    52,    25,    16,    14,
       1,    12,    87,    89,    91,    92,     2,     2,    62,    53,
      54,    55,    23,    15,     3,     3,    66,    67,     4,     4,
      26,    90,    27,    64,    28,    29,    24,    85,    86,    30,
      31,    32,    33,    34,    35,    93,    36,    37,    94,    93,
      93,    93,    96,    97,    98,    99,    93,    93,   100,   102,
     103,    93,    95,   107,   104,   109,    95,    95,    95,   112,
     113,    17,   101,    95,    95,    63,    93,    93,    95,   105,
     106,    93,    93,    93,   108,   110,   111,    68,    70,    64,
      72,    74,    77,    95,    95,    79,    81,    83,    95,    95,
      95,    64,    64,    18,    64,    75,    64,    19,     0,    64,
      64,    64
};

static const yysigned_char yycheck[] =
{
      30,    31,    32,     7,    34,    35,    36,    37,     1,    19,
      21,    21,     5,     6,    21,     7,     9,     7,     0,     7,
       1,    25,    52,    53,    54,    55,     8,     8,     7,    22,
      23,    24,     7,    21,    16,    16,     7,     7,    20,    20,
       1,    19,     3,    21,     5,     6,    21,     7,     7,    10,
      11,    12,    13,    14,    15,     4,    17,    18,     7,     4,
       4,     4,     7,     7,     7,     4,     4,     4,     7,     7,
       7,     4,    21,     7,     7,     7,    21,    21,    21,    21,
      21,     5,    21,    21,    21,     7,     4,     4,    21,     7,
       7,     4,     4,     4,     7,     7,     7,     7,     7,    21,
       7,     7,     7,    21,    21,     7,     7,     7,    21,    21,
      21,    21,    21,     5,    21,    21,    21,     5,    -1,    21,
      21,    21
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned char yystos[] =
{
       0,     1,     8,    16,    20,    28,    29,    30,    31,    44,
      47,     7,    25,    21,     7,    21,     0,    29,    30,    44,
      33,    45,     7,     7,    21,     7,     1,     3,     5,     6,
      10,    11,    12,    13,    14,    15,    17,    18,    32,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,     1,
       5,     6,     9,    22,    23,    24,    46,    48,    49,    50,
      51,    52,     7,     7,    21,    53,     7,     7,     7,    53,
       7,    53,     7,    53,     7,    21,    54,     7,    53,     7,
      53,     7,    53,     7,    53,     7,     7,    53,    19,    53,
      19,    53,    53,     4,     7,    21,     7,     7,     7,     4,
       7,    21,     7,     7,     7,     7,     7,     7,     7,     7,
       7,     7,    21,    21
};

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrlab1

/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)         \
  Current.first_line   = Rhs[1].first_line;      \
  Current.first_column = Rhs[1].first_column;    \
  Current.last_line    = Rhs[N].last_line;       \
  Current.last_column  = Rhs[N].last_column;
#endif

/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YYDSYMPRINT(Args)			\
do {						\
  if (yydebug)					\
    yysymprint Args;				\
} while (0)

# define YYDSYMPRINTF(Title, Token, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr, 					\
                  Token, Value);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (cinluded).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short *bottom, short *top)
#else
static void
yy_stack_print (bottom, top)
    short *bottom;
    short *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned int yylineno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %u), ",
             yyrule - 1, yylineno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname [yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname [yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YYDSYMPRINT(Args)
# define YYDSYMPRINTF(Title, Token, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

#endif /* !YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  if (yytype < YYNTOKENS)
    {
      YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
# ifdef YYPRINT
      YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
    }
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yytype, yyvaluep)
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  switch (yytype)
    {

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;



#define YYPOPSTACK   (yyvsp--, yyssp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YYDSYMPRINTF ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %s, ", yytname[yytoken]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;


  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 8:
#line 231 "probeconfparse.y"
    {
    skpcParseErr("Misplaced or unrecognized keyword");
}
    break;

  case 9:
#line 241 "probeconfparse.y"
    {
    include_file(yyvsp[-1].string);
}
    break;

  case 10:
#line 245 "probeconfparse.y"
    {
    include_file(NULL);
}
    break;

  case 12:
#line 258 "probeconfparse.y"
    {
    probe_begin(yyvsp[-2].string, yyvsp[-1].string);
}
    break;

  case 13:
#line 262 "probeconfparse.y"
    {
    /* error */
    probe_begin(NULL, yyvsp[-1].string);
}
    break;

  case 14:
#line 268 "probeconfparse.y"
    {
    probe_end();
}
    break;

  case 15:
#line 272 "probeconfparse.y"
    {
    skpcParseErr("%s used to close probe", pcscan_clause);
    probe_end();
}
    break;

  case 27:
#line 292 "probeconfparse.y"
    {
    ++defn_errors;
    skpcParseErr("Bad or misplaced keyword");
}
    break;

  case 28:
#line 299 "probeconfparse.y"
    {
    probe_priority(yyvsp[-1].vector);
}
    break;

  case 29:
#line 303 "probeconfparse.y"
    {
    missing_value();
}
    break;

  case 30:
#line 308 "probeconfparse.y"
    {
    probe_protocol(yyvsp[-1].vector);
}
    break;

  case 31:
#line 312 "probeconfparse.y"
    {
    missing_value();
}
    break;

  case 32:
#line 317 "probeconfparse.y"
    {
    probe_listen_as_host(yyvsp[-1].vector);
}
    break;

  case 33:
#line 321 "probeconfparse.y"
    {
    missing_value();
}
    break;

  case 34:
#line 326 "probeconfparse.y"
    {
    probe_listen_on_port(yyvsp[-1].vector);
}
    break;

  case 35:
#line 330 "probeconfparse.y"
    {
    missing_value();
}
    break;

  case 36:
#line 335 "probeconfparse.y"
    {
    probe_listen_on_usocket(yyvsp[-1].vector);
}
    break;

  case 37:
#line 339 "probeconfparse.y"
    {
    missing_value();
}
    break;

  case 38:
#line 344 "probeconfparse.y"
    {
    probe_read_from_file(yyvsp[-1].vector);
}
    break;

  case 39:
#line 348 "probeconfparse.y"
    {
    missing_value();
}
    break;

  case 40:
#line 353 "probeconfparse.y"
    {
    probe_poll_directory(yyvsp[-1].vector);
}
    break;

  case 41:
#line 357 "probeconfparse.y"
    {
    missing_value();
}
    break;

  case 42:
#line 362 "probeconfparse.y"
    {
    probe_accept_from_host(yyvsp[-1].vector);
}
    break;

  case 43:
#line 366 "probeconfparse.y"
    {
    missing_value();
}
    break;

  case 44:
#line 372 "probeconfparse.y"
    {
    probe_log_flags(yyvsp[-1].u32);
}
    break;

  case 45:
#line 376 "probeconfparse.y"
    {
    missing_value();
}
    break;

  case 53:
#line 397 "probeconfparse.y"
    {
    ++defn_errors;
    skpcParseErr("Bad or misplaced keyword");
}
    break;

  case 54:
#line 404 "probeconfparse.y"
    {
    sensor_begin(yyvsp[-1].string);
}
    break;

  case 55:
#line 408 "probeconfparse.y"
    {
    sensor_begin(NULL);
}
    break;

  case 56:
#line 413 "probeconfparse.y"
    {
    sensor_end();
}
    break;

  case 57:
#line 417 "probeconfparse.y"
    {
    skpcParseErr("%s used to close sensor", pcscan_clause);
    sensor_end();
}
    break;

  case 58:
#line 423 "probeconfparse.y"
    {
    sensor_isp_ip(yyvsp[-1].vector);
}
    break;

  case 59:
#line 428 "probeconfparse.y"
    {
    sensor_interface(yyvsp[-2].string, yyvsp[-1].vector);
}
    break;

  case 60:
#line 432 "probeconfparse.y"
    {
    sensor_interface(yyvsp[-2].string, NULL);
}
    break;

  case 61:
#line 437 "probeconfparse.y"
    {
    sensor_ipblock(yyvsp[-2].string, yyvsp[-1].vector, 0);
}
    break;

  case 62:
#line 441 "probeconfparse.y"
    {
    sensor_ipblock(yyvsp[-2].string, NULL, 0);
}
    break;

  case 63:
#line 446 "probeconfparse.y"
    {
    sensor_probes(yyvsp[-2].string, yyvsp[-1].vector);
}
    break;

  case 64:
#line 457 "probeconfparse.y"
    {
    sk_vector_t *v = vectorPoolGet(ptr_pool);
    char *s = yyvsp[0].string;
    skVectorAppendValue(v, &s);
    yyval.vector = v;
}
    break;

  case 65:
#line 464 "probeconfparse.y"
    {
    char *s = yyvsp[0].string;
    skVectorAppendValue(yyvsp[-1].vector, &s);
    yyval.vector = yyvsp[-1].vector;
}
    break;

  case 66:
#line 470 "probeconfparse.y"
    {
    char *s = yyvsp[0].string;
    skVectorAppendValue(yyvsp[-2].vector, &s);
    yyval.vector = yyvsp[-2].vector;
}
    break;

  case 67:
#line 482 "probeconfparse.y"
    {
    yyval.u32 = parse_log_flag(yyvsp[0].string);
}
    break;

  case 68:
#line 486 "probeconfparse.y"
    {
    uint32_t n = parse_log_flag(yyvsp[0].string);
    n = log_flags_add_flag(yyvsp[-1].u32, n);
    yyval.u32 = n;
}
    break;

  case 69:
#line 492 "probeconfparse.y"
    {
    uint32_t n = parse_log_flag(yyvsp[0].string);
    n = log_flags_add_flag(yyvsp[-2].u32, n);
    yyval.u32 = n;
}
    break;


    }

/* Line 991 of yacc.c.  */
#line 1625 "probeconfparse.c"

  yyvsp -= yylen;
  yyssp -= yylen;


  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  int yytype = YYTRANSLATE (yychar);
	  char *yymsg;
	  int yyx, yycount;

	  yycount = 0;
	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  for (yyx = yyn < 0 ? -yyn : 0;
	       yyx < (int) (sizeof (yytname) / sizeof (char *)); yyx++)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      yysize += yystrlen (yytname[yyx]) + 15, yycount++;
	  yysize += yystrlen ("syntax error, unexpected ") + 1;
	  yysize += yystrlen (yytname[yytype]);
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "syntax error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[yytype]);

	      if (yycount < 5)
		{
		  yycount = 0;
		  for (yyx = yyn < 0 ? -yyn : 0;
		       yyx < (int) (sizeof (yytname) / sizeof (char *));
		       yyx++)
		    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
		      {
			const char *yyq = ! yycount ? ", expecting " : " or ";
			yyp = yystpcpy (yyp, yyq);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yycount++;
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("syntax error; also virtual memory exhausted");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror ("syntax error");
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      /* Return failure if at end of input.  */
      if (yychar == YYEOF)
        {
	  /* Pop the error token.  */
          YYPOPSTACK;
	  /* Pop the rest of the stack.  */
	  while (yyss < yyssp)
	    {
	      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
	      yydestruct (yystos[*yyssp], yyvsp);
	      YYPOPSTACK;
	    }
	  YYABORT;
        }

      YYDSYMPRINTF ("Error: discarding", yytoken, &yylval, &yylloc);
      yydestruct (yytoken, &yylval);
      yychar = YYEMPTY;

    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab2;


/*----------------------------------------------------.
| yyerrlab1 -- error raised explicitly by an action.  |
`----------------------------------------------------*/
yyerrlab1:

  /* Suppress GCC warning that yyerrlab1 is unused when no action
     invokes YYERROR.  */
#if defined (__GNUC_MINOR__) && 2093 <= (__GNUC__ * 1000 + __GNUC_MINOR__)
  __attribute__ ((__unused__))
#endif


  goto yyerrlab2;


/*---------------------------------------------------------------.
| yyerrlab2 -- pop states until the error token can be shifted.  |
`---------------------------------------------------------------*/
yyerrlab2:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
      yydestruct (yystos[yystate], yyvsp);
      yyvsp--;
      yystate = *--yyssp;

      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;


  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*----------------------------------------------.
| yyoverflowlab -- parser overflow comes here.  |
`----------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}


#line 492 "probeconfparse.y"


/*
 * *******************   SUPPORTING CODE  ******************************
 */


/*
 *  *****  Pool of sk_vector_t  ****************************************
 */


/* get a new vector from the free-pool; if pool is empty, create
 * a new vector */
static sk_vector_t *vectorPoolGet(vector_pool_t *pool)
{
    sk_vector_t *v;

    /* if there are any in the pool, return one.  Otherwise create one. */
    if (pool->count) {
        --pool->count;
        v = pool->pool[pool->count];
        skVectorClear(v);
    } else {
        v = skVectorNew(pool->element_size);
    }

    return v;
}


/* add the vector to the free-pool.  If the pool is full, just
 * destroy the vector. */
static void vectorPoolPut(vector_pool_t *pool, sk_vector_t *v)
{
    assert(pool);
    assert(v);

    /* If the pool is full, destroy the list we were handed; otherwise
     * add it to the pool. */
    if (pool->count == VECTOR_POOL_CAPACITY) {
        skVectorDestroy(v);
    } else {
        pool->pool[pool->count] = v;
        ++pool->count;
    }
}


/* remove all vector's from the pool and destroy them */
static void vectorPoolEmpty(vector_pool_t *pool)
{
    int i;

    for (i = 0; i < pool->count; ++i) {
        skVectorDestroy(pool->pool[i]);
    }
    pool->count = 0;
}


static void missing_value(void)
{
    skpcParseErr("%s statement with no value", pcscan_clause);
}


static void include_file(char *filename)
{
    skpcParseIncludePush(filename);
}



/*
 *  *****  Probes  *****************************************************
 */


/* complete the current probe */
static void probe_end(void)
{
    if (!probe) {
        skpcParseErr("No active probe in %s statement", pcscan_clause);
        goto END;
    }

    if (defn_errors) {
        goto END;
    }

    if (skpcProbeVerify(probe, 0)) {
        skpcParseErr("Unable to verify probe %s",
                     skpcProbeGetName(probe));
        ++defn_errors;
        goto END;
    }

    /* Probe is valid and now owned by probeconf.  Set to NULL so it
     * doesn't get free()'ed. */
    probe = NULL;

  END:
    if (defn_errors) {
        skAppPrintErr("Encountered %d error%s while processing probe %s",
                      defn_errors, ((defn_errors == 1) ? "" : "s"),
                      (probe ? skpcProbeGetName(probe) : ""));
        pcscan_errors += defn_errors;
        defn_errors = 0;
    }
    if (probe) {
        skpcProbeDestroy(&probe);
        probe = NULL;
    }
}


/* Begin a new probe by setting the memory of the global probe_attr_t
 * into its initial state. */
static void probe_begin(
    char   *probe_name,
    char   *probe_type)
{
    skpc_probetype_t t;

    if (probe) {
        skpcParseErr("Found active probe in %s statement", pcscan_clause);
        skpcProbeDestroy(&probe);
        probe = NULL;
    }
    defn_errors = 0;

    if (skpcProbeCreate(&probe)) {
        skpcParseErr("Fatal: Unable to create probe");
        exit(EXIT_FAILURE);
    }

    /* probe_name will only be NULL on bad input from user */
    if (probe_name == NULL) {
        skpcParseErr("%s requires a name and a type", pcscan_clause);
        ++defn_errors;
        if (skpcProbeSetName(probe, probe_type)) {
            skpcParseErr("Error setting probe name to %s", probe_type);
            ++defn_errors;
        }
        goto END;
    }

    if (skpcProbeLookupByName(probe_name)) {
        skpcParseErr("A probe named '%s' already exists", probe_name);
        ++defn_errors;
    }

    if (skpcProbeSetName(probe, probe_name)) {
        skpcParseErr("Error setting probe name to %s", probe_name);
        ++defn_errors;
    }
    free(probe_name);

    t = skpcProbetypeNameToEnum(probe_type);
    if (t == PROBE_ENUM_INVALID) {
        skpcParseErr("Do not recognize probe type '%s'", probe_type);
        ++defn_errors;
    } else if (skpcProbeSetType(probe, t)) {
        skpcParseErr("Error setting probe type to %s", probe_type);
        ++defn_errors;
    }

  END:
    free(probe_type);
}


/*
 *  probe_priority(s);
 *
 *    Set the priority of the global probe to s.
 */
static void probe_priority(sk_vector_t *v)
{
    uint32_t n;
    char *s;

    if (vectorSingleString(v, &s)) {
        return;
    }

    n = parse_int_u16(s);
    if (n == UINT16_NO_VALUE) {
        ++defn_errors;
        return;
    }

    if (skpcProbeSetPriority(probe, (probe_priority_t)n)) {
        skpcParseErr("Priority %u out of range; use %d <= n <= %d",
                     n, PROBE_MIN_PRIORITY, PROBE_MAX_PRIORITY);
        ++defn_errors;
        return;
    }
}


/*
 *  probe_protocol(s);
 *
 *    Set the probe-type of the global probe to 's'.
 */
static void probe_protocol(sk_vector_t *v)
{
    skpc_proto_t proto;
    char *s;

    if (vectorSingleString(v, &s)) {
        return;
    }

    proto = skpcProtocolNameToEnum(s);
    if (proto == SKPC_PROTO_UNSET) {
        skpcParseErr("Do not recognize protocol '%s'", s);
        ++defn_errors;
    } else if (skpcProbeSetProtocol(probe, proto)) {
        skpcParseErr("Error setting %s value for probe %s to '%s'",
                     pcscan_clause, skpcProbeGetName(probe), s);
        ++defn_errors;
    }

    free(s);
}


/*
 *  probe_listen_as_host(s);
 *
 *    Set the global probe to listen for flows as the host IP 's'.
 */
static void probe_listen_as_host(sk_vector_t *v)
{
    uint32_t ip;
    char *s;

    if (vectorSingleString(v, &s)) {
        return;
    }

    if (parse_ip_addr(s, &ip)) {
        ++defn_errors;
        return;
    }

    if (skpcProbeSetListenAsAddr(probe, ip)) {
        skpcParseErr("Error setting %s value for probe %s",
                     pcscan_clause, skpcProbeGetName(probe));
        ++defn_errors;
    }
}


/*
 *  probe_listen_on_port(s);
 *
 *    Set the global probe to listen for flows on port 's'.
 */
static void probe_listen_on_port(sk_vector_t *v)
{
    uint32_t n;
    char *s;

    if (vectorSingleString(v, &s)) {
        return;
    }

    n = parse_int_u16(s);
    if (n == UINT16_NO_VALUE) {
        ++defn_errors;
        return;
    }

    if (skpcProbeSetListenOnPort(probe, n)) {
        skpcParseErr("Error setting %s value for probe %s",
                     pcscan_clause, skpcProbeGetName(probe));
        ++defn_errors;
    }
}


/*
 *  probe_listen_on_usocket(s);
 *
 *    Set the global probe to listen for flows on the unix domain socket 's'.
 */
static void probe_listen_on_usocket(sk_vector_t *v)
{
    char *s;

    if (vectorSingleString(v, &s)) {
        return;
    }
    if (skpcProbeSetListenOnUnixDomainSocket(probe, s)) {
        skpcParseErr("Error setting %s value for probe %s",
                     pcscan_clause, skpcProbeGetName(probe));
        ++defn_errors;
    }
    free(s);
}


/*
 *  probe_read_from_file(s);
 *
 *    Set the global probe to read flows from the file 's'.
 */
static void probe_read_from_file(sk_vector_t *v)
{
    char *s;

    if (vectorSingleString(v, &s)) {
        return;
    }
    if (skpcProbeSetFileSource(probe, s)) {
        skpcParseErr("Error setting %s value for probe %s",
                     pcscan_clause, skpcProbeGetName(probe));
        ++defn_errors;
    }
    free(s);
}


/*
 *  probe_poll_directory(s);
 *
 *    Set the global probe to read flows from files that appear in the
 *    directory 's'.
 */
static void probe_poll_directory(sk_vector_t *v)
{
    char *s;

    if (vectorSingleString(v, &s)) {
        return;
    }
    if (skpcProbeSetPollDirectory(probe, s)) {
        skpcParseErr("Error setting %s value for probe %s",
                     pcscan_clause, skpcProbeGetName(probe));
        ++defn_errors;
    }
    free(s);
}


/*
 *  probe_accept_from_host(s);
 *
 *    Set the global probe to accept data from the host s.
 */
static void probe_accept_from_host(sk_vector_t *v)
{
    struct in_addr addr;
    const char *err;
    char *s;

    if (vectorSingleString(v, &s)) {
        return;
    }

    err = skNameToAddr(s, &addr);
    if (err) {
        skpcParseErr("Unable to resolve %s value '%s': %s",
                     pcscan_clause, s, err);
        ++defn_errors;
        free(s);
        return;
    }

    if (skpcProbeSetAcceptFromHost(probe, ntohl(addr.s_addr))) {
        skpcParseErr("Error setting %s value for probe %s",
                     pcscan_clause, skpcProbeGetName(probe));
        ++defn_errors;
    }
    free(s);
}


/*
 *  probe_log_flags(n);
 *
 *    Set the log flags on the probe to 'n';
 */
static void probe_log_flags(uint32_t n)
{
    if (n == UINT16_NO_VALUE) {
        /* some error in parsing log flags */
        ++defn_errors;
        return;
    }

    if (skpcProbeSetLogFlags(probe, n)) {
        skpcParseErr("Error setting %s value for probe %s",
                     pcscan_clause, skpcProbeGetName(probe));
        ++defn_errors;
    }
}


/*
 *  *****  Sensors  ****************************************************
 */


static void sensor_end(void)
{
    if (!sensor) {
        skpcParseErr("No active sensor in %s statement", pcscan_clause);
        goto END;
    }

    if (defn_errors) {
        goto END;
    }

    if (skpcSensorVerify(sensor, extra_sensor_verify_fn)) {
        skpcParseErr("Unable to verify sensor %s",
                     skpcSensorGetName(sensor));
        ++defn_errors;
        goto END;
    }

    /* Sensor is valid and now owned by probeconf.  Set to NULL so it
     * doesn't get free()'ed. */
    sensor = NULL;

  END:
    if (defn_errors) {
        skAppPrintErr("Encountered %d error%s while processing sensor %s",
                      defn_errors, ((defn_errors == 1) ? "" : "s"),
                      (sensor ? skpcSensorGetName(sensor) : ""));
        pcscan_errors += defn_errors;
        defn_errors = 0;
    }
    if (sensor) {
        skpcSensorDestroy(&sensor);
        sensor = NULL;
    }
}


/* Begin a new sensor by setting the memory of the global probe_attr_t
 * into its initial state. */
static void sensor_begin(
    char           *sensor_name)
{
    const char *dummy_name = "<ERROR>";

    if (sensor) {
        skpcParseErr("Found active sensor in %s statement", pcscan_clause);
        skpcSensorDestroy(&sensor);
        sensor = NULL;
    }
    defn_errors = 0;

    if (skpcSensorCreate(&sensor)) {
        skpcParseErr("Fatal: Unable to create sensor");
        exit(EXIT_FAILURE);
    }

    /* sensor_name will only be NULL on bad input from user */
    if (sensor_name == NULL) {
        skpcParseErr("%s requires a sensor name", pcscan_clause);
        ++defn_errors;
        skpcSensorSetName(sensor, dummy_name);
    } else {
        if (skpcSensorLookupByName(sensor_name)) {
            skpcParseErr("A sensor named '%s' already exists", sensor_name);
            ++defn_errors;
        }

        if (skpcSensorSetName(sensor, sensor_name)) {
            skpcParseErr("Error setting sensor name to %s", sensor_name);
            ++defn_errors;
        }

        if (SK_INVALID_SENSOR == skpcSensorGetID(sensor)) {
            skpcParseErr("There is no known sensor named %s", sensor_name);
            ++defn_errors;
        }

        free(sensor_name);
    }
}


/*
 *  sensor_isp_ip(list);
 *
 *    Set the isp-ip's on the global sensor to 'list'.
 */
static void sensor_isp_ip(sk_vector_t *v)
{
    sk_vector_t *nl;
    size_t count = skVectorGetCount(v);
    size_t i;
    uint32_t ip;
    char **s;

    /* error on overwrite */
    if (skpcSensorGetIspIps(sensor, NULL) != 0) {
        skpcParseErr("Attempt to overwrite previous %s value for sensor %s",
                     pcscan_clause, skpcSensorGetName(sensor));
        ++defn_errors;
        vectorPoolPut(ptr_pool, v);
        return;
    }

    nl = vectorPoolGet(u32_pool);
    if (nl == NULL) {
        skpcParseErr("Allocation error near %s", pcscan_clause);
        return;
    }

    /* convert string list to a list of numerical IPs */
    for (i = 0; i < count; ++i) {
        s = (char**)skVectorGetValuePointer(v, i);
        if (parse_ip_addr(*s, &ip)) {
            ++defn_errors;
        }
        skVectorAppendValue(nl, &ip);
    }
    vectorPoolPut(ptr_pool, v);

    skpcSensorSetIspIps(sensor, nl);
    vectorPoolPut(u32_pool, nl);
}


/*
 *  sensor_interface(name, list);
 *
 *    Set the interface list for the network whose name is 'name' on
 *    the global sensor to 'list'.
 *
 *    If 'list' is NULL, set the interface list to all the indexes NOT
 *    listed on other interfaces---set it to the 'remainder' of the
 *    interfaces.
 */
static void sensor_interface(char *name, sk_vector_t *v)
{
    const skpc_network_t *network = NULL;
    sk_vector_t *nl = NULL;
    char **s;
    size_t i;
    size_t count;
    uint32_t n;

    if (name == NULL) {
        skpcParseErr("Interface list '%s' gives a NULL name", pcscan_clause);
        abort();
    }

    /* convert the name to a network */
    network = skpcNetworkLookupByName(name);
    if (network == NULL) {
        skpcParseErr(("Cannot set %s for sensor %s because\n"
                      "\tthe '%s' network is not defined"),
                     pcscan_clause, skpcSensorGetName(sensor), name);
        ++defn_errors;
        goto END;
    }

#if 0
    /* produce an error if overwriting existing list */
    if (skpcSensorGetInterfaces(sensor, network->id, NULL)) {
        skpcParseErr("Attempt to overwrite previous %s value for sensor %s",
                     pcscan_clause, skpcSensorGetName(sensor));
        goto END;
    }
#endif

    /* check that the parser got valid interface value(s) */
    if (v == NULL) {
        if (skpcSensorSetToRemainderInterfaces(sensor, network->id)) {
            ++defn_errors;
        }
    } else {
        nl = vectorPoolGet(u32_pool);
        if (nl == NULL) {
            ++defn_errors;
            goto END;
        }

        /* convert string list to a list of interface IDs */
        count = skVectorGetCount(v);
        for (i = 0; i < count; ++i) {
            s = (char**)skVectorGetValuePointer(v, i);
            n = parse_int_u16(*s);
            if (n == UINT16_NO_VALUE) {
                ++defn_errors;
                for (++i; i < count; ++i) {
                    s = (char**)skVectorGetValuePointer(v, i);
                    free(*s);
                }
                goto END;
            }
            skVectorAppendValue(nl, &n);
        }

        if (skpcSensorSetInterfaces(sensor, network->id, nl)) {
            ++defn_errors;
        }
    }

  END:
    if (name) {
        free(name);
    }
    if (v) {
        vectorPoolPut(ptr_pool, v);
    }
    if (nl) {
        vectorPoolPut(u32_pool, nl);
    }
}


/*
 *  sensor_ipblock(name, ip_list, negated);
 *
 *    When 'ip_list' is NULL, set a flag for the network 'name' noting
 *    that its ipblock list should be set to any IP addresses not
 *    covered by other IP blocks; ie., the remaining ipblocks.
 *
 *    When 'negated' is 0, set the ipblocks for the 'name' network of
 *    the global sensor to 'ip_list'.
 *
 *    When negated is non-zero, set the ipblocks for the 'name'
 *    network of the global sensor to the inverse of 'ip_list'.
 */
static void sensor_ipblock(
    char           *name,
    sk_vector_t    *v,
    int             negated)
{
    const skpc_network_t *network = NULL;
    sk_vector_t *wl = NULL;
    size_t i;
    size_t count;
    skIPWildcard_t *ipwild;
    char **s;

    if (name == NULL) {
        skpcParseErr("IP Block list '%s' gives a NULL name", pcscan_clause);
        abort();
    }

    /* convert the name to a network */
    network = skpcNetworkLookupByName(name);
    if (network == NULL) {
        skpcParseErr(("Cannot set %s for sensor %s because\n"
                      "\tthe '%s' network is not defined"),
                     pcscan_clause, skpcSensorGetName(sensor), name);
        ++defn_errors;
        goto END;
    }

#if 0
    /* produce an error if overwriting existing list */
    if (skpcSensorGetIpBlocks(sensor, network->id, NULL, NULL)) {
        skpcParseErr("Attempt to overwrite previous %s value for sensor %s",
                     pcscan_clause, skpcSensorGetName(sensor));
        ++defn_errors;
        goto END;
    }
#endif  /* 0 */

    /* check that the parser got valid wildcard value(s) */
    if (v == NULL) {
        if (skpcSensorSetToRemainderIpBlocks(sensor, network->id)) {
            ++defn_errors;
        }
    } else {
        wl = vectorPoolGet(ptr_pool);
        if (wl == NULL) {
            ++defn_errors;
            goto END;
        }

        count = skVectorGetCount(v);
        for (i = 0; i < count; ++i) {
            s = (char**)skVectorGetValuePointer(v, i);
            ipwild = parse_wildcard_addr(*s);
            if (ipwild == NULL) {
                ++defn_errors;
                for (++i; i < count; ++i) {
                    s = (char**)skVectorGetValuePointer(v, i);
                    free(*s);
                }
                goto END;
            }
            skVectorAppendValue(wl, &ipwild);
        }

        if (skpcSensorSetIpBlocks(sensor, network->id, wl, negated)) {
            skIPWildcard_t **ipwp;
            ++defn_errors;
            count = skVectorGetCount(wl);
            for (i = 0; i < count; ++i) {
                ipwp = (skIPWildcard_t**)skVectorGetValuePointer(wl, i);
                free(*ipwp);
            }
            goto END;
        }
    }

  END:
    if (name) {
        free(name);
    }
    if (v) {
        vectorPoolPut(ptr_pool, v);
    }
    if (wl) {
        vectorPoolPut(ptr_pool, wl);
    }
}


static void sensor_probes(char *probe_type, sk_vector_t *v)
{
    sk_vector_t *pl;
    size_t i = 0;
    char **s;
    const skpc_probe_t *p;
    skpc_probetype_t t;

    /* get a vector to use for the probe objects */
    pl = vectorPoolGet(ptr_pool);

    /* get the probe-type */
    t = skpcProbetypeNameToEnum(probe_type);
    if (t == PROBE_ENUM_INVALID) {
        skpcParseErr("Do not recognize probe type '%s'", probe_type);
        ++defn_errors;
        goto END;
    }

    while (NULL != (s = (char**)skVectorGetValuePointer(v, i))) {
        ++i;
        p = skpcProbeLookupByName(*s);
        if (p) {
            if (skpcProbeGetType(p) != t) {
                skpcParseErr("Attempt to use %s probe '%s' in a %s statement",
                             skpcProbetypeEnumtoName(skpcProbeGetType(p)),
                             *s, pcscan_clause);
                ++defn_errors;
            }
        } else {
            /* Create a new probe with the specified name and type */
            skpc_probe_t *new_probe;
            if (skpcProbeCreate(&new_probe)) {
                skpcParseErr("Fatal: Unable to create ephemeral probe");
                exit(EXIT_FAILURE);
            }
            if (skpcProbeSetName(new_probe, *s)) {
                skpcParseErr("Error setting ephemeral probe name to %s", *s);
                ++defn_errors;
                goto END;
            }
            if (skpcProbeSetType(new_probe, t)) {
                skpcParseErr("Error setting ephemeral probe type to %s",
                             probe_type);
                ++defn_errors;
                goto END;
            }
            if (skpcProbeVerify(new_probe, 1)) {
                skpcParseErr("Error verifying ephemeral probe %s",
                             *s);
                ++defn_errors;
                goto END;
            }
            p = skpcProbeLookupByName(*s);
            if (p == NULL) {
                skpcParseErr("Cannot find newly created ephemeral probe %s",
                             *s);
                abort();
            }
        }
        skVectorAppendValue(pl, &p);
        free(*s);
    }

    if (skpcSensorSetProbes(sensor, pl)) {
        ++defn_errors;
    }

  END:
    free(probe_type);
    while (NULL != (s = (char**)skVectorGetValuePointer(v, i))) {
        ++i;
        free(*s);
    }
    vectorPoolPut(ptr_pool, v);
    vectorPoolPut(ptr_pool, pl);
}


/*
 *  *****  Parsing Utilities  ******************************************
 */


/*
 *  val = parse_int_u16(s);
 *
 *    Parse 's' as a integer from 0 to 0xFFFF inclusive.  Returns the
 *    value on success.  Prints an error and returns UINT16_NO_VALUE
 *    if parsing is unsuccessful or value is out of range.
 */
static uint32_t parse_int_u16(char *s)
{
    uint32_t num;
    int rv;

    rv = skStringParseUint32(&num, s, 0, 0xFFFF);
    if (rv) {
        skpcParseErr("Invalid %s '%s': %s",
                     pcscan_clause, s, skStringParseStrerror(rv));
        num = UINT16_NO_VALUE;
    }

    free(s);
    return num;
}


static int vectorSingleString(sk_vector_t *v, char **s)
{
    int rv = 0;

    if (1 == skVectorGetCount(v)) {
        skVectorGetValue(s, v, 0);
    } else {
        size_t i = 0;
        while (NULL != (s = skVectorGetValuePointer(v, i))) {
            ++i;
            free(*s);
        }
        skpcParseErr("%s takes a single argument", pcscan_clause);
        ++defn_errors;
        rv = -1;
    }

    vectorPoolPut(ptr_pool, v);
    return rv;
}


/*
 *  ipwild = parse_wildcard_addr(ip);
 *
 *    Parse 'ip' as an IP address block in SiLK wildcard notation.
 *    Because the scanner does not allow comma as part of an ID, we
 *    will never see things like  "10.20.30.40,50".
 *
 *    Return the set of ips as an skIPWildcard_t*, or NULL on error.
 */
static skIPWildcard_t *parse_wildcard_addr(char *s)
{
    skIPWildcard_t *ipwild;
    int rv;

    ipwild = malloc(sizeof(skIPWildcard_t));
    if (ipwild) {
        rv = skStringParseIPWildcard(ipwild, s);
        if (rv) {
            skpcParseErr("Invalid IP address block '%s': %s",
                         s, skStringParseStrerror(rv));
            free(ipwild);
            ipwild = NULL;
        }
    }

    free(s);
    return ipwild;
}


/*
 *  ok = parse_ip_addr(ip_string, ip_val);
 *
 *    Parse 'ip_string' as an IP address and put result into 'ip_val'.
 *    Return 0 on success, -1 on failure.
 */
static int parse_ip_addr(char *s, uint32_t *ip)
{
    skipaddr_t addr;
    int rv;

    rv = skStringParseIP(&addr, s);
    if (rv) {
        skpcParseErr("Invalid IP addresses '%s': %s",
                     s, skStringParseStrerror(rv));
        free(s);
        return -1;
    }
#if SK_ENABLE_IPV6
    if (skipaddrIsV6(&addr)) {
        skpcParseErr("Invalid IP address '%s': IPv6 addresses not supported",
                     s);
        free(s);
        return -1;
    }
#endif /* SK_ENABLE_IPV6 */

    free(s);
    *ip = skipaddrGetV4(&addr);
    return 0;
}


/*
 *  new_flags = log_flags_add_flag(old_flags, flag);
 *
 *    Add 'flag' to the 'old_flags' and return the new flags.  Warn if
 *    either value is explicitly "NONE".
 */
static uint32_t log_flags_add_flag(uint32_t old_flags, uint32_t flag)
{
    if ((old_flags == SOURCE_LOG_NONE) || (flag == SOURCE_LOG_NONE)) {
        skpcParseErr(("The %s 'none' ignored when"
                      " mixed with other values on probe %s"),
                     pcscan_clause, skpcProbeGetName(probe));
    }

    return (old_flags | flag);
}


/*
 *  flag = parse_log_flag(s);
 *
 *    Parse the string 's' as a log flag.
 */
static uint32_t parse_log_flag(char *s)
{
    int rv = UINT16_NO_VALUE;

    if (!s || !*s) {
        skpcParseErr("Missing value for %s on probe %s",
                     pcscan_clause, skpcProbeGetName(probe));
    } else if (0 == strcmp(s, "all")) {
        rv = SOURCE_LOG_ALL;
    } else if (0 == strcmp(s, "bad")) {
        rv = SOURCE_LOG_BAD;
    } else if (0 == strcmp(s, "missing")) {
        rv = SOURCE_LOG_MISSING;
    } else if (0 == strcmp(s, "none")) {
        rv = SOURCE_LOG_NONE;
    } else {
        skpcParseErr("Do not recognize %s value '%s' on probe %s",
                     pcscan_clause, s, skpcProbeGetName(probe));
    }

    if (s) {
        free(s);
    }
    return rv;
}


int yyerror(char UNUSED(*s))
{
    return 0;
}


int skpcParseSetup(void)
{
    memset(ptr_pool, 0, sizeof(vector_pool_t));
    ptr_pool->element_size = sizeof(char*);

    memset(u32_pool, 0, sizeof(vector_pool_t));
    u32_pool->element_size = sizeof(uint32_t);

    return 0;
}


void skpcParseTeardown(void)
{
    if (probe) {
        ++defn_errors;
        skpcParseErr("Missing \"end probe\" statement");
        skpcProbeDestroy(&probe);
        probe = NULL;
    }
    if (sensor) {
        ++defn_errors;
        skpcParseErr("Missing \"end sensor\" statement");
        skpcSensorDestroy(&sensor);
        sensor = NULL;
    }

    pcscan_errors += defn_errors;
    vectorPoolEmpty(ptr_pool);
    vectorPoolEmpty(u32_pool);
}


/*
** Local variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/

