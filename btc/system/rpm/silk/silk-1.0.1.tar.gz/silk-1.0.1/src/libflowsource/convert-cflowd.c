/*
** Copyright (C) 2004-2007 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  Interface for converting from NetFlow v5 PDUs (aka cflowd records)
**
*/

#include "silk.h"

RCSIDENT("$SiLK: convert-cflowd.c 8577 2007-08-21 16:34:38Z mthomas $");

#include "convert-cflowd.h"


/*
 *  The naive ordering of events with respect to time in the router
 *  would be to collect the flows and generate the PDU.  Thus, one
 *  would expect:
 *
 *      flow.Start  <  flow.End  <  hdr.sysUptime
 *
 *  where all values are given as milliseconds since the router's
 *  interface was booted, and hdr.sysUptime is advertised as the
 *  "current" time.
 *
 *  However, since values are given as 32bit numbers, the values will
 *  roll-over after about 48 days.  If the values roll-over in the
 *  middle of writing the PDU, we will see one of these two
 *  conditions:
 *
 *      hdr.sysUptime  <  flow.Start  <  flow.End
 *
 *      flow.End  <  hdr.sysUptime  <  flow.Start
 *
 *  Thus, if flow.End less than flow.Start, we need to account for the
 *  roll-over when computing the flow's duration.
 *
 *  In practice, the PDU's header gets filled in before flows are
 *  added, making the hdr.sysUptime not have any true time ordering
 *  with respect to the flow.Start and flow.End, and we have seen
 *  cases in real NetFlow data where hdr.sysUptime is slightly less
 *  than flow.End:
 *
 *      flow.Start  <  hdr.sysUptime  <  flow.End
 *
 *  To determine if the hdr.sysUptime has rolled over but the
 *  flow.Start has not,after we determine the router's boot time we
 *  convert hdr.sysUptime to a 64-bit value and add
 *  sysUptimeAdjustMsecs to it---this gets us back to the naive
 *  ordering.  If flow.Start is greater than the adjusted value, we
 *  know a roll-over has of the sysUptime has occurred, and the
 *  flow.Start time must be reduced by 2^32 milliseconds.
 */
const intmax_t sysUptimeAdjustMsecs = 1000 * 60 * 5;

#define ROLLOVER32 ((intmax_t)UINT32_MAX + 1)



/* Encapsulates information from a netflowV5 header.  The resulting
 * cflowdTimeInfo_t is used to do time calculations when processing
 * individual records. */
void cflowdTimeInfoSetup(const v5Header *hdr, cflowdTimeInfo_t *ti)
{
    intmax_t now;

    /* get the sysUptime, which is the current time in milliseconds
     * since the export device booted */
    ti->sysUptime = ntohl(hdr->SysUptime);

    /* get current time as milliseconds since the UNIX epoch from the
     * PDU header's unix_secs and unix_nsecs values; round nanoseconds
     * by adding 5e5 before dividing. */
    now = ((intmax_t)1000 * ntohl(hdr->unix_secs)
           + ((ntohl(hdr->unix_nsecs) + 5e5L) / 1e6L));

    /* subtract sysUpTime from current-time to get router boot time as
     * milliseconds since UNIX epoch */
    ti->router_boot = now - ti->sysUptime;

    /* See the comment for sysUptimeAdjustMsecs */
    ti->sysUptime += sysUptimeAdjustMsecs;
}


/* Fills out a rwRec from a v5pdu record.
 * The variable ti can be NULL, in which case the start time will not
 * necessarily reflect reality. */
int cflowdToGeneric(
    const v5Record     *v5RPtr,
    rwRec              *rwrec,
    cflowdTimeInfo_t   *ti)
{
    intmax_t s, e;
    intmax_t sTime;

    memset(rwrec, 0, sizeof(*rwrec));

    /* Setup start and duration */
    s = ntohl(v5RPtr->First);
    e = ntohl(v5RPtr->Last);
    if (s > e) {
        /* End has rolled over, while start has not.  Adjust end by
         * 2^32 msecs in order to allow us to subtract start from end
         * and get a correct value for the duration. */
        e += ROLLOVER32;
    }

    sTime = s;
    if (ti) {
        /* sTime is milliseconds since the router booted.  To get UNIX
         * epoch milliseconds, add the router's boot time. */
        sTime += ti->router_boot;

        /* Check to see if the 32bit start time is (much) greater than
         * the sysUptime.  This should mean that the sysUptime has
         * rolled over but the start-time has not, meaning we need to
         * subtract 2^32 from the start time. */
        if (s > ti->sysUptime) {
            sTime -= ROLLOVER32;
        }
    }

    rwRecSetSIPv4(rwrec, ntohl(v5RPtr->srcaddr));
    rwRecSetDIPv4(rwrec, ntohl(v5RPtr->dstaddr));
    rwRecSetSPort(rwrec, ntohs(v5RPtr->srcport));
    rwRecSetDPort(rwrec, ntohs(v5RPtr->dstport));
    rwRecSetProto(rwrec, v5RPtr->prot);
    rwRecSetFlags(rwrec, v5RPtr->tcp_flags);
    rwRecSetInput(rwrec, ntohs(v5RPtr->input));
    rwRecSetOutput(rwrec, ntohs(v5RPtr->output));
    rwRecSetNhIPv4(rwrec, ntohl(v5RPtr->nexthop));
    rwRecSetStartTime(rwrec, (sktime_t)sTime);
    rwRecSetPkts(rwrec, ntohl(v5RPtr->dPkts));
    rwRecSetBytes(rwrec, ntohl(v5RPtr->dOctets));
    rwRecSetElapsed(rwrec, (uint32_t)(e - s));
    rwRecSetRestFlags(rwrec, 0);
    rwRecSetTcpState(rwrec, SK_TCPSTATE_NO_INFO);
    rwRecSetApplication(rwrec, 0);

    return 0;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
