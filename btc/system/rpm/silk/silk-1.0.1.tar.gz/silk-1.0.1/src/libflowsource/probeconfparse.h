/* A Bison parser, made by GNU Bison 1.875.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ACCEPT_FROM_HOST_T = 258,
     COMMA = 259,
     END_PROBE_T = 260,
     END_SENSOR_T = 261,
     EOL = 262,
     INCLUDE_T = 263,
     ISP_IP_T = 264,
     LISTEN_AS_HOST_T = 265,
     LISTEN_ON_PORT_T = 266,
     LISTEN_ON_USOCKET_T = 267,
     LOG_FLAGS_T = 268,
     POLL_DIRECTORY_T = 269,
     PRIORITY_T = 270,
     PROBE_T = 271,
     PROTOCOL_T = 272,
     READ_FROM_FILE_T = 273,
     REMAINDER_T = 274,
     SENSOR_T = 275,
     ID = 276,
     INTERFACE = 277,
     IPBLOCK = 278,
     PROBES = 279,
     QUOTED_STRING = 280,
     ERR_STR_TOO_LONG = 281
   };
#endif
#define ACCEPT_FROM_HOST_T 258
#define COMMA 259
#define END_PROBE_T 260
#define END_SENSOR_T 261
#define EOL 262
#define INCLUDE_T 263
#define ISP_IP_T 264
#define LISTEN_AS_HOST_T 265
#define LISTEN_ON_PORT_T 266
#define LISTEN_ON_USOCKET_T 267
#define LOG_FLAGS_T 268
#define POLL_DIRECTORY_T 269
#define PRIORITY_T 270
#define PROBE_T 271
#define PROTOCOL_T 272
#define READ_FROM_FILE_T 273
#define REMAINDER_T 274
#define SENSOR_T 275
#define ID 276
#define INTERFACE 277
#define IPBLOCK 278
#define PROBES 279
#define QUOTED_STRING 280
#define ERR_STR_TOO_LONG 281




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 181 "probeconfparse.y"
typedef union YYSTYPE {
    char               *string;
    sk_vector_t        *vector;
    uint32_t            u32;
    skpc_probetype_t    p_type;
} YYSTYPE;
/* Line 1204 of yacc.c.  */
#line 95 "probeconfparse.h"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;



