/*
** Copyright (C) 2004-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  rwnetmask
**
**  Read in rw-records and output rw-records, masking the Source IP
**  and Destination IP by the prefix-lengths given on the command
**  line.
**
*/

#include "silk.h"

RCSIDENT("$SiLK: rwnetmask.c 10863 2008-03-10 19:22:04Z mthomas $");

#include "utils.h"
#include "rwpack.h"


/* TYPEDEFS AND DEFINES */

/* File handle for --help output */
#define USAGE_FH stdout

/* Number of prefixes supported: sip, dip, nhip */
#define PREFIX_COUNT 3

enum {
    SIP_MASK, DIP_MASK, NHIP_MASK,
    /* next must be last */
    _FINAL_MASK_
};


/* LOCAL VARIABLES */

/* The netmask of source/dest/next-hop IP.  For class A (/8), value
 * would be 0xFF000000. Value of 0 means to apply no mask--logically
 * the same as 0xFFFFFFFF. */
static uint32_t nmask_prefixes[PREFIX_COUNT];

/* Where to write the output */
static const char *output_path = NULL;

/* Index into the argv[] array */
static int arg_index;


/* OPTIONS */

typedef enum {
    OPT_SIP_PREFIX_LENGTH, OPT_DIP_PREFIX_LENGTH, OPT_NHIP_PREFIX_LENGTH,
    OPT_OUTPUT_PATH
}  appOptionsEnum;

static struct option appOptions[] = {
    {"sip-prefix-length",   REQUIRED_ARG, 0, OPT_SIP_PREFIX_LENGTH},
    {"dip-prefix-length",   REQUIRED_ARG, 0, OPT_DIP_PREFIX_LENGTH},
    {"nhip-prefix-length",  REQUIRED_ARG, 0, OPT_NHIP_PREFIX_LENGTH},
    {"output-path",         REQUIRED_ARG, 0, OPT_OUTPUT_PATH},
    {0,0,0,0}               /* sentinel entry */
};

static const char *appHelp[] = {
    /* add help strings here for the applications options */
    "High bits of the sIP to keep; Def 32",
    "High bits of the dIP to keep; Def 32",
    "High bits of the nhIP to keep; Def 32",
    "Write output to given file path. Def. stdout",
    (char *)NULL
};

/* for compatibility */
static struct option legacyOptions[] = {
    {"source-prefix-length",        REQUIRED_ARG, 0, OPT_SIP_PREFIX_LENGTH},
    {"s",                           REQUIRED_ARG, 0, OPT_SIP_PREFIX_LENGTH},
    {"destination-prefix-length",   REQUIRED_ARG, 0, OPT_DIP_PREFIX_LENGTH},
    {"d",                           REQUIRED_ARG, 0, OPT_DIP_PREFIX_LENGTH},
    {"next-hop-prefix-length",      REQUIRED_ARG, 0, OPT_NHIP_PREFIX_LENGTH},
    {"n",                           REQUIRED_ARG, 0, OPT_NHIP_PREFIX_LENGTH},
    {0,0,0,0}                       /* sentinel entry */
};


/* LOCAL FUNCTION PROTOTYPES */

static void appUsageLong(void);
static void appTeardown(void);
static void appSetup(int argc, char **argv);
static int  appOptionsHandler(clientData cData, int opt_index, char *opt_arg);


/* FUNCTION DEFINITIONS */

/*
 *  appUsageLong();
 *
 *    Print complete usage information to USAGE_FH.  Pass this
 *    function to skOptionsSetUsageCallback(); skOptionsParse() will
 *    call this funciton and then exit the program when the --help
 *    option is given.
 */
static void appUsageLong(void)
{
#define USAGE_MSG                                                             \
    ("[--sip-prefix=N] [--dip-prefix=N] [--nhip-prefix=N]\n"                  \
     "\tRead SiLK Flow records from STDIN, mask-off the lower (32-N) bits\n"  \
     "\tof the specified IP address(es), and write the resulting records to\n"\
     "\tstdout.  Does not process files.\n")

    FILE *fh = USAGE_FH;

    skAppStandardUsage(fh, USAGE_MSG, appOptions, appHelp);
}


/*
 *  appSetup(argc, argv);
 *
 *    Perform all the setup for this application include setting up
 *    required modules, parsing options, etc.  This function should be
 *    passed the same arguments that were passed into main().
 *
 *    Returns to the caller if all setup succeeds.  If anything fails,
 *    this function will cause the application to exit with a FAILURE
 *    exit status.
 */
static void appSetup(int argc, char **argv)
{
    int i;

    /* verify same number of options and help strings */
    assert((sizeof(appHelp)/sizeof(char *)) ==
           (sizeof(appOptions)/sizeof(struct option)));

    assert(PREFIX_COUNT == _FINAL_MASK_);

    /* initialize variables */
    memset(nmask_prefixes, 0, sizeof(nmask_prefixes));

    /* register the application */
    skAppRegister(argv[0]);
    skOptionsSetUsageCallback(&appUsageLong);

    /* register the options */
    if ((skOptionsRegister(appOptions, &appOptionsHandler, NULL))
        || (skOptionsRegister(legacyOptions, &appOptionsHandler, NULL)))
    {
        skAppPrintErr("Unable to register options");
        exit(EXIT_FAILURE);
    }

    /* parse options */
    arg_index = skOptionsParse(argc, argv);
    if (arg_index < 0) {
        skAppUsage();           /* never returns */
    }

    /* make certain at least one mask was specified */
    for (i = 0; i < PREFIX_COUNT; ++i) {
        if (nmask_prefixes[i]) {
            break;
        }
    }
    if (i == PREFIX_COUNT) {
        skAppPrintErr("Must specify at least one prefix length option");
        skAppUsage();
    }

    /* check for input: arg_index is looking at first file name to process */
    if (arg_index == argc) {
        if (FILEIsATty(stdin)) {
            skAppPrintErr("No input files on command line and"
                          " stdin is connected to a terminal");
            skAppUsage();       /* never returns */
        }
    }

    /* check the output */
    if (output_path == NULL) {
        output_path = "stdout";
    }
    if  ((0 == strcmp("stdout", output_path)) && (FILEIsATty(stdout))) {
        skAppPrintErr("Will not write binary data to the terminal");
        exit(EXIT_FAILURE);
    }

    if (atexit(appTeardown) < 0) {
        skAppPrintErr("Unable to register appTeardown() with atexit()");
        appTeardown();
        exit(EXIT_FAILURE);
    }
}


/*
 *  appTeardown()
 *
 *    Teardown all modules, close all files, and tidy up all
 *    application state.
 *
 *    This function is idempotent.
 */
static void appTeardown(void)
{
    static int teardownFlag = 0;

    if (teardownFlag) {
        return;
    }
    teardownFlag = 1;

    skAppUnregister();
}


/*
 *  status = appOptionsHandler(cData, opt_index, opt_arg);
 *
 *    This function is passed to skOptionsRegister(); it will be called
 *    by skOptionsParse() for each user-specified switch that the
 *    application has registered; it should handle the switch as
 *    required---typically by setting global variables---and return 1
 *    if the switch processing failed or 0 if it succeeded.  Returning
 *    a non-zero from from the handler causes skOptionsParse() to return
 *    a negative value.
 *
 *    The clientData in 'cData' is typically ignored; 'opt_index' is
 *    the index number that was specified as the last value for each
 *    struct option in appOptions[]; 'opt_arg' is the user's argument
 *    to the switch for options that have a REQUIRED_ARG or an
 *    OPTIONAL_ARG.
 */
static int appOptionsHandler(
    clientData  UNUSED(cData),
    int         opt_index,
    char       *opt_arg)
{
    uint32_t n;
    uint32_t i;
    int rv;

    /* Store the address of the prefix to set in the switch(), then
     * set the referenced value below the switch() */
    switch ((appOptionsEnum)opt_index) {
      case OPT_SIP_PREFIX_LENGTH:
      case OPT_DIP_PREFIX_LENGTH:
      case OPT_NHIP_PREFIX_LENGTH:
        /* Which mask to change */
        i = (opt_index - OPT_SIP_PREFIX_LENGTH);
        /* Parse value */
        rv = skStringParseUint32(&n, opt_arg, 1, 32);
        if (rv) {
            skAppPrintErr("Invalid %s '%s': %s",
                          appOptions[opt_index].name, opt_arg,
                          skStringParseStrerror(rv));
            return 1;
        }
        if (nmask_prefixes[i]) {
            skAppPrintErr(("The %s value was given multiple times;\n"
                           "\tusing final value %lu"),
                          appOptions[opt_index].name, (unsigned long)n);
        }
        nmask_prefixes[i] = ~((uint32_t)0) << (32-n);
        break;

      case OPT_OUTPUT_PATH:
        if (output_path) {
            skAppPrintErr("The --%s switch was given multiple times",
                          appOptions[opt_index].name);
            return 1;
        }
        output_path = opt_arg;
        break;
    }

    return 0;                   /* OK */
}


/*
 *  maskInput(input_file, output_file);
 *
 *    Read SiLK Flow records from the 'input_file', mask off the
 *    source, destination, and/or next-hop IP addresses, and print the
 *    records to the 'output_file'.
 */
static int maskInput(
    rwIOStruct_t *input_ios,
    rwIOStruct_t *output_ios)
{
    rwRec rwrec;
    int rv = RWIO_OK;

    /* read the records and mask the IP addresses */
    while (!RWIO_ERROR_IS_FATAL(rv) && rwRead(input_ios, &rwrec)) {
        if (nmask_prefixes[SIP_MASK]) {
            rwRecSetSIPv4(&rwrec,
                          rwRecGetMaskSIPv4(&rwrec,nmask_prefixes[SIP_MASK]));
        }
        if (nmask_prefixes[DIP_MASK]) {
            rwRecSetDIPv4(&rwrec,
                          rwRecGetMaskDIPv4(&rwrec,nmask_prefixes[DIP_MASK]));
        }
        if (nmask_prefixes[NHIP_MASK]) {
            rwRecSetNhIPv4(&rwrec,
                           rwRecGetMaskNhIPv4(&rwrec,
                                              nmask_prefixes[NHIP_MASK]));
        }

        rv = rwWrite(output_ios, &rwrec);
    }

    if (RWIO_ERROR_IS_FATAL(rv)) {
        rwioPrintLastErr(output_ios, rv, &skAppPrintErr);
    }
    return rv;
}


/*
 *  rwios = appNextInput(argc, argv);
 *
 *    Open and return the next input file from the command line or the
 *    standard input if no files were given on the command line.
 */
static rwIOStruct *appNextInput(int argc, char **argv)
{
    static int initialized = 0;
    rwIOStruct *rwios = NULL;
    const char *fname = NULL;
    int rv;

    if (arg_index < argc) {
        /* get current file and prepare to get next */
        fname = argv[arg_index];
        ++arg_index;
    } else {
        if (initialized) {
            /* no more input */
            return NULL;
        }
        /* input is from stdin */
        fname = "stdin";
    }

    initialized = 1;

    /* create rwios and open file */
    if ((rv = rwioCreate(&rwios, fname, SK_IO_READ))
        || (rv = skStreamSetIPv6Policy(rwios, SK_IPV6POLICY_ASV4))
        || (rv = rwioOpen(rwios)))
    {
        rwioPrintLastErr(rwios, rv, &skAppPrintErr);
        rwioDestroy(&rwios);
    }

    return rwios;
}


int main(int argc, char **argv)
{
    rwIOStruct_t *rwios_in;
    rwIOStruct_t *rwios_out;
    int rv;

    appSetup(argc, argv);       /* never returns on error */

    /* Open the output file */
    if ((rv = rwioCreate(&rwios_out, output_path, SK_IO_WRITE))
        || (rv = rwioOpen(rwios_out))
        || (rv = rwioWriteHeader(rwios_out)))
    {
        rwioPrintLastErr(rwios_out, rv, &skAppPrintErr);
        rwioDestroy(&rwios_out);
        exit(EXIT_FAILURE);
    }

    /* Process each input file */
    while (NULL != (rwios_in = appNextInput(argc, argv))) {
        maskInput(rwios_in, rwios_out);
        rwioDestroy(&rwios_in);
    }

    /* Close output */
    rv = rwioClose(rwios_out);
    if (rv) {
        rwioPrintLastErr(rwios_out, rv, &skAppPrintErr);
    }
    rwioDestroy(&rwios_out);

    /* done */
    appTeardown();

    return 0;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
