/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  rwuniqsetup.c
**
**  Application setup for rwuniq.  See rwuniq.c for a description.
*/


#include "silk.h"

RCSIDENT("$SiLK: rwuniqsetup.c 11341 2008-04-23 13:48:37Z mthomas $");

#include "rwuniq.h"
#include "sksite.h"


/* TYPEDEFS AND DEFINES */

/* default sTime bin size to use when --bin-time is requested */
#define DEFAULT_TIME_BIN  60
#define DEFAULT_TIME_BIN_STR  "60"

/* file handle for --help usage message */
#define USAGE_FH stdout

/* Maximum number of dynamic libraries that rwuniq can open */
#define APP_MAX_DYNLIBS 8

/* Internal interface to libdynlib */
typedef struct app_dynlib_st {
    dynlibInfoStruct   *dlisp;  /* the libdynlib object */
    unsigned int        offset; /* number of field just before this dynlib */
    uniqf_t             fxn;    /* function to get output from dynlib */
} app_dynlib_t;


/* LOCAL VARIABLES */

/* available key fields */
static sk_stringmap_t *field_map = NULL;

/* the maximum ID in the field_names string-map */
static uint32_t max_field_id = 0;

/* the text the user entered for the --fields switch */
static char *fields_arg = NULL;

/* name of program to run to page output */
static char *pager;

/* the floor of the sTime and/or eTime */
static uint32_t time_bin_size = 0;

/* when time-binning is active and all time fields---sTime, eTime,
 * elapased---are requested, we must adjust 'elapsed' so that it is
 * equal to eTime-sTime.  this is non-0 if we must adjust */
static int adjust_elapsed = 0;

/* List of dynamic libraries to attempt to open at startup */
static const char *app_dynlib_names[] = {
    "addrtype.so",
    "ccfilter.so",
    "pmapfilter.so",
    NULL /* sentinel */
};

/* Dynamic libraries we actually opened */
static app_dynlib_t app_dynlib_list[APP_MAX_DYNLIBS];

/* Number of dynamic libraries actually opened */
static int app_dynlib_count;


/* OPTIONS */

typedef enum {
    OPT_FIELDS,
    OPT_PRESORTED_INPUT,
    OPT_ALL_COUNTS,
    OPT_BYTES,
    OPT_PACKETS,
    OPT_FLOWS,
    OPT_STIME,
    OPT_ETIME,
    OPT_SIP_DISTINCT,
    OPT_DIP_DISTINCT,
    OPT_DYNAMIC_LIB_VALUE,
    OPT_BIN_TIME,
    OPT_EPOCH_TIME,
    OPT_INTEGER_IPS,
    OPT_ZERO_PAD_IPS,
    OPT_INTEGER_SENSORS,
    OPT_NO_TITLES,
    OPT_NO_COLUMNS,
    OPT_COLUMN_SEPARATOR,
    OPT_NO_FINAL_DELIMITER,
    OPT_DELIMITED,
    OPT_PRINT_FILENAMES,
    OPT_COPY_INPUT,
    OPT_OUTPUT_PATH,
    OPT_PAGER,
    OPT_LEGACY_TIMESTAMPS
#ifdef ENABLE_BINARY
    , OPT_ENABLE_BINARY
#endif
} appOptionsEnum;


static struct option appOptions[] = {
    {"fields",              REQUIRED_ARG, 0, OPT_FIELDS},
    {"presorted-input",     NO_ARG,       0, OPT_PRESORTED_INPUT},
    {"all-counts",          NO_ARG,       0, OPT_ALL_COUNTS},
    {"bytes",               OPTIONAL_ARG, 0, OPT_BYTES},
    {"packets",             OPTIONAL_ARG, 0, OPT_PACKETS},
    {"flows",               OPTIONAL_ARG, 0, OPT_FLOWS},
    {"stime",               NO_ARG,       0, OPT_STIME},
    {"etime",               NO_ARG,       0, OPT_ETIME},
    {"sip-distinct",        OPTIONAL_ARG, 0, OPT_SIP_DISTINCT},
    {"dip-distinct",        OPTIONAL_ARG, 0, OPT_DIP_DISTINCT},
    {OPT_DYNAMIC_LIBRARY,   REQUIRED_ARG, 0, OPT_DYNAMIC_LIB_VALUE},
    {"bin-time",            OPTIONAL_ARG, 0, OPT_BIN_TIME},
    {"epoch-time",          NO_ARG,       0, OPT_EPOCH_TIME},
    {"integer-ips",         NO_ARG,       0, OPT_INTEGER_IPS},
    {"zero-pad-ips",        NO_ARG,       0, OPT_ZERO_PAD_IPS},
    {"integer-sensors",     NO_ARG,       0, OPT_INTEGER_SENSORS},
    {"no-titles",           NO_ARG,       0, OPT_NO_TITLES},
    {"no-columns",          NO_ARG,       0, OPT_NO_COLUMNS},
    {"column-separator",    REQUIRED_ARG, 0, OPT_COLUMN_SEPARATOR},
    {"no-final-delimiter",  NO_ARG,       0, OPT_NO_FINAL_DELIMITER},
    {"delimited",           OPTIONAL_ARG, 0, OPT_DELIMITED},
    {"print-filenames",     NO_ARG,       0, OPT_PRINT_FILENAMES},
    {"copy-input",          REQUIRED_ARG, 0, OPT_COPY_INPUT},
    {"output-path",         REQUIRED_ARG, 0, OPT_OUTPUT_PATH},
    {"pager",               REQUIRED_ARG, 0, OPT_PAGER},
    {"legacy-timestamps",   OPTIONAL_ARG, 0, OPT_LEGACY_TIMESTAMPS},
#ifdef ENABLE_BINARY
    {"binary",              NO_ARG,       0, OPT_ENABLE_BINARY},
#endif
    {0,0,0,0}               /* sentinel entry */
};

static const char *appHelp[] = {
    NULL, /* generated dynamically */
    ("Assume input has been presorted using\n"
     "\trwsort invoked with the exact same --fields value. Def. No"),
    ("Enable the next five switches--count everything.  If no\n"
     "\tcount is specified, flows are counted.  Def. No"),
    ("Sum bytes in each bin; optionally choose to print\n"
     "\tbins whose total is in given range; range is MIN or MIN-MAX. Def. No"),
    ("Sum packets in each bin; optionally choose to print\n"
     "\tbins whose total is in given range; range is MIN or MIN-MAX. Def. No"),
    ("Count flow records in each bin; optionally choose to print\n"
     "\tbins whose count is in given range; range is MIN or MIN-MAX. Def. No"),
    "Print earliest time flow was seen in each bin. Def. No",
    "Print latest time flow was seen  in each bin. Def. No",
    ("Count distinct sIPs in each bin; optionally choose to\n"
     "\tprint bins whose count is in range; range is MIN or MIN-MAX. Def. No"),
    ("Count distinct dIPs in each bin; optionally choose to\n"
     "\tprint bins whose count is in range; range is MIN or MIN-MAX. Def. No"),
    "Use given dynamic library to add fields. Def. None",
    ("When using 'sTime' or 'eTime' as a key, adjust time(s) to\n"
     "\tto appear in N-second bins (floor of time is used). Def. No, "
     DEFAULT_TIME_BIN_STR),
    "Print times in UNIX epoch seconds. Def. No",
    "Print IP numbers as integers. Def. Dotted decimal",
    "Print IP numbers as zero-padded dotted decimal. Def. No",
    "Print sensor as an integer. Def. Sensor name",
    "Do not print column titles. Def. Print titles",
    "Disable fixed-width columnar output. Def. Columnar",
    "Use specified character between columns. Def. '|'",
    "Suppress column delimiter at end of line. Def. No",
    "Shortcut for --no-columns --no-final-del --column-sep=CHAR",
    "Print names of input files as they are opened. Def. No",
    "Copy all input SiLK Flows to given pipe or file. Def. No",
    "Send output to given file path. Def. stdout",
    "Program to invoke to page output. Def. $SILK_PAGER or $PAGER",
    ("Timestamp format. Choices:\n"
     "\t0==(new)\"YYYY/MM/DDThh:mm:ss\"; 1==(legacy)\"MM/DD/YYYY hh:mm:ss\".\n"
     "\tDef. 0 when switch not provided; 1 when switch provided with no value"),
#ifdef ENABLE_BINARY
    "Output in binary (hash serialization) format. Def. ASCII",
#endif
    (char *)NULL
};



/* LOCAL FUNCTION PROTOTYPES */

static void appUsageLong(void);
static int  appOptionsHandler(clientData cData, int opt_index, char *opt_arg);

/* Adding key and value fields */
static int  parseKeyFields(const char *field_string);
static key_field_t *addKeyField(
    uint32_t        id,
    size_t          width,
    rec2key_fn_t    r2kf,
    key2rec_fn_t    k2rf,
    uniqf_t         uniqf,
    unsigned int    fn_id);
static int setValueFields(void);

static void outStreamsSetProperties(void);

/* Functions to handle plug-ins */
static int appAddDynlib(const char *dlpath, int warn_on_error);
static app_dynlib_t* fieldNum2Dynlib(uint32_t fieldNum);

/* Sometimes key fields must be modified---e.g., sTime and eTime when
 * the --bin-time switch is given.  These functions have the same
 * signature as the uniq() function and do the necessary
 * modification. */
static int setKeyStime(
    unsigned int    id,
    uint8_t        *bin_value,
    char           *text_value,
    size_t          text_len,
    rwRec          *rwrec);
static int setKeyEtime(
    unsigned int    id,
    uint8_t        *bin_value,
    char           *text_value,
    size_t          text_len,
    rwRec          *rwrec);
static int setKeyElapsed(
    unsigned int    id,
    uint8_t        *bin_value,
    char           *text_value,
    size_t          text_len,
    rwRec          *rwrec);


/* FUNCTION DEFINITIONS */

/*
 *  appUsageLong();
 *
 *    Print complete usage information to USAGE_FH.  Pass this
 *    function to skOptionsSetUsageCallback(); skOptionsParse() will
 *    call this funciton and then exit the program when the --help
 *    option is given.
 */
static void appUsageLong(void)
{
    FILE *fh = USAGE_FH;
    int i;
    int j;

#define USAGE_MSG                                                             \
    ("--fields=N [SWITCHES] [FILES]\n"                                        \
     "\tSummarize SiLK Flow records into user-defined keyed bins specified\n" \
     "\twith the --fields switch.  For each keyed bin, print byte, packet,\n" \
     "\tand/or flow counts and/or the time window when key was active.\n"     \
     "\tWhen no files are given on command line, flows are read from STDIN.\n")

    fprintf(fh, "%s %s", skAppName(), USAGE_MSG);

    fprintf(fh, "\nSWITCHES:\n");
    skOptionsDefaultUsage(fh);
    sksiteOptionsUsage(fh);
    for (i = 0; appOptions[i].name; i++) {
        fprintf(fh, "--%s %s. ", appOptions[i].name,
                SK_OPTION_HAS_ARG(appOptions[i]));
        switch ((appOptionsEnum)i) {
          case OPT_FIELDS:
            /* Dynamically build the help */
            fprintf(fh, "Field(s) to use as key:\n");
            rwAsciiFieldMapPrintUsage(fh, field_map);

            /* Print the IPv6 usage next */
            skIPv6PolicyUsage(fh);
            break;

          default:
            /* Simple help text from the appHelp array */
            fprintf(fh, "%s\n", appHelp[i]);
            break;
        }
    }

    for (j = 0; j < app_dynlib_count; ++j) {
        dynlibOptionsUsage(app_dynlib_list[j].dlisp, fh);
    }

    fprintf(fh, "\nNOTES:\t* The --fields switch is required.\n");
}


/*
 *  appSetup(argc, argv);
 *
 *    Perform all the setup for this application include setting up
 *    required modules, parsing options, etc.  This function should be
 *    passed the same arguments that were passed into main().
 *
 *    Returns to the caller if all setup succeeds.  If anything fails,
 *    this function will cause the application to exit with a FAILURE
 *    exit status.
 */
void appSetup(int argc, char **argv)
{
    int using_pager = 0;
    size_t i;
    int j;

    /* verify same number of options and help strings */
    assert((sizeof(appHelp)/sizeof(char *)) ==
           (sizeof(appOptions)/sizeof(struct option)));

    /* check that NUM_VALUES and NUM_DISTINCTS are correct */
    assert(NUM_VALUES == _NUM_VALUES_);
    assert(NUM_DISTINCTS == _NUM_DISTINCTS_);

    /* register the application */
    skAppRegister(argv[0]);
    skOptionsSetUsageCallback(&appUsageLong);

    /* initialize globals */
    outputs = NULL;
    output_count = 0;
    uniq_io.outFPath = "stdout";
    uniq_io.outF = stdout;
    value_byte_width = 0;
    value_num_fields = 0;
    memset(&uniq_flags, 0, sizeof(uniq_flags));

    /* allow for 0 input and 0 output pipes */
    uniq_io.ISP = iochecksSetup(1, 0, argc, argv);

    /* initialize string-map of field identifiers: add default fields,
     * then remove millisec fields, since unique-ing over them makes
     * little sense.
     *
     * Note that although we remove the MSEC fields from the available
     * fields here, the remainder of the code still supports MSEC
     * fields---which are mapped onto the non-MSEC versions of the
     * fields. */
    if (rwAsciiFieldMapAddDefaultFields(&field_map)) {
        skAppPrintErr("Unable to setup fields stringmap");
        exit(EXIT_FAILURE);
    }
    (void)skStringMapRemoveByID(field_map, RWREC_FIELD_STIME_MSEC);
    (void)skStringMapRemoveByID(field_map, RWREC_FIELD_ETIME_MSEC);
    (void)skStringMapRemoveByID(field_map, RWREC_FIELD_ELAPSED_MSEC);
    max_field_id = RWREC_PRINTABLE_FIELD_COUNT - 1;

    /* register the options */
    if (skOptionsRegister(appOptions, &appOptionsHandler, NULL)
        || sksiteOptionsRegister(SK_SITE_FLAG_CONFIG_FILE)
        || skIPv6PolicyOptionsRegister(&ipv6_policy))
    {
        skAppPrintErr("Unable to register options");
        exit(EXIT_FAILURE);
    }

    /* try to load run-time dynamic libraries */
    for (j = 0; app_dynlib_names[j]; ++j) {
        appAddDynlib(app_dynlib_names[j], 0);
    }

    /* parse options */
    uniq_io.ISP->firstFile = skOptionsParse(argc, argv);
    if (uniq_io.ISP->firstFile < 0) {
        skAppUsage();/* never returns */
    }

    /* try to load site config file; if it fails, we will not be able
     * to resolve flowtype and sensor from input file names, but we
     * should not consider it a complete failure */
    sksiteConfigure(0);

    /* Set the value and/or distinct fields and parse the user's
     * minima/maxima */
    if (setValueFields()) {
        exit(EXIT_FAILURE);
    }

    /* If epoch time requested, reduce width of VALUE_STIME and
     * VALUE_ETIME fields. */
    if (time_flags & SKTIMESTAMP_EPOCH) {
        for (i = 0; i < value_num_fields; ++i) {
            if ((value_fields[i].vf_id == VALUE_STIME)
                || (value_fields[i].vf_id == VALUE_ETIME))
            {
                value_fields[i].vf_text_len = 10;
            }
        }
    }

    /* Make sure the user specified at least one key field, parse the
     * fields */
    if (fields_arg == NULL || fields_arg[0] == '\0') {
        skAppPrintErr("The --%s switch is required",
                      appOptions[OPT_FIELDS].name);
        skAppUsage();         /* never returns */
    }
    if (parseKeyFields(fields_arg)) {
        exit(EXIT_FAILURE);
    }

    /* Use STDIN as an input stream if it is not a TTY; make certain
     * we have some input and we are either reading from STDIN or
     * using files listed the command line, but not both. */
    if (iochecksAcceptFromStdin(uniq_io.ISP)
        || iochecksInputs(uniq_io.ISP, 0))
    {
        skAppUsage();
    }

#ifdef ENABLE_BINARY
    /* if binary is selected, check that uniq_io.outF is not a tty */
    if (uniq_flags.binary_output) {
        if (FILEIsATty(uniq_io.outF)) {
            skAppPrintErr("Will not print binary output to tty");
            exit(EXIT_FAILURE);
        }
    }
#endif

    /* final check. See if stdout is being used for both --copy-input
     * and as the destination for the uniq data.  */
    if (uniq_io.ISP->stdoutUsed && uniq_io.outF == stdout) {
        skAppPrintErr("stdout used for both --copy-input and ascii output");
        exit(EXIT_FAILURE);
    }

    /* Invoke the pager */
    using_pager = skOpenPagerWhenStdoutTty(&(uniq_io.outF), &pager);
    if (using_pager < 0) {
        exit(EXIT_FAILURE);
    }
    if (using_pager) {
        uniq_io.outFPath = pager;
        uniq_io.outIsPipe = 1;
    }

    /* looks good, open the --copy-input destination */
    if (iochecksOpenCopyDest(uniq_io.ISP)) {
        exit(EXIT_FAILURE);
    }

    /* Finally, set the output handle properties */
    outStreamsSetProperties();

    /* We don't need this any more.  Destroy it */
    if (field_map != NULL) {
        skStringMapDestroy(field_map);
        field_map = NULL;
    }

    if (atexit(appTeardown) < 0) {
        skAppPrintErr("Unable to register appTeardown() with atexit()");
        appTeardown();
        exit(EXIT_FAILURE);
    }

    return;                       /* OK */
}


/*
 *  appTeardown()
 *
 *    Teardown all modules, close all files, and tidy up all
 *    application state.
 *
 *    This function is idempotent.
 */
void appTeardown(void)
{
    static int teardownFlag = 0;
    int j;

    if (teardownFlag) {
        return;
    }
    teardownFlag = 1;

    iochecksTeardown(uniq_io.ISP);

    /* Dynamic library teardown */
    for (j = 0; j < app_dynlib_count; ++j) {
        dynlibTeardown(app_dynlib_list[j].dlisp);
        app_dynlib_list[j].dlisp = NULL;
    }
    app_dynlib_count = 0;

    /* close output */
    if (uniq_io.outF != stdout) {
        if (uniq_io.outIsPipe) {
            pclose(uniq_io.outF);
        } else {
            if (EOF == fclose(uniq_io.outF)) {
                skAppPrintErr("Error closing output file '%s': %s",
                              uniq_io.outFPath, strerror(errno));
            }
        }
    }

    /* destroy output */
    if (outputs) {
        size_t i;
        out_stream_t *ostream;

        for (i = 0; i < output_count; ++i) {
            ostream = outputs[i];
            if (ostream->a_stream) {
                rwAsciiStreamDestroy(&ostream->a_stream);
            }
            free(ostream);
        }

        free(outputs);
        outputs = NULL;
    }

    /* destroy field map */
    if (field_map != NULL) {
        skStringMapDestroy(field_map);
        field_map = NULL;
    }

    /* destroy key */
    if (key_fields) {
        free(key_fields);
        key_fields = NULL;
    }

    skAppUnregister();
}


/*
 *  status = appOptionsHandler(cData, opt_index, opt_arg);
 *
 *    Called by skOptionsParse(), this handles a user-specified switch
 *    that the application has registered, typically by setting global
 *    variables.  Returns 1 if the switch processing failed or 0 if it
 *    succeeded.  Returning a non-zero from from the handler causes
 *    skOptionsParse() to return a negative value.
 *
 *    The clientData in 'cData' is typically ignored; 'opt_index' is
 *    the index number that was specified as the last value for each
 *    struct option in appOptions[]; 'opt_arg' is the user's argument
 *    to the switch for options that have a REQUIRED_ARG or an
 *    OPTIONAL_ARG.
 */
static int appOptionsHandler(
    clientData  UNUSED(cData),
    int         opt_index,
    char       *opt_arg)
{
    size_t i;
    int rv;

    switch ((appOptionsEnum)opt_index) {
      case OPT_FIELDS:
        if (fields_arg) {
            skAppPrintErr("The --%s switch was specified multiple times",
                          appOptions[opt_index].name);
            return 1;
        }
        fields_arg = opt_arg;
        break;

      case OPT_ALL_COUNTS:
        for (i = 0; i < NUM_VALUES; ++i) {
            if (value_fields[i].vf_include_in_all) {
                value_fields[i].vf_iscounted = 1;
            }
        }
        break;

      case OPT_FLOWS:
      case OPT_BYTES:
      case OPT_PACKETS:
      case OPT_STIME:
      case OPT_ETIME:
        i = opt_index - OPT_BYTES;
        assert(i == value_fields[i].vf_id);
        value_fields[i].vf_iscounted = 1;
        value_fields[i].vf_user_param = opt_arg;
        break;

      case OPT_SIP_DISTINCT:
      case OPT_DIP_DISTINCT:
        i = opt_index - OPT_SIP_DISTINCT;
        assert(i == distinct_fields[i].df_id);
        distinct_fields[i].df_iscounted = 1;
        distinct_fields[i].df_user_param = opt_arg;
        break;

      case OPT_DYNAMIC_LIB_VALUE:
        /* dynamic library */
        if (appAddDynlib(opt_arg, 1)) {
            return 1;
        }
        break;

      case OPT_BIN_TIME:
        if (opt_arg == NULL || opt_arg[0] == '\0') {
            /* no time given; use default */
            time_bin_size = DEFAULT_TIME_BIN;
        } else {
            /* parse user's time */
            rv = skStringParseUint32(&time_bin_size, opt_arg, 1, 0);
            if (rv) {
                skAppPrintErr("Invalid %s '%s': %s",
                              appOptions[opt_index].name, opt_arg,
                              skStringParseStrerror(rv));
                return 1;
            }
        }
        break;

      case OPT_PRESORTED_INPUT:
        uniq_flags.presorted_input = 1;
        break;

      case OPT_EPOCH_TIME:
        if (time_flags & SKTIMESTAMP_MMDDYYYY) {
            skAppPrintErr("Both --%s and --%s specified. Using --%s",
                          appOptions[OPT_EPOCH_TIME].name,
                          appOptions[OPT_LEGACY_TIMESTAMPS].name,
                          appOptions[OPT_EPOCH_TIME].name);
        }
        time_flags = (time_flags & ~SKTIMESTAMP_MMDDYYYY) | SKTIMESTAMP_EPOCH;
        break;

      case OPT_INTEGER_IPS:
        uniq_flags.integer_ips = 1;
        break;

      case OPT_ZERO_PAD_IPS:
        uniq_flags.zero_pad_ips = 1;
        break;

      case OPT_INTEGER_SENSORS:
        uniq_flags.integer_sensors = 1;
        break;

      case OPT_NO_TITLES:
        uniq_flags.no_titles = 1;
        break;

      case OPT_NO_COLUMNS:
        uniq_flags.no_columns = 1;
        break;

      case OPT_NO_FINAL_DELIMITER:
        uniq_flags.no_final_delimiter = 1;
        break;

      case OPT_COLUMN_SEPARATOR:
        g_delimiter = opt_arg[0];
        break;

      case OPT_DELIMITED:
        uniq_flags.no_columns = 1;
        uniq_flags.no_final_delimiter = 1;
        if (opt_arg) {
            g_delimiter = opt_arg[0];
        }
        break;

      case OPT_PRINT_FILENAMES:
        uniq_flags.print_filenames = 1;
        break;

      case OPT_COPY_INPUT:
        if (iochecksAllDestinations(uniq_io.ISP, opt_arg)) {
            return 1;
        }
        break;

      case OPT_OUTPUT_PATH:
        uniq_io.outFPath = opt_arg;
        if (skOpenFile(uniq_io.outFPath, 1 /* write */, &uniq_io.outF,
                       &uniq_io.outIsPipe))
        {
            return 1;
        }
        break;

      case OPT_PAGER:
        pager = opt_arg;
        break;

      case OPT_LEGACY_TIMESTAMPS:
        if ((opt_arg == NULL) || (opt_arg[0] == '\0') || (opt_arg[0] == '1')) {
            if (time_flags & SKTIMESTAMP_EPOCH) {
                skAppPrintErr("Both --%s and --%s specified; using --%s",
                              appOptions[OPT_EPOCH_TIME].name,
                              appOptions[OPT_LEGACY_TIMESTAMPS].name,
                              appOptions[OPT_EPOCH_TIME].name);
                /* no change */
            } else {
                time_flags |= SKTIMESTAMP_MMDDYYYY;
            }
        } else if (opt_arg[0] != '0') {
            skAppPrintErr("Invalid %s '%s': Select 0 or 1",
                          appOptions[opt_index].name, opt_arg);
            return 1;
        }
        break;

#ifdef ENABLE_BINARY
      case OPT_ENABLE_BINARY:
        skAppPrintErr("Enabling binary output!");
        uniq_flags.binary_output = 1;
        break;
#endif

    }

    return 0;                     /* OK */
}


/*
 *  keyfield = addKeyField(map_id, byte_width, member_addr, func_ptr, func_id);
 *
 *    Add a new field to the attributes that will make up the key.
 *    'map_id' is the ID that this field has in the global field_map
 *    (RWREC_FIELD_SIP for source IP).
 *
 *    'byte_width' is the number of bytes required to hold this
 *    field's value; if 'byte_width' is 0, the function given in
 *    'func_ptr' will be invoked to get the byte-width.
 *
 *    'member_addr', if non-NULL, is a pointer to the member of the
 *    global rwRec 'g_rwrec' that the binary value of this key-field
 *    will be mapped back to during output.  If 'func_ptr' is NULL,
 *    the 'member_addr' will also be read to get the key field's
 *    value while reading the SiLK flow records.
 *
 *    If 'func_ptr' is non-NULL, it will used to convert the fields on
 *    an rwRec to a binary key-field value.  If 'member_addr' is NULL,
 *    the function will also be used to convert the binary value back
 *    to a textual value for output.
 *
 *    'fn_id' is the value that must be passed to 'func_ptr' to
 *    represent this key-field.
 *
 *    Returns a pointer into the global 'key_fields' array.
 */
static key_field_t *addKeyField(
    uint32_t        map_id,
    size_t          width,
    rec2key_fn_t    r2kf,
    key2rec_fn_t    k2rf,
    uniqf_t         uniqf,
    unsigned int    fn_id)
{
    key_field_t *key = &(key_fields[key_num_fields]);

    assert(r2kf || uniqf);
    assert(k2rf || uniqf);
    assert(width || uniqf);

    key->kf_id      = map_id;
    key->kf_offset  = key_byte_width;
    key->kf_width   = width;
    key->kf_fxn_r2k = r2kf;
    key->kf_fxn_k2r = k2rf;
    key->kf_fxn     = uniqf;
    key->kf_fxn_id  = fn_id;

    if (uniqf != NULL && width == 0) {
        uint8_t dummy_byte;
        rwRec dummy_rec;

        /* binary width */
        key->kf_width = (size_t)uniqf(fn_id, &dummy_byte, NULL, 0, NULL);

        /* printed width; if requested size is wider than the maximum
         * column width (VALUE_OUT_BUF_SIZE), only use the maximum. */
        key->kf_text_len = uniqf(fn_id, NULL, NULL, 0, &dummy_rec);
        if (key->kf_text_len == 0 || key->kf_text_len > VALUE_OUT_BUF_SIZE) {
            key->kf_text_len = VALUE_OUT_BUF_SIZE;
        }
    }

    /* compute new key width */
    key_byte_width += key->kf_width;
    ++key_num_fields;

    return key;
}


/*
 *  ok = setValueFields();
 *
 *    Loop over all the entries in the value_field[] array; for those
 *    value fields the user wants to count, parse the parameter to
 *    the switch.  The parameter should be NULL to use the default
 *    limits, a single value ("10") or a single value followed by a
 *    single hyphen ("10-") to be used as the minimum threshold, or
 *    the minimum and maximum limits separated by a hyphen ("10-20").
 *
 *    If the user didn't provide a value field, default to counting
 *    flows.
 *
 *    Figure out all the offsets into the values byte-array for each
 *    of the value fields and the overall length of the byte-array.
 *
 *    Returns 0 on success, or 1 if the opt_arg could not be parsed.
 */
static int setValueFields(void)
{
    uint64_t temp;
    int rv;
    const char *sp;
    size_t offset;
    uint8_t p_order;
    uint8_t target_order;
    uint8_t seen_min;
    size_t seen_idx;
    size_t i;
    int opt_index;

    /* process all the 'values' switches, parsing the user's parameter
     * (if any) and removing from the value_fields array all inactive
     * entries. */
    for (i = 0; i < NUM_VALUES; ++i) {
        if (0 == value_fields[i].vf_iscounted) {
            continue;
        }
        opt_index = i + OPT_BYTES;

        /* If an argument is provided, parse it as min-max.  If a
         * single number or a single number followed by a hyphen,
         * treat it as the minimum with no maximum. */
        sp = value_fields[i].vf_user_param;
        if (sp && sp[0]) {
            rv = skStringParseUint64(&temp, sp, 0, 0);
            if ((rv < 0) || ((rv > 0) && (sp[rv] != '-'))) {
                skAppPrintErr("Invalid %s '%s': %s",
                              appOptions[opt_index].name,
                              value_fields[i].vf_user_param,
                              skStringParseStrerror(rv));
                return 1;
            }
            if (temp > 0) {
                value_fields[i].vf_min = temp;
            }

            if ((rv > 0) && (sp[rv+1] != '\0')) {
                sp += rv + 1;
                rv = skStringParseUint64(&temp, sp, 0, 0);
                if (rv) {
                    skAppPrintErr("Invalid %s upper bound '%s': %s",
                                  appOptions[opt_index].name,
                                  value_fields[i].vf_user_param,
                                  skStringParseStrerror(rv));
                    return 1;
                }
                if (temp < value_fields[i].vf_min) {
                    skAppPrintErr("Invalid %s '%s': min > max",
                                  appOptions[opt_index].name,
                                  value_fields[i].vf_user_param);
                    return 1;
                }
                value_fields[i].vf_max = temp;
            }
        }

        value_byte_width += value_fields[i].vf_byte_width;

        /* move the values we actually use to the front of the
         * value_fields array */
        if (i != value_num_fields) {
            memcpy(&value_fields[value_num_fields], &value_fields[i],
                   sizeof(value_field_t));
        }
        ++value_num_fields;
    }

    /* process all the 'distinct' switches, parsing the user's
     * parameter (if any) and removing from the distinct_fields array
     * all inactive entries. */
    for (i = 0; i < NUM_DISTINCTS; ++i) {
        if (0 == distinct_fields[i].df_iscounted) {
            continue;
        }
        opt_index = i + OPT_SIP_DISTINCT;

        /* If an argument is provided, parse it as min-max.  If a
         * single number or a single number followed by a hyphen,
         * treat it as the minimum with no maximum. */
        sp = distinct_fields[i].df_user_param;
        if (sp && sp[0]) {
            rv = skStringParseUint64(&temp, sp, 0, 0);
            if ((rv < 0) || ((rv > 0) && (sp[rv] != '-'))) {
                skAppPrintErr("Invalid %s '%s': %s",
                              appOptions[opt_index].name,
                              distinct_fields[i].df_user_param,
                              skStringParseStrerror(rv));
                return 1;
            }
            if (temp > 0) {
                distinct_fields[i].df_min = temp;
            }

            if ((rv > 0) && (sp[rv] != '\0')) {
                sp += rv;
                rv = skStringParseUint64(&temp, sp, 0, 0);
                if (rv) {
                    skAppPrintErr("Invalid %s upper bound '%s': %s",
                                  appOptions[opt_index].name,
                                  distinct_fields[i].df_user_param,
                                  skStringParseStrerror(rv));
                    return 1;
                }
                if (temp < distinct_fields[i].df_min) {
                    skAppPrintErr("Invalid %s '%s': min > max",
                                  appOptions[opt_index].name,
                                  distinct_fields[i].df_user_param);
                    return 1;
                }
                distinct_fields[i].df_max = temp;
            }
        }

        distinct_fields[i].df_offset = distinct_byte_width;
        distinct_byte_width += distinct_fields[i].df_byte_width;

        /* move the values we actually use to the front of the
         * distinct_fields array */
        if (i != distinct_num_fields) {
            memcpy(&distinct_fields[distinct_num_fields], &distinct_fields[i],
                   sizeof(distinct_field_t));
        }
        ++distinct_num_fields;
    }

    /* Make certain the user specified at least one value or distinct
     * field.  If not, count by records (flows) for legacy
     * compatibility. */
    if ((value_num_fields + distinct_num_fields) == 0) {
        assert(value_fields[VALUE_FLOWS].vf_id == VALUE_FLOWS);
        value_byte_width += value_fields[VALUE_FLOWS].vf_byte_width;
        memcpy(&value_fields[value_num_fields], &value_fields[VALUE_FLOWS],
               sizeof(value_field_t));
        ++value_num_fields;
        return 0;
    }

    /* compute all the offsets; since the packing order is different
     * than the printing order, and values are in the value_fields[]
     * array in printing order. */
    offset = 0;
    target_order = 0;
    while (offset != value_byte_width) {
        assert(offset < value_byte_width);
        assert(target_order < NUM_VALUES);
        seen_idx = seen_min = NUM_VALUES;
        for (i = 0; i < value_num_fields; ++i) {
            p_order = value_fields[i].vf_pack_order;
            if ((p_order < seen_min) && (p_order >= target_order)) {
                seen_idx = i;
                seen_min = p_order;
                if (p_order == target_order) {
                    /* there is no need to look further */
                    break;
                }
            }
        }
        assert(seen_min != NUM_VALUES);
        value_fields[seen_idx].vf_offset = offset;
        offset += value_fields[seen_idx].vf_byte_width;
        target_order = seen_min + 1;
    }

    return 0;
}



/*
 *  status = parseKeyFields(field_string);
 *
 *    Parse the string that represents the columns the user wishes to
 *    "uniq" over and fill in the key_fields[] and outputs[] arrays.
 *    Return 0 on success or non-zero on error.
 */
static int parseKeyFields(const char *field_string)
{
    /* the fields (columns) to print and the order to print them; each
     * value is an ID from field_map */
    uint32_t *field_list;

    /* number of fields to print; length of field_list */
    uint32_t field_count;

    /* return value; assume failure */
    int rv = 1;

    /* whether we've added the dPort key.  Both DPORT and
     * ICMP_TYPE_CODE map to the dPort. */
    unsigned int saw_dport = 0;

    /* use bits to determine which of elapsed(1), sTime(2), and
     * eTime(4) were seen */
    unsigned int saw_time = 0;

    /* which of class and type were seen */
    unsigned int saw_class_type = 0;

    /* rwRec fields are printed by an rwAsciiStream_t; plug-in fields
     * must be printed by called the uniqDL.  ostream is wrapper
     * around these two ways of printing a field. */
    out_stream_t *ostream;

    /* used to build an array of out_stream_t's that will eventually
     * fill the outputs[] array. */
    sk_vector_t *outputs_vec = NULL;

    /* we can map multiple rwRec fields into a single rwAsciiStream_t,
     * but we must know the range of start and end. This gives start
     * of the range, as an index into the field_list[] array. */
    int first_position = 0;

    /* whether the previous key-field is part of an rwAsciiStream */
    int previous_field_builtin;

    size_t j;
    uint32_t i;

    /* parse the field-list into an array of fields */
    if (rwAsciiFieldMapParseFields(&field_list, &field_count, field_string,
                                   field_map, RW_ASCII_DUPES_ERROR))
    {
        /* library printed the error */
        return 1;
    }

    /* set the number of key-fields and the key-byte-width to zero.
     * create the array to hold the information about each
     * key-field. */
    key_byte_width = 0;
    key_num_fields = 0;
    key_fields = calloc(field_count, sizeof(key_field_t));
    if (key_fields == NULL) {
        goto END;
    }

    /* create vector to hold output streams */
    outputs = NULL;
    outputs_vec = skVectorNew(sizeof(out_stream_t*));
    if (outputs_vec == NULL) {
        goto END;
    }

    /*
     * We make two passes over the fields is the field_list[].  For
     * this first pass, create an ostream for every key-field that
     * comes from a plug-in, and for each run of consecutive built-in
     * (rwAsciiStream) key-fields.  We will fill in the ostream's on
     * the second pass.
     *
     * Also, for each built-in key-field, add it to the key_fields[]
     * array unless we have to compute it (eTime), in which case we'll
     * add it later.  Note that we do not have to preserve the order
     * of the keys, since we only care about the key's uniqueness.
     */
    previous_field_builtin = 0;
    for (i = 0; i < field_count; ++i) {
        if (field_list[i] >= RWREC_PRINTABLE_FIELD_COUNT) {
            /* field is not built-in; create a new ostream which we
             * will fill in later. */
            ostream = calloc(1, sizeof(out_stream_t));
            if (ostream == NULL) {
                goto END;
            }
            if (0 != skVectorAppendValue(outputs_vec, &ostream)) {
                free(ostream);
                goto END;
            }
            previous_field_builtin = 0;
        } else {
            /* field is built-in */

            /* handle the output stream */
            if (previous_field_builtin == 0) {
                /* must create a new AsciiStream and a new ostream to
                 * hold it. */
                ostream = calloc(1, sizeof(out_stream_t));
                if (ostream == NULL) {
                    goto END;
                }
                if (0 != rwAsciiStreamCreate(&(ostream->a_stream))) {
                    skAppPrintErr("Cannot create output stream");
                    goto END;
                }
                if (0 != skVectorAppendValue(outputs_vec, &ostream)) {
                    goto END;
                }
                ostream = NULL;
            }
            previous_field_builtin = 1;

            /* add this field to the key_fields[]. */
            switch ((rwrec_printable_fields_t)field_list[i]) {
              case RWREC_FIELD_SIP:
                /* Counting distinct IPs when the IP is part of the
                 * key doesn't make sense. */
                for (j = 0; j < distinct_num_fields; ++j) {
                    if (distinct_fields[j].df_id == DISTINCT_SIP) {
                        skAppPrintErr(("Error: Cannot count distinct sIPs"
                                       " when sIP is part of key."));
                        goto END;
                    }
                }
#if SK_ENABLE_IPV6
                if (ipv6_policy >= SK_IPV6POLICY_MIX) {
                    addKeyField(field_list[i], RWREC_SIZEOF_SIPv6,
                                &rwrec_MemGetSIPv6, &rwrec_MemSetSIPv6,NULL,0);
                    break;
                }
#endif /* SK_ENABLE_IPV6 */
                addKeyField(field_list[i], RWREC_SIZEOF_SIPv4,
                            &rwrec_MemGetSIPv4, &rwrec_MemSetSIPv4, NULL, 0);
                break;

              case RWREC_FIELD_DIP:
                /* Counting distinct IPs when the IP is part of the
                 * key doesn't make sense. */
                for (j = 0; j < distinct_num_fields; ++j) {
                    if (distinct_fields[j].df_id == DISTINCT_DIP) {
                        skAppPrintErr(("Error: Cannot count distinct dIPs"
                                       " when dIP is part of key."));
                        goto END;
                    }
                }
#if SK_ENABLE_IPV6
                if (ipv6_policy >= SK_IPV6POLICY_MIX) {
                    addKeyField(field_list[i], RWREC_SIZEOF_DIPv6,
                                &rwrec_MemGetDIPv6, &rwrec_MemSetDIPv6,NULL,0);
                    break;
                }
#endif /* SK_ENABLE_IPV6 */
                addKeyField(field_list[i], RWREC_SIZEOF_DIPv4,
                            &rwrec_MemGetDIPv4, &rwrec_MemSetDIPv4, NULL, 0);
                break;

              case RWREC_FIELD_NHIP:
#if SK_ENABLE_IPV6
                if (ipv6_policy >= SK_IPV6POLICY_MIX) {
                    addKeyField(field_list[i], RWREC_SIZEOF_NHIPv6,
                                &rwrec_MemGetNhIPv6, &rwrec_MemSetNhIPv6,
                                NULL, 0);
                    break;
                }
#endif /* SK_ENABLE_IPV6 */
                addKeyField(field_list[i], RWREC_SIZEOF_NHIPv4,
                            &rwrec_MemGetNhIPv4, &rwrec_MemSetNhIPv4, NULL, 0);
                break;

              case RWREC_FIELD_SPORT:
                addKeyField(field_list[i], RWREC_SIZEOF_SPORT,
                            &rwrec_MemGetSPort, &rwrec_MemSetSPort, NULL, 0);
                break;

              case RWREC_FIELD_DPORT:
              case RWREC_FIELD_ICMP_TYPE_CODE:
                if (saw_dport == 0) {
                    addKeyField(field_list[i], RWREC_SIZEOF_DPORT,
                                &rwrec_MemGetDPort, &rwrec_MemSetDPort,
                                NULL, 0);
                }
                saw_dport = 1;
                break;

              case RWREC_FIELD_PROTO:
                addKeyField(field_list[i], RWREC_SIZEOF_PROTO,
                            &rwrec_MemGetProto, &rwrec_MemSetProto, NULL, 0);
                break;

              case RWREC_FIELD_PKTS:
                addKeyField(field_list[i], RWREC_SIZEOF_PKTS,
                            &rwrec_MemGetPkts, &rwrec_MemSetPkts, NULL, 0);
                break;

              case RWREC_FIELD_BYTES:
                addKeyField(field_list[i], RWREC_SIZEOF_BYTES,
                            &rwrec_MemGetBytes, &rwrec_MemSetBytes, NULL, 0);
                break;

              case RWREC_FIELD_FLAGS:
                addKeyField(field_list[i], RWREC_SIZEOF_FLAGS,
                            &rwrec_MemGetFlags, &rwrec_MemSetFlags, NULL, 0);
                break;

              case RWREC_FIELD_STIME:
              case RWREC_FIELD_STIME_MSEC:
                if (0 == (saw_time & 2)) {
                    saw_time |= 2;
                    addKeyField(field_list[i], 4,
                                NULL, NULL, &setKeyStime, 0);
                }
                break;

              case RWREC_FIELD_ELAPSED:
              case RWREC_FIELD_ELAPSED_MSEC:
                /* this could be a pointer or a function; handle below */
                saw_time |= 1;
                break;

              case RWREC_FIELD_ETIME:
              case RWREC_FIELD_ETIME_MSEC:
                /* etime is always a function; handle below */
                saw_time |= 4;
                break;

              case RWREC_FIELD_SID:
                addKeyField(field_list[i], RWREC_SIZEOF_SID,
                            &rwrec_MemGetSensor, &rwrec_MemSetSensor, NULL, 0);
                break;

              case RWREC_FIELD_INPUT:
                addKeyField(field_list[i], RWREC_SIZEOF_INPUT,
                            &rwrec_MemGetInput, &rwrec_MemSetInput, NULL, 0);
                break;

              case RWREC_FIELD_OUTPUT:
                addKeyField(field_list[i], RWREC_SIZEOF_OUTPUT,
                            &rwrec_MemGetOutput, &rwrec_MemSetOutput, NULL, 0);
                break;

              case RWREC_FIELD_INIT_FLAGS:
                addKeyField(field_list[i], RWREC_SIZEOF_INIT_FLAGS,
                            &rwrec_MemGetInitFlags, &rwrec_MemSetInitFlags,
                            NULL, 0);
                break;

              case RWREC_FIELD_REST_FLAGS:
                addKeyField(field_list[i], RWREC_SIZEOF_REST_FLAGS,
                            &rwrec_MemGetRestFlags, &rwrec_MemSetRestFlags,
                            NULL, 0);
                break;

              case RWREC_FIELD_TCP_STATE:
                addKeyField(field_list[i], RWREC_SIZEOF_TCP_STATE,
                            &rwrec_MemGetTcpState, &rwrec_MemSetTcpState,
                            NULL, 0);
                break;

              case RWREC_FIELD_APPLICATION:
                addKeyField(field_list[i], RWREC_SIZEOF_APPLICATION,
                            &rwrec_MemGetApplication, &rwrec_MemSetApplication,
                            NULL, 0);
                break;

              case RWREC_FIELD_FTYPE_CLASS:
              case RWREC_FIELD_FTYPE_TYPE:
                if (saw_class_type == 0) {
                    addKeyField(field_list[i], RWREC_SIZEOF_FLOW_TYPE,
                                &rwrec_MemGetFlowType, &rwrec_MemSetFlowType,
                                NULL, 0);
                }
                saw_class_type = 1;
                break;
            }
        }
    }

    /* convert the output_vec to an array */
    output_count = skVectorGetCount(outputs_vec);
    outputs = calloc(output_count, sizeof(out_stream_t*));
    if (outputs == NULL) {
        goto END;
    }
    skVectorToArray(outputs, outputs_vec);
    skVectorDestroy(outputs_vec);
    outputs_vec = NULL;

    /* Warn if --bin-time requested but time not part of key.  Warn
     * that duration field will be modified when all time fields are
     * given. */
    if (time_bin_size != 0) {
        if (saw_time < 2) {
            if (FILEIsATty(stderr)) {
                skAppPrintErr("No time fields in key; %s switch ignored",
                              appOptions[OPT_BIN_TIME].name);
            }
        } else if (saw_time == 7) {
            /* must adjust elapsed to be eTime-sTime */
            adjust_elapsed = 1;
            if (FILEIsATty(stderr)) {
                skAppPrintErr("Warning: modifying duration field "
                              "to be eTime-sTime");
            }
        }
    }

    /* We skipped the elapsed field above; add it now that we know
     * whether it should be a function or not. */
    if (saw_time & 1) {
        /* use special function to convert elapsed to key; use
         * standard function to convert key back to elapsed. */
        addKeyField(RWREC_FIELD_ELAPSED, RWREC_SIZEOF_ELAPSED,
                    NULL, NULL, &setKeyElapsed, 0);
    }

    /* We skipped the etime field above; add it now that sTime and
     * elapsed have been processed.  Since the key is order dependent,
     * this ensures that we will have what we need when we unpack the
     * key during printing. */
    if (saw_time & 4) {
        addKeyField(RWREC_FIELD_ETIME, 4,
                    NULL, NULL, &setKeyEtime, 0);
    }

    /*
     * Now make a second pass through the field_list[].  For any
     * non-built-in fields, find the dynamic library that provides
     * them, initialize that plug-in, add the plug-in's uniq()
     * function to the key-fields, and have the output stream point to
     * the key-field.
     *
     * For built-in fields, fill the rwAsciiStream that we created in
     * the first pass.
     *
     * The variable 'j' is an index into the outputs[] array.
     */
    previous_field_builtin = 0;
    j = 0;
    for (i = 0; i < field_count; ++i) {
        if (field_list[i] >= RWREC_PRINTABLE_FIELD_COUNT) {
            /* field is not built-in */

            app_dynlib_t *app_dl;
            key_field_t *keyfield;
            unsigned int id;

            if (previous_field_builtin) {
                /* found a consecutive run of built-in fields, add
                 * them to the rwAsciiStream. */
                rwAsciiSetFields(outputs[j]->a_stream,
                                 &field_list[first_position],
                                 i - first_position);
                ++j;
            }
            previous_field_builtin = 0;

            /* map the field_id to the dynamic library and initialize
             * the plug-in; find the id that the plug-in uses for this
             * field. */
            app_dl = fieldNum2Dynlib(field_list[i]);
            if (app_dl == NULL) {
                /* could not initialize the plug-in */
                goto END;
            }
            id = field_list[i] - app_dl->offset;

            /* add the key-field */
            keyfield = addKeyField(field_list[i], 0, NULL, NULL,
                                   app_dl->fxn, id);
            outputs[j]->k_field = keyfield;
            ++j;
        } else {
            /* field is built-in.  We just need to keep a track of
             * consecutive runs of these */
            if (previous_field_builtin == 0) {
                first_position = i;
            }
            previous_field_builtin = 1;
        }
    }

    /* handle the case where the final field(s) are built-in */
    if (previous_field_builtin) {
        /* set the fields on the ascii stream */
        rwAsciiSetFields(outputs[j]->a_stream, &field_list[first_position],
                         i - first_position);
        ++j;
    }
    assert(j == output_count);

    /* adjust the offset of any distinct fields by the key width */
    for (i = 0; i < distinct_num_fields; ++i) {
        distinct_fields[i].df_offset += key_byte_width;
    }

    /* check size of key */
    if (key_byte_width > MAX_KEY_BYTE_WIDTH) {
        skAppPrintErr("Fields make too large a key: %u bytes > %u max",
                      (unsigned int)key_byte_width, MAX_KEY_BYTE_WIDTH);
        goto END;
    }

    /* successful */
    rv = 0;

  END:
    if (rv != 0) {
        /* something went wrong.  clean up */
        if (key_fields) {
            free(key_fields);
            key_fields = NULL;
        }
        if (outputs_vec != NULL) {
            /* clean up all the out_stream_t's on error */
            output_count = skVectorGetCount(outputs_vec);
            for (i = 0; i < output_count; ++i) {
                out_stream_t *o_stream;
                skVectorGetValue(&o_stream, outputs_vec, i);
                if (NULL != o_stream->a_stream) {
                    rwAsciiStreamDestroy(&(o_stream->a_stream));
                }
                free(o_stream);
            }
        }
        if (outputs != NULL) {
            for (i = 0; i < output_count; ++i) {
                out_stream_t *o_stream = outputs[i];
                if (NULL != o_stream->a_stream) {
                    rwAsciiStreamDestroy(&(o_stream->a_stream));
                }
                free(o_stream);
            }
            free(outputs);
            outputs = NULL;
        }
    }
    /* do standard clean-up */
    if (outputs_vec != NULL) {
        skVectorDestroy(outputs_vec);
    }
    if (field_list != NULL) {
        free(field_list);
    }

    return rv;
}


/*
 *  outStreamsSetProperties();
 *
 *    Use the switches entered by the user to set properties on all
 *    the ascii-streams that appear in the global 'outputs' array.
 */
static void outStreamsSetProperties(void)
{
    uint32_t i;
    rwAsciiStream_t *a_stream;
    int ip_warning_printed = 0;

    for (i = 0; i < output_count; ++i) {
        if (NULL == outputs[i]->a_stream) {
            continue;
        }

        /* only ascii streams make it here */
        a_stream = outputs[i]->a_stream;

        /* properties for every stream */
        rwAsciiSetNoNewline(a_stream);
        rwAsciiSetDelimiter(a_stream, g_delimiter);
        rwAsciiSetOutputHandle(a_stream, uniq_io.outF);
        rwAsciiSetIPv6Policy(a_stream, ipv6_policy);

        /* simple properties */
        rwAsciiSetTimestampFlags(a_stream, time_flags);
        if (uniq_flags.no_titles) {
            rwAsciiSetNoTitles(a_stream);
        }
        if (uniq_flags.no_columns) {
            rwAsciiSetNoColumns(a_stream);
        }
        if (uniq_flags.integer_sensors) {
            rwAsciiSetIntegerSensors(a_stream);
        }

        /* conflicting properties */
        if (uniq_flags.zero_pad_ips && !uniq_flags.integer_ips) {
            rwAsciiSetZeroPadIps(a_stream);
        }
        if (uniq_flags.integer_ips) {
            if ((uniq_flags.zero_pad_ips) && (ip_warning_printed == 0)) {
                ip_warning_printed = 1;
                skAppPrintErr("--integer-ips option overrides"
                              " --zero-pad-ips\n"
                              "\tWill print IPs as integers.");
            }
            rwAsciiSetIntegerIps(a_stream);
        }
#if 0
        if ((uniq_flags.icmpTandC) && (icmp_t_and_c == 0)) {
            icmp_t_and_c = 1;
            /* would prefer to do this in the ascii-stream where the
             * user has used sport/dport columns */
            rwAsciiSetIcmpTypeCode(a_stream);
        }
#endif
    }
}


/*
 *  len = setKeyStime(id, bin_value, text_value, text_len, rwrec);
 *
 *    When 'text_value' is null, generate a key value from the stime
 *    field in 'rwrec' and put that value into 'bin_value' and return
 *    the length of 'bin_value'.  If the user requested the floor of
 *    the stime, do that calculation.
 *
 *    When 'text_value' is null, take the key value from 'bin_value'
 *    and update the sTime field in the 'rwrec'.
 */
static int setKeyStime(
    unsigned int    UNUSED(id),
    uint8_t        *bin_value,
    char           *text_value,
    size_t          UNUSED(text_len),
    rwRec          *rwrec)
{
    uint32_t sTime;

    if (NULL == text_value) {
        sTime = rwRecGetStartSeconds(rwrec);
        if (time_bin_size > 1) {
            /* find the floor of the time */
            sTime -= (sTime % time_bin_size);
        }
        memcpy(bin_value, &sTime, sizeof(sTime));
        return (int)sizeof(sTime);
    }

    memcpy(&sTime, bin_value, sizeof(sTime));
    rwRecSetStartTime(rwrec, (sktime_t)1000 * sTime);
    return 0;
}


/*
 *  len = setKeyElapsed(id, bin_value, text_value, text_len, rwrec);
 *
 *    Get the elapsed field from the 'rwrec' and adjust it so that the
 *    computed 'sTime' and 'eTime' fields fall into the proper bins
 *    with respect to the global 'time_bin_size'.  Put that computed
 *    elapsed value into 'bin_value' and return the length of
 *    'bin_value'.
 *
 *    This function is only used when converting rwRec's into the
 *    key-byte-array.  For turning the key-byte-array back into an
 *    rwRec, just use the standard function to set the elapsed field.
 */
static int setKeyElapsed(
    unsigned int    UNUSED(id),
    uint8_t        *bin_value,
    char           *text_value,
    size_t          UNUSED(text_len),
    rwRec          *rwrec)
{
    uint32_t elapsed;

    if (NULL == text_value) {
        elapsed = rwRecGetElapsedSeconds(rwrec);
        if (adjust_elapsed) {
            /*
             * set elapsed to:
             * (eTime - (eTime % bin_size)) - (sTime - (sTime % bin_size))
             */
            uint32_t sTime = rwRecGetStartSeconds(rwrec);
            elapsed += ((sTime % time_bin_size)
                        - ((sTime + elapsed) % time_bin_size));
        }
        memcpy(bin_value, &elapsed, sizeof(elapsed));
        return (int)sizeof(elapsed);
    }

    memcpy(&elapsed, bin_value, sizeof(elapsed));
    rwRecSetElapsed(rwrec, 1000 * elapsed);
    return 0;
}


/*
 *  len = setKeyEtime(id, bin_value, text_value, text_len, rwrec);
 *
 *    When text_value is null (input), use the sTime and elapsed fields on the
 *    'rwrec' to compute the eTime, put the value into 'bin_value',
 *    and return the length of 'bin_value'.  Adjust the eTime relative
 *    to the global 'time_bin_size' if required.
 *
 *    When text_value is non-null (output), adjust the sTime and
 *    elapsed fields on the rwrec so that the eTime will have the
 *    value present in the key-byte-array.
 */
static int setKeyEtime(
    unsigned int    UNUSED(id),
    uint8_t        *bin_value,
    char           *text_value,
    size_t          UNUSED(text_len),
    rwRec          *rwrec)
{
    uint32_t eTime, sTime, elapsed;

    if (NULL == bin_value) {
        return 0;
    }
    if (NULL == text_value) {
        /* compute eTime and put it into bin_value */
        eTime = rwRecGetEndSeconds(rwrec);
        if (time_bin_size != 0) {
            /* compute floor */
            eTime -= (eTime % time_bin_size);
        }
        memcpy(bin_value, &eTime, sizeof(eTime));
        return (int)sizeof(eTime);
    }

    /* given an eTime value, find the sTime and elapsed values to set
     * on the rwrec that will add to give eTime.  This assumes that
     * the rwrec's sTime and elapsed have already been set. */
    memcpy(&eTime, bin_value, sizeof(eTime));

    sTime = rwRecGetStartSeconds(rwrec);
    elapsed = rwRecGetElapsedSeconds(rwrec);
    if (sTime) {
        if (elapsed == 0) {
            /* set elapsed based on start and end times */
            assert(sTime <= eTime);
            rwRecSetElapsed(rwrec, (1000 * (eTime - sTime)));
        }
#ifndef NDEBUG
        else {
            /* nothing to do to the records; verify that the times all
             * make sense. */
            assert(eTime == (sTime + elapsed));
        }
#endif
    } else if (elapsed) {
        /* set start time based on end time and elapsed */
        assert(eTime > elapsed);
        rwRecSetStartTime(rwrec, (sktime_t)1000 * (eTime - elapsed));
    } else {
        /* Just set sTime to eTime and elapsed is already 0 */
        rwRecSetStartTime(rwrec, (sktime_t)1000 * eTime);
    }

    return 0;
}


/*
 *  appAddDynlib(dlpath, warn_on_error);
 *
 *    Load the dynamic library at 'dlpath', store its information in
 *    the global 'app_dynlib_list', and increment the global counter
 *    'app_dynlib_count'.  Return 0 on success.
 *
 *    Return 1 if the library cannot be loaded or if too many dynamic
 *    libraries have been loaded.  In addition, if 'warn_on_error' is
 *    non-zero, print a message to stderr that the library could not
 *    be loaded.
 */
static int appAddDynlib(const char *dlpath, int warn_on_error)
{
    dynlibInfoStruct *dlisp = NULL;
    uniqf_t uniqf;
    sk_stringmap_entry_t *entries = NULL;
    int i;
    uint32_t offset;
    int rv = 1; /* return value; assume error */

    /* fields from the plug-in are added above this value.  All fields
     * from the plug-in must have an ID > 0. */
    offset = max_field_id;

    /* too many plug-ins? */
    if (app_dynlib_count == APP_MAX_DYNLIBS) {
        skAppPrintErr("Too many dynlibs.  Only %u allowed",
                      APP_MAX_DYNLIBS);
        goto END;
    }

    /* load it */
    dlisp = dynlibCreate(DYNLIB_UNIQ);
    if (dynlibLoad(dlisp, dlpath)) {
        /* failed to find library, missing symbols, or setup failed */
        if (warn_on_error) {
            skAppPrintErr("Error loading dynamic library '%s': %s",
                          dlpath, dynlibLastError(dlisp));
        }
        goto END;
    }
    uniqf = (uniqf_t)dynlibGetRWProcessor(dlisp);
    /* dynlibCheck() should have made this check already */
    assert(uniqf != NULL);

    /* get the fields for the application */
    if (dynlibConfigure(dlisp, (void*)(&entries)) != 0) {
        skAppPrintErr("Error getting fields from plug-in %s",
                      dynlibGetPath(dlisp));
        goto END;
    }

    if (entries == NULL) {
        /* We didn't get any fields from dynlibConfigure().  That's
         * the only way this application supports fields, so ignore
         * this dynlib. */
        if (warn_on_error) {
            skAppPrintErr(("Did not get fields from configure() method in\n"
                           "plug-in '%s'"),
                          dynlibGetPath(dlisp));
        }
        goto END;
    }

    /* the dynlibConfigure() routine gave us the fields */
    for (i = 0; entries[i].name != NULL; ++i) {
        /* check that value is not too small or too big */
        if (entries[i].id == 0) {
            skAppPrintErr("Invalid id '0' for field '%s' in %s plugin",
                          entries[i].name, dynlibGetPath(dlisp));
            goto END;
        }
        if (offset >= (UINT32_MAX - entries[i].id)) {
            skAppPrintErr("Invalid id '%u' for field '%s' in %s plugin",
                          entries[i].id, entries[i].name,
                          dynlibGetPath(dlisp));
            goto END;
        }

        /* add it */
        if (SKSTRINGMAP_OK != skStringMapAddID(field_map, entries[i].name,
                                               offset + entries[i].id))
        {
            skAppPrintErr("Cannot add entries to map");
            goto END;
        }
        /* keep track of the maximum field id */
        if (max_field_id < (offset + entries[i].id)) {
            max_field_id = offset + entries[i].id;
        }
    }

    /* success, add the dynamic library */
    app_dynlib_list[app_dynlib_count].dlisp  = dlisp;
    app_dynlib_list[app_dynlib_count].fxn    = uniqf;
    app_dynlib_list[app_dynlib_count].offset = offset;
    ++app_dynlib_count;

    rv = 0;

  END:
    if ((rv != 0) && (dlisp != NULL)) {
        sk_link_err_t link_rv;
        sk_link_item_t *node;
        sk_stringmap_entry_t *entry;

        dynlibTeardown(dlisp);

        /* roll back the field_map to those whose IDs are <= offset */
        link_rv = skLinkGetHead(&node, field_map);
        while (link_rv == SKLINK_OK) {
            skLinkGetData((void**)&entry, node);
            link_rv = skLinkGetNext(&node, node);
            if (entry->id > offset) {
                /* remove the entry */
                skStringMapRemoveByName(field_map, entry->name);
            }
        }
        max_field_id = offset;
    }

    return rv;
}


/*
 *  fieldNum2Dynlib(field_id);
 *
 *    Given a field number 'field_id' from the global 'field_map',
 *    return a pointer to a app_dynlib_t from the app_dynlib_list[]
 *    that points to the dynamic library used to print the field_id
 *    field.  Initializes the dynamic library.
 *
 *    Return NULL if the field_id is not related to any dynamic
 *    library or if the initialization of dynamic library failed.
 */
static app_dynlib_t* fieldNum2Dynlib(uint32_t field_id)
{
    int j;
    app_dynlib_t *app_dl;

    if (!app_dynlib_count || (field_id <= app_dynlib_list[0].offset)) {
        return NULL;
    }

    for (j = 1; j < app_dynlib_count; ++j) {
        if (field_id <= app_dynlib_list[j].offset) {
            break;
        }
    }
    app_dl = &(app_dynlib_list[j-1]);

    /* since we will be using the dynamic library, initialize it */
    if (dynlibInitialize(app_dl->dlisp)) {
        /* did not find the field; go through a lot of trouble to
         * print an error message, then return */
        sk_vector_t *entries_vec;
        sk_stringmap_entry_t *entry = NULL;

        entries_vec = skVectorNew(sizeof(sk_stringmap_entry_t*));
        if (NULL == entries_vec) {
            skAppPrintErr(("Field not available--cannot initialize %s"),
                          dynlibGetPath(app_dl->dlisp));
            return NULL;
        }
        skStringMapGetNames(entries_vec, field_map, field_id);
        skVectorGetValue(&entry, entries_vec, 0);
        if (NULL != entry) {
            skAppPrintErr(("Field '%s' not available--cannot initialize %s"),
                          entry->name, dynlibGetPath(app_dl->dlisp));
        }
        skVectorClear(entries_vec);
        return NULL;
    }

    return app_dl;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
