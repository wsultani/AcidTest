/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  rwuniq.c
**
**  Implementation of the rwuniq application.
**
**  rwuniq reads SiLK flow records---from files listen on the command
**  line or from the standard input when no filenames are given---and
**  bins those flows by a key composed of user-selected fields of an
**  rwRec, or by fields generated from a plug-in---run time dynamic
**  library.  For each bin, a user-selected combination of bytes,
**  packets, flows, earliest start-time, latest end-time, distinct
**  sIPs, and/or distinct dIPs may be computed.
**
**  Once the input is read or rwuniq's hash table runs out of memory,
**  the keys fields and computed values are printed for each bin that
**  meets the user-specified minimum and maximum.
**
*/


#include "silk.h"

RCSIDENT("$SiLK: rwuniq.c 10609 2008-02-22 23:00:38Z mthomas $");

#include "rwuniq.h"
#include "hashlib.h"


/* TYPEDEFS AND DEFINES */

/* Initializer for hash table creation */
#define HASH_INITIAL_SIZE 500000

/* Where to write filenames if --print-file specified */
#define PRINT_FILENAMES_FH  stderr

/* The summation values are stored in an array of bytes; the offsets
 * into this array are stored in the variable value_fields[].  The
 * following macros access the memory at these offsets or copy the
 * values from/to the byte-array and a variable. */
#define VAL_FIELD_GET_ADDR32(val_ptr, i)                        \
    ((uint32_t*)((val_ptr) + value_fields[(i)].vf_offset))

#define VAL_FIELD_MEMGET(val_ptr, i, out_val)                     \
    memcpy((out_val), ((val_ptr) + value_fields[(i)].vf_offset),  \
           value_fields[(i)].vf_byte_width)

#define VAL_FIELD_MEMSET(val_ptr, i, in_val)                      \
    memcpy(((val_ptr) + value_fields[(i)].vf_offset), (in_val),   \
           value_fields[(i)].vf_byte_width)


/* EXPORTED VARIABLES */

/* delimiter between output columns */
char g_delimiter = '|';

/* the columns/fields that make up our key for this run */
key_field_t *key_fields = NULL;

/* the number of actual columns/fields that make up the key */
size_t key_num_fields = 0;

/* the total byte count of the key */
size_t key_byte_width = 0;

/* Information about each potential "distinct" field the user can
 * choose to compute and display. */
distinct_field_t distinct_fields[NUM_DISTINCTS] = {
    {"Unique_SIP", NULL, 1, UINT64_MAX, &rwrec_MemGetSIPv4,
     sizeof(uint32_t), 0, 10, DISTINCT_SIP, 0},
    {"Unique_DIP", NULL, 1, UINT64_MAX, &rwrec_MemGetDIPv4,
     sizeof(uint32_t), 0, 10, DISTINCT_DIP, 0}
};

/* Number of distinct fields the user has requested */
size_t distinct_num_fields = 0;

/* Total byte count for all distinct_fields that are being computed */
size_t distinct_byte_width = 0;

/* Information about each potential "value" field the user can choose
 * to compute and display. */
value_field_t value_fields[NUM_VALUES] = {
    {"Bytes",      NULL, 1, UINT64_MAX, sizeof(uint64_t), 0, 20, 0,
     VALUE_BYTES,   1, 0},
    {"Packets",    NULL, 1, UINT64_MAX, sizeof(uint32_t), 0, 10, 1,
     VALUE_PACKETS, 1, 0},
    {"Records",    NULL, 1, UINT64_MAX, sizeof(uint32_t), 0, 10, 2,
     VALUE_FLOWS,   1, 0},
    {"min_sTime",  NULL, 1, UINT64_MAX, sizeof(uint32_t), 0, 19, 3,
     VALUE_STIME,   1, 0},
    {"max_eTime",  NULL, 1, UINT64_MAX, sizeof(uint32_t), 0, 19, 4,
     VALUE_ETIME,   1, 0}
};

/* Number of value fields the user has requested */
size_t value_num_fields = 0;

/* Total byte count for all value_fields that are being computed */
size_t value_byte_width = 0;

/* Array of out_stream_t* */
out_stream_t **outputs;

/* Count of 'outputs' */
size_t output_count;

/* the real output */
uniq_io_t uniq_io;

/* flags set by the user options */
uniq_flags_t uniq_flags;

/* how to print timestamps */
uint32_t time_flags = SKTIMESTAMP_NOMSEC;

/* how to handle IPv6 flows */
sk_ipv6policy_t ipv6_policy = SK_IPV6POLICY_MIX;


/* LOCAL VARIABLES */

/* number of records read */
static uint64_t g_record_count = 0;


/* LOCAL FUNCTION PROTOTYPES */

/* I/O Functions */
#ifdef  ENABLE_BINARY
static void writeBinary(FILE *fd, HashTable *table_ptr);
#endif
static void writeColTitles(void);
static int  fillRecordAndKey(rwRec *rwrec, uint8_t *key);

/* Functions to manipulate and test the count values in the hash
 * table */
static int  packValues(
    uint8_t        *out_val_ptr,
    const rwRec    *rec_ptr);
static void unpackValues(
    uint64_t        out_value[],
    uint8_t        *packed_val);


/* FUNCTION DEFINITIONS */


/*
 *  writeColTitles();
 *
 *    Print the column titles to the global 'uniq_io.outF'.
 */
static void writeColTitles(void)
{
    size_t i;
    char buf[VALUE_OUT_BUF_SIZE];
    char delim[2] = {'\0', '\0'};
    out_stream_t *ostream;

    if (uniq_flags.no_titles) {
        return;
    }

    /* print key titles */
    for (i = 0; i < output_count; ++i) {
        ostream = outputs[i];
        if (ostream->a_stream) {
            rwAsciiPrintTitles(ostream->a_stream);
        } else {
            /* call the uniq() function on the plug-in to get the title */
            assert(ostream->k_field->kf_text_len <= (int)sizeof(buf));
            ostream->k_field->kf_fxn(ostream->k_field->kf_fxn_id, 0, buf,
                                     ostream->k_field->kf_text_len, NULL);
            if (uniq_flags.no_columns) {
                fprintf(uniq_io.outF, "%s%c", buf, g_delimiter);
            } else {
                fprintf(uniq_io.outF, "%*s%c",
                        ostream->k_field->kf_text_len-1,
                        buf, g_delimiter);
            }
        }
    }

    /* print value titles */
    for (i = 0; i < value_num_fields; ++i) {
        if (uniq_flags.no_columns) {
            fprintf(uniq_io.outF, "%s%s",
                    delim, value_fields[i].vf_title);
        } else {
            fprintf(uniq_io.outF, "%s%*.*s",
                    delim,
                    value_fields[i].vf_text_len,
                    value_fields[i].vf_text_len,
                    value_fields[i].vf_title);
        }
        delim[0] = g_delimiter;
    }

    /* print distinct titles */
    if (distinct_num_fields) {
        for (i = 0; i < distinct_num_fields; ++i) {
            if (uniq_flags.no_columns) {
                fprintf(uniq_io.outF, "%s%s",
                        delim, distinct_fields[i].df_title);
            } else {
                fprintf(uniq_io.outF, "%s%*.*s",
                        delim,
                        distinct_fields[i].df_text_len,
                        distinct_fields[i].df_text_len,
                        distinct_fields[i].df_title);
            }
            delim[0] = g_delimiter;
        }
    }

    if (uniq_flags.no_final_delimiter) {
        delim[0] = '\0';
    }

    fprintf(uniq_io.outF, "%s\n", delim);
}


/*
 *  writeAsciiRecord(key, value, distincts);
 *
 *    Verifies that the 'value' and 'distincts' values are within the
 *    limits specified by the user.  If they are not, the function
 *    returns without printing anything.
 *
 *    Unpacks the fields from 'key' and prints the key fields, the
 *    value fields, and the distinct fields to the global output
 *    stream 'uniq_io.outF'.
 */
static void writeAsciiRecord(
    uint8_t        *key,
    const uint64_t  values[NUM_VALUES],
    const uint64_t  distincts[NUM_DISTINCTS])
{
    size_t i;
    out_stream_t *ostream;
    char buf[VALUE_OUT_BUF_SIZE];
    rwRec rwrec;
    char delim[2] = {'\0', '\0'};

    /* see if values are within limits */
    for (i = 0; i < value_num_fields; ++i) {
        switch ((value_types_t)value_fields[i].vf_id) {
          case VALUE_BYTES:
          case VALUE_PACKETS:
          case VALUE_FLOWS:
            if ((values[i] < value_fields[i].vf_min)
                || (values[i] > value_fields[i].vf_max))
            {
                return;
            }
            break;

          case VALUE_STIME:
          case VALUE_ETIME:
            break;

          case _NUM_VALUES_:
            assert(0);
            abort();
        }
    }

    /* see if distinct counts are within limits */
    for (i = 0; i < distinct_num_fields; ++i) {
        if ((distincts[i] < distinct_fields[i].df_min)
            || (distincts[i] > distinct_fields[i].df_max))
        {
            return;
        }
    }


    /* Zero out rwrec to avoid display errors---specifically with msec
     * fields and eTime. */
    RWREC_CLEAR(&rwrec);

    /* Initialize the protocol to 1, so that if the user has requested
     * ICMP without the protocol, we get ICMP values. */
    rwRecSetProto(&rwrec, 1);

#if SK_ENABLE_IPV6
    if (ipv6_policy >= SK_IPV6POLICY_MIX) {
        /* Force records to be in IPv6 format */
        rwRecSetIPv6(&rwrec);
    }
#endif /* SK_ENABLE_IPV6 */

    /* unpack the key into 'rwrec' */
    for (i = 0; i < key_num_fields; ++i) {
        if (key_fields[i].kf_fxn_k2r) {
            key_fields[i].kf_fxn_k2r(&rwrec, key+key_fields[i].kf_offset);
        } else {
            /* key is from plug-in; call plug-in to convert binary
             * value to a textual value */
            key_fields[i].kf_fxn(key_fields[i].kf_fxn_id,
                                 key+key_fields[i].kf_offset,
                                 key_fields[i].kf_textbuf,
                                 key_fields[i].kf_text_len,
                                 &rwrec);
        }
    }

    /* print key fields */
    for (i = 0; i < output_count; ++i) {
        ostream = outputs[i];
        if (ostream->a_stream) {
            rwAsciiPrintRec(ostream->a_stream, &rwrec);
        } else if (uniq_flags.no_columns) {
            fprintf(uniq_io.outF, "%s%c",
                    ostream->k_field->kf_textbuf, g_delimiter);
        } else {
            fprintf(uniq_io.outF, "%*s%c",
                    ostream->k_field->kf_text_len-1,
                    ostream->k_field->kf_textbuf, g_delimiter);
        }
    }

    /* print value fields */
    for (i = 0; i < value_num_fields; ++i) {
        switch ((value_types_t)value_fields[i].vf_id) {
          case VALUE_BYTES:
          case VALUE_PACKETS:
          case VALUE_FLOWS:
            sprintf(buf, ("%" PRIu64), values[i]);
            break;

          case VALUE_STIME:
          case VALUE_ETIME:
            sktimestamp_r(buf, ((sktime_t)1000 * values[i]), time_flags);
            break;

          case _NUM_VALUES_:
            assert(0);
            abort();
        }

        if (uniq_flags.no_columns) {
            fprintf(uniq_io.outF, "%s%s", delim, buf);
        } else {
            fprintf(uniq_io.outF, "%s%*s",
                    delim, value_fields[i].vf_text_len, buf);
        }
        delim[0] = g_delimiter;
    }

    /* print distinct fields */
    for (i = 0; i < distinct_num_fields; ++i) {
        if (uniq_flags.no_columns) {
            fprintf(uniq_io.outF, ("%s%" PRIu64), delim, distincts[i]);
        } else {
            fprintf(uniq_io.outF, ("%s%*" PRIu64),
                    delim, distinct_fields[i].df_text_len, distincts[i]);
        }
        delim[0] = g_delimiter;
    }

    if (uniq_flags.no_final_delimiter) {
        delim[0] = '\0';
    }

    fprintf(uniq_io.outF, "%s\n", delim);
}


#ifdef  ENABLE_BINARY
/* Serialize the hash table data in binary form */
void writeBinary(FILE *fd, HashTable *table_ptr)
{
    genericHeader header;

    /* Build the header */
    PREPHEADER(&header);
    header.type = FT_RWUNIQ_DATA;
    header.version = RWUNIQ_FILE_VERSION;

    /* Write the data, prefixed with the header */
    hashlib_serialize_table(table_ptr, fd,
                            (uint8_t*)&header, sizeof(header));
}
#endif  /* ENABLE_BINARY */


/*
 *  status = packValues(out_val_ptr, rwrec);
 *
 *    For each value field that is being computed (value_fields[]),
 *    add the values from the current 'rwrec' to the values that are
 *    packed into the byte-array 'out_val_ptr'.  Return 0 on success or
 *    -1 on a memory allocation error.
 */
static int packValues(
    uint8_t        *out_val_ptr,
    const rwRec    *rwrec)
{
    uint64_t val64;
#ifdef HAVE_ALIGNED_ACCESS_REQUIRED
    uint32_t val32;
#else
    uint32_t *pval32;
#endif
    size_t i;

    for (i = 0; i < value_num_fields; ++i) {
        switch ((value_types_t)value_fields[i].vf_id) {
          case VALUE_BYTES:
            VAL_FIELD_MEMGET(out_val_ptr, i, &val64);
            val64 += rwRecGetBytes(rwrec);
            VAL_FIELD_MEMSET(out_val_ptr, i, &val64);
            break;

          case VALUE_PACKETS:
#ifdef HAVE_ALIGNED_ACCESS_REQUIRED
            VAL_FIELD_MEMGET(out_val_ptr, i, &val32);
            val32 += rwRecGetPkts(rwrec);
            VAL_FIELD_MEMSET(out_val_ptr, i, &val32);
#else
            *VAL_FIELD_GET_ADDR32(out_val_ptr, i) += rwRecGetPkts(rwrec);
#endif  /* HAVE_ALIGNED_ACCESS_REQUIRED */
            break;

          case VALUE_FLOWS:
#ifdef HAVE_ALIGNED_ACCESS_REQUIRED
            VAL_FIELD_MEMGET(out_val_ptr, i, &val32);
            ++val32;
            VAL_FIELD_MEMSET(out_val_ptr, i, &val32);
#else
            ++*VAL_FIELD_GET_ADDR32(out_val_ptr, i);
#endif  /* HAVE_ALIGNED_ACCESS_REQUIRED */
            break;

          case VALUE_STIME:
            /* earliest sTime */
#ifdef HAVE_ALIGNED_ACCESS_REQUIRED
            VAL_FIELD_MEMGET(out_val_ptr, i, &val32);
            if ((val32 == 0) || (rwRecGetStartSeconds(rwrec) < val32)) {
                val32 = rwRecGetStartSeconds(rwrec);
                VAL_FIELD_MEMSET(out_val_ptr, i, &val32);
            }
#else
            pval32 = VAL_FIELD_GET_ADDR32(out_val_ptr, i);
            if ((*pval32 == 0) || (rwRecGetStartSeconds(rwrec) < *pval32)) {
                *pval32 = rwRecGetStartSeconds(rwrec);
            }
#endif  /* HAVE_ALIGNED_ACCESS_REQUIRED */
            break;

          case VALUE_ETIME:
            /* latest eTime */
#ifdef HAVE_ALIGNED_ACCESS_REQUIRED
            VAL_FIELD_MEMGET(out_val_ptr, i, &val32);
            if (val32 < rwRecGetEndSeconds(rwrec)) {
                val32 = rwRecGetEndSeconds(rwrec);
                VAL_FIELD_MEMSET(out_val_ptr, i, &val32);
            }
#else
            pval32 = VAL_FIELD_GET_ADDR32(out_val_ptr, i);
            if (*pval32 < rwRecGetEndSeconds(rwrec)) {
                *pval32 = rwRecGetEndSeconds(rwrec);
            }
#endif  /* HAVE_ALIGNED_ACCESS_REQUIRED */
            break;

          case _NUM_VALUES_:
            assert(0);
            abort();
        }
    }

    return 0;
}


/*
 *  unpackValues(out_val, packed_val);
 *
 *    Does reverse of the packValues() subroutine: Unpacks the
 *    'packed_val' values into 'out_val', an array of NUM_VALUES
 *    elements.  Values unpacked depend on the elements of the
 *    value_fields[] array and occur in that order.
 */
static void unpackValues(
    uint64_t        out_val[NUM_VALUES],
    uint8_t        *packed_val)
{
#ifdef HAVE_ALIGNED_ACCESS_REQUIRED
    uint32_t val32;
#endif
    size_t i;

    for (i = 0; i < value_num_fields; ++i) {
        switch ((value_types_t)value_fields[i].vf_id) {
          case VALUE_BYTES:
            VAL_FIELD_MEMGET(packed_val, i, &out_val[i]);
            break;

          case VALUE_PACKETS:
          case VALUE_FLOWS:
          case VALUE_STIME:
          case VALUE_ETIME:
#ifdef HAVE_ALIGNED_ACCESS_REQUIRED
            VAL_FIELD_MEMGET(packed_val, i, &val32);
            out_val[i] = val32;
#else
            out_val[i] = *VAL_FIELD_GET_ADDR32(packed_val, i);
#endif
            break;

          case _NUM_VALUES_:
            assert(0);
            abort();
        }
    }
}


/*
 *  unpackAndAddValues(val, packed_val);
 *
 *    Similar to unpackValues(), except instead of overwriting the
 *    values in the 'val' array, the values in the 'packed_val' byte
 *    array are added to the current value.  Values unpacked depend on
 *    the elements of the value_fields[] array and occur in that
 *    order.
 */
static void unpackAndAddValues(
    uint64_t        val[NUM_VALUES],
    uint8_t        *packed_val)
{
    size_t i;
    uint64_t tmp64;
#ifdef HAVE_ALIGNED_ACCESS_REQUIRED
    uint32_t tmp32;
#endif

    /* add this entry's values */
    for (i = 0; i < value_num_fields; ++i) {
        switch ((value_types_t)value_fields[i].vf_id) {
          case VALUE_BYTES:
            VAL_FIELD_MEMGET(packed_val, i, &tmp64);
            val[i] += tmp64;
            break;

          case VALUE_PACKETS:
          case VALUE_FLOWS:
#ifdef HAVE_ALIGNED_ACCESS_REQUIRED
            VAL_FIELD_MEMGET(packed_val, i, &tmp32);
            val[i] += tmp32;
#else
            val[i] += *VAL_FIELD_GET_ADDR32(packed_val, i);
#endif  /* HAVE_ALIGNED_ACCESS_REQUIRED */
            break;

          case VALUE_STIME:
            /* earliest sTime */
#ifdef HAVE_ALIGNED_ACCESS_REQUIRED
            VAL_FIELD_MEMGET(packed_val, i, &tmp32);
            if (val[i] > tmp32) {
                val[i] = tmp32;
            }
#else
            if (val[i] > *VAL_FIELD_GET_ADDR32(packed_val, i)) {
                val[i] = *VAL_FIELD_GET_ADDR32(packed_val, i);
            }
#endif  /* HAVE_ALIGNED_ACCESS_REQUIRED */
            break;

          case VALUE_ETIME:
            /* latest eTime */
#ifdef HAVE_ALIGNED_ACCESS_REQUIRED
            VAL_FIELD_MEMGET(packed_val, i, &tmp32);
            if (val[i] < tmp32) {
                val[i] = tmp32;
            }
#else
            if (val[i] < *VAL_FIELD_GET_ADDR32(packed_val, i)) {
                val[i] = *VAL_FIELD_GET_ADDR32(packed_val, i);
            }
#endif  /* HAVE_ALIGNED_ACCESS_REQUIRED */
            break;

          case _NUM_VALUES_:
            assert(0);
            abort();
        }
    }
}


/*
 *  status = fillRecordAndKey(rec, key);
 *
 *    Fills in 'rec' with a flow read from the input.  Processes stdin
 *    or the files listed on the command line.  Computes the key based
 *    on the key_fields[] settings and fills in the parameter 'key'
 *    with that value.
 */
static int fillRecordAndKey(rwRec *rwrec, uint8_t *key)
{
    static int ctr = -1;
    static rwIOStruct_t *rwIOS = NULL;
    size_t i;

    while (ctr < uniq_io.ISP->fileCount) {
        if (rwIOS) {
            /* get next record */
            if (rwRead(rwIOS, rwrec)) {
                /* create the key */
                for (i = 0; i < key_num_fields; ++i) {
                    if (key_fields[i].kf_fxn) {
                        key_fields[i].kf_fxn(key_fields[i].kf_fxn_id,
                                             key+key_fields[i].kf_offset,
                                             NULL, 0, rwrec);
                    } else {
                        key_fields[i].kf_fxn_r2k(rwrec,
                                                 key+key_fields[i].kf_offset);
                    }
                }

                /* Unless we are running with presorted input, add the
                 * distinct fields to the key. */
                if (distinct_num_fields && !uniq_flags.presorted_input) {
                    for (i = 0; i < distinct_num_fields; ++i) {
                        distinct_fields[i]
                            .df_r2k(rwrec, (key+distinct_fields[i].df_offset));
                    }
                }

                ++g_record_count;
                return 1;
            }

            /* rwRead failed; close file */
            rwioDestroy(&rwIOS);
        }

        /* goto next file */
        if (ctr == -1) {
            ctr = uniq_io.ISP->firstFile;
        } else {
            ++ctr;
        }
        if (ctr < uniq_io.ISP->fileCount) {
            /* open the file */
            rwIOS = rwOpenFile(uniq_io.ISP->fnArray[ctr],
                               uniq_io.ISP->inputCopyFD);
            if (!rwIOS) {
                /* rwOpenFile prints error */
                ctr = uniq_io.ISP->fileCount;
                break;
            }

            /* print its name */
            if (uniq_flags.print_filenames) {
                fprintf(PRINT_FILENAMES_FH, "%s\n", rwGetFileName(rwIOS));
            }

            /* set IPv6 policy */
            skStreamSetIPv6Policy(rwIOS, ipv6_policy);
        }
    }

    /* out of files */
    return 0;
}


/*
 *  status = printTableSimple(hash_table);
 *
 *    Just print the key/value pairs from the hash table.  There are
 *    no distinct values to keep track of.
 */
static int printTableSimple(HashTable *ht)
{
    HASH_ITER it;
    uint8_t *key_ptr;
    uint8_t *val_ptr;
    uint64_t values[NUM_VALUES];
    uint64_t distincts[NUM_DISTINCTS];

    /* We can do simple iteration through the hash table */

    /* create the iterator */
    it = hashlib_create_iterator(ht);

    while (hashlib_iterate(ht, &it, &key_ptr, &val_ptr) != ERR_NOMOREENTRIES) {
        unpackValues(values, val_ptr);
        writeAsciiRecord(key_ptr, values, distincts);
    }
    return 0;
}


/*
 *  status = printTableSingleDistinct(hash_table, key_array);
 *
 *    Print the entries from the hash table when one distinct field
 *    was requested.  Part of each entry's key is the column we are
 *    computing the 'distinct' count of.  The 'key_array' parameter is
 *    a byte array to use for scratch space.  It is big enough to hold
 *    an entry's key.
 */
static int printTableSingleDistinct(
    HashTable  *ht,
    uint8_t    *key_array)
{
    HASH_ITER it;
    uint8_t *key_ptr;
    uint8_t *val_ptr;
    uint64_t values[NUM_VALUES];
    uint64_t distincts[NUM_DISTINCTS];

    /* Sort the entries then iterate through the hash table,
     * watching for the key (minus the distinct column) to
     * change. */
    hashlib_sort_entries(ht);

    /* create the iterator */
    it = hashlib_create_iterator(ht);

    /* get first key/value from hash table */
    if (hashlib_iterate(ht, &it, &key_ptr, &val_ptr) == ERR_NOMOREENTRIES) {
        /* no data.  done. */
        return 0;
    }

    /* cache the key */
    memcpy(key_array, key_ptr, key_byte_width);

    /* unpack the values */
    unpackValues(values, val_ptr);

    /* set the distincts */
    distincts[0] = 1;

    /* process the remaining hash entries */
    while (hashlib_iterate(ht, &it, &key_ptr, &val_ptr) != ERR_NOMOREENTRIES) {
        /* compare keys */
        if (0 != memcmp(key_array, key_ptr, key_byte_width)) {
            /* keys differ, print the old key and the values */
            writeAsciiRecord(key_array, values, distincts);

            /* remember the key and reset values and distincts */
            memcpy(key_array, key_ptr, key_byte_width);
            unpackValues(values, val_ptr);
            distincts[0] = 1;
        } else {
            /* add current 'val_ptr' to the 'values' array */
            unpackAndAddValues(values, val_ptr);
            ++distincts[0];
        }
    }

    /* print final entry */
    writeAsciiRecord(key_array, values, distincts);

    return 0;
}


/*
 *  status = printTableMultipleDistinct(hash_table, key_array);
 *
 *    Print the entries from the hash table when multiple distinct
 *    fields were requested.  Part of each entry's key are the columns
 *    we are computing the 'distinct' count of.  The 'key_array'
 *    parameter is a byte array to use for scratch space.  It is big
 *    enough to hold an entry's key.
 */
static int printTableMultipleDistinct(
    HashTable  *ht,
    uint8_t    *key_array)
{
    HASH_ITER it;
    uint8_t *key_ptr;
    uint8_t *val_ptr;
    uint64_t values[NUM_VALUES];
    uint64_t distincts[NUM_DISTINCTS];
    skIPTree_t *ipset = NULL;
    uint32_t ipaddr;
#ifdef HAVE_ALIGNED_ACCESS_REQUIRED
    uint32_t tmp32;
#endif

    /* multiple distinct columns.  sort the hash entries.  the first
     * distinct column we get for "free" by watching the values go by.
     * for the other columns, we must maintain a list of values we
     * have seen. */

    hashlib_sort_entries(ht);

    /* create the iterator */
    it = hashlib_create_iterator(ht);

    /* create an IPset for keeping track of values we see */
    if (skIPTreeCreate(&ipset)) {
        skAppPrintErr("Unable to create IPset");
        exit(EXIT_FAILURE);
    }

    /* get first key/value from hash table */
    if (hashlib_iterate(ht, &it, &key_ptr, &val_ptr) == ERR_NOMOREENTRIES) {
        return 0;
    }

    /* cache the key */
    memcpy(key_array, key_ptr, key_byte_width);

    /* unpack the values */
    unpackValues(values, val_ptr);

    /* cache the first distinct value---which we know is an IP
     * address---and begin list of other values */
    distincts[0] = 1;
#ifdef HAVE_ALIGNED_ACCESS_REQUIRED
    memcpy(&ipaddr, key_ptr + distinct_fields[0].df_offset,
           distinct_fields[0].df_byte_width);
    memcpy(&tmp32, key_ptr + distinct_fields[1].df_offset,
           distinct_fields[1].df_byte_width);
    skIPTreeAddAddress(ipset, tmp32);
#else
    ipaddr = *(uint32_t*)(key_ptr + distinct_fields[0].df_offset);
    skIPTreeAddAddress(ipset,
                       *(uint32_t*)(key_ptr+distinct_fields[1].df_offset));
#endif  /* HAVE_ALIGNED_ACCESS_REQUIRED */

    /* process the remaining hash entries */
    while (hashlib_iterate(ht, &it, &key_ptr, &val_ptr) != ERR_NOMOREENTRIES) {
        /* compare keys */
        if (0 != memcmp(key_array, key_ptr, key_byte_width)) {
            /* keys differ, print the old key and the values */
            distincts[1] = skIPTreeCountIPs(ipset);
            writeAsciiRecord(key_array, values, distincts);

            /* remember the key, set values, store distincts */
            memcpy(key_array, key_ptr, key_byte_width);
            unpackValues(values, val_ptr);
            distincts[0] = 1;
            skIPTreeRemoveAll(ipset);
#ifdef HAVE_ALIGNED_ACCESS_REQUIRED
            memcpy(&ipaddr, key_ptr + distinct_fields[0].df_offset,
                   distinct_fields[0].df_byte_width);
            memcpy(&tmp32, key_ptr + distinct_fields[1].df_offset,
                   distinct_fields[1].df_byte_width);
            skIPTreeAddAddress(ipset, tmp32);
#else
            ipaddr = *(uint32_t*)(key_ptr + distinct_fields[0].df_offset);
            skIPTreeAddAddress(ipset,
                               *(uint32_t*)(key_ptr +
                                            distinct_fields[1].df_offset));
#endif  /* HAVE_ALIGNED_ACCESS_REQUIRED */
        } else {
            /* add current 'val_ptr' to the 'values' array */
            unpackAndAddValues(values, val_ptr);

            /* handle the distinct fields */
#ifdef HAVE_ALIGNED_ACCESS_REQUIRED
            memcpy(&tmp32, key_ptr + distinct_fields[0].df_offset,
                   distinct_fields[0].df_byte_width);
            if (ipaddr != tmp32) {
                ++distincts[0];
                ipaddr = tmp32;
            }
            memcpy(&tmp32, key_ptr + distinct_fields[1].df_offset,
                   distinct_fields[1].df_byte_width);
            skIPTreeAddAddress(ipset, tmp32);
#else
            if (ipaddr
                != *(uint32_t*)(key_ptr + distinct_fields[0].df_offset))
            {
                ++distincts[0];
                ipaddr = *(uint32_t*)(key_ptr
                                      + distinct_fields[0].df_offset);
            }
            skIPTreeAddAddress(ipset,
                               *(uint32_t*)(key_ptr
                                            +distinct_fields[1].df_offset));
#endif  /* HAVE_ALIGNED_ACCESS_REQUIRED */
        }
    }

    /* print final entry */
    distincts[1] = skIPTreeCountIPs(ipset);
    writeAsciiRecord(key_array, values, distincts);

    if (ipset) {
        skIPTreeDelete(&ipset);
    }
    return 0;
}


/*
 *  uniqmain_hash();
 *
 *    Main control function that creates a hash table, processes the
 *    input (files or stdin), and prints the results.
 */
static int uniqmain_hash(void)
{
    /* hash table to count tuples */
    static HashTable *ht;
    uint8_t *no_val_ptr;
    uint8_t *key_array = NULL;
    uint8_t *val_ptr;
    uint8_t *key_ptr;
    int rv = 0;
    rwRec rwrec;
    size_t hash_value_bytes = (value_byte_width > 0) ? value_byte_width : 1;

    /* allocate the memory for the key */
    key_array = calloc((key_byte_width + distinct_byte_width),sizeof(uint8_t));
    if (!key_array) {
        skAppPrintErr("Unable to allocate key");
        exit(EXIT_FAILURE);
    }
    key_ptr = key_array;

    /* Create the value that the hash table uses to indicate a key
     * without a value */
    no_val_ptr = (uint8_t *)malloc(hash_value_bytes);
    if (!no_val_ptr) {
        skAppPrintErr("Unable to allocate no-value default");
        exit(EXIT_FAILURE);
    }
    memset(no_val_ptr, 0xFF, hash_value_bytes);

    /* Create the hash table */
    ht = hashlib_create_table((key_byte_width + distinct_byte_width),
                              hash_value_bytes,
                              HTT_INPLACE,
                              no_val_ptr,
                              NULL,
                              0,
                              HASH_INITIAL_SIZE,
                              DEFAULT_LOAD_FACTOR);
    if (NULL == ht) {
        skAppPrintErr("Unable to create hash table");
        rv = 1;
        goto END;
    }

    /* Fill in the record and specified key */
    while (fillRecordAndKey(&rwrec, key_ptr)) {

        /* the 'insert' will set 'val_ptr' to the memory to use to
         * store the values. either fresh memory or the existing
         * value(s). */
        rv = hashlib_insert(ht, key_ptr, &val_ptr);
        switch (rv) {
          case OK:
            /* new value; clear the memory */
            memset(val_ptr, 0, hash_value_bytes);
            /* FALLTHROUGH */

          case OK_DUPLICATE:
            /* existing value; add new value */
            packValues(val_ptr, &rwrec);
            break;

          case ERR_OUTOFMEMORY:
          case ERR_NOMOREBLOCKS:
            /* out of memory */
            --g_record_count;
            rv = RWUNIQ_NO_MEMORY_EXIT_CODE;
            goto GENERATE_OUTPUT;

          default:
            skAppPrintErr(("Unexpected return code '%d'"
                           " from hash table insert"),
                          rv);
            exit(EXIT_FAILURE);
        }
    }

    rv = 0;

  GENERATE_OUTPUT:
    if (rv == RWUNIQ_NO_MEMORY_EXIT_CODE) {
        skAppPrintErr(("Out of memory after processing %" PRIu64 " records for"
                       " %u unique entries.  Printing partial results"),
                      g_record_count, hashlib_count_entries(ht));
    }

    /* Generate output */
#ifdef  ENABLE_BINARY
    if (uniq_flags.binary_output) {
        writeBinary(uniq_io.outF, ht);
        goto END;
    }
#endif

    /* Write out the headings */
    writeColTitles();

    if (distinct_num_fields == 0) {
        printTableSimple(ht);
    } else if (distinct_num_fields == 1) {
        printTableSingleDistinct(ht, key_array);
    } else {
        printTableMultipleDistinct(ht, key_array);
    }

  END:
    if (ht) {
        hashlib_free_table(ht);
    }
    free(no_val_ptr);
    free(key_array);

    return rv;
}


/*
 *  uniqmain_presorted();
 *
 *    Main control function that reads presorted flow records from
 *    files or stdin and prints the results.
 */
static int uniqmain_presorted(void)
{
    uint64_t values[NUM_VALUES];
    uint64_t distincts[NUM_DISTINCTS];
    uint8_t *key = NULL;
    uint8_t *old_key = NULL;
    rwRec rwrec;
    size_t i;
    int rv = 0;
    size_t sip_pos = NUM_DISTINCTS;
    size_t dip_pos = NUM_DISTINCTS;
    skIPTree_t *sip_set = NULL;
    skIPTree_t *dip_set = NULL;

    /* figure out whether DISTINCT_SIP and/or DISTINCT_DIP were specified;
     * if so, determine their index in the distinct_fields array and
     * create IPsets for them. */
    for (i = 0; i < distinct_num_fields; ++i) {
        switch ((distinct_types_t)distinct_fields[i].df_id) {
          case DISTINCT_SIP:
            sip_pos = i;
            if (skIPTreeCreate(&sip_set)) {
                skAppPrintErr("Unable to create IPset");
                exit(EXIT_FAILURE);
            }
            break;

          case DISTINCT_DIP:
            dip_pos = i;
            if (skIPTreeCreate(&dip_set)) {
                skAppPrintErr("Unable to create IPset");
                exit(EXIT_FAILURE);
            }
            break;

          default:
            break;
        }
    }

    /* create two keys, current and old */
    key = calloc(key_byte_width, sizeof(uint8_t));
    if (!key) {
        skAppPrintErr("Unable to allocate key");
        exit(EXIT_FAILURE);
    }
    old_key = calloc(key_byte_width, sizeof(uint8_t));
    if (!old_key) {
        skAppPrintErr("Unable to allocate key");
        exit(EXIT_FAILURE);
    }

    /* Write out the headings */
    writeColTitles();

    /* Fill in the record and specified key */
    while (fillRecordAndKey(&rwrec, key)) {
        /* compare keys unless this is the first entry */
        if (g_record_count == 1) {
            /* remember the key and initialize values */
            memcpy(old_key, key, key_byte_width);
            memset(values, 0, sizeof(values));
            memset(distincts, 0, sizeof(distincts));
        } else if (0 != memcmp(key, old_key, key_byte_width)) {
            if (sip_set) {
                distincts[sip_pos] = skIPTreeCountIPs(sip_set);
            }
            if (dip_set) {
                distincts[dip_pos] = skIPTreeCountIPs(dip_set);
            }
            writeAsciiRecord(old_key, values, distincts);

            /* remember the key and reset values */
            memcpy(old_key, key, key_byte_width);
            memset(values, 0, sizeof(values));
            memset(distincts, 0, sizeof(distincts));
            if (sip_set) {
                skIPTreeRemoveAll(sip_set);
            }
            if (dip_set) {
                skIPTreeRemoveAll(dip_set);
            }
        }

        /* add this entry's values */
        for (i = 0; i < value_num_fields; ++i) {
            switch ((value_types_t)value_fields[i].vf_id) {
              case VALUE_BYTES:
                values[i] += rwRecGetBytes(&rwrec);
                break;

              case VALUE_PACKETS:
                values[i] += rwRecGetPkts(&rwrec);
                break;

              case VALUE_FLOWS:
                ++values[i];
                break;

              case VALUE_STIME:
                /* earliest sTime */
                if ((values[i] == 0)
                    || (rwRecGetStartSeconds(&rwrec) < values[i]))
                {
                    values[i] = rwRecGetStartSeconds(&rwrec);
                }
                break;

              case VALUE_ETIME:
                /* latest eTime */
                if (values[i] < rwRecGetEndSeconds(&rwrec)) {
                    values[i] = rwRecGetEndSeconds(&rwrec);
                }
                break;

              case _NUM_VALUES_:
                assert(0);
                abort();
            }
        }

#if SK_ENABLE_IPV6
        if (rwRecIsIPv6(&rwrec)) {
            /* no-op */
        } else
#endif /* SK_ENABLE_IPV6 */
        {
            for (i = 0; i < distinct_num_fields; ++i) {
                switch ((distinct_types_t)distinct_fields[i].df_id) {
                  case DISTINCT_SIP:
                    /* unique source ips */
                    skIPTreeAddAddress(sip_set, rwRecGetSIPv4(&rwrec));
                    break;

                  case DISTINCT_DIP:
                    /* unique destination ips */
                    skIPTreeAddAddress(dip_set, rwRecGetDIPv4(&rwrec));
                    break;

                  case _NUM_DISTINCTS_:
                    assert(0);
                    abort();
                }
            }
        }
    }

    /* print final entry */
    if (g_record_count > 0) {
        if (sip_set) {
            distincts[sip_pos] = skIPTreeCountIPs(sip_set);
        }
        if (dip_set) {
            distincts[dip_pos] = skIPTreeCountIPs(dip_set);
        }
        writeAsciiRecord(key, values, distincts);
    }

    /* cleanup */
    if (key) {
        free(key);
    }
    if (old_key) {
        free(old_key);
    }
    if (sip_set) {
        skIPTreeDelete(&sip_set);
    }
    if (dip_set) {
        skIPTreeDelete(&dip_set);
    }

    return rv;
}


int main(int argc, char **argv)
{
    int rv;

    /* Global setup */
    appSetup(argc, argv);

    if (uniq_flags.presorted_input) {
        rv = uniqmain_presorted();
    } else {
        rv = uniqmain_hash();
    }

    /* Done, do cleanup */
    appTeardown();

    return rv;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
