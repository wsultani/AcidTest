/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/
#ifndef _RWUNIQ_H
#define _RWUNIQ_H

/*
**  rwuniq.h
**
**  Common declarations for the rwuniq application.  See rwuniq.c for
**  an explanation.
*/


#include "silk.h"

RCSIDENTVAR(rcsID_RWUNIQ_H, "$SiLK: rwuniq.h 10238 2008-01-21 19:41:09Z mthomas $");

#include "utils.h"
#include "rwpack.h"
#include "iochecks.h"
#include "hashlib.h"
#include "iptree.h"
#include "dynlib.h"


/* TYPEDEFS AND DEFINES */

/* For the compound key version of rwuniq, the maximum number of bytes
 * we allow in the key.  An arbitary number that should be big enough
 * for almost all cases. */
#define MAX_KEY_BYTE_WIDTH 256

/* For ASCII output, maximum size of a single value column. Must be
 * big enough to hold printed uint64_t, sktimestamp(), class, type,
 * sensor, or arbitrary pmap value. */
#define VALUE_OUT_BUF_SIZE  256

/* Value to use as exit code when we run out of memory */
#define RWUNIQ_NO_MEMORY_EXIT_CODE 16

/* default sTime bin size to use when --bin-time is requested */
#define DEFAULT_TIME_BIN  60
#define DEFAULT_TIME_BIN_STR  "60"


/* function that plugins must supply */
typedef int (*uniqf_t)(
    unsigned int    id,
    uint8_t        *bin_value,
    char           *text_value,
    size_t          text_len,
    rwRec          *rwrec);

/* function that gets the local part of the key from an rwrec */
typedef void (*rec2key_fn_t)(const rwRec *rec, void *key_pos);

/* function that puts the key into the rwrec */
typedef void (*key2rec_fn_t)(rwRec *rec, const void *key_pos);

/* struct to hold the columns/fields that make up our key for this run */
typedef struct key_field_st {
    /* the id of the column (from librw) that make up this key_field */
    uint32_t        kf_id;
    /* the byte-offset for this field */
    size_t          kf_offset;
    /* the byte-width of this field */
    size_t          kf_width;
    /* function to call to fill in the key from the rec.  used when
     * kf_fxn is NULL. */
    rec2key_fn_t    kf_fxn_r2k;
    /* function to call to fill in the rec from the key.  will be used
     * if set, regardless of kf_fxn. */
    key2rec_fn_t    kf_fxn_k2r;
    /* the function to call to fill in this field.  When this is set,
     * it is used to convert a member of an rwRec into a binary value,
     * regardless of whether kf_addr is non-null. */
    uniqf_t         kf_fxn;
    /* the field_id that must be passed to kf_fxn for this field */
    unsigned int    kf_fxn_id;
    /* a buffer to hold the textual value for this field */
    char            kf_textbuf[VALUE_OUT_BUF_SIZE];
    /* width of above for columnar output */
    int             kf_text_len;
} key_field_t;

/*
 *  Possible value fields to count w.r.t. the uniq key.  Keep this in
 *  sync with the value_fields[] array, and with the OPT_COUNT_*
 *  values in appOptionsEnum.
 */
typedef enum {
    VALUE_BYTES = 0,
    VALUE_PACKETS,
    VALUE_FLOWS,
    VALUE_STIME,
    VALUE_ETIME,
    _NUM_VALUES_ /* must be last item */
} value_types_t;

/* The number of types; should be equal to _NUM_VALUES_ */
#define NUM_VALUES 5

/* struct to hold information about potential value fields */
typedef struct value_field_st {
    /* the title of this field */
    const char     *vf_title;
    /* the user's parameter to this field (if any) */
    const char     *vf_user_param;
    /* only print sums if the minimum value is at least this value */
    uint64_t        vf_min;
    /* only print sums if the maximum value is no more than this value */
    uint64_t        vf_max;
    /* the byte-width of this field */
    size_t          vf_byte_width;
    /* the byte-offset for each value field */
    size_t          vf_offset;
    /* the text width of the field for columnar output */
    int             vf_text_len;
    /* Packing order: The various values are packed into a single byte
     * array, and we dereference elements of this array directly.
     * Pack things from biggest to smallest avoid mis-alignment
     * issues: Put bytes (64bit) first, and put pointer values between
     * the 64bit and 32bit values. */
    uint8_t         vf_pack_order;
    /* the id for this column */
    value_types_t   vf_id;
    /* whether this column is used for --all-counts, 1==yes */
    unsigned        vf_include_in_all :1;
    /* whether the user requested this field */
    unsigned        vf_iscounted :1;
} value_field_t;


typedef enum {
    DISTINCT_SIP = 0,
    DISTINCT_DIP,
    _NUM_DISTINCTS_ /* must be last item */
} distinct_types_t;

/* The number of types; should be equal to _NUM_DISTINCTS_ */
#define NUM_DISTINCTS 2

/* struct to hold information about distinct fields */
typedef struct distinct_field_st {
    /* the title of this field */
    const char         *df_title;
    /* the user's parameter to this field (if any) */
    const char         *df_user_param;
    /* only print if the count is at least this value */
    uint64_t            df_min;
    /* only print if the count is no more than this value */
    uint64_t            df_max;
    /* function to call to pack this field into key */
    rec2key_fn_t        df_r2k;
    /* the byte-width of this field */
    size_t              df_byte_width;
    /* the byte-offset for each distinct field in the key */
    size_t              df_offset;
    /* the text width of the field for columnar output */
    int                 df_text_len;
    /* the id for this column */
    distinct_types_t    df_id;
    /* whether the user requested this field */
    unsigned            df_iscounted :1;
} distinct_field_t;

/* Structure describing the output functions for printing the
 * key. Fields that are part of the standard rwrec are printed with an
 * rwAsciiStream_t; those that come from a plug-in must be determined
 * by calling the plug-in's uniq() function, which the key_field_t has
 * a reference to. */
typedef struct out_stream_st {
    /* Call rwAsciiPrintRec() with this stream as first arg */
    rwAsciiStream_t *a_stream;
    /* Use the buffer from this key-field */
    key_field_t     *k_field;
} out_stream_t;

/* group input/output variables into a single struct */
typedef struct uniq_io_st {
    FILE                 *outF;
    const char           *outFPath;
    int                   outIsPipe;
    iochecksInfoStruct_t *ISP;
} uniq_io_t;

/* flags set by user options */
typedef struct uniq_flags_st {
    unsigned binary_output      :1;      /* Default to ascii */
    unsigned presorted_input    :1;      /* Assume input is sorted */
    unsigned print_filenames    :1;
    unsigned no_columns         :1;
    unsigned no_titles          :1;
    unsigned no_final_delimiter :1;
    unsigned integer_sensors    :1;
    unsigned integer_ips        :1;
    unsigned zero_pad_ips       :1;
} uniq_flags_t;


/* VARIABLE DECLARATIONSS */

/* delimiter between output columns */
extern char g_delimiter;

/* the columns/fields that make up our key for this run */
extern key_field_t *key_fields;

/* the number of actual columns/fields that make up the key */
extern size_t key_num_fields;

/* the total byte count of the key */
extern size_t key_byte_width;

/* Information about each potential value field. */
extern value_field_t value_fields[NUM_VALUES];

/* number of value fields the user has requested */
extern size_t value_num_fields;

/* total byte count for all value_fields that are being computed */
extern size_t value_byte_width;

/* Information about each distinct field. */
extern distinct_field_t distinct_fields[NUM_DISTINCTS];

/* number of distinct fields the user has requested */
extern size_t distinct_num_fields;

/* total byte count for all distinct_fields that are being computed */
extern size_t distinct_byte_width;

/* Array of out_stream_t* that make up the real output */
extern out_stream_t **outputs;

/* Count of 'outputs' */
extern size_t output_count;

/* the real output */
extern uniq_io_t uniq_io;

/* flags set by the user options */
extern uniq_flags_t uniq_flags;

/* how to print timestamps */
extern uint32_t time_flags;

/* how to handle IPv6 flows */
extern sk_ipv6policy_t ipv6_policy;


/* FUNCTION DECLARATIONS */

void appSetup(int argc, char **argv);
void appTeardown(void);


#endif /* _RWUNIQ_H */

/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
