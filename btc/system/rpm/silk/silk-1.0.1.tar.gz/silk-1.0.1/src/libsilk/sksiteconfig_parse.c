/* A Bison parser, made by GNU Bison 1.875.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TOK_NL = 258,
     TOK_ATOM = 259,
     TOK_INTEGER = 260,
     TOK_STRING = 261,
     TOK_CLASS = 262,
     TOK_DEF_CLASS = 263,
     TOK_DEF_TYPES = 264,
     TOK_END_CLASS = 265,
     TOK_END_GROUP = 266,
     TOK_GROUP = 267,
     TOK_INCLUDE = 268,
     TOK_PATH_FORMAT = 269,
     TOK_PACKING_LOGIC = 270,
     TOK_SENSOR = 271,
     TOK_SENSORS = 272,
     TOK_TYPE = 273,
     TOK_VERSION = 274,
     ERR_UNK_CMD = 275,
     ERR_UNREC = 276,
     ERR_UNTERM_STRING = 277,
     ERR_STR_TOO_LONG = 278,
     ERR_INVALID_OCTAL_ESCAPE = 279
   };
#endif
#define TOK_NL 258
#define TOK_ATOM 259
#define TOK_INTEGER 260
#define TOK_STRING 261
#define TOK_CLASS 262
#define TOK_DEF_CLASS 263
#define TOK_DEF_TYPES 264
#define TOK_END_CLASS 265
#define TOK_END_GROUP 266
#define TOK_GROUP 267
#define TOK_INCLUDE 268
#define TOK_PATH_FORMAT 269
#define TOK_PACKING_LOGIC 270
#define TOK_SENSOR 271
#define TOK_SENSORS 272
#define TOK_TYPE 273
#define TOK_VERSION 274
#define ERR_UNK_CMD 275
#define ERR_UNREC 276
#define ERR_UNTERM_STRING 277
#define ERR_STR_TOO_LONG 278
#define ERR_INVALID_OCTAL_ESCAPE 279




/* Copy the first part of user declarations.  */
#line 1 "sksiteconfig_parse.y"

/*
** Copyright (C) 2006-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  Parser for silk toolset configuration file
**
*/

#include "silk.h"

RCSIDENT("$SiLK: sksiteconfig_parse.y 10720 2008-02-29 20:38:41Z mthomas $");

#include "sksiteconfig.h"
#include "sksite.h"


/* EXPORTED VARIABLES */

/* set to 1 to use the test handlers, which output what they think they're
 * seeing, for testing purposes. */
int sksiteconfig_testing = 0;


/* LOCAL VARIABLES */

/* current group or class being filled in--only one should be non-NULL
 * at a time. */
static char *current_group = NULL;
static sensorgroupID_t current_group_id = SK_INVALID_SENSORGROUP;
static char *current_class = NULL;
static classID_t current_class_id = SK_INVALID_CLASS;


/* LOCAL FUNCTION PROTOTYPES */

/* Handle config file version */
static void do_version(char *str);

/* Define sensor */
static void do_sensor(int id, char *name);

/* Define path-format */
static void do_path_format(char *fmt);

/* Define packing-logic */
static void do_packing_logic(char *fmt);

/* Include a file */
static void do_include(char *filename);

/* Begin defining a group */
static void do_group(char *groupname);

/* Add sensors to a group definition */
static void do_group_sensors(sk_vector_t *sensors);

/* Finish defining a group */
static void do_end_group(void);

/* Begin defining a class */
static void do_class(char *classname);

/* Add sensors to a class definition */
static void do_class_sensors(sk_vector_t *sensors);

/* Define type within a class definition */
static void do_class_type(int id, char *name, char *prefix);

/* Define the default types for a class */
static void do_class_default_types(sk_vector_t *types);

/* Finish defining a class */
static void do_end_class(void);

/* Set the default class */
static void do_default_class(char *classname);

/* Report an error while parsing (printf style) */
#define do_err sksiteconfigErr

/* Report a context error, like trying to define a sensor in a class */
static void do_err_ctx(const char *ctx, const char *cmd);

/* Report an argument error: too many, too few, or the wrong args */
static void do_err_args(const char *cmd);

/* Report an argument error: shouldn't be any arguments */
static void do_err_args_none(const char *cmd);




/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 143 "sksiteconfig_parse.y"
typedef union YYSTYPE {
    int integer;
    char *str;
    sk_vector_t *str_list;
} YYSTYPE;
/* Line 186 of yacc.c.  */
#line 271 "sksiteconfig_parse.c"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 214 of yacc.c.  */
#line 283 "sksiteconfig_parse.c"

#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# if YYSTACK_USE_ALLOCA
#  define YYSTACK_ALLOC alloca
# else
#  ifndef YYSTACK_USE_ALLOCA
#   if defined (alloca) || defined (_ALLOCA_H)
#    define YYSTACK_ALLOC alloca
#   else
#    ifdef __GNUC__
#     define YYSTACK_ALLOC __builtin_alloca
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  2
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   206

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  25
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  29
/* YYNRULES -- Number of rules. */
#define YYNRULES  90
/* YYNRULES -- Number of states. */
#define YYNSTATES  192

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   279

#define YYTRANSLATE(YYX) 						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short yyprhs[] =
{
       0,     0,     3,     4,     7,    10,    14,    18,    19,    22,
      25,    29,    33,    34,    37,    40,    42,    44,    46,    48,
      50,    52,    54,    56,    58,    60,    62,    64,    66,    68,
      70,    74,    78,    82,    86,    90,    94,    98,   102,   106,
     110,   114,   118,   122,   126,   130,   134,   138,   142,   146,
     150,   154,   158,   162,   166,   170,   174,   178,   182,   186,
     190,   194,   198,   202,   206,   210,   214,   218,   222,   227,
     231,   235,   239,   243,   247,   250,   254,   258,   262,   266,
     270,   275,   281,   285,   288,   292,   294,   296,   298,   300,
     301
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const yysigned_char yyrhs[] =
{
      26,     0,    -1,    -1,    26,     3,    -1,    26,    31,    -1,
      37,    28,    50,    -1,     7,     1,     3,    -1,    -1,    28,
       3,    -1,    28,    32,    -1,    39,    30,    46,    -1,    12,
       1,     3,    -1,    -1,    30,     3,    -1,    30,    33,    -1,
      27,    -1,    38,    -1,    29,    -1,    40,    -1,    41,    -1,
      42,    -1,    43,    -1,    44,    -1,    34,    -1,    47,    -1,
      48,    -1,    49,    -1,    36,    -1,    45,    -1,    35,    -1,
      10,     1,     3,    -1,    11,     1,     3,    -1,    17,     1,
       3,    -1,    18,     1,     3,    -1,    20,     1,     3,    -1,
      21,     1,     3,    -1,     7,     1,     3,    -1,     8,     1,
       3,    -1,    10,     1,     3,    -1,    12,     1,     3,    -1,
      13,     1,     3,    -1,    14,     1,     3,    -1,    15,     1,
       3,    -1,    16,     1,     3,    -1,    18,     1,     3,    -1,
      19,     1,     3,    -1,    20,     1,     3,    -1,    21,     1,
       3,    -1,     7,     1,     3,    -1,     8,     1,     3,    -1,
      11,     1,     3,    -1,    12,     1,     3,    -1,    13,     1,
       3,    -1,    14,     1,     3,    -1,    15,     1,     3,    -1,
      16,     1,     3,    -1,    19,     1,     3,    -1,    20,     1,
       3,    -1,    21,     1,     3,    -1,     7,    52,     3,    -1,
       8,    52,     3,    -1,    12,    52,     3,    -1,    13,    52,
       3,    -1,    13,     1,     3,    -1,    14,    52,     3,    -1,
      14,     1,     3,    -1,    15,    52,     3,    -1,    15,     1,
       3,    -1,    16,    51,    52,     3,    -1,    16,     1,     3,
      -1,    19,    52,     3,    -1,    19,     1,     3,    -1,    17,
      53,     3,    -1,    17,     1,     3,    -1,    11,     3,    -1,
      11,     1,     3,    -1,     9,    53,     3,    -1,     9,     1,
       3,    -1,    17,    53,     3,    -1,    17,     1,     3,    -1,
      18,    51,    52,     3,    -1,    18,    51,    52,    52,     3,
      -1,    18,     1,     3,    -1,    10,     3,    -1,    10,     1,
       3,    -1,     5,    -1,     4,    -1,     6,    -1,     5,    -1,
      -1,    53,    52,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short yyrline[] =
{
       0,   171,   171,   173,   174,   178,   179,   182,   184,   185,
     189,   190,   193,   195,   196,   202,   203,   204,   205,   206,
     207,   208,   209,   210,   214,   215,   216,   217,   221,   222,
     228,   229,   230,   231,   232,   234,   238,   239,   240,   241,
     242,   243,   244,   245,   246,   247,   248,   250,   254,   255,
     256,   257,   258,   259,   260,   261,   262,   263,   264,   268,
     274,   278,   284,   285,   289,   290,   294,   295,   299,   300,
     304,   305,   309,   310,   314,   315,   319,   320,   324,   325,
     329,   330,   331,   335,   336,   341,   347,   348,   349,   353,
     354
};
#endif

#if YYDEBUG || YYERROR_VERBOSE
/* YYTNME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "TOK_NL", "TOK_ATOM", "TOK_INTEGER", 
  "TOK_STRING", "TOK_CLASS", "TOK_DEF_CLASS", "TOK_DEF_TYPES", 
  "TOK_END_CLASS", "TOK_END_GROUP", "TOK_GROUP", "TOK_INCLUDE", 
  "TOK_PATH_FORMAT", "TOK_PACKING_LOGIC", "TOK_SENSOR", "TOK_SENSORS", 
  "TOK_TYPE", "TOK_VERSION", "ERR_UNK_CMD", "ERR_UNREC", 
  "ERR_UNTERM_STRING", "ERR_STR_TOO_LONG", "ERR_INVALID_OCTAL_ESCAPE", 
  "$accept", "top_cmd_list", "block_class", "class_cmd_list", 
  "block_group", "group_cmd_list", "top_cmd", "class_cmd", "group_cmd", 
  "err_top", "err_grp", "err_cls", "cmd_class", "cmd_default_class", 
  "cmd_group", "cmd_include", "cmd_path_format", "cmd_packing_logic", 
  "cmd_sensor", "cmd_version", "cmd_group_sensors", "cmd_end_group", 
  "cmd_class_default_types", "cmd_class_sensors", "cmd_class_type", 
  "cmd_end_class", "int", "str", "str_list", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned char yyr1[] =
{
       0,    25,    26,    26,    26,    27,    27,    28,    28,    28,
      29,    29,    30,    30,    30,    31,    31,    31,    31,    31,
      31,    31,    31,    31,    32,    32,    32,    32,    33,    33,
      34,    34,    34,    34,    34,    34,    35,    35,    35,    35,
      35,    35,    35,    35,    35,    35,    35,    35,    36,    36,
      36,    36,    36,    36,    36,    36,    36,    36,    36,    37,
      38,    39,    40,    40,    41,    41,    42,    42,    43,    43,
      44,    44,    45,    45,    46,    46,    47,    47,    48,    48,
      49,    49,    49,    50,    50,    51,    52,    52,    52,    53,
      53
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     0,     2,     2,     3,     3,     0,     2,     2,
       3,     3,     0,     2,     2,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     4,     3,
       3,     3,     3,     3,     2,     3,     3,     3,     3,     3,
       4,     5,     3,     2,     3,     1,     1,     1,     1,     0,
       2
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned char yydefact[] =
{
       2,     0,     1,     3,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    15,    17,
       4,    23,     7,    16,    12,    18,    19,    20,    21,    22,
       0,    86,    88,    87,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    85,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     6,    59,    60,
      30,    31,    11,    61,    63,    62,    65,    64,    67,    66,
      69,     0,    32,    33,    71,    70,    34,    35,     8,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     9,    27,    24,    25,    26,     5,
      13,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    14,    29,    28,    10,    68,
       0,     0,     0,     0,     0,    83,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    74,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    48,    49,    77,    76,    90,
      84,    50,    51,    52,    53,    54,    55,    79,    78,    82,
       0,    56,    57,    58,    36,    37,    38,    75,    39,    40,
      41,    42,    43,    73,    72,    44,    45,    46,    47,    80,
       0,    81
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short yydefgoto[] =
{
      -1,     1,    18,    55,    19,    56,    20,    94,   115,    21,
     116,    95,    22,    23,    24,    25,    26,    27,    28,    29,
     117,   118,    96,    97,    98,    99,    48,   159,   123
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -80
static const short yypact[] =
{
     -80,     9,   -80,   -80,    90,   140,     1,     2,    96,   102,
     108,   114,    13,     7,    32,   120,    39,    42,   -80,   -80,
     -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,
      36,   -80,   -80,   -80,    59,    63,    77,    83,    89,    95,
     101,   107,   113,   119,   144,   145,   146,   -80,   140,   147,
     148,   149,   150,   151,   152,    38,    57,   -80,   -80,   -80,
     -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,
     -80,   153,   -80,   -80,   -80,   -80,   -80,   -80,   -80,    92,
      98,    31,    12,   104,   110,   116,   122,   156,   157,    78,
      37,   158,   159,   160,   -80,   -80,   -80,   -80,   -80,   -80,
     -80,   161,   162,   163,    60,   164,   166,   167,   168,   169,
      84,   170,   171,   172,   173,   -80,   -80,   -80,   -80,   -80,
     174,   175,   176,   124,   177,   -80,   178,   179,   180,   181,
     182,   183,   184,   129,   185,   140,   186,   187,   188,   189,
     190,   191,   192,   -80,   193,   194,   195,   196,   197,   198,
     133,   199,   200,   201,   202,   -80,   -80,   -80,   -80,   -80,
     -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,
     137,   -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,
     -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,
     203,   -80
};

/* YYPGOTO[NTERM-NUM].  */
static const yysigned_char yypgoto[] =
{
     -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,
     -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,   -80,
     -80,   -80,   -80,   -80,   -80,   -80,    85,    -4,   -79
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -90
static const short yytable[] =
{
      34,    35,    36,    37,    39,    41,    43,    45,    49,     2,
     133,    52,     3,   124,    46,   125,     4,     5,    47,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,   150,   122,    50,   -89,   -89,   -89,   -89,   134,    57,
      53,    78,    47,    54,    71,    79,    80,    81,    82,    83,
      84,    85,    86,    87,    88,    89,    90,    91,    92,    93,
     100,   142,    58,   143,   101,   102,    59,   103,   104,   105,
     106,   107,   108,   109,   110,   111,   112,   113,   114,   132,
      60,   -89,   -89,   -89,   -89,   149,    61,   -89,   -89,   -89,
     -89,    30,    62,   120,    31,    32,    33,    38,    63,   121,
      31,    32,    33,    40,    64,   126,    31,    32,    33,    42,
      65,   127,    31,    32,    33,    44,    66,   128,    31,    32,
      33,    51,    67,   129,    31,    32,    33,   158,    31,    32,
      33,   170,   168,    31,    32,    33,   184,    31,    32,    33,
     189,    31,    32,    33,    31,    32,    33,    68,    69,    70,
      72,    73,    74,    75,    76,    77,   119,   130,   131,   136,
     137,   138,   139,   140,   141,   144,   190,   145,   146,   147,
     148,   151,   152,   153,   154,   135,     0,   155,   156,   157,
     160,   161,   162,   163,   164,   165,   166,   167,   169,   171,
     172,   173,   174,   175,   176,   177,   178,   179,   180,   181,
     182,   183,   185,   186,   187,   188,   191
};

static const short yycheck[] =
{
       4,     5,     1,     1,     8,     9,    10,    11,     1,     0,
      89,    15,     3,     1,     1,     3,     7,     8,     5,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,   110,     1,     1,     3,     4,     5,     6,     1,     3,
       1,     3,     5,     1,    48,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
       3,     1,     3,     3,     7,     8,     3,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,    21,     1,
       3,     3,     4,     5,     6,     1,     3,     3,     4,     5,
       6,     1,     3,     1,     4,     5,     6,     1,     3,     1,
       4,     5,     6,     1,     3,     1,     4,     5,     6,     1,
       3,     1,     4,     5,     6,     1,     3,     1,     4,     5,
       6,     1,     3,     1,     4,     5,     6,     3,     4,     5,
       6,   135,     3,     4,     5,     6,     3,     4,     5,     6,
       3,     4,     5,     6,     4,     5,     6,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     1,     1,     1,
       1,     1,     1,     1,     1,     1,   170,     1,     1,     1,
       1,     1,     1,     1,     1,    90,    -1,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned char yystos[] =
{
       0,    26,     0,     3,     7,     8,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    27,    29,
      31,    34,    37,    38,    39,    40,    41,    42,    43,    44,
       1,     4,     5,     6,    52,    52,     1,     1,     1,    52,
       1,    52,     1,    52,     1,    52,     1,     5,    51,     1,
       1,     1,    52,     1,     1,    28,    30,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,    52,     3,     3,     3,     3,     3,     3,     3,     7,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    32,    36,    47,    48,    49,    50,
       3,     7,     8,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    33,    35,    45,    46,     3,
       1,     1,     1,    53,     1,     3,     1,     1,     1,     1,
       1,     1,     1,    53,     1,    51,     1,     1,     1,     1,
       1,     1,     1,     3,     1,     1,     1,     1,     1,     1,
      53,     1,     1,     1,     1,     3,     3,     3,     3,    52,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
      52,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
      52,     3
};

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrlab1

/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)         \
  Current.first_line   = Rhs[1].first_line;      \
  Current.first_column = Rhs[1].first_column;    \
  Current.last_line    = Rhs[N].last_line;       \
  Current.last_column  = Rhs[N].last_column;
#endif

/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YYDSYMPRINT(Args)			\
do {						\
  if (yydebug)					\
    yysymprint Args;				\
} while (0)

# define YYDSYMPRINTF(Title, Token, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr, 					\
                  Token, Value);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (cinluded).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short *bottom, short *top)
#else
static void
yy_stack_print (bottom, top)
    short *bottom;
    short *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned int yylineno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %u), ",
             yyrule - 1, yylineno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname [yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname [yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YYDSYMPRINT(Args)
# define YYDSYMPRINTF(Title, Token, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

#endif /* !YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  if (yytype < YYNTOKENS)
    {
      YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
# ifdef YYPRINT
      YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
    }
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yytype, yyvaluep)
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  switch (yytype)
    {

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;



#define YYPOPSTACK   (yyvsp--, yyssp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YYDSYMPRINTF ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %s, ", yytname[yytoken]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;


  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 6:
#line 179 "sksiteconfig_parse.y"
    { do_err_args("class"); }
    break;

  case 11:
#line 190 "sksiteconfig_parse.y"
    { do_err_args("group"); }
    break;

  case 30:
#line 228 "sksiteconfig_parse.y"
    { do_err_ctx("top level", "end class"); }
    break;

  case 31:
#line 229 "sksiteconfig_parse.y"
    { do_err_ctx("top level", "end group"); }
    break;

  case 32:
#line 230 "sksiteconfig_parse.y"
    { do_err_ctx("top level", "sensors"); }
    break;

  case 33:
#line 231 "sksiteconfig_parse.y"
    { do_err_ctx("top level", "type"); }
    break;

  case 34:
#line 232 "sksiteconfig_parse.y"
    { do_err("unknown command '%s'", yyvsp[-2].str);
                                    free(yyvsp[-2].str); }
    break;

  case 35:
#line 234 "sksiteconfig_parse.y"
    { do_err("unrecognizable command"); }
    break;

  case 36:
#line 238 "sksiteconfig_parse.y"
    { do_err_ctx("group", "class"); }
    break;

  case 37:
#line 239 "sksiteconfig_parse.y"
    { do_err_ctx("group", "default-class"); }
    break;

  case 38:
#line 240 "sksiteconfig_parse.y"
    { do_err_ctx("group", "end class"); }
    break;

  case 39:
#line 241 "sksiteconfig_parse.y"
    { do_err_ctx("group", "group"); }
    break;

  case 40:
#line 242 "sksiteconfig_parse.y"
    { do_err_ctx("group", "include"); }
    break;

  case 41:
#line 243 "sksiteconfig_parse.y"
    { do_err_ctx("group", "path-format"); }
    break;

  case 42:
#line 244 "sksiteconfig_parse.y"
    {do_err_ctx("group", "packing-logic"); }
    break;

  case 43:
#line 245 "sksiteconfig_parse.y"
    { do_err_ctx("group", "sensor"); }
    break;

  case 44:
#line 246 "sksiteconfig_parse.y"
    { do_err_ctx("group", "type"); }
    break;

  case 45:
#line 247 "sksiteconfig_parse.y"
    { do_err_ctx("group", "version"); }
    break;

  case 46:
#line 248 "sksiteconfig_parse.y"
    { do_err("unknown command '%s'", yyvsp[-2].str);
                                    free(yyvsp[-2].str); }
    break;

  case 47:
#line 250 "sksiteconfig_parse.y"
    { do_err("unrecognizable command"); }
    break;

  case 48:
#line 254 "sksiteconfig_parse.y"
    { do_err_ctx("class", "class"); }
    break;

  case 49:
#line 255 "sksiteconfig_parse.y"
    { do_err_ctx("class", "default-class"); }
    break;

  case 50:
#line 256 "sksiteconfig_parse.y"
    { do_err_ctx("class", "end group"); }
    break;

  case 51:
#line 257 "sksiteconfig_parse.y"
    { do_err_ctx("class", "group"); }
    break;

  case 52:
#line 258 "sksiteconfig_parse.y"
    { do_err_ctx("class", "include"); }
    break;

  case 53:
#line 259 "sksiteconfig_parse.y"
    { do_err_ctx("class", "path-format"); }
    break;

  case 54:
#line 260 "sksiteconfig_parse.y"
    {do_err_ctx("class","packing-logic");}
    break;

  case 55:
#line 261 "sksiteconfig_parse.y"
    { do_err_ctx("class", "sensor"); }
    break;

  case 56:
#line 262 "sksiteconfig_parse.y"
    { do_err_ctx("class", "version"); }
    break;

  case 57:
#line 263 "sksiteconfig_parse.y"
    { do_err("unknown command '%s'", yyvsp[-2].str); }
    break;

  case 58:
#line 264 "sksiteconfig_parse.y"
    { do_err("unrecognizable command"); }
    break;

  case 59:
#line 268 "sksiteconfig_parse.y"
    { do_class(yyvsp[-1].str); }
    break;

  case 60:
#line 274 "sksiteconfig_parse.y"
    { do_default_class(yyvsp[-1].str); }
    break;

  case 61:
#line 278 "sksiteconfig_parse.y"
    { do_group(yyvsp[-1].str); }
    break;

  case 62:
#line 284 "sksiteconfig_parse.y"
    { do_include(yyvsp[-1].str); }
    break;

  case 63:
#line 285 "sksiteconfig_parse.y"
    { do_err_args("include"); }
    break;

  case 64:
#line 289 "sksiteconfig_parse.y"
    { do_path_format(yyvsp[-1].str); }
    break;

  case 65:
#line 290 "sksiteconfig_parse.y"
    { do_err_args("path-format"); }
    break;

  case 66:
#line 294 "sksiteconfig_parse.y"
    { do_packing_logic(yyvsp[-1].str); }
    break;

  case 67:
#line 295 "sksiteconfig_parse.y"
    { do_err_args("packing-logic"); }
    break;

  case 68:
#line 299 "sksiteconfig_parse.y"
    { do_sensor(yyvsp[-2].integer, yyvsp[-1].str); }
    break;

  case 69:
#line 300 "sksiteconfig_parse.y"
    { do_err_args("sensor"); }
    break;

  case 70:
#line 304 "sksiteconfig_parse.y"
    { do_version(yyvsp[-1].str); }
    break;

  case 71:
#line 305 "sksiteconfig_parse.y"
    { do_err_args("version"); }
    break;

  case 72:
#line 309 "sksiteconfig_parse.y"
    { do_group_sensors(yyvsp[-1].str_list); }
    break;

  case 73:
#line 310 "sksiteconfig_parse.y"
    { do_err_args("sensors"); }
    break;

  case 74:
#line 314 "sksiteconfig_parse.y"
    { do_end_group(); }
    break;

  case 75:
#line 315 "sksiteconfig_parse.y"
    { do_err_args_none("end group"); }
    break;

  case 76:
#line 319 "sksiteconfig_parse.y"
    { do_class_default_types(yyvsp[-1].str_list); }
    break;

  case 77:
#line 320 "sksiteconfig_parse.y"
    { do_err_args("default-types"); }
    break;

  case 78:
#line 324 "sksiteconfig_parse.y"
    { do_class_sensors(yyvsp[-1].str_list); }
    break;

  case 79:
#line 325 "sksiteconfig_parse.y"
    { do_err_args("sensors"); }
    break;

  case 80:
#line 329 "sksiteconfig_parse.y"
    { do_class_type(yyvsp[-2].integer, yyvsp[-1].str, NULL); }
    break;

  case 81:
#line 330 "sksiteconfig_parse.y"
    { do_class_type(yyvsp[-3].integer, yyvsp[-2].str, yyvsp[-1].str); }
    break;

  case 82:
#line 331 "sksiteconfig_parse.y"
    { do_err_args("type"); }
    break;

  case 83:
#line 335 "sksiteconfig_parse.y"
    { do_end_class(); }
    break;

  case 84:
#line 336 "sksiteconfig_parse.y"
    { do_err_args_none("end class"); }
    break;

  case 85:
#line 341 "sksiteconfig_parse.y"
    { yyval.integer = atoi(yyvsp[0].str); free(yyvsp[0].str); }
    break;

  case 89:
#line 353 "sksiteconfig_parse.y"
    { yyval.str_list = skVectorNew(sizeof(char*)); }
    break;

  case 90:
#line 354 "sksiteconfig_parse.y"
    { skVectorAppendValue(yyvsp[-1].str_list, &yyvsp[0].str); yyval.str_list = yyvsp[-1].str_list; }
    break;


    }

/* Line 991 of yacc.c.  */
#line 1627 "sksiteconfig_parse.c"

  yyvsp -= yylen;
  yyssp -= yylen;


  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  int yytype = YYTRANSLATE (yychar);
	  char *yymsg;
	  int yyx, yycount;

	  yycount = 0;
	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  for (yyx = yyn < 0 ? -yyn : 0;
	       yyx < (int) (sizeof (yytname) / sizeof (char *)); yyx++)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      yysize += yystrlen (yytname[yyx]) + 15, yycount++;
	  yysize += yystrlen ("syntax error, unexpected ") + 1;
	  yysize += yystrlen (yytname[yytype]);
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "syntax error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[yytype]);

	      if (yycount < 5)
		{
		  yycount = 0;
		  for (yyx = yyn < 0 ? -yyn : 0;
		       yyx < (int) (sizeof (yytname) / sizeof (char *));
		       yyx++)
		    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
		      {
			const char *yyq = ! yycount ? ", expecting " : " or ";
			yyp = yystpcpy (yyp, yyq);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yycount++;
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("syntax error; also virtual memory exhausted");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror ("syntax error");
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      /* Return failure if at end of input.  */
      if (yychar == YYEOF)
        {
	  /* Pop the error token.  */
          YYPOPSTACK;
	  /* Pop the rest of the stack.  */
	  while (yyss < yyssp)
	    {
	      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
	      yydestruct (yystos[*yyssp], yyvsp);
	      YYPOPSTACK;
	    }
	  YYABORT;
        }

      YYDSYMPRINTF ("Error: discarding", yytoken, &yylval, &yylloc);
      yydestruct (yytoken, &yylval);
      yychar = YYEMPTY;

    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab2;


/*----------------------------------------------------.
| yyerrlab1 -- error raised explicitly by an action.  |
`----------------------------------------------------*/
yyerrlab1:

  /* Suppress GCC warning that yyerrlab1 is unused when no action
     invokes YYERROR.  */
#if defined (__GNUC_MINOR__) && 2093 <= (__GNUC__ * 1000 + __GNUC_MINOR__)
  __attribute__ ((__unused__))
#endif


  goto yyerrlab2;


/*---------------------------------------------------------------.
| yyerrlab2 -- pop states until the error token can be shifted.  |
`---------------------------------------------------------------*/
yyerrlab2:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
      yydestruct (yystos[yystate], yyvsp);
      yyvsp--;
      yystate = *--yyssp;

      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;


  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*----------------------------------------------.
| yyoverflowlab -- parser overflow comes here.  |
`----------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}


#line 354 "sksiteconfig_parse.y"


/* SUPPORTING CODE */

int yyerror(char UNUSED(*s))
{
    /* do nothing, we handle error messages ourselves */
    return 0;
}

/* Handle config file version */
static void do_version(char *str)
{
    if ( sksiteconfig_testing ) {
        fprintf(stderr, "version \"%s\"\n", str);
    }
    if ( strcmp(str, "1") != 0 ) {
        sksiteconfigErr("unrecognized version '%s'", str);
    }
    free(str);
}

/* Define sensor */
static void do_sensor(int id, char *name)
{
    if ( sksiteconfig_testing ) {
        fprintf(stderr, "sensor %d \"%s\"\n", id, name);
    }
    if ( sksiteSensorExists(id) ) {
        sksiteconfigErr("sensor with id '%d' already exists", id);
    } else if ( sksiteSensorLookup(name) != SK_INVALID_SENSOR ) {
        sksiteconfigErr("sensor with name '%s' already exists", name);
    } else if ( sksiteSensorCreate(id, name) ) {
        sksiteconfigErr("failed to create sensor");
    }
    free(name);
}

/* Define path-format */
static void do_path_format(char *fmt)
{
    int len;

    if ( sksiteconfig_testing ) {
        fprintf(stderr, "path-format \"%s\"\n", fmt);
    }
    len = strlen(fmt);
    if ( (fmt[len-2] != '%') || (fmt[len-1] != 'x') ) {
        sksiteconfigErr("path-format '%s' does not end with '%%x'", fmt);
    }
    if ( sksiteSetPathFormat(fmt) ) {
        sksiteconfigErr("failed to set path-format");
    }
    free(fmt);
}

/* Define the packing-logic file */
static void do_packing_logic(char *fmt)
{
    if ( sksiteconfig_testing ) {
        fprintf(stderr, "packing-logic \"%s\"\n", fmt);
    }
    if ( sksiteSetPackingLogicPath(fmt) ) {
        sksiteconfigErr("failed to set packing-logic");
    }
    free(fmt);
}

/* Include a file */
static void do_include(char *filename)
{
    if ( sksiteconfig_testing ) {
        fprintf(stderr, "include \"%s\"\n", filename);
    }
    sksiteconfigIncludePush(filename);
}

/* Begin defining a group */
static void do_group(char *groupname)
{
    assert(current_group == NULL);
    assert(current_class == NULL);
    if ( sksiteconfig_testing ) {
        fprintf(stderr, "group \"%s\"\n", groupname);
    }
    current_group = groupname;
    current_group_id = sksiteSensorgroupLookup(current_group);
    if ( current_group_id == SK_INVALID_SENSORGROUP ) {
        current_group_id = sksiteSensorgroupGetMaxID() + 1;
        if ( sksiteSensorgroupCreate(current_group_id, groupname) ) {
            current_group_id = SK_INVALID_SENSORGROUP;
            sksiteconfigErr("failed to create sensorgroup");
        }
    }
}

/* Add sensors to a group definition */
static void do_group_sensors(sk_vector_t *sensors)
{
    int i;
    int len;
    char *str;
    sensorID_t sensor_id;
    sensorgroupID_t sensorgroup_id;

    assert(current_group != NULL);
    assert(current_class == NULL);
    len = skVectorGetCount(sensors);
    if ( sksiteconfig_testing ) {
        fprintf(stderr, "[group \"%s\"] sensors", current_group);
        for ( i = 0; i < len; i++ ) {
            skVectorGetValue(&str, sensors, i);
            fprintf(stderr, " %s", str);
        }
        fprintf(stderr, "\n");
    }
    if ( current_group_id != SK_INVALID_SENSORGROUP ) {
        for ( i = 0; i < len; i++ ) {
            skVectorGetValue(&str, sensors, i);
            if ( str[0] == '@' ) {
                sensorgroup_id = sksiteSensorgroupLookup(&str[1]);
                if ( sensorgroup_id == SK_INVALID_SENSORGROUP ) {
                    sksiteconfigErr("unknown group '%s'", str);
                } else {
                    sksiteSensorgroupAddSensorgroup(current_group_id,
                                                    sensorgroup_id);
                }
            } else {
                sensor_id = sksiteSensorLookup(str);
                if ( sensor_id == SK_INVALID_SENSOR ) {
                    sksiteconfigErr("unknown sensor '%s'", str);
                } else {
                    sksiteSensorgroupAddSensor(current_group_id, sensor_id);
                }
            }
        }
    }
    /* free the vector and its contents */
    for (i = 0; i < len; ++i) {
        skVectorGetValue(&str, sensors, i);
        free(str);
    }
    skVectorDestroy(sensors);
}

/* Finish defining a group */
static void do_end_group(void)
{
    assert(current_group != NULL);
    assert(current_class == NULL);
    if ( sksiteconfig_testing ) {
        fprintf(stderr, "[group \"%s\"] end group\n", current_group);
    }
    free(current_group);
    current_group = NULL;
}

/* Begin defining a class */
static void do_class(char *classname)
{
    assert(current_group == NULL);
    assert(current_class == NULL);
    if ( sksiteconfig_testing ) {
        fprintf(stderr, "class \"%s\"\n", classname);
    }
    current_class = classname;
    current_class_id = sksiteClassLookup(current_class);
    /* We're okay on "duplicates": just more info on existing class */
    if ( current_class_id == SK_INVALID_CLASS ) {
        current_class_id = sksiteClassGetMaxID() + 1;
        if ( sksiteClassCreate(current_class_id, classname) ) {
            current_class_id = SK_INVALID_CLASS;
            sksiteconfigErr("failed to create class");
        }
    }
}

/* Add sensors to a class definition */
static void do_class_sensors(sk_vector_t *sensors)
{
    int i;
    int len;
    char *str;
    sensorID_t sensor_id;
    sensorgroupID_t sensorgroup_id;

    assert(current_class != NULL);
    assert(current_group == NULL);
    len = skVectorGetCount(sensors);
    if ( sksiteconfig_testing ) {
        fprintf(stderr, "[class \"%s\"] sensors", current_class);
        for ( i = 0; i < len; i++ ) {
            skVectorGetValue(&str, sensors, i);
            fprintf(stderr, " %s", str);
        }
        fprintf(stderr, "\n");
    }
    if ( current_class_id != SK_INVALID_CLASS ) {
        for ( i = 0; i < len; i++ ) {
            skVectorGetValue(&str, sensors, i);
            if ( str[0] == '@' ) {
                sensorgroup_id = sksiteSensorgroupLookup(&str[1]);
                if ( sensorgroup_id == SK_INVALID_SENSORGROUP ) {
                    sksiteconfigErr("unknown group '%s'", str);
                } else {
                    sksiteClassAddSensorgroup(current_class_id,
                                              sensorgroup_id);
                }
            } else {
                sensor_id = sksiteSensorLookup(str);
                if ( sensor_id == SK_INVALID_SENSOR ) {
                    sksiteconfigErr("unknown sensor '%s'", str);
                } else {
                    sksiteClassAddSensor(current_class_id, sensor_id);
                }
            }
        }
    }
    /* free the vector and its contents */
    for (i = 0; i < len; ++i) {
        skVectorGetValue(&str, sensors, i);
        free(str);
    }
    skVectorDestroy(sensors);
}

/* Define type within a class definition */
static void do_class_type(int id, char *type, char *name)
{
    char flowtype_name_buf[SK_MAX_STRLEN_FLOWTYPE+1];

    assert(current_class != NULL);
    if ( name == NULL ) {
        if ( snprintf(flowtype_name_buf, SK_MAX_STRLEN_FLOWTYPE,
                      "%s%s", current_class, type)
             > SK_MAX_STRLEN_FLOWTYPE ) {
            sksiteconfigErr("type prefix too long");
        }
        name = flowtype_name_buf;
    }
    if ( sksiteconfig_testing ) {
        fprintf(stderr, "[class \"%s\"] type %d %s %s", current_class,
                id, type, name);
        fprintf(stderr, "\n");
    }
    if ( current_class_id != SK_INVALID_CLASS ) {
        if ( sksiteFlowtypeExists(id) ) {
            sksiteconfigErr("type with id '%d' already exists", id);
        } else if ( sksiteFlowtypeLookup(name) != SK_INVALID_FLOWTYPE ) {
            sksiteconfigErr("type with prefix '%s' already exists", name);
        } else if ( sksiteFlowtypeLookupByClassIDType(current_class_id, type)
                    != SK_INVALID_CLASS ) {
            sksiteconfigErr("type '%s' for class '%s' already exists",
                            type, current_class);
        } else if ( sksiteFlowtypeCreate(id, name, current_class_id, type) ) {
            sksiteconfigErr("failed to create type");
        }
    }
    free(type);
    if (name != flowtype_name_buf) {
        free(name);
    }
}

/* Set the default types within a class definition */
static void do_class_default_types(sk_vector_t *types)
{
    int i;
    int len;
    char *str;
    flowtypeID_t flowtype_id;

    assert(current_class != NULL);
    assert(current_group == NULL);
    len = skVectorGetCount(types);
    if ( sksiteconfig_testing ) {
        fprintf(stderr, "[class \"%s\"] default-types", current_class);
        for ( i = 0; i < len; i++ ) {
            skVectorGetValue(&str, types, i);
            fprintf(stderr, " %s", str);
        }
        fprintf(stderr, "\n");
    }
    if ( current_class_id != SK_INVALID_CLASS ) {
        for ( i = 0; i < len; i++ ) {
            skVectorGetValue(&str, types, i);
            flowtype_id =
                sksiteFlowtypeLookupByClassIDType(current_class_id, str);
            if ( flowtype_id == SK_INVALID_FLOWTYPE ) {
                sksiteconfigErr("unknown type '%s' in class '%s'",
                                str, current_class);
            } else {
                if ( sksiteClassAddDefaultFlowtype(current_class_id,
                                                   flowtype_id) ) {
                    sksiteconfigErr("failed to add default type");
                }
            }
        }
    }
    /* free the vector and its contents */
    for (i = 0; i < len; ++i) {
        skVectorGetValue(&str, types, i);
        free(str);
    }
    skVectorDestroy(types);
}

/* Finish defining a class */
static void do_end_class(void)
{
    assert(current_class != NULL);
    assert(current_group == NULL);
    if ( sksiteconfig_testing ) {
        fprintf(stderr, "[class \"%s\"] end class\n", current_class);
    }
    free(current_class);
    current_class = NULL;
}

static void do_default_class(char *name)
{
    classID_t class_id;

    if ( sksiteconfig_testing ) {
        fprintf(stderr, "default-class \"%s\"\n", name);
    }
    class_id = sksiteClassLookup(name);
    if ( class_id == SK_INVALID_CLASS ) {
        sksiteconfigErr("undefined class '%s'", name);
    } else {
        if ( sksiteClassSetDefault(class_id) ) {
            sksiteconfigErr("failed to set default class");
        }
    }
    free(name);
}

/* Report a context error, like trying to define a sensor in a class */
static void do_err_ctx(const char *ctx, const char *cmd)
{
    do_err("command '%s' not allowed in %s", cmd, ctx);
}

/* Report an argument error: too many, too few, or the wrong args */
static void do_err_args(const char *cmd)
{
    do_err("bad arguments to command '%s'", cmd);
}

/* Report an argument error: shouldn't be any arguments */
static void do_err_args_none(const char *cmd)
{
    do_err("command '%s' does take arguments", cmd);
}


/*
** Local variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/

