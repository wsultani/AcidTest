/*
** Copyright (C) 2004-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/
#ifndef _SKSTREAM_PRIV_H
#define _SKSTREAM_PRIV_H

#include "silk.h"

RCSIDENTVAR(rcsID_SKSTREAM_PRIV_H, "$SiLK: skstream_priv.h 10829 2008-03-07 16:28:35Z mthomas $");

/*
**  skstream_priv.h
**
**  For sharing of functions within librw (to avoid tons of extern's).
**
**  THESE FUNCTIONS ARE FOR INTERNAL USE BY LIBRW.
**
*/

#include "sksite.h"
#include "utils.h"
#include "rwpack.h"
#include "bits.h"
#include "skiobuf.h"


/* macros to swap the bytes in place */
#define SWAP_DATA64(d) *((uint64_t*)(d)) = BSWAP64(*(uint64_t*)(d))
#define SWAP_DATA32(d) *((uint32_t*)(d)) = BSWAP32(*(uint32_t*)(d))
#define SWAP_DATA16(d) *((uint16_t*)(d)) = BSWAP16(*(uint16_t*)(d))
#if 0
/* macros to swap the bytes in place */
#define _SWAP_HELP(_byte, ar, a, b)             \
    {                                           \
        (_byte) = (ar)[(a)];                    \
        (ar)[(a)] = (ar)[(b)];                  \
        (ar)[(b)] = (_byte);                    \
    }
#define SWAP_DATA16(ar)                         \
    {                                           \
        uint8_t _byte;                          \
        _SWAP_HELP(_byte, (ar), 0, 1);          \
    }
#define SWAP_DATA32(ar)                         \
    {                                           \
        uint8_t _byte;                          \
        _SWAP_HELP(_byte, (ar), 0, 3);          \
        _SWAP_HELP(_byte, (ar), 1, 2);          \
    }
#define SWAP_DATA64(ar)                         \
    {                                           \
        uint8_t _byte;                          \
        _SWAP_HELP(_byte, (ar), 0, 7);          \
        _SWAP_HELP(_byte, (ar), 1, 6);          \
        _SWAP_HELP(_byte, (ar), 2, 5);          \
        _SWAP_HELP(_byte, (ar), 3, 4);          \
    }
#endif /* 0 */


#define MAX_PKTS              1048576   /* 2^20 */
#define PKTS_DIVISOR               64
/*
 *    We store the packet count in a 20 bit value.  When the packet
 *    count is larger than that, we divide the value by the
 *    PKTS_DIVISOR and store the result.  That gives an absolute max
 *    of 67,100,864 packets.
 */

#define BPP_BITS                    6
#define BPP_PRECN                  64   /* 2^BPP_BITS */
#define BPP_PRECN_DIV_2            32   /* 2^BPP_BITS/2 */


#define MAX_START_TIME           4096   /* 2^12 */
/*
 *    We pack flows by their start time into hourly files.  The file's
 *    hour is stored in the header; each record's start time is offset
 *    from that and stored in 12 bits.
 */


#define MAX_ELAPSED_TIME         4096   /* 2^12 */
#define MAX_ELAPSED_TIME_OLD     2048   /* 2^11 */
/*
 *    The elapsed time is the offset from the record's start time.  We
 *    assume the router flushes flows at least once an hour, though in
 *    practice CISCO flushes every 30 mintues.  The elapsed time is
 *    stored in 11 or 12 bits, depending on file format.
 */



/* Web classification utilities */


#define WEBP(p) ((p) == 80 || (p) == 443 || (p) == 8080)
/*
 *  isweb = WEBP(p)
 *
 *    Return a true value if port 'p' is a "web" port; false otherwise
 */


#define WEBPORT(p)                              \
    (((p) == 80)                                \
     ? 0                                        \
     : (((p) == 443)                            \
        ? 1                                     \
        : (((p) == 8080)                        \
           ? 2                                  \
           : 3)))
/*
 *  encoding = WEBPORT(p)
 *
 *    Encode the port 'p' into a value suitable for storing in the
 *    wPort field of an FT_RWWWW record.
 */


#define EXPAND_WEBPORT(p)                               \
    (((p) == 0)                                         \
     ? 80                                               \
     : (((p) == 1)                                      \
        ? 443                                           \
        : (((p) == 2)                                   \
           ? 8080                                       \
           : 0)))
/*
 *  decoding = EXPAND_WEBPORT(p)
 *
 *    Decode the port 'p' from the value stored in the wPort field in
 *    an FT_RWWWW record.
 */


#define IS_WEB_PORT(p) WEBP(p)
/*
 *  isweb = IS_WEB_PORT(p)
 *
 *    Alias for WEBP
 */


#define IS_WEB(r)                               \
    (((r).prot == 6) && (IS_WEB_PORT((r).srcport) || IS_WEB_PORT((r).dstport)))
/*
 *  isweb = IS_WEB(r)
 *
 *    Return a true value if the flow 'r' represents a web flow;
 *    return false otherwise.  'r' is an rwrec, NOT an rwrec*.
 */


/* for getting fields from a packed data file */
#define rwioGetFileStarttime(rwIOS)  ((rwIOS)->hdr_starttime)
#define rwioGetFileSensor(rwIOS)     ((rwIOS)->hdr_sensor)
#define rwioGetFileFlowtype(rwIOS)   ((rwIOS)->hdr_flowtype)




struct skstream_st {
    off_t                   pre_iobuf_pos;
    int                     fd;
    FILE                   *fp;
#if SK_ENABLE_ZLIB
    /* When the entire file has been compressed, we use gzread/gzwrite
     * to process the file, this is interface to those functions */
    gzFile                  gz;
#endif
    sk_iobuf_t             *iobuf;

    int                     err_info;
#if 0
    void                   *errobj;
    int                     errnum;
#endif

    char                   *pathname;
    sk_file_header_t       *silk_hdr;

    /* Number of records read or written.  For appending, this is the
     * number records added to the file. */
    uint64_t                rec_count;

    /* Pointer to a function to convert an array of bytes into a record */
    int                   (*rwUnpackFn)(rwIOStruct_t*, rwRec*, uint8_t*);
    /* Pointer to a function to convert a record into an array of bytes */
    int                   (*rwPackFn)(rwIOStruct_t*, const rwRec*, uint8_t*);
    /* The stream to copy the input to---for support of the --all-dest
     * and --copy-input switches */
    skstream_t             *copyInputFD;

    /* An object to hold the parameter that caused the last error */
    union {
        uint32_t        num;
        const rwRec    *rec;
    }                       errobj;

    /* The errno from the last system call that failed */
    int                     errnum;

    /* The fixed length of records of this type */
    uint16_t                recLen;

    /* The sensor ID stored in the file's header, or
     * SK_INVALID_SENSOR.  For easy access. */
    sensorID_t              hdr_sensor;

    /* Start time as recorded in file's header, or 0. For easy access */
    sktime_t                hdr_starttime;

    /* The flowtype ID stored in the file's header, or
     * SK_INVALID_FLOWTYPE.  For easy access. */
    flowtypeID_t            hdr_flowtype;

    /* Whether stream is read, write, append. */
    skstream_mode_t         io_mode;

    /* ipv6 policy */
    sk_ipv6policy_t         v6policy;

    char                   *pager;
    char                   *comment_start;
    skcontent_t             content_type;
    unsigned                is_seekable     :1;
    unsigned                is_silk         :1;
    unsigned                is_silk_flow    :1;
    unsigned                is_pager_active :1;
    unsigned                is_binary       :1;
    unsigned                is_terminal     :1;
    unsigned                is_dirty        :1;
    unsigned                is_closed       :1;
    unsigned                is_mpi          :1;
    unsigned                is_stdio        :1;
    unsigned                is_unbuffered   :1;
    unsigned                is_eof          :1;
    unsigned                is_iobuf_error  :1;
    unsigned                supports_ipv6   :1;
    unsigned                have_hdr        :1;
    unsigned                swapFlag        :1;
};



/*  *****  Functions exported from each rw<format>io.c file  *****  */


int augmentedioPrepare(rwIOStruct_t *rwIOS);
int augroutingioPrepare(rwIOStruct_t *rwIOS);
int augsnmpoutioPrepare(rwIOStruct_t *rwIOS);
int augwebioPrepare(rwIOStruct_t *rwIOS);
int filterioPrepare(rwIOStruct_t *rwIOS);
int flowcapioPrepare(rwIOStruct_t *rwIOS);
int genericioPrepare(rwIOStruct_t *rwIOS);
int ipv6ioPrepare(rwIOStruct_t *rwIOS);
int ipv6routingioPrepare(rwIOStruct_t *rwIOS);
int notroutedioPrepare(rwIOStruct_t *rwIOS);
int routedioPrepare(rwIOStruct_t *rwIOS);
int splitioPrepare(rwIOStruct_t *rwIOS);
int wwwioPrepare(rwIOStruct_t *rwIOS);
/*
 *  status = _<format>ioPrepare(rwIOS);
 *
 *    DO NOT CALL DIRECTLY.  FOR INTERNAL LIBRW USE
 *
 *    Sets the record version to the default if it is unspecified,
 *    checks that the record format supports the requested record
 *    version, sets the record length, and sets the pack and unpack
 *    functions for this record format and version.
 *
 *    Returns RWIO_OK on success; otherwise returns an error code on
 *    failure: bad version.
 */


uint16_t augmentedioGetRecLen(fileVersion_t);
uint16_t augroutingioGetRecLen(fileVersion_t);
uint16_t augsnmpoutioGetRecLen(fileVersion_t);
uint16_t augwebioGetRecLen(fileVersion_t);
uint16_t filterioGetRecLen(fileVersion_t);
uint16_t flowcapioGetRecLen(fileVersion_t);
uint16_t genericioGetRecLen(fileVersion_t);
uint16_t ipv6ioGetRecLen(fileVersion_t);
uint16_t ipv6routingioGetRecLen(fileVersion_t);
uint16_t notroutedioGetRecLen(fileVersion_t);
uint16_t routedioGetRecLen(fileVersion_t);
uint16_t splitioGetRecLen(fileVersion_t);
uint16_t wwwioGetRecLen(fileVersion_t);
/*
 *  length = _<format>ioGetRecLen(version);
 *
 *    Return the on-disk length in bytes of records of the specified
 *    type and vresion; or return 0 if the specified version is not
 *    defined for the given type.
 */



/*  *****  rwpack.c  *****  */


int rwpackPackBytesPackets(
    uint32_t               *bpp_out,
    uint32_t               *pkts_out,
    uint32_t               *pflag_out,
    const rwGenericRec_V5  *rwrec);
/*
 *    Uses fields from the rwRec pointed to by 'rwrec' to compute the
 *    bytes-per-packet ('bpp'), packets ('pkts'), and
 *    packets-multiplier ('pflag') field required by the packed file
 *    formats FILTER, SPLIT, WWW, ROUTED, and NOTROUTED.
 *
 *    The parameters 'bpp', 'pkts', and 'pflag' will be the values to
 *    store in the packed file format; i.e., they will be the values
 *    that rwpackUnpackBytesPackets() can read; they will be in native
 *    byte order.
 *
 *    Specifically, 'pkts' is either the packet count or the packet
 *    count divided by the PKTS_DIVISOR when 'pflag' is non-zero.
 *    'bpp' is the bytes-per-packet ratio given by a 14 bit value and
 *    a 6 bit fractional part.
 *
 *    This function returns RWIO_OK on success, or the following to
 *    indicate an error: SKSTREAM_ERR_PKTS_ZERO-the 'pkts' field on rwrec
 *    is 0; SKSTREAM_ERR_PKTS_OVRFLO-the 'pkts' value is too large to
 *    store in the packed file format.
 */


void rwpackUnpackBytesPackets(
    rwGenericRec_V5    *rwrec,
    uint32_t            bpp,
    uint32_t            pkts,
    uint32_t            pflag);
/*
 *    Does the reverse of rwpackPackBytesPackets(): Fills in the
 *    'bytes', 'packets', and 'bpp' fields of the rwRec pointed to by
 *    'rwrec'.  All values are expected to be in native byte order.
 *
 *    This function does no error checking.
 */


void rwpackPackProtoFlags(
    uint8_t                *is_tcp_out,
    uint8_t                *prot_flags_out,
    uint8_t                *tcp_state_out,
    uint8_t                *rest_flags_out,
    const rwGenericRec_V5  *rwrec);
/*
 *    Uses fields from the rwRec pointed to by 'rwrec' to compute the
 *    values pointed to by these variables:
 *
 *        is_tcp_out - 1 if the flow is TCP (proto==6); 0 otherwise
 *
 *        prot_flags_out - protocol when is_tcp==0; bitwise OR of TCP
 *        flags on ALL packages when is_tcp==1 and tcp_state!=0; TCP
 *        flags on FIRST packet when is_tcp==1 and tcp_state!=0
 *
 *        tcp_state_out - value of tcp_state field on the rwrec
 *
 *        rest_flags_out - the flags reported by the flow collector
 *        when is_tcp==0 (even though there are no flags to report);
 *        empty when is_tcp==1 and tcp_state==0; bitwise OR of TCP
 *        flags on all but the first packet when is_tcp==1 and
 *        tcp_state!=0.
 *
 *    The output variables prot_flags, tcp_state, and rest_flags will
 *    be the values to store in the packed file format; is_tcp can be
 *    stored in a single bit.  The values can be read by the
 *    rwpackUnpackProtoFlags() function.
 *
 *    This function should never fail, and thus has no return value.
 */


void rwpackUnpackProtoFlags(
    rwGenericRec_V5    *rwrec,
    uint8_t             is_tcp,
    uint8_t             prot_flags,
    uint8_t             tcp_state,
    uint8_t             rest_flags);
/*
 *    Does the reverse of rwpackPackProtoFlags(): Fills in the 'proto',
 *    'flags', 'init_flags', 'rest_flags', and 'tcp_state' fields on
 *    the rwRec pointed to by 'rwrec'.  All values are expected to be
 *    in native byte order.
 *
 *    This function does no error checking.
 */


int rwpackPackSbbPef(
    uint32_t               *sbb_out,
    uint32_t               *pef_out,
    const rwGenericRec_V5  *rwrec,
    sktime_t                file_start_time);
/*
 *    Uses fields from the rwRec pointed to by 'rwrec' to compute the
 *    'sbb' and 'pef' fields used when packing SPLIT, WWW, ROUTED, and
 *    NOTROUTED V1 and V2 files.  'file_start_time' is the time value
 *    stored in the header--record times are offset from that time.
 *
 *    Uses the sTime, elapsed, pkts, bytes in the rwrec to compute
 *    these values.  Any millisec values for sTime and/or elapsed on
 *    the rwRec are ingored..
 *
 *    sbb and pef are returned in native byte order.
 *
 *    Returns 0 on success or non-zero on these failures: rwrec's sTime
 *    is earlier than the 'file_start_time' or is too large; elapsed
 *    time is too large; packets field is zero or too large.
 */


void rwpackUnpackSbbPef(
    rwGenericRec_V5    *rwrec,
    sktime_t            file_start_time,
    const uint32_t     *sbb,
    const uint32_t     *pef);
/*
 *    Does the reverse of rwpackPackSbbPef(): Fills in the 'sTime',
 *    'elapsed', 'bytes', 'pkts', and 'bpp' fields on the rwRec
 *    pointed to by 'rwrec'.  All values are expected to be in native
 *    byte order.
 *
 *    This function does no error checking.
 */


int rwpackPackTimeBytesPktsFlags(
    uint32_t               *pkts_stime_out,
    uint32_t               *bbe_out,
    uint32_t               *msec_flags_out,
    const rwGenericRec_V5  *rwrec,
    sktime_t                file_start_time);
/*
 *    Computes the 'pkts_stime', 'bbe', and 'msec_flags' fields used
 *    when packing into various formats.
 *
 *    Uses the sTime, elapsed, pkts, and bytes fields in the rwRec
 *    pointed to by rwrec to compute these values.  'file_start_time'
 *    is the hour stored in the file's header---record times are
 *    offset from it.
 *
 *    sbb and pef are returned in native byte order.
 *
 *    Returns 0 on success or non-zero on these failures: rwrec's sTime
 *    is earlier than rwIOS's sTime or is too large; elapsed time
 *    is too large; packets field is too large.
 */


void rwpackUnpackTimeBytesPktsFlags(
    rwGenericRec_V5    *rwrec,
    sktime_t            file_start_time,
    const uint32_t     *pkts_stime,
    const uint32_t     *bbe,
    const uint32_t     *msec_flags);
/*
 *    Does the reverse of rwpackPackSbbPef(): Fills in the 'sTime',
 *    'elapsed', 'sTime_msec, 'elapsed_msec', 'bytes', 'pkts', and
 *    'bpp' fields on the rwRec pointed to by 'rwrec'.  All values are
 *    expected to be in native byte order.
 *
 *    This function does no error checking.
 */


int rwpackPackFlagsTimesVolumes(
    uint8_t                *ar,
    const rwGenericRec_V5  *rwRP,
    sktime_t                file_start_time,
    size_t                  len);


void rwpackUnpackFlagsTimesVolumes(
    rwGenericRec_V5        *rwRP,
    const uint8_t          *ar,
    sktime_t                file_start_time,
    size_t                  len,
    int                     is_tcp);



#endif /* _SKSTREAM_PRIV_H */

/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
