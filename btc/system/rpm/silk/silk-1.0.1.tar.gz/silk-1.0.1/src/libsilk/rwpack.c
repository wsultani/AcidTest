/*
** Copyright (C) 2004-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  Functions to support binary output: opening binary SiLK files for
**  writing or appending.
**
*/


#include "silk.h"

RCSIDENT("$SiLK: rwpack.c 10473 2008-02-13 14:56:55Z mthomas $");

#include "skstream_priv.h"



/*  Convert bytes and packets fields in 'rwRP' to the values used in
 *  rwfilter output files and in the packed file formats.  See
 *  skstream_priv.h. */
int rwpackPackBytesPackets(
    uint32_t               *bpp_out,
    uint32_t               *pkts_out,
    uint32_t               *pflag_out,
    const rwGenericRec_V5  *rwRP)
{
    imaxdiv_t bpp;
    uint32_t packets;
    uint32_t bytes;

    assert(bpp_out);
    assert(pkts_out);
    assert(pflag_out);
    assert(rwRP);

    packets = rwRecGetPkts(rwRP);
    bytes = rwRecGetBytes(rwRP);

    /* Check for 0 value in 'pkts' field */
    if (packets == 0) {
        return SKSTREAM_ERR_PKTS_ZERO;
    }

    /* Verify that there are more bytes than packets */
    if (packets > bytes) {
        return SKSTREAM_ERR_PKTS_GT_BYTES;
    }

    /* Set packets field; check for overflow */
    if (packets < MAX_PKTS) {
        *pkts_out = packets;
        *pflag_out = 0;
    } else {
        *pkts_out = packets / PKTS_DIVISOR;
        if (*pkts_out >= MAX_PKTS) {
            /* Double overflow in pkts */
            return SKSTREAM_ERR_PKTS_OVRFLO;
        }
        /* pktsFlag */
        *pflag_out = 1;
    }

    /* calculate the bytes-per-packet ratio */
    bpp = imaxdiv(bytes, packets);

    if (bpp.quot > MASKARRAY_14) {
        return SKSTREAM_ERR_BPP_OVRFLO;
    }

    /* compute new value */
    *bpp_out = (((uint32_t)bpp.quot) << 6) |
                ((uint32_t)(bpp.rem * BPP_PRECN / packets));

    return RWIO_OK;
}


/*  Fill in the bytes and packets fields in rwRP by expanding the
 *  values that were read from disk.  See skstream_priv.h for details. */
void rwpackUnpackBytesPackets(
    rwGenericRec_V5    *rwRP,
    uint32_t            bpp,
    uint32_t            pkts,
    uint32_t            pflag)
{
    uint32_t bytes;
    int bPPkt, bPPFrac;
    div_t i;

    if (pflag) {
        pkts *= PKTS_DIVISOR;
    }

    /* Unpack the bpp value:  bPPkt:14; bPPFrac:6; */
    bPPkt = GET_MASKED_BITS(bpp, 6, 14);
    bPPFrac = GET_MASKED_BITS(bpp, 0, 6);

    /* convert fraction to whole number */
    i = div((bPPFrac * pkts), BPP_PRECN);

    bytes = ((bPPkt * pkts) + i.quot + ((i.rem >= BPP_PRECN_DIV_2) ? 1 : 0));

    rwRecSetPkts(rwRP, pkts);
    rwRecSetBytes(rwRP, bytes);
}


/* Pack the protocol, flags, and TCP state fields.  See skstream_priv.h */
void rwpackPackProtoFlags(
    uint8_t                *is_tcp_out,
    uint8_t                *prot_flags_out,
    uint8_t                *tcp_state_out,
    uint8_t                *rest_flags_out,
    const rwGenericRec_V5  *rwRP)
{
    if (rwRecGetProto(rwRP) != 6) {
        /* Flow is not TCP, so there is no additional TCP info.  Set
         * '*rest_flags_out' to value of rwRP->flags. */
        *is_tcp_out = 0;
        *prot_flags_out = rwRecGetProto(rwRP);
        *tcp_state_out  = 0;
        *rest_flags_out = rwRecGetFlags(rwRP);
    } else {
        /* Flow is TCP */
        *is_tcp_out = 1;
        *tcp_state_out = rwRecGetTcpState(rwRP);
        if (*tcp_state_out == 0) {
            /* There is no additional TCP info. */
            *prot_flags_out = rwRecGetFlags(rwRP);
            *rest_flags_out = 0;
        } else {
            /* There is additional TCP info.  Put the initial TCP
             * flags into the '*prot_flags_out' value. */
            *prot_flags_out = rwRecGetInitFlags(rwRP);
            *rest_flags_out = rwRecGetRestFlags(rwRP);
        }
    }
}


/* Fill in the protocol, flags, and TCP state fields on the rwRP.  See
 * skstream_priv.h */
void rwpackUnpackProtoFlags(
    rwGenericRec_V5    *rwRP,
    uint8_t             is_tcp,
    uint8_t             prot_flags,
    uint8_t             tcp_state,
    uint8_t             rest_flags)
{
    /* For some record types (e.g., RWWWW), proto is fixed at 6(TCP)
     * and there may be another value in the 'is_tcp' bit; ignore the
     * 'is_tcp' bit if the protocol is already set to TCP. */
    if ((rwRecGetProto(rwRP) == 6) || (is_tcp == 1)) {
        /* Flow is TCP */
        rwRecSetProto(rwRP, 6);

        if (tcp_state == 0) {
            /* We don't have additional TCP info; 'prot_flags' holds
             * the flags. */
            rwRecSetFlags(rwRP, prot_flags);
        } else {
            /* We have additional flow information; value in
             * prot_flags are the flags on the first packet. */
            rwRecSetTcpState(rwRP, tcp_state);
            rwRecSetInitFlags(rwRP, prot_flags);
            rwRecSetRestFlags(rwRP, rest_flags);
            rwRecSetFlags(rwRP, (uint8_t)(prot_flags | rest_flags));
        }
    } else {
        /* Flow is not TCP so there can be no additional TCP info.
         * 'prot_flags' holds the protocol.  Although 'flags' has no
         * real meaning here, the 'rest_flags' value has the value
         * that we got from the flow collector, so set 'rwRP->flags'
         * to that value. */
        rwRecSetProto(rwRP, prot_flags);
        rwRecSetFlags(rwRP, rest_flags);
    }
}


/*  Compute the 'sbb' and 'pef' fields used in packed file formats.
 *  See skstream_priv.h. */
int rwpackPackSbbPef(
    uint32_t                 *sbb_out,
    uint32_t                 *pef_out,
    const rwGenericRec_V5    *rwRP,
    sktime_t                  file_start_time)
{
    int rv = RWIO_OK; /* return value */
    sktime_t start_time;
    uint32_t elapsed;
    uint32_t pkts, bpp, pflag;

    elapsed = (rwRecGetElapsed(rwRP) / 1000);
    if (elapsed >= MAX_ELAPSED_TIME_OLD) {
        rv = SKSTREAM_ERR_ELPSD_OVRFLO;
        goto END;
    }

    start_time = rwRecGetStartTime(rwRP);
    if (start_time < file_start_time) {
        rv = SKSTREAM_ERR_STIME_UNDRFLO;
        goto END;
    }
    /* convert start time to seconds in the hour */
    start_time = (start_time - file_start_time) / 1000;
    if (start_time >= MAX_START_TIME) {
        rv = SKSTREAM_ERR_STIME_OVRFLO;
        goto END;
    }

    rv = rwpackPackBytesPackets(&bpp, &pkts, &pflag, rwRP);
    if (rv) { goto END; }

    /* sbb: uint32_t sTime:12;  uint32_t bPPkt:14;  uint32_t bPPFrac:6; */
    *sbb_out = (((MASKARRAY_12 & (uint32_t)start_time) << 20)
                | (bpp & MASKARRAY_20));

    /* pef: uint32_t pkts:20; uint32_t elapsed :11; uint32_t pktsFlag:1; */
    *pef_out = ((pkts << 12) | (elapsed << 1) | pflag);

  END:
    return rv;
}


/* Set values in rwRP by expanding the 'sbb' and 'pef' fields that
 * exist in the packed file formats.  See skstream_priv.h for details. */
void rwpackUnpackSbbPef(
    rwGenericRec_V5    *rwRP,
    sktime_t            file_start_time,
    const uint32_t     *sbb,
    const uint32_t     *pef)
{
    uint32_t pkts, pktsFlag, bpp, start_time;

    /* pef: uint32_t pkts:20; uint32_t elapsed :11; uint32_t pktsFlag:1; */
    pkts = *pef >> 12;
    rwRecSetElapsed(rwRP, (1000 * ((*pef >> 1) & MASKARRAY_11)));
    pktsFlag = *pef & MASKARRAY_01;

    /* sbb: uint32_t start_time:12; uint32_t bpp:20 */
    bpp = *sbb & MASKARRAY_20;
    start_time = (*sbb >> 20);
    rwRecSetStartTime(rwRP, (sktime_t)1000 * start_time + file_start_time);

    rwpackUnpackBytesPackets(rwRP, bpp, pkts, pktsFlag);
}


int rwpackPackTimeBytesPktsFlags(
    uint32_t               *pkts_stime_out,
    uint32_t               *bbe_out,
    uint32_t               *msec_flags_out,
    const rwGenericRec_V5  *rwRP,
    sktime_t                file_start_time)
{
    int rv = RWIO_OK; /* return value */
    sktime_t start_time;
    uint32_t pkts, bpp, pflag, is_tcp;
    uint8_t prot_flags;
    imaxdiv_t stime_div;
    imaxdiv_t elapsed_div;

    elapsed_div = imaxdiv(rwRecGetElapsed(rwRP), 1000);

    if (elapsed_div.quot >= MAX_ELAPSED_TIME) {
        rv = SKSTREAM_ERR_ELPSD_OVRFLO;
        goto END;
    }

    start_time = rwRecGetStartTime(rwRP);
    if (start_time < file_start_time) {
        rv = SKSTREAM_ERR_STIME_UNDRFLO;
        goto END;
    }
    start_time -= file_start_time;
    stime_div = imaxdiv(start_time, 1000);
    if (stime_div.quot >= MAX_START_TIME) {
        rv = SKSTREAM_ERR_STIME_OVRFLO;
        goto END;
    }

    rv = rwpackPackBytesPackets(&bpp, &pkts, &pflag, rwRP);
    if (rv) { goto END; }

    /* pkts_stime: pkts:20; sTime: 12; */
    *pkts_stime_out = ((pkts << 12)
                       | (MASKARRAY_12 & (uint32_t)stime_div.quot));

    /* bbe: bpp: 20; elapsed: 12 */
    *bbe_out = ((bpp << 12)
                | (MASKARRAY_12 & (uint32_t)elapsed_div.quot));

    /* set is_tcp bit and prot_flags */
    if (rwRecGetProto(rwRP) == 6) {
        is_tcp = 1;
        prot_flags = rwRecGetFlags(rwRP);
    } else {
        is_tcp = 0;
        prot_flags = rwRecGetProto(rwRP);
    }

    /* msec_flags: sTime_msec:10; elaps_msec:10; pflag:1;
     *             is_tcp:1; pad:2; prot_flags:8;*/
    *msec_flags_out = (((MASKARRAY_10 & (uint32_t)stime_div.rem) << 22)
                       | ((MASKARRAY_10 & (uint32_t)elapsed_div.rem) << 12)
                       | (pflag ? (1 << 11) : 0)
                       | (is_tcp ? (1 << 10) : 0)
                       | prot_flags);

  END:
    return rv;
}


void rwpackUnpackTimeBytesPktsFlags(
    rwGenericRec_V5    *rwRP,
    sktime_t            file_start_time,
    const uint32_t     *pkts_stime,
    const uint32_t     *bbe,
    const uint32_t     *msec_flags)
{
    uint32_t pkts, bpp, is_tcp, pflag;
    uint8_t prot_flags;

    /* pkts_stime: pkts:20; sTime: 12; */
    /* msec_flags: sTime_msec:10; elaps_msec:10; pflag:1;
     *             is_tcp:1; pad:2, prot_flags:8;          */
    pkts = GET_MASKED_BITS(*pkts_stime, 12, 20);

    rwRecSetStartTime(rwRP, ((sktime_t)1000*GET_MASKED_BITS(*pkts_stime, 0, 12)
                             + GET_MASKED_BITS(*msec_flags, 22, 10)
                             + file_start_time));

    /* bbe: bpp: 20; elapsed: 12 */
    bpp = GET_MASKED_BITS(*bbe, 12, 20);

    rwRecSetElapsed(rwRP, (1000u * GET_MASKED_BITS(*bbe, 0, 12)
                           + GET_MASKED_BITS(*msec_flags, 12, 10)));

    /* msec_flags: sTime_msec:10; elaps_msec:10; pflag:1;
     *             is_tcp:1; pad:2, prot_flags:8;          */
    pflag = GET_MASKED_BITS(*msec_flags, 11, 1);
    is_tcp = GET_MASKED_BITS(*msec_flags, 10, 1);
    prot_flags = (uint8_t)GET_MASKED_BITS(*msec_flags, 0, 8);

    if (rwRecGetProto(rwRP) == 6) {
        /* caller has forced record to be TCP */
        rwRecSetFlags(rwRP, prot_flags);
    } else if (is_tcp == 0) {
        /* flow is not TCP */
        rwRecSetProto(rwRP, prot_flags);
    } else {
        /* flow is TCP */
        rwRecSetProto(rwRP, 6);
        rwRecSetFlags(rwRP, prot_flags);
    }

    /* unpack the bpp value into bytes and packets */
    rwpackUnpackBytesPackets(rwRP, bpp, pkts, pflag);
}


int rwpackPackFlagsTimesVolumes(
    uint8_t                *ar,
    const rwGenericRec_V5  *rwRP,
    sktime_t                file_start_time,
    size_t                  len)
{
    uint32_t bpp, tmp, pkts, pflag;
    uint8_t tcp_state;
    sktime_t start_time;
    int rv = RWIO_OK;

    if (rwRecGetElapsed(rwRP) >= 1000u * MAX_ELAPSED_TIME) {
        rv = SKSTREAM_ERR_ELPSD_OVRFLO;
        goto END;
    }

    start_time = rwRecGetStartTime(rwRP);
    if (start_time < file_start_time) {
        rv = SKSTREAM_ERR_STIME_UNDRFLO;
        goto END;
    }
    start_time -= file_start_time;
    if (start_time >= (sktime_t)1000 * MAX_START_TIME) {
        rv = SKSTREAM_ERR_STIME_OVRFLO;
        goto END;
    }

    rv = rwpackPackBytesPackets(&bpp, &pkts, &pflag, rwRP);
    if (rv) { goto END; }

/*
**    uint32_t      stime_bb1;       //  0- 3
**    // uint32_t     stime     :22  //        Start time:msec offset from hour
**    // uint32_t     bPPkt1    :10; //        Whole bytes-per-packet (hi 10)
*/
    tmp = (((MASKARRAY_22 & (uint32_t)start_time) << 10)
           | (GET_MASKED_BITS(bpp, 10, 10)));
    memcpy(&ar[0], &tmp, sizeof(tmp));

/*
**    uint32_t      bb2_elapsed;     //  4- 7
**    // uint32_t     bPPkt2    : 4; //        Whole bytes-per-packet (low 4)
**    // uint32_t     bPPFrac   : 6; //        Fractional bytes-per-packet
**    // uint32_t     elapsed   :22; //        Duration of flow in msec
**
*/
    tmp = ((GET_MASKED_BITS(bpp, 0, 10) << 22)
           | (MASKARRAY_22 & rwRecGetElapsed(rwRP)));
    memcpy(&ar[4], &tmp, sizeof(tmp));

/*
**    uint32_t     tcp_state;        // 12     TCP state machine info
**    uint32_t     rest_flags;       // 13     is_tcp==0: Flow's reported flags
**                                   //        is_tcp==1 &&
**                                   //          tcp_state==0:Empty
**                                   //          tcp_state==1:TCPflags/!1st pkt
**    uint32_t     application;      // 14-15  Type of traffic
*/
    if (len == 12) {
        tcp_state = 0;
    } else if (len == 16) {
        tcp_state = rwRecGetTcpState(rwRP);
        ar[12] = tcp_state;
        if (rwRecGetProto(rwRP) != 6) {
            /* when not TCP, holds whatever flags value we have */
            ar[13] = rwRecGetFlags(rwRP);
        } else if (tcp_state) {
            /* when TCP and extended data, hold the rest flags */
            ar[13] = rwRecGetRestFlags(rwRP);
        } else {
            /* when TCP but no extended data, is empty */
            ar[13] = 0;
        }
        rwRecMemGetApplication(rwRP, &ar[14]);
    } else {
        skAppPrintErr(("Bad length (%lu) to rwpackPackFlagsTimesVolumes"
                       " at %s:%d"),
                      (unsigned long)len, __FILE__, __LINE__);
        abort();
    }

/*
**    uint32_t      pro_flg_pkts;    //  8-11
**    // uint32_t     prot_flags: 8; //        is_tcp==0: IP protocol
**                                   //        is_tcp==1 &&
**                                   //          tcp_state==0:TCPflags/All pkts
**                                   //          tcp_state==1:TCPflags/1st pkt
**    // uint32_t     pflag     : 1; //        'pkts' requires multiplier?
**    // uint32_t     is_tcp    : 1; //        1 if flow is TCP; 0 otherwise
**    // uint32_t     padding   : 2; //
**    // uint32_t     pkts      :20; //        Count of packets
*/
    tmp = ((pflag << 23)
           | (MASKARRAY_20 & pkts));
    if (rwRecGetProto(rwRP) != 6) {
        tmp |= (rwRecGetProto(rwRP) << 24);
    } else {
        if (tcp_state) {
            tmp |= ((rwRecGetInitFlags(rwRP) << 24)
                    | (1 << 22));
        } else {
            tmp |= ((rwRecGetFlags(rwRP) << 24)
                    | (1 << 22));
        }
    }
    memcpy(&ar[8], &tmp, sizeof(tmp));

  END:
    return rv;
}


void rwpackUnpackFlagsTimesVolumes(
    rwGenericRec_V5    *rwRP,
    const uint8_t      *ar,
    sktime_t            file_start_time,
    size_t              len,
    int                 is_tcp)
{
    uint32_t bpp, tmp, pkts, pflag;
    uint8_t tcp_state, rest_flags;

/*
**    uint32_t     tcp_state;        // 12     TCP state machine info
**    uint32_t     rest_flags;       // 13     is_tcp==0: Flow's reported flags
**                                   //        is_tcp==1 &&
**                                   //          tcp_state==0:Empty
**                                   //          tcp_state==1:TCPflags/!1st pkt
**    uint32_t     application;      // 14-15  Type of traffic
*/
    if (len == 12) {
        tcp_state = 0;
        rest_flags = 0;
    } else if (len == 16) {
        tcp_state = ar[12];
        rest_flags = ar[13];
        rwRecSetTcpState(rwRP, tcp_state);
        rwRecSetRestFlags(rwRP, rest_flags);
        rwRecMemSetApplication(rwRP, &ar[14]);
    } else {
        skAppPrintErr(("Bad length (%lu) to rwpackUnpackFlagsTimesVolumes"
                       " at %s:%d"),
                      (unsigned long)len, __FILE__, __LINE__);
        abort();
    }

/*
**    uint32_t      pro_flg_pkts;    //  8-11
**    // uint32_t     prot_flags: 8; //        is_tcp==0: IP protocol
**                                   //        is_tcp==1 &&
**                                   //          tcp_state==0:TCPflags/All pkts
**                                   //          tcp_state==1:TCPflags/1st pkt
**    // uint32_t     pflag     : 1; //        'pkts' requires multiplier?
**    // uint32_t     is_tcp    : 1; //        1 if flow is TCP; 0 otherwise
**    // uint32_t     padding   : 2; //
**    // uint32_t     pkts      :20; //        Count of packets
*/
    memcpy(&tmp, &ar[8], sizeof(tmp));
    pkts = GET_MASKED_BITS(tmp, 0, 20);
    pflag = GET_MASKED_BITS(tmp, 23, 1);
    if (!is_tcp) {
        is_tcp = GET_MASKED_BITS(tmp, 22, 1);
    }
    if (!is_tcp) {
        rwRecSetProto(rwRP, GET_MASKED_BITS(tmp, 24, 8));
        rwRecSetFlags(rwRP, rest_flags);
    } else {
        rwRecSetProto(rwRP, 6);
        if (tcp_state) {
            rwRecSetInitFlags(rwRP, GET_MASKED_BITS(tmp, 24, 8));
        }
        rwRecSetFlags(rwRP, (GET_MASKED_BITS(tmp, 24, 8)
                             | rest_flags));
    }

/*
**    uint32_t      bb2_elapsed;     //  4- 7
**    // uint32_t     bPPkt2    : 4; //        Whole bytes-per-packet (low 4)
**    // uint32_t     bPPFrac   : 6; //        Fractional bytes-per-packet
**    // uint32_t     elapsed   :22; //        Duration of flow in msec
**
*/
    memcpy(&tmp, &ar[4], sizeof(tmp));
    rwRecSetElapsed(rwRP, GET_MASKED_BITS(tmp, 0, 22));


/*
**    uint32_t      stime_bb1;       //  0- 3
**    // uint32_t     stime     :22  //        Start time:msec offset from hour
**    // uint32_t     bPPkt1    :10; //        Whole bytes-per-packet (hi 10)
*/
    memcpy(&bpp, &ar[0], sizeof(bpp));
    rwRecSetStartTime(rwRP, ((sktime_t)file_start_time
                             + GET_MASKED_BITS(bpp, 10, 22)));

    bpp = ((GET_MASKED_BITS(bpp, 0, 10) << 10)
           | GET_MASKED_BITS(tmp, 22, 10));

    rwpackUnpackBytesPackets(rwRP, bpp, pkts, pflag);
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
