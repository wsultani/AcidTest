/*
** Copyright (C) 2004-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

#include "silk.h"

RCSIDENT("$SiLK: flowcapio.c 10876 2008-03-11 16:28:59Z mthomas $");

#include "skstream_priv.h"

/*
**  Converts FLOWCAP records to RWGENERIC records
**
*/


/* Version to use when SK_RECORD_VERSION_ANY is specified */
#define DEFAULT_RECORD_VERSION 5


/* LOCAL FUNCTION PROTOTYPES */

static int _flowcapioRecordUnpack_V3(
    rwIOStruct_t           *rwIOS,
    rwGenericRec_V5        *rwRP,
    uint8_t                *ar);
static int _flowcapioRecordPack_V3(
    rwIOStruct_t           *rwIOS,
    const rwGenericRec_V5  *rwRP,
    uint8_t                *ar);



/* ********************************************************************* */

/*
**  FLOWCAP VERSION 5
**
**    uint32_t      sIP;             //  0- 3  Source IP
**    uint32_t      dIP;             //  4- 7  Destination IP
**
**    uint32_t      bytes;           //  8-11  Byte count
**
**    uint32_t      sTime;           // 12-15  Start time as UNIX epoch secs
**
**    uint16_t      elapsed;         // 16-17  Duration of flow in seconds
**    uint16_t      sPort;           // 18-19  Source port
**
**    uint16_t      dPort;           // 20-21  Destination port
**    uint16_t      service_port;    // 22-23  Port reported by flow collector
**
**    uint16_t      input;           // 24-25  SNMP Input
**    uint16_t      output;          // 26-27  SNMP Output
**
**    uint8_t       pkts[3]          // 28-30  Count of packets
**    uint8_t       proto            // 31     Protocol
**
**    uint8_t       flags            // 32     tcp_state==0: All TCP Flags
**                                   //        tcp_state==1: Flags !1st pkt
**    uint8_t       first_flags;     // 33     tcp_state==0: 0
**                                   //        tcp_state==1: TCP Flags 1st pkt
**    uint8_t       tcp_state;       // 34     TCP state machine info
**    uint8_t       time_frac[3];    // 35-37  sTime msec & elapsed msec
**
**
**  38 bytes on disk.
*/

#define RECLEN_FLOWCAP_V5 38


/*
 *    Byte swap the FLOWCAP v5 record 'ar' in place.
 */
#define _flowcapioRecordSwap_V5(ar)                                     \
    {                                                                   \
        uint8_t _tmp;                                                   \
                                                                        \
        SWAP_DATA32((ar) +  0);   /* sIP */                             \
        SWAP_DATA32((ar) +  4);   /* dIP */                             \
        SWAP_DATA32((ar) +  8);   /* bytes */                           \
        SWAP_DATA32((ar) + 12);   /* sTime */                           \
        SWAP_DATA16((ar) + 16);   /* dur */                             \
        SWAP_DATA16((ar) + 18);   /* sPort */                           \
        SWAP_DATA16((ar) + 20);   /* dPort */                           \
        SWAP_DATA16((ar) + 22);   /* service_port */                    \
        SWAP_DATA16((ar) + 24);   /* input */                           \
        SWAP_DATA16((ar) + 26);   /* output */                          \
                                                                        \
        _tmp = ar[28];            /* packets */                         \
        ar[28] = ar[30];                                                \
        ar[30] = _tmp;                                                  \
                                                                        \
        /* four bytes: proto(31), flags(32), first_flags(33) tcp_state(34) */ \
        /* three bytes in hand-encoded time_frac[3] */                  \
    }


/*
 *  Unpack the array of bytes 'ar' into a record 'rwRP'
 */
static int _flowcapioRecordUnpack_V5(
    rwIOStruct_t           *rwIOS,
    rwGenericRec_V5        *rwRP,
    uint8_t                *ar)
{
    uint32_t tmp32 = 0;
    uint16_t elapsed = 0;

    /* swap if required */
    if (rwIOS->swapFlag) {
        _flowcapioRecordSwap_V5(ar);
    }

    /* sIP, dIP, bytes */
    rwRecMemSetSIPv4(rwRP, &ar[0]);
    rwRecMemSetDIPv4(rwRP, &ar[4]);
    rwRecMemSetBytes(rwRP, &ar[8]);

    /* sTime seconds, plus fractional seconds in bytes 35,36 */
    memcpy(&tmp32, &ar[12], sizeof(tmp32));
    rwRecSetStartTime(rwRP, ((sktime_t)1000 * tmp32
                             + ((ar[35] << 2)|GET_MASKED_BITS(ar[36], 6, 2))));

    /* elapsed seconds, plus fractional seconds in bytes 36,37 */
    memcpy(&elapsed, &ar[16], sizeof(elapsed));
    rwRecSetElapsed(rwRP, (((uint32_t)1000 * elapsed)
                           + ((GET_MASKED_BITS(ar[36], 0, 6) << 4)
                              | GET_MASKED_BITS(ar[37], 4, 4))));

    /* sPort, dPort, application, input, output */
    rwRecMemSetSPort(rwRP, &ar[18]);
    rwRecMemSetDPort(rwRP, &ar[20]);
    rwRecMemSetApplication(rwRP, &ar[22]);
    rwRecMemSetInput(rwRP, &ar[24]);
    rwRecMemSetOutput(rwRP, &ar[26]);

    /* packets, protocol */
    tmp32 = 0;
#if IS_LITTLE_ENDIAN
    memcpy(&tmp32, &ar[28], 3);
#else
    memcpy((((uint8_t*)&tmp32) + 1), &ar[28], 3);
#endif
    rwRecSetPkts(rwRP, tmp32);
    rwRecSetProto(rwRP, ar[31]);

    /* Flags, Initial flags, TCP State */
    if (ar[34]) {
        /* have extra TCP state information, initial and session flags */
        rwRecSetFlags(rwRP, (ar[32] | ar[33]));
        rwRecSetRestFlags(rwRP, ar[32]);
        rwRecSetInitFlags(rwRP, ar[33]);
        rwRecSetTcpState(rwRP, ar[34]);
    } else {
        /* have a single flags field */
        rwRecSetFlags(rwRP, ar[32]);
    }

    /* Fractional times in bytes 35-37 handled above */

    /* Get sensor from header */
    rwRecSetSensor(rwRP, rwioGetFileSensor(rwIOS));

    return RWIO_OK;
}


/*
 *  Pack the record 'rwRP' into an array of bytes 'ar'
 */
static int _flowcapioRecordPack_V5(
    rwIOStruct_t           *rwIOS,
    const rwGenericRec_V5  *rwRP,
    uint8_t                *ar)
{
    uint32_t tmp32;
    uint16_t elapsed;

    /* sIP, dIP, bytes, sTime */
    rwRecMemGetSIPv4(rwRP, &ar[0]);
    rwRecMemGetDIPv4(rwRP, &ar[4]);
    rwRecMemGetBytes(rwRP, &ar[8]);
    rwRecMemGetStartSeconds(rwRP, &ar[12]);

    /* elapsed */
    if (rwRecGetElapsedSeconds(rwRP) > UINT16_MAX) {
        memset(&ar[16], 0xFF, sizeof(elapsed));
    } else {
        elapsed = (uint16_t)rwRecGetElapsedSeconds(rwRP);
        memcpy(&ar[16], &elapsed, sizeof(elapsed));
    }

    /* sPort, dPort, application, input, output */
    rwRecMemGetSPort(rwRP, &ar[18]);
    rwRecMemGetDPort(rwRP, &ar[20]);
    rwRecMemGetApplication(rwRP, &ar[22]);
    rwRecMemGetInput(rwRP, &ar[24]);
    rwRecMemGetOutput(rwRP, &ar[26]);

    /* packets, protocol */
    tmp32 = rwRecGetPkts(rwRP);
    if (tmp32 > 0xFFFFFF) {
        memset(&ar[28], 0xFF, 3);
    } else {
#if IS_LITTLE_ENDIAN
        memcpy(&ar[28], &tmp32, 3);
#else
        memcpy(&ar[28], (((uint8_t*)&tmp32) + 1), 3);
#endif
    }
    ar[31] = rwRecGetProto(rwRP);

    /* Flags, Initial flags, TCP State */
    ar[34] = rwRecGetTcpState(rwRP);
    if (ar[34]) {
        /* have separate initial and rest flags */
        ar[32] = rwRecGetRestFlags(rwRP);
        ar[33] = rwRecGetInitFlags(rwRP);
    } else {
        /* have a single flags field */
        ar[32] = rwRecGetFlags(rwRP);
        ar[33] = 0;
    }

    /* Fractional time encoding: by hand, always big endian */
    ar[35] = 0xFF & (rwRecGetStartMSec(rwRP) >> 2);
    SET_MASKED_BITS(ar[36], rwRecGetStartMSec(rwRP), 6, 2);
    SET_MASKED_BITS(ar[36], rwRecGetElapsedMSec(rwRP) >> 4, 0, 6);
    ar[37] = 0xFF & (rwRecGetElapsedMSec(rwRP) << 4);

    /* swap if required */
    if (rwIOS->swapFlag) {
        _flowcapioRecordSwap_V5(ar);
    }

    return RWIO_OK;
}


/* ********************************************************************* */

/*
**  FLOWCAP VERSION 4
**
**    uint32_t      sIP;             //  0- 3  Source IP
**    uint32_t      dIP;             //  4- 7  Destination IP
**
**    uint32_t      bytes;           //  8-11  Byte count
**
**    uint32_t      sTime;           // 12-15  Start time as UNIX epoch secs
**
**    uint16_t      elapsed;         // 16-17  Duration of flow in seconds
**    uint16_t      sPort;           // 18-19  Source port
**
**    uint16_t      dPort;           // 20-21  Destination port
**    uint16_t      service_port;    // 22-23  Port reported by flow collector
**
**    uint8_t       input;           // 24     SNMP Input
**    uint8_t       output;          // 25     SNMP Output
**
**    uint8_t       pkts[3]          // 26-28  Count of packets
**    uint8_t       proto            // 29     Protocol
**
**    uint8_t       flags            // 30     tcp_state==0: All TCP Flags
**                                   //        tcp_state==1: Flags !1st pkt
**    uint8_t       first_flags;     // 31     tcp_state==0: 0
**                                   //        tcp_state==1: TCP Flags 1st pkt
**    uint8_t       tcp_state;       // 32     TCP state machine info
**    uint8_t       time_frac[3];    // 33-35  sTime msec & elapsed msec
**
**    uint32_t      payload_hash;    // 36-39  Hash of packet's payload
**
**
**  40 bytes on disk.
*/

#define RECLEN_FLOWCAP_V4 40


/*
 *  Unpack the array of bytes 'ar' into a record 'rwRP'
 */
static int _flowcapioRecordUnpack_V4(
    rwIOStruct_t           *rwIOS,
    rwGenericRec_V5        *rwRP,
    uint8_t                *ar)
{
    int rv;

    /* The first 36 bytes of a V4 are identical to V3 */
    rv = _flowcapioRecordUnpack_V3(rwIOS, rwRP, ar);

    /* swap if required */
    if (rwIOS->swapFlag) {
        /* only need to swap the payload hash */
        SWAP_DATA32((ar) + 36);
    }

    /* Put the payload hash into the nhIP */
    if (rv == RWIO_OK) {
        rwRecMemSetNhIPv4(rwRP, &ar[36]);
    }

    return rv;
}


/*
 *  Pack the record 'rwRP' into an array of bytes 'ar'
 */
static int _flowcapioRecordPack_V4(
    rwIOStruct_t           *rwIOS,
    const rwGenericRec_V5  *rwRP,
    uint8_t                *ar)
{
    int rv;

    /* The first 36 bytes of a V4 are identical to V3 */
    rv = _flowcapioRecordPack_V3(rwIOS, rwRP, ar);

    if (rv == RWIO_OK) {
        rwRecMemGetNhIPv4(rwRP, &ar[36]);
    }

    /* swap if required */
    if (rwIOS->swapFlag) {
        /* only need to swap the payload hash */
        SWAP_DATA32((ar) + 36);
    }

    return rv;
}


/* ********************************************************************* */

/*
**  FLOWCAP VERSION 3
**
**    uint32_t      sIP;             //  0- 3  Source IP
**    uint32_t      dIP;             //  4- 7  Destination IP
**
**    uint32_t      bytes;           //  8-11  Byte count
**
**    uint32_t      sTime;           // 12-15  Start time as UNIX epoch secs
**
**    uint16_t      elapsed;         // 16-17  Duration of flow in seconds
**    uint16_t      sPort;           // 18-19  Source port
**
**    uint16_t      dPort;           // 20-21  Destination port
**    uint16_t      service_port;    // 22-23  Port reported by flow collector
**
**    uint8_t       input;           // 24     SNMP Input
**    uint8_t       output;          // 25     SNMP Output
**
**    uint8_t       pkts[3]          // 26-28  Count of packets
**    uint8_t       proto            // 29     Protocol
**
**    uint8_t       flags            // 30     tcp_state==0: All TCP Flags
**                                   //        tcp_state==1: Flags !1st pkt
**    uint8_t       first_flags;     // 31     tcp_state==0: 0
**                                   //        tcp_state==1: TCP Flags 1st pkt
**    uint8_t       tcp_state;       // 32     TCP state machine info
**    uint8_t       time_frac[3];    // 33-35  sTime msec & elapsed msec
**
**
**  36 bytes on disk.
*/

#define RECLEN_FLOWCAP_V3 36


/*
 *    Byte swap the FLOWCAP v3 record 'ar' in place.
 */
#define _flowcapioRecordSwap_V3(ar)                                     \
    {                                                                   \
        uint8_t _tmp;                                                   \
                                                                        \
        SWAP_DATA32((ar) +  0);   /* sIP */                             \
        SWAP_DATA32((ar) +  4);   /* dIP */                             \
        SWAP_DATA32((ar) +  8);   /* bytes */                           \
        SWAP_DATA32((ar) + 12);   /* sTime */                           \
        SWAP_DATA16((ar) + 16);   /* dur */                             \
        SWAP_DATA16((ar) + 18);   /* sPort */                           \
        SWAP_DATA16((ar) + 20);   /* dPort */                           \
        SWAP_DATA16((ar) + 22);   /* service_port */                    \
        /* Two single byte values: input(24), output(25) */             \
                                                                        \
        _tmp = ar[26];            /* packets */                         \
        ar[26] = ar[28];                                                \
        ar[28] = _tmp;                                                  \
                                                                        \
        /* four bytes: proto(29), flags(30), first_flags(31) tcp_state(32) */ \
        /* three bytes in hand-encoded time_frac[3] */                  \
    }


/*
 *  Unpack the array of bytes 'ar' into a record 'rwRP'
 */
static int _flowcapioRecordUnpack_V3(
    rwIOStruct_t           *rwIOS,
    rwGenericRec_V5        *rwRP,
    uint8_t                *ar)
{
    uint32_t tmp32 = 0;
    uint16_t elapsed = 0;

    /* swap if required */
    if (rwIOS->swapFlag) {
        _flowcapioRecordSwap_V3(ar);
    }

    /* sIP, dIP, bytes */
    rwRecMemSetSIPv4(rwRP, &ar[0]);
    rwRecMemSetDIPv4(rwRP, &ar[4]);
    rwRecMemSetBytes(rwRP, &ar[8]);

    /* sTime seconds, plus fractional seconds in bytes 33,34 */
    memcpy(&tmp32, &ar[12], sizeof(tmp32));
    rwRecSetStartTime(rwRP, ((sktime_t)1000 * tmp32
                             + ((ar[33] << 2)|GET_MASKED_BITS(ar[34], 6, 2))));

    /* elapsed seconds, plus fractional seconds in bytes 34,35 */
    memcpy(&elapsed, &ar[16], sizeof(elapsed));
    rwRecSetElapsed(rwRP, (((uint32_t)1000 * elapsed)
                           + ((GET_MASKED_BITS(ar[34], 0, 6) << 4)
                              | GET_MASKED_BITS(ar[35], 4, 4))));

    /* sPort, dPort, application */
    rwRecMemSetSPort(rwRP, &ar[18]);
    rwRecMemSetDPort(rwRP, &ar[20]);
    rwRecMemSetApplication(rwRP, &ar[22]);

    /* input, output are single byte values */
    rwRecSetInput(rwRP, ar[24]);
    rwRecSetOutput(rwRP, ar[25]);

    /* packets, protocol */
    tmp32 = 0;
#if IS_LITTLE_ENDIAN
    memcpy(&tmp32, &ar[26], 3);
#else
    memcpy((((uint8_t*)&tmp32) + 1), &ar[26], 3);
#endif
    rwRecSetPkts(rwRP, tmp32);
    rwRecSetProto(rwRP, ar[29]);

    /* Flags, Initial flags, TCP State */
    if (ar[32]) {
        /* have extra TCP state information, initial and session flags */
        rwRecSetFlags(rwRP, (ar[30] | ar[31]));
        rwRecSetRestFlags(rwRP, ar[30]);
        rwRecSetInitFlags(rwRP, ar[31]);
        rwRecSetTcpState(rwRP, ar[32]);
    } else {
        /* have a single flags field */
        rwRecSetFlags(rwRP, ar[30]);
    }

    /* Fractional times in bytes 33-35 handled above */

    /* Get sensor from header */
    rwRecSetSensor(rwRP, rwioGetFileSensor(rwIOS));

    return RWIO_OK;
}


/*
 *  Pack the record 'rwRP' into an array of bytes 'ar'
 */
static int _flowcapioRecordPack_V3(
    rwIOStruct_t           *rwIOS,
    const rwGenericRec_V5  *rwRP,
    uint8_t                *ar)
{
    uint32_t tmp32;
    uint16_t elapsed;

    /* sIP, dIP, bytes, sTime */
    rwRecMemGetSIPv4(rwRP, &ar[0]);
    rwRecMemGetDIPv4(rwRP, &ar[4]);
    rwRecMemGetBytes(rwRP, &ar[8]);
    rwRecMemGetStartSeconds(rwRP, &ar[12]);

    /* elapsed */
    if (rwRecGetElapsedSeconds(rwRP) > UINT16_MAX) {
        memset(&ar[16], 0xFF, sizeof(elapsed));
    } else {
        elapsed = (uint16_t)rwRecGetElapsedSeconds(rwRP);
        memcpy(&ar[16], &elapsed, sizeof(elapsed));
    }

    /* sPort, dPort, application */
    rwRecMemGetSPort(rwRP, &ar[18]);
    rwRecMemGetDPort(rwRP, &ar[20]);
    rwRecMemGetApplication(rwRP, &ar[22]);

    /* input, output are single byte values */
    ar[24] = 0xFF & rwRecGetInput(rwRP);
    ar[25] = 0xFF & rwRecGetOutput(rwRP);

    /* packets, protocol */
    tmp32 = rwRecGetPkts(rwRP);
    if (tmp32 > 0xFFFFFF) {
        memset(&ar[26], 0xFF, 3);
    } else {
#if IS_LITTLE_ENDIAN
        memcpy(&ar[26], &tmp32, 3);
#else
        memcpy(&ar[26], (((uint8_t*)&tmp32) + 1), 3);
#endif
    }
    ar[29] = rwRecGetProto(rwRP);

    /* Flags, Initial flags, TCP State */
    ar[32] = rwRecGetTcpState(rwRP);
    if (ar[32]) {
        /* have separate initial and rest flags */
        ar[30] = rwRecGetRestFlags(rwRP);
        ar[31] = rwRecGetInitFlags(rwRP);
    } else {
        /* have a single flags field */
        ar[30] = rwRecGetFlags(rwRP);
        ar[31] = 0;
    }

    /* Fractional time encoding: by hand, always big endian */
    ar[33] = 0xFF & (rwRecGetStartMSec(rwRP) >> 2);
    SET_MASKED_BITS(ar[34], rwRecGetStartMSec(rwRP), 6, 2);
    SET_MASKED_BITS(ar[34], rwRecGetElapsedMSec(rwRP) >> 4, 0, 6);
    ar[35] = 0xFF & (rwRecGetElapsedMSec(rwRP) << 4);

    /* swap if required */
    if (rwIOS->swapFlag) {
        _flowcapioRecordSwap_V3(ar);
    }

    return RWIO_OK;
}



/* ********************************************************************* */

/*
**  FLOWCAP VERSION 2
**
**    uint32_t      sIP;             //  0- 3  Source IP
**    uint32_t      dIP;             //  4- 7  Destination IP
**
**    uint32_t      bytes;           //  8-11  Byte count
**
**    uint32_t      sTime;           // 12-15  Start time as UNIX epoch secs
**
**    uint16_t      elapsed;         // 16-17  Duration of flow in seconds
**    uint16_t      sPort;           // 18-19  Source port
**
**    uint16_t      dPort;           // 20-21  Destination port
**    uint8_t       input;           // 22     SNMP Input
**    uint8_t       output;          // 23     SNMP Output
**
**    uint8_t       pkts[3]          // 24-26  Count of packets
**    uint8_t       proto            // 27     Protocol
**
**    uint8_t       flags            // 28     OR of TCP Flags on all pkts
**    uint8_t       first_flags;     // 29     TOS (ignored)
**
**
**  30 bytes on disk.
*/

#define RECLEN_FLOWCAP_V2 30


/*
 *    Byte swap the FLOWCAP v2 record 'ar' in place.
 */
#define _flowcapioRecordSwap_V2(ar)                             \
    {                                                           \
        uint8_t _tmp;                                           \
                                                                \
        SWAP_DATA32((ar) +  0);   /* sIP */                     \
        SWAP_DATA32((ar) +  4);   /* dIP */                     \
        SWAP_DATA32((ar) +  8);   /* bytes */                   \
        SWAP_DATA32((ar) + 12);   /* sTime */                   \
        SWAP_DATA16((ar) + 16);   /* dur */                     \
        SWAP_DATA16((ar) + 18);   /* sPort */                   \
        SWAP_DATA16((ar) + 20);   /* dPort */                   \
        /* Two single byte values: input(22), output(23) */     \
                                                                \
        _tmp = ar[24];            /* packets */                 \
        ar[24] = ar[26];                                        \
        ar[26] = _tmp;                                          \
                                                                \
        /* three bytes: proto(27), flags(28), TOS(29) */        \
    }


/*
 *  Unpack the array of bytes 'ar' into a record 'rwRP'
 */
static int _flowcapioRecordUnpack_V2(
    rwIOStruct_t           *rwIOS,
    rwGenericRec_V5        *rwRP,
    uint8_t                *ar)
{
    uint32_t tmp32 = 0;
    uint16_t elapsed = 0;

    /* swap if required */
    if (rwIOS->swapFlag) {
        _flowcapioRecordSwap_V2(ar);
    }

    /* sIP, dIP, bytes */
    rwRecMemSetSIPv4(rwRP, &ar[0]);
    rwRecMemSetDIPv4(rwRP, &ar[4]);
    rwRecMemSetBytes(rwRP, &ar[8]);

    /* sTime */
    memcpy(&tmp32, &ar[12], sizeof(tmp32));
    rwRecSetStartTime(rwRP, ((sktime_t)1000 * tmp32));

    /* elapsed */
    memcpy(&elapsed, &ar[16], sizeof(elapsed));
    rwRecSetElapsed(rwRP, ((uint32_t)1000 * elapsed));

    /* sPort, dPort */
    rwRecMemSetSPort(rwRP, &ar[18]);
    rwRecMemSetDPort(rwRP, &ar[20]);

    /* input, output are single byte values */
    rwRecSetInput(rwRP, ar[22]);
    rwRecSetOutput(rwRP, ar[23]);

    /* packets, protocol */
    tmp32 = 0;
#if IS_LITTLE_ENDIAN
    memcpy(&tmp32, &ar[24], 3);
#else
    memcpy((((uint8_t*)&tmp32) + 1), &ar[24], 3);
#endif
    rwRecSetPkts(rwRP, tmp32);
    rwRecSetProto(rwRP, ar[27]);

    /* Flags */
    rwRecSetFlags(rwRP, ar[28]);

    /* Get sensor from header */
    rwRecSetSensor(rwRP, rwioGetFileSensor(rwIOS));

    return RWIO_OK;
}


/*
 *  Pack the record 'rwRP' into an array of bytes 'ar'
 */
static int _flowcapioRecordPack_V2(
    rwIOStruct_t           *rwIOS,
    const rwGenericRec_V5  *rwRP,
    uint8_t                *ar)
{
    uint32_t tmp32;
    uint16_t elapsed;

    /* sIP, dIP, bytes, sTime */
    rwRecMemGetSIPv4(rwRP, &ar[0]);
    rwRecMemGetDIPv4(rwRP, &ar[4]);
    rwRecMemGetBytes(rwRP, &ar[8]);
    rwRecMemGetStartSeconds(rwRP, &ar[12]);

    /* elapsed */
    if (rwRecGetElapsedSeconds(rwRP) > UINT16_MAX) {
        memset(&ar[16], 0xFF, sizeof(elapsed));
    } else {
        elapsed = (uint16_t)rwRecGetElapsedSeconds(rwRP);
        memcpy(&ar[16], &elapsed, sizeof(elapsed));
    }

    /* sPort, dPort */
    rwRecMemGetSPort(rwRP, &ar[18]);
    rwRecMemGetDPort(rwRP, &ar[20]);

    /* input, output are single byte values */
    ar[22] = 0xFF & rwRecGetInput(rwRP);
    ar[23] = 0xFF & rwRecGetOutput(rwRP);

    /* packets, protocol */
    tmp32 = rwRecGetPkts(rwRP);
    if (tmp32 > 0xFFFFFF) {
        memset(&ar[24], 0xFF, 3);
    } else {
#if IS_LITTLE_ENDIAN
        memcpy(&ar[24], &tmp32, 3);
#else
        memcpy(&ar[24], (((uint8_t*)&tmp32) + 1), 3);
#endif
    }
    ar[27] = rwRecGetProto(rwRP);

    /* Flags, TOS */
    ar[28] = rwRecGetFlags(rwRP);
    ar[29] = 0;

    /* swap if required */
    if (rwIOS->swapFlag) {
        _flowcapioRecordSwap_V2(ar);
    }

    return RWIO_OK;
}


/* ********************************************************************* */

/*
 *  Return length of record of specified version, or 0 if no such
 *  version exists.  See skstream_priv.h for details.
 */
uint16_t flowcapioGetRecLen(fileVersion_t vers)
{
    switch (vers) {
      case 2:
        return RECLEN_FLOWCAP_V2;
      case 3:
        return RECLEN_FLOWCAP_V3;
      case 4:
        return RECLEN_FLOWCAP_V4;
      case 5:
        return RECLEN_FLOWCAP_V5;
      default:
        return 0;
    }
}


/*
 *  status = flowcapioPrepare(&rwIOSPtr);
 *
 *    Sets the record version to the default if it is unspecified,
 *    checks that the record format supports the requested record
 *    version, sets the record length, and sets the pack and unpack
 *    functions for this record format and version.
 */
int flowcapioPrepare(rwIOStruct_t *rwIOS)
{
#define FILE_FORMAT "FT_FLOWCAP"
    sk_file_header_t *hdr = rwIOS->silk_hdr;
    int rv = RWIO_OK; /* return value */

    assert(skHeaderGetFileFormat(hdr) == FT_FLOWCAP);

    /* Set version if none was selected by caller */
    if ((rwIOS->io_mode == SK_IO_WRITE)
        && (skHeaderGetRecordVersion(hdr) == SK_RECORD_VERSION_ANY))
    {
        skHeaderSetRecordVersion(hdr, DEFAULT_RECORD_VERSION);
    }

    /* version check; set values based on version */
    switch (skHeaderGetRecordVersion(hdr)) {
      case 5:
        rwIOS->rwUnpackFn = &_flowcapioRecordUnpack_V5;
        rwIOS->rwPackFn   = &_flowcapioRecordPack_V5;
        break;
      case 4:
        rwIOS->rwUnpackFn = &_flowcapioRecordUnpack_V4;
        rwIOS->rwPackFn   = &_flowcapioRecordPack_V4;
        break;
      case 3:
        rwIOS->rwUnpackFn = &_flowcapioRecordUnpack_V3;
        rwIOS->rwPackFn   = &_flowcapioRecordPack_V3;
        break;
      case 2:
        rwIOS->rwUnpackFn = &_flowcapioRecordUnpack_V2;
        rwIOS->rwPackFn   = &_flowcapioRecordPack_V2;
        break;
      case 1:
        /* no longer supported */
      case 0:
      default:
        rv = SKSTREAM_ERR_UNSUPPORT_VERSION;
        goto END;
    }

    rwIOS->recLen = flowcapioGetRecLen(skHeaderGetRecordVersion(hdr));

    /* verify lengths */
    if (rwIOS->recLen == 0) {
        skAppPrintErr("Record length not set for %s version %u",
                      FILE_FORMAT, skHeaderGetRecordVersion(hdr));
        abort();
    }
    if (rwIOS->recLen != skHeaderGetRecordLength(hdr)) {
        if (0 == skHeaderGetRecordLength(hdr)) {
            skHeaderSetRecordLength(hdr, rwIOS->recLen);
        } else {
            skAppPrintErr(("Record length mismatch for %s version %u\n"
                           "\tcode = %" PRIu16 " bytes;  header = %lu bytes"),
                          FILE_FORMAT, skHeaderGetRecordVersion(hdr),
                          rwIOS->recLen,
                          (unsigned long)skHeaderGetRecordLength(hdr));
            abort();
        }
    }

  END:
    return rv;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
