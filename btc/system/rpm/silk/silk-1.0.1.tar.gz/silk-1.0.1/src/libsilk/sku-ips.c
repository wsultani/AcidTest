/*
** Copyright (C) 2007-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  Miscellaneous functions for dealing with IP addresses.
**
*/


#include "silk.h"

RCSIDENT("$SiLK: sku-ips.c 11021 2008-03-24 15:55:23Z mthomas $");

#include "utils.h"


#define SILK_IPV6_POLICY_ENVAR  "SILK_IPV6_POLICY"


/* LOCAL VARIABLES */

/* masks of various sizes used when computing CIDR blocks */
static const uint32_t bitmask[] = {
    /*  0- 3 */ 0xffffffff, 0x7fffffff, 0x3fffffff, 0x1fffffff,
    /*  4- 7 */  0xfffffff,  0x7ffffff,  0x3ffffff,  0x1ffffff,
    /*  8-11 */   0xffffff,   0x7fffff,   0x3fffff,   0x1fffff,
    /* 12-15 */    0xfffff,    0x7ffff,    0x3ffff,    0x1ffff,
    /* 16-19 */     0xffff,     0x7fff,     0x3fff,     0x1fff,
    /* 20-23 */      0xfff,      0x7ff,      0x3ff,      0x1ff,
    /* 24-27 */       0xff,       0x7f,       0x3f,       0x1f,
    /* 28-31 */        0xf,        0x7,        0x3,        0x1,
    /* 32    */        0x0
};


/* FUNCTION DEFINITIONS */


/* compute a CIDR block */
int skComputeCIDR(
    uint32_t    start_ip,
    uint32_t    end_ip,
    uint32_t   *new_start_ip)
{
    uint32_t xor_bits;
    int bit_count;
    uint32_t range_start;

    if (end_ip < start_ip) {
        return -1;
    }
    if (start_ip == end_ip) {
        if (new_start_ip) {
            *new_start_ip = 0;
        }
        return 32;
    }

    /* find the location of the most significant bit where the
     * start_ip and end_ip differ by taking the bitwise XOR of them
     * and then masking bits until we find the value. */
    xor_bits = (start_ip ^ end_ip);
    for (bit_count = 31;
         (bitmask[bit_count] <= xor_bits) && (bit_count > 0);
         --bit_count);

    /* the range is too wide; tighten it until we match the start of
     * the range */
    do {
        /* need to back-up one */
        ++bit_count;

        /* get the range of IPs covered by 'bit_count' bits */
        range_start = (start_ip & ~(bitmask[bit_count]));
    } while (range_start < start_ip);

    /* assert that the CIDR block is within the limits */
    assert(range_start == start_ip);
    assert((range_start | (bitmask[bit_count])) <= end_ip);

    if (new_start_ip) {
        /* compute the start of the next CIDR block, which is the IP
         * after the block we just finished.  In the case of
         * roll-over, the 'else' clause will be invoked, and we will
         * return 0. */
        start_ip = 1 + (range_start | (bitmask[bit_count]));
        if (start_ip > end_ip) {
            *new_start_ip = 0;
        } else {
            *new_start_ip = start_ip;
        }
    }
    return bit_count;
}


int skCIDR2IPRange(
    const skipaddr_t   *ipaddr,
    uint32_t            cidr,
    skipaddr_t         *min_ip,
    skipaddr_t         *max_ip)
{
#if SK_ENABLE_IPV6
    if (skipaddrIsV6(ipaddr)) {
        uint8_t ip6[16];
        uint8_t min6[16];
        uint8_t max6[16];
        uint32_t i;
        uint32_t bits;

        if (cidr > 128) {
            return -1;
        }

        skipaddrGetV6(ipaddr, &ip6);
        memcpy(min6, ip6, sizeof(ip6));
        memcpy(max6, ip6, sizeof(ip6));

        for (i = 0, bits = 0; i < 16; ++i, bits += 8) {
            if (cidr <= bits) {
                /* complete control on this block */
                min6[i] = 0;
                max6[i] = 0xFF;
            } else if (cidr >= (bits + 8)) {
                /* no effect on this block */
                min6[i] = ip6[i];
                max6[i] = ip6[i];
            } else {
                /* some effect */
                min6[i] = ip6[i] & ~(0xFF >> (cidr - bits));
                max6[i] = ip6[i] | (0xFF >> (cidr - bits));
            }
        }

        skipaddrSetV6(min_ip, &min6);
        skipaddrSetV6(max_ip, &max6);
    } else
#endif /* SK_ENABLE_IPV6 */
    {
        uint32_t ip4;
        uint32_t min4;
        uint32_t max4;

        if (cidr > 32) {
            return -1;
        }

        ip4 = skipaddrGetV4(ipaddr);
        if (cidr == 32) {
            min4 = ip4;
            max4 = ip4;
        } else {
            min4 = ip4 & ~(UINT32_MAX >> cidr);
            max4 = ip4 | (UINT32_MAX >> cidr);
        }

        skipaddrSetV4(min_ip, &min4);
        skipaddrSetV4(max_ip, &max4);
    }

    return 0;
}


char *skipaddrString(char *outbuf, const skipaddr_t *ip, uint32_t ip_flags)
{
#if SK_ENABLE_IPV6
    if (skipaddrIsV6(ip)) {
        switch (ip_flags) {
          case SKIPADDR_DECIMAL:
          case SKIPADDR_CANONICAL:
#ifdef HAVE_INET_NTOP
#  if    SK_NUM2DOT_STRLEN < INET6_ADDRSTRLEN
#    error "SK_NUM2DOT_STRLEN is not big enough"
#  endif
            if (NULL == inet_ntop(AF_INET6, &(ip->ip_ip.ipu_ipv6), outbuf,
                                  SK_NUM2DOT_STRLEN))
            {
                outbuf[0] = '\0';
            }
            break;
#endif /* HAVE_INET_NTOP */

          case SKIPADDR_ZEROPAD:
            /* Convert integer 0 to string "000.000.000.000" */
            snprintf(outbuf, SK_NUM2DOT_STRLEN,
                     ("%02x%02x:%02x%02x:%02x%02x:%02x%02x"
                      ":%02x%02x:%02x%02x:%02x%02x:%02x%02x"),
                     ip->ip_ip.ipu_ipv6[ 0], ip->ip_ip.ipu_ipv6[ 1],
                     ip->ip_ip.ipu_ipv6[ 2], ip->ip_ip.ipu_ipv6[ 3],
                     ip->ip_ip.ipu_ipv6[ 4], ip->ip_ip.ipu_ipv6[ 5],
                     ip->ip_ip.ipu_ipv6[ 6], ip->ip_ip.ipu_ipv6[ 7],
                     ip->ip_ip.ipu_ipv6[ 8], ip->ip_ip.ipu_ipv6[ 9],
                     ip->ip_ip.ipu_ipv6[10], ip->ip_ip.ipu_ipv6[11],
                     ip->ip_ip.ipu_ipv6[12], ip->ip_ip.ipu_ipv6[13],
                     ip->ip_ip.ipu_ipv6[14], ip->ip_ip.ipu_ipv6[15]);
            break;
        }
    } else
#endif
    {
        switch (ip_flags) {
          case SKIPADDR_CANONICAL:
            /* Convert integer 0 to string "0.0.0.0" */
            snprintf(outbuf, SK_NUM2DOT_STRLEN, "%u.%u.%u.%u",
                     ((ip->ip_ip.ipu_ipv4 >> 24) & 0xFF),
                     ((ip->ip_ip.ipu_ipv4 >> 16) & 0xFF),
                     ((ip->ip_ip.ipu_ipv4 >> 8) & 0xFF),
                     (ip->ip_ip.ipu_ipv4 & 0xFF));
            break;

          case SKIPADDR_ZEROPAD:
            /* Convert integer 0 to string "000.000.000.000" */
            snprintf(outbuf, SK_NUM2DOT_STRLEN, "%03u.%03u.%03u.%03u",
                     ((ip->ip_ip.ipu_ipv4 >> 24) & 0xFF),
                     ((ip->ip_ip.ipu_ipv4 >> 16) & 0xFF),
                     ((ip->ip_ip.ipu_ipv4 >> 8) & 0xFF),
                     (ip->ip_ip.ipu_ipv4 & 0xFF));
            break;

          case SKIPADDR_DECIMAL:
            snprintf(outbuf, SK_NUM2DOT_STRLEN, "%u", ip->ip_ip.ipu_ipv4);
            break;
        }
    }

    outbuf[SK_NUM2DOT_STRLEN-1] = '\0';
    return outbuf;
}


static struct policies_st {
    sk_ipv6policy_t     policy;
    const char         *name;
    const char         *description;
} policies[] = {
    {SK_IPV6POLICY_IGNORE, "ignore",
     "Completely ignore IPv6 flows"},
    {SK_IPV6POLICY_ASV4,   "asv4",
     "Convert IPv6 flows to IPv4 if possible, else ignore"},
    {SK_IPV6POLICY_MIX,    "mix",
     "Process a mixture of IPv4 and IPv6 flows"},
    {SK_IPV6POLICY_FORCE,  "force",
     "Force IPv4 flows to be converted to IPv6"},
    {SK_IPV6POLICY_ONLY,   "only",
     "Only process flows that were marked as IPv6"}
};


/* Parse an IPv6 policy.  Return 0 if it is valid, -1 otherwise. */
int skIPv6PolicyParse(
    sk_ipv6policy_t    *ipv6_policy,
    const char         *policy_name,
    const char         *option_name)
{
    size_t len = strlen(policy_name);
    size_t i;

    for (i = 0; i < sizeof(policies)/sizeof(struct policies_st); ++i) {
        if (len < strlen(policies[i].name)) {
            if (0 == strncmp(policies[i].name, policy_name, len)) {
                *ipv6_policy = policies[i].policy;
                return 0;
            }
        } else if (0 == strcmp(policies[i].name, policy_name)) {
            *ipv6_policy = policies[i].policy;
            return 0;
        }
    }

    if (option_name) {
        skAppPrintErr("Invalid %s '%s'", option_name, policy_name);
    }
    return -1;
}


/* store the default policy from the application */
static sk_ipv6policy_t ipv6_default;

/* support for the option */
#define OPT_IPV6_POLICY  0

static struct option ipv6_policy_options[] = {
    {"ipv6-policy",         REQUIRED_ARG, 0, OPT_IPV6_POLICY},
    {0,0,0,0}               /* sentinel */
};

/* handler for the option */
static int ipv6PolicyHandler(
    clientData  cData,
    int         opt_index,
    char       *opt_arg)
{
    sk_ipv6policy_t *ipv6_policy = (sk_ipv6policy_t*)cData;

    switch (opt_index) {
      case OPT_IPV6_POLICY:
        if (skIPv6PolicyParse(ipv6_policy, opt_arg,
                              ipv6_policy_options[opt_index].name))
        {
            return 1;
        }
        break;

      default:
        skAppPrintErr("Bad value %d passed to ipv6PolicyHandler",
                      opt_index);
        abort();
    }

    return 0;
}


int skIPv6PolicyOptionsRegister(sk_ipv6policy_t *ipv6_policy)
{
    sk_ipv6policy_t tmp_policy;
    char *env;

    assert(ipv6_policy);

    /* store the default policy wanted by the application */
    ipv6_default = *ipv6_policy;

    /* get the default from the environment */
    env = getenv(SILK_IPV6_POLICY_ENVAR);
    if (env) {
        if (skIPv6PolicyParse(&tmp_policy, env, SILK_IPV6_POLICY_ENVAR) == 0) {
            *ipv6_policy = tmp_policy;
        }
    }

#if !SK_ENABLE_IPV6
    /* Force an IPv4-only SiLK to ignore any IPv6 flows */
    ipv6_default = SK_IPV6POLICY_IGNORE;
    *ipv6_policy = ipv6_default;

    /* Register the option for compatibility with an IPv6-enabled
     * silk, but pass 'ipv6_default' as the clientData, so the user's
     * value does not modify the value the application uses. */
    return skOptionsRegister(ipv6_policy_options, &ipv6PolicyHandler,
                             (clientData)&ipv6_default);
#else
    /* add the option */
    return skOptionsRegister(ipv6_policy_options, &ipv6PolicyHandler,
                             (clientData)ipv6_policy);
#endif  /* SK_ENABLE_IPV6 */
}


void skIPv6PolicyUsage(FILE *fh)
{
    size_t i;

    fprintf(fh, "--%s %s. ",
            ipv6_policy_options[OPT_IPV6_POLICY].name,
            SK_OPTION_HAS_ARG(ipv6_policy_options[OPT_IPV6_POLICY]));
#if !SK_ENABLE_IPV6
    fprintf(fh, ("No IPv6 support available; IPv6 flows are always ignored\n"
                 "\tregardless of the value passed to this switch."
                 " Legal values:\n"));
#else
    fprintf(fh, "Set policy for IPv4/IPv6 flows. ");
    for (i = 0; i < sizeof(policies)/sizeof(struct policies_st); ++i) {
        if (ipv6_default != policies[i].policy) {
            continue;
        }
        fprintf(fh, "Def. %s. ", policies[i].name);
        break;
    }
    fprintf(fh, "Choices:\n");
#endif
    for (i = 0; i < sizeof(policies)/sizeof(struct policies_st); ++i) {
        fprintf(fh, "\t%-6s  - %s\n",
                policies[i].name, policies[i].description);
    }
}


#if SK_ENABLE_IPV6
int skipaddrCompare(const skipaddr_t *addr1, const skipaddr_t *addr2)
{
    skipaddr_t tmp;

    if (addr1->ip_is_v6) {
        if (addr2->ip_is_v6) {
            return memcmp(&(addr1->ip_ip.ipu_ipv6), &(addr2->ip_ip.ipu_ipv6),
                          16);
        }
        skipaddrV4toV6(addr2, &tmp);
        return memcmp(&(addr1->ip_ip.ipu_ipv6), &tmp, 16);
    }
    if (addr2->ip_is_v6) {
        skipaddrV4toV6(addr1, &tmp);
        return memcmp(&tmp, &(addr2->ip_ip.ipu_ipv6), 16);
    }
    if (addr1->ip_ip.ipu_ipv4 < addr2->ip_ip.ipu_ipv4) {
        return -1;
    }
    if (addr1->ip_ip.ipu_ipv4 > addr2->ip_ip.ipu_ipv4) {
        return 1;
    }
    return 0;
}
#endif /* SK_ENABLE_IPV6 */


/* *************    IP WILDCARDS   ******************* */


void skIPWildcardClear(skIPWildcard_t *ipwild)
{
    assert(ipwild);
    memset(ipwild, 0, sizeof(skIPWildcard_t));
    memset(ipwild->m_min, 0xFF, sizeof(ipwild->m_min));
}



#if SK_ENABLE_IPV6
int skIPWildcardCheckIp(const skIPWildcard_t *ipwild, const skipaddr_t *ipaddr)
{
    assert(ipwild);
    assert(ipaddr);

    if (skIPWildcardIsV6(ipwild)) {
        uint8_t ip6[16];
        int i;

        if (skipaddrIsV6(ipaddr)) {
            skipaddrGetV6(ipaddr, ip6);
        } else {
            skipaddr_t tmpip;
            skipaddrV4toV6(ipaddr, &tmpip);
            skipaddrGetV6(&tmpip, ip6);
        }

        for (i = 0; i < 8; ++i) {
            if (!_IPWILD_BLOCK_IS_SET(ipwild, i, ip6[2*i] << 8 | ip6[2*i+1])) {
                return 0;
            }
        }

        return 1;
    }

    if (skipaddrIsV6(ipaddr)) {
        skipaddr_t tmpip;
        const uint8_t ip4in6[12] = {0x0, 0x0, 0x0, 0x0,  0x0,  0x0,
                                    0x0, 0x0, 0x0, 0x0, 0xFF, 0xFF};
        uint8_t ip6[16];
        uint32_t ip4;

        skipaddrGetV6(ipaddr, ip6);
        if (memcmp(ip6, ip4in6, sizeof(ip4in6)) != 0) {
            return 0;
        }

        memcpy(&ip4, &ip6[12], 4);
        ip4 = ntohl(ip4);
        skipaddrSetV4(&tmpip, &ip4);
        return _IPWILD_IPv4_IS_SET(ipwild, &tmpip);
    }

    return _IPWILD_IPv4_IS_SET(ipwild, ipaddr);
}


/* Bind iterator to an ipwildcard, forcing IPv6 addresses */
int skIPWildcardIteratorBindV6(
    skIPWildcardIterator_t *out_iter,
    const skIPWildcard_t   *ipwild)
{
    if (skIPWildcardIteratorBind(out_iter, ipwild)) {
        return -1;
    }
    out_iter->force_ipv6 = 1;
    return 0;
}
#endif /* SK_ENABLE_IPV6 */


/* Bind iterator to an ipwildcard */
int skIPWildcardIteratorBind(
    skIPWildcardIterator_t *out_iter,
    const skIPWildcard_t   *ipwild)
{
    assert(out_iter);
    if (ipwild == NULL) {
        return -1;
    }

    out_iter->ipwild = ipwild;
    out_iter->force_ipv6 = 0;
    skIPWildcardIteratorReset(out_iter);

    return 0;
}


/* Get next entry in tree */
skIteratorStatus_t skIPWildcardIteratorNext(
    skIPWildcardIterator_t *iter,
    skipaddr_t             *ipaddr)
{
    int i;

    assert(ipaddr);

    /* the stopping condition */
    if (iter->no_more_entries) {
        return SK_ITERATOR_NO_MORE_ENTRIES;
    }

    /* iterator is looking at current value */
#if SK_ENABLE_IPV6
    if (skIPWildcardIsV6(iter->ipwild)) {
        uint8_t ip6[16];
        for (i = 0; i < 8; ++i) {
            ip6[2*i] = 0xFF & (iter->i_block[i] >> 8);
            ip6[2*i + 1] = 0xFF & iter->i_block[i];
        }
        skipaddrSetV6(ipaddr, ip6);
    } else if (iter->force_ipv6) {
        uint8_t ip6[16] = {0,0,0,0, 0,0,0,0, 0,0,0xFF,0xFF, 0,0,0,0};
        for (i = 0; i < 4; ++i) {
            ip6[12+i] = (uint8_t)(iter->i_block[i]);
        }
        skipaddrSetV6(ipaddr, ip6);
    } else
#endif /* SK_ENABLE_IPV6 */
    {
        uint32_t ip4 = ((iter->i_block[0] << 24) |
                        (iter->i_block[1] << 16) |
                        (iter->i_block[2] <<  8) |
                        (iter->i_block[3]));
        skipaddrSetV4(ipaddr, &ip4);
    }

    /* find the next value */
    for (i = iter->ipwild->num_blocks - 1; i >= 0; --i) {
        /* can we increment the i'th block? */
        if (iter->i_block[i] < iter->ipwild->m_max[i]) {
            /* yes */
            break;
        }
        /* no; reset it and try the block to the left */
        iter->i_block[i] = iter->ipwild->m_min[i];
    }

    /* did we run out of blocks? */
    if (i == -1) {
        iter->no_more_entries = 1;
    } else {
        assert(_IPWILD_BLOCK_IS_SET(iter->ipwild, i, iter->ipwild->m_max[i]));
        do {
            ++iter->i_block[i];
        } while ( !_IPWILD_BLOCK_IS_SET(iter->ipwild, i, iter->i_block[i]));
    }

    return SK_ITERATOR_OK;
}


/* Reset iterator */
void skIPWildcardIteratorReset(skIPWildcardIterator_t *iter)
{
    int i;

    assert(iter);
    iter->no_more_entries = 0;
    for (i = 0; i < 8; ++i) {
        iter->i_block[i] = iter->ipwild->m_min[i];
    }
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
