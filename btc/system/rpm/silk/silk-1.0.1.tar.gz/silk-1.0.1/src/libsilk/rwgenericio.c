/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
** rwgenericio.c
**
** Suresh L Konda
**      routines to do io stuff with generic records.
*/

#include "silk.h"

RCSIDENT("$SiLK: rwgenericio.c 10877 2008-03-11 16:51:13Z mthomas $");

#include "skstream_priv.h"


/* Version to use when SK_RECORD_VERSION_ANY is specified */
#define DEFAULT_RECORD_VERSION 5


/* ********************************************************************* */

/*
**  RWGENERIC VERSION 5
**
**    int64_t       sTime;       //  0- 7  Flow start time as milliseconds
**                               //        since UNIX epoch
**
**    uint32_t      elapsed;     //  8-11  Duration of flow in milliseconds
**                               //        (Allows for a 49 day flow)
**
**    uint16_t      sPort;       // 12-13  Source port
**    uint16_t      dPort;       // 14-15  Destination port
**
**    uint8_t       proto;       // 16     IP protocol
**    flowtypeID_t  flow_type;   // 17     Class & Type info
**    sensorID_t    sID;         // 18-19  Sensor ID
**
**    uint8_t       flags;       // 20     OR of all flags (Netflow flags)
**    uint8_t       init_flags;  // 21     TCP flags in first packet
**                               //        or blank for "legacy" data
**    uint8_t       rest_flags;  // 22     TCP flags on non-initial packet
**                               //        or blank for "legacy" data
**    uint8_t       tcp_state;   // 23     TCP state machine info (below)
**
**    uint16_t      application; // 24-25  Indication of type of traffic
**    uint16_t      memo;        // 26-27  Application specific field
**
**    uint16_t      input;       // 28-29  Router incoming SNMP interface
**    uint16_t      output;      // 30-31  Router outgoing SNMP interface
**
**    uint32_t      pkts;        // 32-35  Count of packets
**    uint32_t      bytes;       // 36-39  Count of bytes
**
**    uint32_t      sIP;         // 40-43  Source IP
**    uint32_t      dIP;         // 44-47  Destination IP
**    uint32_t      nhIP;        // 48-51  Router Next Hop IP
**
**
**  52 bytes on disk.
*/

#define RECLEN_RWGENERIC_V5 52


/*
 *    Byte swap the RWGENERIC v5 record 'ar' in place.
 */
#define _genericioRecordSwap_V5(ar)                             \
    {                                                           \
        SWAP_DATA64((ar) +  0);   /* sTime */                   \
        SWAP_DATA32((ar) +  8);   /* elapsed */                 \
        SWAP_DATA16((ar) + 12);   /* sPort */                   \
        SWAP_DATA16((ar) + 14);   /* dPort */                   \
        /* Two single bytes: (16)proto, (17)flow_type */        \
        SWAP_DATA16((ar) + 18);   /* sID */                     \
        /* Four single bytes: (20)flags, (21)init_flags,        \
         *                    (22)rest_flags, (23)tcp_state */  \
        SWAP_DATA16((ar) + 24);   /* application */             \
        SWAP_DATA16((ar) + 26);   /* memo */                    \
        SWAP_DATA16((ar) + 28);   /* input */                   \
        SWAP_DATA16((ar) + 30);   /* output */                  \
        SWAP_DATA32((ar) + 32);   /* pkts */                    \
        SWAP_DATA32((ar) + 36);   /* bytes */                   \
        SWAP_DATA32((ar) + 40);   /* sIP */                     \
        SWAP_DATA32((ar) + 44);   /* dIP */                     \
        SWAP_DATA32((ar) + 48);   /* nhIP */                    \
    }


/*
 *  Unpack the array of bytes 'ar' into a record 'rwRP'
 */
static int _genericioRecordUnpack_V5(
    rwIOStruct_t     *rwIOS,
    rwGenericRec_V5  *rwRP,
    uint8_t          *ar)
{
    /* swap if required */
    if (rwIOS->swapFlag) {
        _genericioRecordSwap_V5(ar);
    }

#if  !SK_ENABLE_IPV6
    memcpy(rwRP, ar, RECLEN_RWGENERIC_V5);
#else
    rwRecMemSetStartTime(rwRP, &ar[0]);
    rwRecMemSetElapsed(rwRP, &ar[8]);
    rwRecMemSetSPort(rwRP, &ar[12]);
    rwRecMemSetDPort(rwRP, &ar[14]);
    rwRecMemSetProto(rwRP, &ar[16]);
    rwRecMemSetFlowType(rwRP, &ar[17]);
    rwRecMemSetSensor(rwRP, &ar[18]);
    rwRecMemSetFlags(rwRP, &ar[20]);
    rwRecMemSetInitFlags(rwRP, &ar[21]);
    rwRecMemSetRestFlags(rwRP, &ar[22]);
    rwRecMemSetTcpState(rwRP, &ar[23]);
    rwRecMemSetApplication(rwRP, &ar[24]);
    rwRecMemSetMemo(rwRP, &ar[26]);
    rwRecMemSetInput(rwRP, &ar[28]);
    rwRecMemSetOutput(rwRP, &ar[30]);
    rwRecMemSetPkts(rwRP, &ar[32]);
    rwRecMemSetBytes(rwRP, &ar[36]);
    rwRecMemSetSIPv4(rwRP, &ar[40]);
    rwRecMemSetDIPv4(rwRP, &ar[44]);
    rwRecMemSetNhIPv4(rwRP, &ar[48]);
#endif
    return RWIO_OK;
}


/*
 *  Pack the record 'rwRP' into an array of bytes 'ar'
 */
static int _genericioRecordPack_V5(
    rwIOStruct_t           *rwIOS,
    const rwGenericRec_V5  *rwRP,
    uint8_t                *ar)
{
#if  !SK_ENABLE_IPV6
    memcpy(ar, rwRP, RECLEN_RWGENERIC_V5);
#else
    rwRecMemGetStartTime(rwRP, &ar[0]);
    rwRecMemGetElapsed(rwRP, &ar[8]);
    rwRecMemGetSPort(rwRP, &ar[12]);
    rwRecMemGetDPort(rwRP, &ar[14]);
    rwRecMemGetProto(rwRP, &ar[16]);
    rwRecMemGetFlowType(rwRP, &ar[17]);
    rwRecMemGetSensor(rwRP, &ar[18]);
    rwRecMemGetFlags(rwRP, &ar[20]);
    rwRecMemGetInitFlags(rwRP, &ar[21]);
    rwRecMemGetRestFlags(rwRP, &ar[22]);
    rwRecMemGetTcpState(rwRP, &ar[23]);
    rwRecMemGetApplication(rwRP, &ar[24]);
    rwRecMemGetMemo(rwRP, &ar[26]);
    rwRecMemGetInput(rwRP, &ar[28]);
    rwRecMemGetOutput(rwRP, &ar[30]);
    rwRecMemGetPkts(rwRP, &ar[32]);
    rwRecMemGetBytes(rwRP, &ar[36]);
    rwRecMemGetSIPv4(rwRP, &ar[40]);
    rwRecMemGetDIPv4(rwRP, &ar[44]);
    rwRecMemGetNhIPv4(rwRP, &ar[48]);
#endif
    /* swap if required */
    if (rwIOS->swapFlag) {
        _genericioRecordSwap_V5(ar);
    }

    return RWIO_OK;
}


/* ********************************************************************* */

/*
**  RWGENERIC VERSION 3
**  RWGENERIC VERSION 4
**
**    uint32_t      sIP;             //  0- 3  Source IP
**    uint32_t      dIP;             //  4- 7  Destination IP
**
**    uint16_t      sPort;           //  8- 9  Source port
**    uint16_t      dPort;           // 10-11  Destination port
**
**    uint32_t      nhIP;            // 12-15  Router Next Hop IP
**    uint16_t      input;           // 16-17  Router incoming SNMP interface
**    uint16_t      output;          // 18-19  Router outgoing SNMP interface
**
**    uint32_t      sTime;           // 20-23  Start time of flow-epoch secs
**    uint32_t      elapsed;         // 24-27  Duration of flow
**
**    uint32_t      pkts;            // 28-31  Count of packets
**    uint32_t      bytes;           // 32-35  Count of bytes
**
**    uint8_t       proto;           // 36     IP protocol
**    uint8_t       flow_type;       // 37     Class & Type info
**    sensorID_t sID;                // 38-39  Sensor ID
**
**    uint8_t       flags;           // 40     OR of all flags (Netflow flags)
**    uint8_t       init_flags;      // 41     TCP flags in first packet
**                                   //        or blank for "legacy" data
**    uint8_t       rest_flags;      // 42     TCP flags on non-initial packet
**                                   //        or blank for "legacy" data
**    uint8_t       tcp_state;       // 43     TCP state machine information
**
**    uint32_t      bpp;             // 44-47  Bytes-per-Packet
**
**    uint16_t      sTime_msec;      // 48-49  Start time fraction (millisec)
**    uint16_t      elapsed_msec;    // 50-51  Elapsed time fraction (millisec)
**
**    uint16_t      application;     // 52-53  Type of traffic
**    uint8_t[2]                     // 54-55  PADDING
**
**  56 bytes on disk.
*/

#define RECLEN_RWGENERIC_V3 56
#define RECLEN_RWGENERIC_V4 RECLEN_RWGENERIC_V3


/*
 *    Byte swap the RWGENERIC v3 record 'ar' in place.
 */
#define _genericioRecordSwap_V3(ar)                             \
    {                                                           \
        SWAP_DATA32((ar) +  0);   /* sIP */                     \
        SWAP_DATA32((ar) +  4);   /* dIP */                     \
        SWAP_DATA16((ar) +  8);   /* sPort */                   \
        SWAP_DATA16((ar) + 10);   /* dPort */                   \
        SWAP_DATA32((ar) + 12);   /* nhIP */                    \
        SWAP_DATA16((ar) + 16);   /* input */                   \
        SWAP_DATA16((ar) + 18);   /* output */                  \
        SWAP_DATA32((ar) + 20);   /* sTime */                   \
        SWAP_DATA32((ar) + 24);   /* elapsed */                 \
        SWAP_DATA32((ar) + 28);   /* pkts */                    \
        SWAP_DATA32((ar) + 32);   /* bytes */                   \
        /* Two single bytes: (36)proto, (37)flow_type */        \
        SWAP_DATA16((ar) + 38);   /* sID */                     \
        /* Four single bytes: (40)flags, (41)init_flags,        \
         *                    (42)rest_flags, (43)tcp_state */  \
        SWAP_DATA32((ar) + 44);   /* bpp */                     \
        SWAP_DATA16((ar) + 48);   /* sTime_msec */              \
        SWAP_DATA16((ar) + 50);   /* elapsed_msec */            \
        SWAP_DATA16((ar) + 52);   /* application */             \
    }


/*
 *  Unpack the array of bytes 'ar' into a record 'rwRP'
 */
static int _genericioRecordUnpack_V3(
    rwIOStruct_t     *rwIOS,
    rwGenericRec_V5  *rwRP,
    uint8_t          *ar)
{
    uint32_t quot;
    uint16_t rem;

    /* swap if required */
    if (rwIOS->swapFlag) {
        _genericioRecordSwap_V3(ar);
    }

    /* sIP, dIP, sPort, dPort, nhIP, input, output */
    rwRecMemSetSIPv4(rwRP, &ar[0]);
    rwRecMemSetDIPv4(rwRP, &ar[4]);
    rwRecMemSetSPort(rwRP, &ar[8]);
    rwRecMemSetDPort(rwRP, &ar[10]);
    rwRecMemSetNhIPv4(rwRP, &ar[12]);
    rwRecMemSetInput(rwRP, &ar[16]);
    rwRecMemSetOutput(rwRP, &ar[18]);

    /* sTime, sTime_msec */
    memcpy(&quot, &ar[20], 4);
    memcpy(&rem, &ar[48], 2);
    rwRecSetStartTime(rwRP, ((sktime_t)1000 * quot + rem));

    /* elapsed, elapsed_msec */
    memcpy(&quot, &ar[24], 4);
    memcpy(&rem, &ar[50], 2);
    rwRecSetElapsed(rwRP, (1000 * quot + rem));

    /* pkts, bytes */
    rwRecMemSetPkts(rwRP, &ar[28]);
    rwRecMemSetBytes(rwRP, &ar[32]);

    /* proto, flowtype, sensor, flags, init_flags, rest_flags, tcp_state */
    rwRecMemSetProto(rwRP, &ar[36]);
    rwRecMemSetFlowType(rwRP, &ar[37]);
    rwRecMemSetSensor(rwRP, &ar[38]);
    rwRecMemSetFlags(rwRP, &ar[40]);
    rwRecMemSetInitFlags(rwRP, &ar[41]);
    rwRecMemSetRestFlags(rwRP, &ar[42]);
    rwRecMemSetTcpState(rwRP, &ar[43]);

    /* bpp field no longer exists */
    /* sTime_msec (above), elapsed_msec (above) */

    /* application */
    rwRecMemSetApplication(rwRP, &ar[52]);

    return RWIO_OK;
}


/*
 *  Pack the record 'rwRP' into an array of bytes 'ar'
 */
static int _genericioRecordPack_V3(
    rwIOStruct_t           *rwIOS,
    const rwGenericRec_V5  *rwRP,
    uint8_t                *ar)
{
    imaxdiv_t idiv;
    uint32_t quot;
    uint16_t rem;

    /* sIP, dIP, sPort, dPort, nhIP, input, output */
    rwRecMemGetSIPv4(rwRP, &ar[0]);
    rwRecMemGetDIPv4(rwRP, &ar[4]);
    rwRecMemGetSPort(rwRP, &ar[8]);
    rwRecMemGetDPort(rwRP, &ar[10]);
    rwRecMemGetNhIPv4(rwRP, &ar[12]);
    rwRecMemGetInput(rwRP, &ar[16]);
    rwRecMemGetOutput(rwRP, &ar[18]);

    /* sTime, sTime_msec */
    idiv = imaxdiv(rwRecGetStartTime(rwRP), 1000);
    quot = (uint32_t)idiv.quot;
    rem = (uint16_t)idiv.rem;
    memcpy(&ar[20], &quot, 4);
    memcpy(&ar[48], &rem, 2);

    /* elapsed, elapsed_msec */
    idiv = imaxdiv(rwRecGetElapsed(rwRP), 1000);
    quot = (uint32_t)idiv.quot;
    rem = (uint16_t)idiv.rem;
    memcpy(&ar[24], &quot, 4);
    memcpy(&ar[50], &rem, 2);

    /* pkts, bytes */
    rwRecMemGetPkts(rwRP, &ar[28]);
    rwRecMemGetBytes(rwRP, &ar[32]);

    /* proto, flowtype, sensor, flags, init_flags, rest_flags, tcp_state */
    rwRecMemGetProto(rwRP, &ar[36]);
    rwRecMemGetFlowType(rwRP, &ar[37]);
    rwRecMemGetSensor(rwRP, &ar[38]);
    rwRecMemGetFlags(rwRP, &ar[40]);
    rwRecMemGetInitFlags(rwRP, &ar[41]);
    rwRecMemGetRestFlags(rwRP, &ar[42]);
    rwRecMemGetTcpState(rwRP, &ar[43]);

    /* bpp field no longer exists */
    memset(&ar[44], 0, 4);

    /* sTime_msec (above), elapsed_msec (above) */

    /* application */
    rwRecMemGetApplication(rwRP, &ar[52]);

    /* padding */
    memset(&ar[54], 0, 2);

    /* swap if required */
    if (rwIOS->swapFlag) {
        _genericioRecordSwap_V3(ar);
    }

    return RWIO_OK;
}


/* ********************************************************************* */

/*
**  RWGENERIC VERSION 2
**
**    uint32_t      sIP;             //  0- 3  Source IP
**    uint32_t      dIP;             //  4- 7  Destination IP
**
**    uint16_t      sPort;           //  8- 9  Source port
**    uint16_t      dPort;           // 10-11  Destination port
**
**    uint32_t      nhIP;            // 12-15  Router Next Hop IP
**    uint16_t      input;           // 16-17  Router incoming SNMP interface
**    uint16_t      output;          // 18-19  Router outgoing SNMP interface
**
**    uint32_t      sTime;           // 20-23  Start time of flow-epoch secs
**    uint32_t      elapsed;         // 24-27  Duration of flow
**
**    uint32_t      pkts;            // 28-31  Count of packets
**    uint32_t      bytes;           // 32-35  Count of bytes
**
**    uint8_t       proto;           // 36     IP protocol
**    uint8_t       flow_type;       // 37     Class & Type info
**    sensorID_t sID;                // 38-39  Sensor ID
**
**    uint8_t       flags;           // 40     OR of all flags (Netflow flags)
**    uint8_t       init_flags;      // 41     TCP flags in first packet
**                                   //        or blank for "legacy" data
**    uint8_t       rest_flags;      // 42     TCP flags on non-initial packet
**                                   //        or blank for "legacy" data
**    uint8_t       tcp_state;       // 43     TCP state machine information
**
**    uint32_t      bpp;             // 44-47  Bytes-per-Packet
**
**
**  48 bytes on disk.
*/

#define RECLEN_RWGENERIC_V2 48


/*
 *    Byte swap the RWGENERIC v2 record 'ar' in place.
 */
#define _genericioRecordSwap_V2(ar)                             \
    {                                                           \
        SWAP_DATA32((ar) +  0);   /* sIP */                     \
        SWAP_DATA32((ar) +  4);   /* dIP */                     \
        SWAP_DATA16((ar) +  8);   /* sPort */                   \
        SWAP_DATA16((ar) + 10);   /* dPort */                   \
        SWAP_DATA32((ar) + 12);   /* nhIP */                    \
        SWAP_DATA16((ar) + 16);   /* input */                   \
        SWAP_DATA16((ar) + 18);   /* output */                  \
        SWAP_DATA32((ar) + 20);   /* sTime */                   \
        SWAP_DATA32((ar) + 24);   /* elapsed */                 \
        SWAP_DATA32((ar) + 28);   /* pkts */                    \
        SWAP_DATA32((ar) + 32);   /* bytes */                   \
        /* Two single bytes: (36)proto, (37)flow_type */        \
        SWAP_DATA16((ar) + 38);   /* sID */                     \
        /* Four single bytes: (40)flags, (41)init_flags,        \
         *                    (42)rest_flags, (43)tcp_state */  \
        SWAP_DATA32((ar) + 44);   /* bpp */                     \
    }


/*
 *  Unpack the array of bytes 'ar' into a record 'rwRP'
 */
static int _genericioRecordUnpack_V2(
    rwIOStruct_t     *rwIOS,
    rwGenericRec_V5  *rwRP,
    uint8_t          *ar)
{
    uint32_t tmp32;

    /* swap if required */
    if (rwIOS->swapFlag) {
        _genericioRecordSwap_V2(ar);
    }

    /* sIP, dIP, sPort, dPort, nhIP, input, output */
    rwRecMemSetSIPv4(rwRP, &ar[0]);
    rwRecMemSetDIPv4(rwRP, &ar[4]);
    rwRecMemSetSPort(rwRP, &ar[8]);
    rwRecMemSetDPort(rwRP, &ar[10]);
    rwRecMemSetNhIPv4(rwRP, &ar[12]);
    rwRecMemSetInput(rwRP, &ar[16]);
    rwRecMemSetOutput(rwRP, &ar[18]);

    /* sTime, elapsed */
    memcpy(&tmp32, &ar[20], 4);
    rwRecSetStartTime(rwRP, ((sktime_t)1000 * tmp32));
    memcpy(&tmp32, &ar[24], 4);
    rwRecSetElapsed(rwRP, (1000 * tmp32));

    /* pkts, bytes */
    rwRecMemSetPkts(rwRP, &ar[28]);
    rwRecMemSetBytes(rwRP, &ar[32]);

    /* proto, flow_type, sID, flags, init_flags, rest_flags, tcp_state */
    rwRecMemSetProto(rwRP, &ar[36]);
    rwRecMemSetFlowType(rwRP, &ar[37]);
    rwRecMemSetSensor(rwRP, &ar[38]);
    rwRecMemSetFlags(rwRP, &ar[40]);
    rwRecMemSetInitFlags(rwRP, &ar[41]);
    rwRecMemSetRestFlags(rwRP, &ar[42]);
    rwRecMemSetTcpState(rwRP, &ar[43]);

    /* bpp field no longer exists */

    return RWIO_OK;
}


/*
 *  Pack the record 'rwRP' into an array of bytes 'ar'
 */
static int _genericioRecordPack_V2(
    rwIOStruct_t           *rwIOS,
    const rwGenericRec_V5  *rwRP,
    uint8_t                *ar)
{
    uint32_t tmp32;

    /* sIP, dIP, sPort, dPort, nhIP, input, output */
    rwRecMemGetSIPv4(rwRP, &ar[0]);
    rwRecMemGetDIPv4(rwRP, &ar[4]);
    rwRecMemGetSPort(rwRP, &ar[8]);
    rwRecMemGetDPort(rwRP, &ar[10]);
    rwRecMemGetNhIPv4(rwRP, &ar[12]);
    rwRecMemGetInput(rwRP, &ar[16]);
    rwRecMemGetOutput(rwRP, &ar[18]);

    /* sTime, elapsed */
    tmp32 = (uint32_t)(rwRecGetStartTime(rwRP) / 1000);
    memcpy(&ar[20], &tmp32, 4);
    tmp32 = rwRecGetElapsed(rwRP) / 1000;
    memcpy(&ar[24], &tmp32, 4);

    /* pkts, bytes */
    rwRecMemGetPkts(rwRP, &ar[28]);
    rwRecMemGetBytes(rwRP, &ar[32]);

    /* proto, flow_type, sID, flags, init_flags, rest_flags, tcp_state */
    rwRecMemGetProto(rwRP, &ar[36]);
    rwRecMemGetFlowType(rwRP, &ar[37]);
    rwRecMemGetSensor(rwRP, &ar[38]);
    rwRecMemGetFlags(rwRP, &ar[40]);
    rwRecMemGetInitFlags(rwRP, &ar[41]);
    rwRecMemGetRestFlags(rwRP, &ar[42]);
    rwRecMemGetTcpState(rwRP, &ar[43]);

    /* bpp field no longer exists */
    memset(&ar[44], 0, 4);

    /* swap if required */
    if (rwIOS->swapFlag) {
        _genericioRecordSwap_V2(ar);
    }

    return RWIO_OK;
}


/* ********************************************************************* */

/*
**  RWGENERIC VERSION 0
**  RWGENERIC VERSION 1
**
**    uint32_t      sIP;             //  0- 3  Source IP
**    uint32_t      dIP;             //  4- 7  Destination IP
**
**    uint16_t      sPort;           //  8- 9  Source port
**    uint16_t      dPort;           // 10-11  Destination port
**
**    uint8_t       proto;           // 12     IP protocol
**    uint8_t       flags;           // 13     OR of all TCP flags on all pkts
**    uint8_t       input;           // 14     Router incoming SNMP interface
**    uint8_t       output;          // 15     Router outgoing SNMP interface
**
**    uint32_t      nhIP;            // 16-19  Router Next Hop IP
**    uint32_t      sTime;           // 20-23  Start time of flow-epoch secs
**    uint32_t      pkts;            // 24-27  Count of packets
**    uint32_t      bytes;           // 28-31  Count of bytes
**    uint32_t      elapsed;         // 32-35  Duration of flow
**
**    uint8_t       sID;             // 36     Sensor ID
**    uint8_t       padding[3];      // 37-39  Padding
**
**  40 bytes on disk with padding (VERSION 0)
**  37 bytes on disk without padding (VERSION 1)
*/

#define RECLEN_RWGENERIC_V0 40
#define RECLEN_RWGENERIC_V1 37


/*
 *    Byte swap the RWGENERIC v1 record 'ar' in place.
 */
#define _genericioRecordSwap_V1(ar)                                     \
    {                                                                   \
        SWAP_DATA32((ar) +  0);   /* sIP */                             \
        SWAP_DATA32((ar) +  4);   /* dIP */                             \
        SWAP_DATA16((ar) +  8);   /* sPort */                           \
        SWAP_DATA16((ar) + 10);   /* dPort */                           \
        /* Four single bytes: (12)proto, (13)flags, (14)input, (15)output */ \
        SWAP_DATA32((ar) + 16);   /* nhIP */                            \
        SWAP_DATA32((ar) + 20);   /* sTime */                           \
        SWAP_DATA32((ar) + 24);   /* pkts */                            \
        SWAP_DATA32((ar) + 28);   /* bytes */                           \
        SWAP_DATA32((ar) + 32);   /* elapsed */                         \
        /* One single bytes: (36)sensorId */                            \
    }


/*
 *  Unpack the array of bytes 'ar' into a record 'rwRP'
 */
static int _genericioRecordUnpack_V1(
    rwIOStruct_t           *rwIOS,
    rwGenericRec_V5        *rwRP,
    uint8_t                *ar)
{
    uint32_t tmp32;

    /* swap if required */
    if (rwIOS->swapFlag) {
        _genericioRecordSwap_V1(ar);
    }

    /* sIP, dIP, sPort, dPort */
    rwRecMemSetSIPv4(rwRP, &ar[0]);
    rwRecMemSetDIPv4(rwRP, &ar[4]);
    rwRecMemSetSPort(rwRP, &ar[8]);
    rwRecMemSetDPort(rwRP, &ar[10]);

    /* proto, flags, input, output */
    rwRecSetProto(rwRP, ar[12]);
    rwRecSetFlags(rwRP, ar[13]);
    rwRecSetInput(rwRP, ar[14]);
    rwRecSetOutput(rwRP, ar[15]);

    /* nhIP */
    rwRecMemSetNhIPv4(rwRP, &ar[16]);

    /* sTime */
    memcpy(&tmp32, &ar[20], 4);
    rwRecSetStartTime(rwRP, ((sktime_t)1000 * tmp32));

    /* pkts, bytes */
    rwRecMemSetPkts(rwRP, &ar[24]);
    rwRecMemSetBytes(rwRP, &ar[28]);

    /* elapsed */
    memcpy(&tmp32, &ar[32], 4);
    rwRecSetElapsed(rwRP, (1000 * tmp32));

    /* sID */
    rwRecSetSensor(rwRP, ar[36]);

    return RWIO_OK;
}


/*
 *  Pack the record 'rwRP' into an array of bytes 'ar'
 */
static int _genericioRecordPack_V1(
    rwIOStruct_t           *rwIOS,
    const rwGenericRec_V5  *rwRP,
    uint8_t                *ar)
{
    uint32_t tmp32;

    /* Check sizes of fields we've expanded in later versions */
    if (rwRecGetInput(rwRP) > 255 || rwRecGetOutput(rwRP) > 255) {
        return SKSTREAM_ERR_SNMP_OVRFLO;
    }
    /* Check sizes of fields we've expanded in later versions */
    if (rwRecGetSensor(rwRP) > 255) {
        return SKSTREAM_ERR_SENSORID_OVRFLO;
    }

    /* sIP, dIP, sPort, dPort */
    rwRecMemGetSIPv4(rwRP, &ar[0]);
    rwRecMemGetDIPv4(rwRP, &ar[4]);
    rwRecMemGetSPort(rwRP, &ar[8]);
    rwRecMemGetDPort(rwRP, &ar[10]);

    /* proto, flags, input, output */
    ar[12] = rwRecGetProto(rwRP);
    ar[13] = rwRecGetFlags(rwRP);
    ar[14] = (uint8_t)rwRecGetInput(rwRP);
    ar[15] = (uint8_t)rwRecGetOutput(rwRP);

    /* nhIP */
    rwRecMemGetNhIPv4(rwRP, &ar[16]);

    /* sTime */
    tmp32 = (uint32_t)(rwRecGetStartTime(rwRP) / 1000);
    memcpy(&ar[20], &tmp32, 4);

    /* pkts, bytes */
    rwRecMemGetPkts(rwRP, &ar[24]);
    rwRecMemGetBytes(rwRP, &ar[28]);

    /* elapsed */
    tmp32 = rwRecGetElapsed(rwRP) / 1000;
    memcpy(&ar[32], &tmp32, 4);

    /* sID */
    ar[36] = (uint8_t)rwRecGetSensor(rwRP);

    /* clear padding if present (for consistent output) */
    if (rwIOS->recLen == 40) {
        memset(&ar[37], 0, 3);
    }

    /* swap if required */
    if (rwIOS->swapFlag) {
        _genericioRecordSwap_V1(ar);
    }

    return RWIO_OK;
}


/* ********************************************************************* */

/*
 *  Return length of record of specified version, or 0 if no such
 *  version exists.  See skstream_priv.h for details.
 */
uint16_t genericioGetRecLen(fileVersion_t vers)
{
    switch (vers) {
      case 0:
        return RECLEN_RWGENERIC_V0;
      case 1:
        return RECLEN_RWGENERIC_V1;
      case 2:
        return RECLEN_RWGENERIC_V2;
      case 3:
        return RECLEN_RWGENERIC_V3;
      case 4:
        return RECLEN_RWGENERIC_V4;
      case 5:
        return RECLEN_RWGENERIC_V5;
      default:
        return 0;
    }
}


/*
 *  status = genericioPrepare(&rwIOSPtr);
 *
 *    Sets the record version to the default if it is unspecified,
 *    checks that the record format supports the requested record
 *    version, sets the record length, and sets the pack and unpack
 *    functions for this record format and version.
 */
int genericioPrepare(rwIOStruct_t *rwIOS)
{
#define FILE_FORMAT "FT_RWGENERIC"
    sk_file_header_t *hdr = rwIOS->silk_hdr;
    int rv = RWIO_OK; /* return value */

    assert(skHeaderGetFileFormat(hdr) == FT_RWGENERIC);

    /* Set version if none was selected by caller */
    if ((rwIOS->io_mode == SK_IO_WRITE)
        && (skHeaderGetRecordVersion(hdr) == SK_RECORD_VERSION_ANY))
    {
        skHeaderSetRecordVersion(hdr, DEFAULT_RECORD_VERSION);
    }

    /* version check; set values based on version */
    switch (skHeaderGetRecordVersion(hdr)) {
      case 5:
        rwIOS->rwUnpackFn = &_genericioRecordUnpack_V5;
        rwIOS->rwPackFn   = &_genericioRecordPack_V5;
        break;
      case 4:
      case 3:
        /* V3 and V4 differ only in that V4 supports compression on
         * read and write; V3 supports compression only on read */
        rwIOS->rwUnpackFn = &_genericioRecordUnpack_V3;
        rwIOS->rwPackFn   = &_genericioRecordPack_V3;
        break;
      case 2:
        rwIOS->rwUnpackFn = &_genericioRecordUnpack_V2;
        rwIOS->rwPackFn   = &_genericioRecordPack_V2;
        break;
      case 1:
      case 0:
        /* Version 0 and Version 1 records are nearly the same; the
         * on-disk Version 0 records included the 3 bytes of in-core
         * padding; the on-disk Version 1 records do not include these
         * 3 bytes. */
        rwIOS->rwUnpackFn = &_genericioRecordUnpack_V1;
        rwIOS->rwPackFn   = &_genericioRecordPack_V1;
        break;
      default:
        rv = SKSTREAM_ERR_UNSUPPORT_VERSION;
        goto END;
    }

    rwIOS->recLen = genericioGetRecLen(skHeaderGetRecordVersion(hdr));

    /* verify lengths */
    if (rwIOS->recLen == 0) {
        skAppPrintErr("Record length not set for %s version %u",
                      FILE_FORMAT, skHeaderGetRecordVersion(hdr));
        abort();
    }
    if (rwIOS->recLen != skHeaderGetRecordLength(hdr)) {
        if (0 == skHeaderGetRecordLength(hdr)) {
            skHeaderSetRecordLength(hdr, rwIOS->recLen);
        } else {
            skAppPrintErr(("Record length mismatch for %s version %u\n"
                           "\tcode = %" PRIu16 " bytes;  header = %lu bytes"),
                          FILE_FORMAT, skHeaderGetRecordVersion(hdr),
                          rwIOS->recLen,
                          (unsigned long)skHeaderGetRecordLength(hdr));
            abort();
        }
    }

  END:
    return rv;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
