/* A Bison parser, made by GNU Bison 1.875.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TOK_NL = 258,
     TOK_ATOM = 259,
     TOK_INTEGER = 260,
     TOK_STRING = 261,
     TOK_CLASS = 262,
     TOK_DEF_CLASS = 263,
     TOK_DEF_TYPES = 264,
     TOK_END_CLASS = 265,
     TOK_END_GROUP = 266,
     TOK_GROUP = 267,
     TOK_INCLUDE = 268,
     TOK_PATH_FORMAT = 269,
     TOK_PACKING_LOGIC = 270,
     TOK_SENSOR = 271,
     TOK_SENSORS = 272,
     TOK_TYPE = 273,
     TOK_VERSION = 274,
     ERR_UNK_CMD = 275,
     ERR_UNREC = 276,
     ERR_UNTERM_STRING = 277,
     ERR_STR_TOO_LONG = 278,
     ERR_INVALID_OCTAL_ESCAPE = 279
   };
#endif
#define TOK_NL 258
#define TOK_ATOM 259
#define TOK_INTEGER 260
#define TOK_STRING 261
#define TOK_CLASS 262
#define TOK_DEF_CLASS 263
#define TOK_DEF_TYPES 264
#define TOK_END_CLASS 265
#define TOK_END_GROUP 266
#define TOK_GROUP 267
#define TOK_INCLUDE 268
#define TOK_PATH_FORMAT 269
#define TOK_PACKING_LOGIC 270
#define TOK_SENSOR 271
#define TOK_SENSORS 272
#define TOK_TYPE 273
#define TOK_VERSION 274
#define ERR_UNK_CMD 275
#define ERR_UNREC 276
#define ERR_UNTERM_STRING 277
#define ERR_STR_TOO_LONG 278
#define ERR_INVALID_OCTAL_ESCAPE 279




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 143 "sksiteconfig_parse.y"
typedef union YYSTYPE {
    int integer;
    char *str;
    sk_vector_t *str_list;
} YYSTYPE;
/* Line 1204 of yacc.c.  */
#line 90 "sksiteconfig_parse.h"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;



