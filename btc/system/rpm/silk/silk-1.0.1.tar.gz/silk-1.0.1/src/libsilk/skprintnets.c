/*
** Copyright (C) 2005-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  Functions for printing CIDR blocks with indentation noting the
**  level of the block.  Also does summation for smaller CIDR blocks.
**  Used by rwbagcat and rwsetcat.
**
*/


#include "silk.h"

RCSIDENT("$SiLK: skprintnets.c 10004 2008-01-04 23:08:59Z mthomas $");

#include "skprintnets.h"
#include "iptree.h"


#define NET_T  0
#define NET_A  1
#define NET_B  2
#define NET_C  3
#define NET_X  4
#define NET_H  5


#define IP_TO_STRING(ns, ip, cidr)                                      \
    switch ((ns)->ip_format) {                                          \
      case SKIPADDR_CANONICAL:                                          \
        if ((cidr) < 0) {                                               \
            num2dot_r((ip), (ns)->ip_buf);                              \
        } else {                                                        \
            snprintf((ns)->ip_buf, sizeof((ns)->ip_buf), "%s/%d",       \
                     num2dot(ip), (cidr));                              \
        }                                                               \
        break;                                                          \
                                                                        \
      case SKIPADDR_ZEROPAD:                                            \
        if ((cidr) < 0) {                                               \
            num2dot0_r((ip), (ns)->ip_buf);                             \
        } else {                                                        \
            snprintf((ns)->ip_buf, sizeof((ns)->ip_buf), "%s/%d",       \
                     num2dot0(ip), (cidr));                             \
        }                                                               \
        break;                                                          \
                                                                        \
      case SKIPADDR_DECIMAL:                                            \
        if ((cidr) < 0) {                                               \
            snprintf((ns)->ip_buf, sizeof((ns)->ip_buf), "%u",          \
                     (ip));                                             \
        } else {                                                        \
            snprintf((ns)->ip_buf, sizeof((ns)->ip_buf), "%u/%d",       \
                     (ip), (cidr));                                     \
        }                                                               \
        break;                                                          \
                                                                        \
      default:                                                          \
        assert(0);                                                      \
        abort();                                                        \
    }


#define PLURAL(x) (((x) == 1) ? "" : "s")

#define NET_T_TITLE "TOTAL"

typedef struct net_struct_cidr_st {
    /* The sum of the counters. */
    uint64_t    cb_sum;

    /* whether to output the data for this CIDR block. */
    int         cb_print;

    /* the number of spaces by* which to indent this CIDR block. */
    int         cb_indent;

    /* the number of characters to allow for the CIDR block.
     * cb_indent+cb_width should be identical for all CIDR blocks. */
    int         cb_width;

    /* cblock[i].cb_ips[j], where i=NET_A..i-1, is the number of
     * smaller CIDR blocks j seen in the CIDR block i. */
    uint64_t    cb_ips[NET_H+1];
} net_struct_cidr_t;


struct netStruct_st {
    /* output stream */
    skstream_t         *outstrm;

    /* a buffer for IPs as strings. Must allow extra space for CIDR. */
    char                ip_buf[2*SK_NUM2DOT_STRLEN];

    /* previous key */
    uint32_t            prev_ip;

    /* the width of the 'count' column */
    int                 count_width;

    /* how to print the IP address. Values from "enum skipaddr_flags_t" */
    int                 ip_format;

    /* delimiter to print between columns */
    char                delimiter;

    /* delimiter or empty string to go between IP and Count */
    char                ip_count_delim[2];

    /* delimiter or empty string to go between Count and EOL */
    char                count_eol_delim[2];

    net_struct_cidr_t   cblock[NET_H+1];

    /* whether this entry is the first entry to be printed */
    unsigned            first_entry         :1;

    /* whether this entry is final entry to be printed */
    unsigned            final_entry         :1;

    /* whether to print the summary */
    unsigned            print_summary       :1;

    /* whether to suppress fixed width columnar output */
    unsigned            no_columns          :1;

    /* whether to suppress the final delimiter */
    unsigned            no_final_delimiter  :1;

    /* whether the caller will be passing a valid 'count' value. */
    unsigned            use_count           :1;
};


/* LOCAL VARIABLES */

static const struct cidr_consts_st {
    int         bits;
    uint32_t    octet_mask;
    uint32_t    change_mask;
} cidr_consts[NET_H+1] = {
    /* NET_T */ { 0, 0,          0},
    /* NET_A */ { 8, 0xFF000000, 0xFF000000},
    /* NET_B */ {16, 0x00FF0000, 0xFFFF0000},
    /* NET_C */ {24, 0x0000FF00, 0xFFFFFF00},
    /* NET_X */ {27, 0x000000E0, 0xFFFFFFE0},
    /* NET_H */ {-1, 0,          0xFFFFFFFF},
};

/* Current code is single threaded non-reentrant; so use static variable */
static netStruct_t static_ns;
static netStruct_t *g_ns = &static_ns;


/* LOCAL FUNCTION PROTOTYPES */

static void netStructureInitialize(netStruct_t *ns, int has_count);
static void netStructurePreparePrint(netStruct_t *ns);


/* FUNCTION DEFINITIONS */

/*
 * print an individual key inside the network-structure
 */
void netStructurePrintIP(
    uint32_t        ip,
    uint64_t       *count,
    netStruct_t     UNUSED(*ns))
{
    int first_change = -1;
    int i, j;

    /* determine whether a given octet has changed */
    if (g_ns->first_entry) {
        /* first entry is considered a change for all octets, but
         * don't print close blocks since nothing is open yet. */
        first_change = NET_T;
        g_ns->first_entry = 0;
        netStructurePreparePrint(g_ns);
    } else {

        if (g_ns->final_entry) {
            /* for the last entry, we need to close all the blocks and
             * print all summaries. */
            first_change = NET_T;
        } else {
            /* determine which octet is the first to change from the
             * previous value. */
            first_change = NET_H;
            for (i = NET_A; i <= NET_X; ++i) {
                if ((ip & cidr_consts[i].octet_mask)
                    != (g_ns->prev_ip & cidr_consts[i].octet_mask))
                {
                    first_change = i;
                    break;
                }
            }
        }

        /*
         * if counting and summarizing, calculate changes in blocks
         * and close out blocks.
         */
        for (i = NET_X; i >= first_change; --i) {

            /* only print if requested */
            if ( !g_ns->cblock[i].cb_print) {
                continue;
            }

            /* Convert IP and CIDR block to string, or use NET_T_TITLE */
            if (i == NET_T) {
                strncpy(g_ns->ip_buf, NET_T_TITLE, sizeof(g_ns->ip_buf));
            } else {
                IP_TO_STRING(g_ns, g_ns->prev_ip & cidr_consts[i].change_mask,
                             cidr_consts[i].bits);
            }

            skStreamPrint(g_ns->outstrm, "%*s%*s%s",
                          g_ns->cblock[i].cb_indent, "",
                          g_ns->cblock[i].cb_width, g_ns->ip_buf,
                          g_ns->ip_count_delim);

            if (g_ns->use_count) {
                skStreamPrint(g_ns->outstrm, ("%*" PRIu64 "%s"),
                              g_ns->count_width, g_ns->cblock[i].cb_sum,
                              g_ns->count_eol_delim);
            }

            if (g_ns->print_summary) {
                const char *comma_char = "";

                skStreamPrint(g_ns->outstrm, (" %" PRIu64 " host%s%s"),
                              g_ns->cblock[i].cb_ips[NET_H],
                              PLURAL(g_ns->cblock[i].cb_ips[NET_H]),
                              ((i != NET_X) ? " in " : ""));

                switch (i) {
                  case NET_T:
                    skStreamPrint(g_ns->outstrm, ("%" PRIu64 " /8%s, "),
                                  g_ns->cblock[i].cb_ips[NET_A],
                                  PLURAL(g_ns->cblock[i].cb_ips[NET_A]));
                    /* FALLTHROUGH */

                  case NET_A:
                    skStreamPrint(g_ns->outstrm, ("%" PRIu64 " /16%s, "),
                                  g_ns->cblock[i].cb_ips[NET_B],
                                  PLURAL(g_ns->cblock[i].cb_ips[NET_B]));
                    comma_char = ",";
                    /* FALLTHROUGH */

                  case NET_B:
                    skStreamPrint(g_ns->outstrm, ("%" PRIu64 " /24%s%s and "),
                                  g_ns->cblock[i].cb_ips[NET_C],
                                  PLURAL(g_ns->cblock[i].cb_ips[NET_C]),
                                  comma_char);
                    /* FALLTHROUGH */

                  case NET_C:
                    skStreamPrint(g_ns->outstrm, ("%" PRIu64 " /27%s"),
                                  g_ns->cblock[i].cb_ips[NET_X],
                                  PLURAL(g_ns->cblock[i].cb_ips[NET_X]));
                }
            } else if ( !g_ns->use_count) {
                /* Without summary nor counts, print the number of IPs
                 * seen in the block (otherwise, net structure serves
                 * little purpose. */
                skStreamPrint(g_ns->outstrm, (" %" PRIu64),
                              g_ns->cblock[i].cb_ips[NET_H]);
            }

            skStreamPrint(g_ns->outstrm, "\n");
        }
    } /* if !first_entry */


    /*
     * Now that we've closed the footers, if we are at the end of
     * the data set, we can quit.
     */
    if (g_ns->final_entry) {
        return;
    }


    /* print host if necessary. */
    if (g_ns->cblock[NET_H].cb_print) {
        IP_TO_STRING(g_ns, ip, cidr_consts[NET_H].bits);

        skStreamPrint(g_ns->outstrm, "%*s%*s%s",
                      g_ns->cblock[NET_H].cb_indent, "",
                      g_ns->cblock[NET_H].cb_width, g_ns->ip_buf,
                      g_ns->ip_count_delim);

        if (g_ns->use_count) {
            skStreamPrint(g_ns->outstrm, ("%*" PRIu64 "%s"),
                          g_ns->count_width, *count, g_ns->count_eol_delim);
        }
        skStreamPrint(g_ns->outstrm, "\n");
    }


    /* Increment blocks that hold this one. */
    for (i = NET_T; i < first_change; ++i) {
        for (j = first_change; j <= NET_H; ++j) {
            /* If NET_C has changed (first_change==NET_C), then NET_X
             * and NET_H have also changed (given by j), and the
             * NET_T, NET_A, and NET_B blocks (given by i) that
             * contain these sub-blocks must be incremented. */
            ++g_ns->cblock[i].cb_ips[j];
        }

        if (g_ns->use_count) {
            g_ns->cblock[i].cb_sum += *count;
        }
    }

    for (i = first_change; i < NET_H; ++i) {
        /* set levels below me to initial values */
        for (j = i+1; j <= NET_H; ++j) {
            g_ns->cblock[i].cb_ips[j] = 1;
        }

        if (g_ns->use_count) {
            g_ns->cblock[i].cb_sum = *count;
        }
    }

    g_ns->prev_ip = ip;
} /* netStructurePrintIP */


int netStructureCreate(
    netStruct_t   **ns,
    int             has_count)
{
    assert(ns);
    *ns = g_ns;

    netStructureInitialize(*ns, has_count);
    return 0;
}


void netStructureDestroy(netStruct_t **ns)
{
     if (ns && *ns) {
         *ns = NULL;
     }
}


static void netStructureInitialize(
    netStruct_t    *ns,
    int             has_count)
{
    assert(ns);
    memset(ns, 0, sizeof(netStruct_t));
    ns->first_entry = 1;
    ns->use_count = (has_count ? 1 : 0);
    ns->ip_format = SKIPADDR_CANONICAL;
    ns->delimiter = '|';
    ns->count_width = 15;

    /* Default is to print hosts only */
    ns->cblock[NET_H].cb_print = 1;
}


void netStructurePrintFinalize(netStruct_t *ns)
{
    ns->final_entry = 1;
    if (ns->first_entry) {
        /* assume no data was printed */
        return;
    }
    netStructurePrintIP(0, 0, ns);
}


void netStructurePrintStatistics(netStruct_t *ns)
{
    if ( !ns->final_entry) {
        skAppPrintErr("Must call netStructurePrintFinalize"
                      " before netStructurePrintStatistics");
        return;
    }
}


void netStructureSetCountWidth(
    netStruct_t             *ns,
    int                      width)
{
    assert(ns);
    ns->count_width = width;
}


void netStructureSetNoColumns(netStruct_t *ns)
{
    assert(ns);
    ns->no_columns = 1;
}


void netStructureSetNoFinalDelimiter(netStruct_t *ns)
{
    assert(ns);
    ns->no_final_delimiter = 1;
}


void netStructureSetOutputStream(
    netStruct_t    *ns,
    skstream_t     *stream)
{
    assert(ns);
    assert(stream);
    ns->outstrm = stream;
}


void netStructureSetIpFormat(
    netStruct_t            *ns,
    skipaddr_flags_t        format)
{
    assert(ns);
    ns->ip_format = format;
}


void netStructureSetDelimiter(
    netStruct_t    *ns,
    char            delimiter)
{
    assert(ns);
    ns->delimiter = delimiter;
}


int netStructureParse(
    netStruct_t    *ns,
    const char     *input)
{
    const char *cp;
    int i;

    /* Clear printing */
    memset(ns->cblock, 0, sizeof(ns->cblock));

    /* If input is NULL, use "TS" as default. */
    if (NULL == input) {
        cp = "TS";
    } else {
        cp = input;
    }

    while (*cp) {
        switch (*cp) {
          case 'T':
            ns->cblock[NET_T].cb_print = 1;
            break;
          case 'A':
            ns->cblock[NET_A].cb_print = 1;
            break;
          case 'B':
            ns->cblock[NET_B].cb_print = 1;
            break;
          case 'C':
            ns->cblock[NET_C].cb_print = 1;
            break;
          case 'X':
            ns->cblock[NET_X].cb_print = 1;
            break;
          case 'H':
            ns->cblock[NET_H].cb_print = 1;
            break;
          case 'S':
            ns->print_summary = 1;
            break;
          default:
            if (isspace((int)*cp)) {
                break;
            }
            skAppPrintErr(("Illegal network structure output character '%c'.\n"
                           "\tShould be some combination of TABCXHS."),
                          *cp);
            return 1;
        }

        ++cp;
    }

    /* Make certain we have something other than just 'S' */
    for (i = NET_T; i <= NET_H; ++i) {
        if (ns->cblock[i].cb_print) {
            /* we're good */
            return 0;
        }
    }

    skAppPrintErr("Network structure must include one of TABCXH");
    return 1;
}


static void netStructurePreparePrint(netStruct_t *ns)
{
#define INDENT_LEVEL 2
    int first_level = -1;
    int last_level = -1;
    int levels_printed = 0;
    int indent = 0;
    int width;
    int justify = -1; /* -1 for left-justified IPs; 1 for right */
    int i;

    assert(ns);

    /* open output stream */
    if (ns->outstrm == NULL) {
        int rv;
        if ((rv = skStreamCreate(&ns->outstrm, SK_IO_WRITE, SK_CONTENT_TEXT))
            || (rv = skStreamBind(ns->outstrm, "stdout"))
            || (rv = skStreamOpen(ns->outstrm)))
        {
            skStreamPrintLastErr(ns->outstrm, rv, &skAppPrintErr);
            skStreamDestroy(&ns->outstrm);
            return;
        }
    }

    /* the delimiter between the IP and count, or between IP and
     * summary when handling sets */
    ns->ip_count_delim[0] = ns->delimiter;
    ns->ip_count_delim[1] = '\0';

    /* the delimiter between the count and summary or count and
     * end-of-line when no summary */
    ns->count_eol_delim[0] = ns->delimiter;
    ns->count_eol_delim[1] = '\0';

    /* Compute indentation for each level. */
    for (i = NET_T; i <= NET_H; ++i) {
        ns->cblock[i].cb_indent = indent;
        if (ns->cblock[i].cb_print) {
            last_level = i;
            ++levels_printed;
            if (first_level == -1) {
                first_level = i;
                indent += INDENT_LEVEL;
                continue;
            }
        }
        if (last_level > NET_T) {
            /* Once we have one thing indented, indent the remaining
             * levels by the offset, even if they are not printed. */
            indent += INDENT_LEVEL;
        }
    }

    assert(levels_printed > 0);

    if ((first_level == NET_H) && (ns->use_count == 0) && !ns->print_summary){
        /* If there is no 'count' column and we are not printing
         * the summary---i.e., print IPs only---do no
         * formatting and disable the ip_count_delim. */
        ns->cblock[NET_H].cb_width = 0;
        ns->ip_count_delim[0] = '\0';
        return;
    }

    /* if no summary is requested, modify the delimiter between the
     * count and the end-of-line if no_final_delimiter is set */
    if (ns->no_final_delimiter && !ns->print_summary) {
        ns->count_eol_delim[0] = '\0';
    }

    if (ns->no_columns) {
        /* If fixed-width output is not requested, set all widths and
         * indents to 0 and return. */
        for (i = NET_T; i <= NET_H; ++i) {
            ns->cblock[i].cb_indent = 0;
            ns->cblock[i].cb_width = 0;
        }
        ns->count_width = 0;
        return;
    }

    /* Width will be at least the size of the indenation, but don't
     * include trailing levels that aren't printed. */
    width = indent - (INDENT_LEVEL * (1 + NET_H - last_level));

    /* Allow space for IP addresses; we'll add space for CIDR value
     * below. */
    if (SKIPADDR_DECIMAL == ns->ip_format) {
        width += 10;
    } else {
        width += 15;
    }

    /* Allow for the CIDR block */
    switch (last_level) {
      case NET_T:
        /* We are printing the total only.  Set that width and
         * return. */
        ns->cblock[NET_T].cb_width = strlen(NET_T_TITLE);
        return;

      case NET_A:
        /* Need to allow for "/8" */
        width += 2;
        break;

      case NET_B:
      case NET_C:
      case NET_X:
        /* Need to allow for "/16" or "/24" or "/27" */
        width += 3;
        break;

      case NET_H:
        /* Allow for "/27" at previous level if that level printed */
        if (ns->cblock[NET_X].cb_print && (INDENT_LEVEL < 3)) {
            width += (3 - INDENT_LEVEL);
        }
    }

    /* When doing only one level, right justify the keys */
    if (first_level == last_level) {
        justify = 1;
    }

    /* Set the widths for every level */
    for (i = NET_T; i <= NET_H; ++i) {
        ns->cblock[i].cb_width = justify * (width - ns->cblock[i].cb_indent);
    }
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
