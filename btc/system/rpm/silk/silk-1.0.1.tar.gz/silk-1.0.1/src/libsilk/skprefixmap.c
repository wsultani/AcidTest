/*
** Copyright (C) 2004-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
** skprefixmap.c
**
** John McClary Prevost
** December 2nd, 2004
**
**   Data structure for binding values to IP address prefixes (for
**   example, mapping every value under 128.2/16 to a single value.)
**
*/

#include "silk.h"

RCSIDENT("$SiLK: skprefixmap.c 10466 2008-02-12 21:22:29Z mthomas $");

#include "skprefixmap.h"


/* DEFINES AND TYPEDEFS */

typedef struct skPrefixMapRecord_st {
    uint32_t left;
    uint32_t right;
} skPrefixMapRecord_t;

struct skPrefixMap_st {
    /* the nodes that make up the tree */
    skPrefixMapRecord_t    *tree;
    /* all terms in dictionary joined by '\0', or NULL for vers 1 */
    char                   *dict_buf;
    /* Pointers into 'dict_buf', one for each word, or NULL for vers 1 */
    char                  **dict_words;
    /* number of nodes in the tree that are in use */
    size_t                  tree_used;
    /* number of nodes in the tree */
    size_t                  tree_size;
    /* number of bytes in dictionary that are in use, or 0 for vers 1 */
    uint32_t                dict_buf_used;
    /* number of bytes allocated to dictionary, or 0 for vers 1 */
    uint32_t                dict_buf_size;
    /* number of words in dictionary, or 0 for vers 1 */
    uint32_t                dict_words_used;
    /* number of possible words in dictionary, or 0 for vers 1 */
    uint32_t                dict_words_size;
    /* max len of word in dictionary, or 0 for vers 1 */
    uint32_t                dict_max_wordlen;
    /* type of data in the map */
    skPrefixMapContent_t    content_type;
};


#define SKPREFIXMAP_IS_NODE(x)      (!(x & 0x80000000u))
#define SKPREFIXMAP_IS_LEAF(x)      (x & 0x80000000u)
#define SKPREFIXMAP_LEAF_VALUE(x)   (x & (~0x80000000u))
#define SKPREFIXMAP_MAKE_LEAF(val)  ((val) | 0x80000000u)


/* The initial sizes of and how quickly to grow the (1)tree of nodes,
 * the (2)dictionary buffer, and the (3)dictionary words index */
#define SKPREFIXMAP_TREE_SIZE_INIT      (1 << 14)
#define SKPREFIXMAP_TREE_SIZE_GROW      SKPREFIXMAP_TREE_SIZE_INIT

#define SKPREFIXMAP_DICT_BUF_INIT       (1 << 16)
#define SKPREFIXMAP_DICT_BUF_GROW       SKPREFIXMAP_DICT_BUF_INIT

#define SKPREFIXMAP_WORDS_COUNT_INIT    8192
#define SKPREFIXMAP_WORDS_COUNT_GROW    2048



/* LOCAL FUNCTION PROTOTYPES */

static skPrefixMapErr_t _prefixMapGrowTree(skPrefixMap_t *map);


/* FUNCTION DEFINITIONS */

/*
 *  err = _prefixMapAdd(map, low, high, dict_val, key, bit);
 *
 *    Add the range 'low' to 'high' to the prefix map 'map' with a
 *    value of 'dict_val'.  This function is recursive.
 */
static skPrefixMapErr_t _prefixMapAdd(
    skPrefixMap_t  *map,
    uint32_t        low_val,
    uint32_t        high_val,
    uint32_t        dict_val,
    uint32_t        key,
    uint32_t        bit)
{
    uint32_t masked;
    int rv;

    assert(low_val <= high_val);
    assert(bit < 32);

    /* Does the left subtree overlap [low_val,high_val] ? */
    if (0 == GET_MASKED_BITS(low_val, bit, 1)) {
        /* Yes, left tree overlaps */

        /*
         * Is the left subtree completely contained in
         * [low_bits,high_bits] ?
         *
         * That is, is the low end the low end of the left subtree?
         * And, is the high end either the high end of the left
         * subtree or somewhere in the right subtree?)
         */

        if ((0 == GET_MASKED_BITS(low_val, 0, bit))
            && ((1 == GET_MASKED_BITS(high_val, bit, 1))
                || (GET_MASKED_BITS(high_val, 0, bit) == _BITMASK(bit))))
        {
            /* Left subtree completely contained; set left subtree to
             * the dictionary value. */
            map->tree[key].left = dict_val;
        } else {

            /* Left subtree overlaps but is not completely contained. */

            /* If left subtree is a leaf, we need to break it into two
             * subrecords */
            if (SKPREFIXMAP_IS_LEAF(map->tree[key].left)) {
                if (map->tree_used == map->tree_size) {
                    if (_prefixMapGrowTree(map)) {
                        return SKPREFIXMAP_ERR_MEMORY;
                    }
                }
                map->tree[map->tree_used].left = map->tree[key].left;
                map->tree[map->tree_used].right = map->tree[key].left;
                map->tree[key].left = map->tree_used;
                ++map->tree_used;
            }

            /* Recurse down the tree.  */
            if (1 == GET_MASKED_BITS(high_val, bit, 1)) {
                /* set least significant 'bit' bits to 1 */
                masked = low_val;
                SET_MASKED_BITS(masked, UINT32_MAX, 0, bit);
                rv = _prefixMapAdd(map, low_val, masked, dict_val,
                                   map->tree[key].left, bit-1);
            } else {
                rv = _prefixMapAdd(map, low_val, high_val, dict_val,
                                   map->tree[key].left, bit-1);
            }
            if (rv != SKPREFIXMAP_OK) {
                return rv;
            }
        }
    }


    /* NOW, handle the right-hand side, a mirror image */

    /* Does the right subtree overlap [low_val,high_val] ? */
    if (1 == GET_MASKED_BITS(high_val, bit, 1)) {
        /* Yes, right tree overlaps */

        /*
         * Is the right subtree completely contained in
         * [low_bits,high_bits] ?
         *
         * That is, is the high end the high end of the right subtree?
         * And, is the low end either the low end of the right
         * subtree or somewhere in the left subtree?)
         */

        if ((GET_MASKED_BITS(high_val, 0, bit) == _BITMASK(bit))
            && ((0 == GET_MASKED_BITS(low_val, bit, 1))
                || (0 == GET_MASKED_BITS(low_val, 0, bit))))
        {
            /* Right subtree completely contained; set right subtree
             * to the dictionary value. */
            map->tree[key].right = dict_val;
        } else {

            /* Right subtree overlaps but is not completely contained. */

            /* If right subtree is a leaf, we need to break it into two
             * subrecords */
            if (SKPREFIXMAP_IS_LEAF(map->tree[key].right)) {
                if (map->tree_used == map->tree_size) {
                    if (_prefixMapGrowTree(map)) {
                        return SKPREFIXMAP_ERR_MEMORY;
                    }
                }
                map->tree[map->tree_used].left = map->tree[key].right;
                map->tree[map->tree_used].right = map->tree[key].right;
                map->tree[key].right = map->tree_used;
                ++map->tree_used;
            }

            /* Recurse down the tree.  */
            if (0 == GET_MASKED_BITS(low_val, bit, 1)) {
                /* set least significant 'bit' bits to 0 */
                masked = high_val;
                SET_MASKED_BITS(masked, 0, 0, bit);
                rv = _prefixMapAdd(map, masked, high_val, dict_val,
                                   map->tree[key].right, bit-1);
            } else {
                rv = _prefixMapAdd(map, low_val, high_val, dict_val,
                                   map->tree[key].right, bit-1);
            }
            if (rv != SKPREFIXMAP_OK) {
                return rv;
            }
        }
    }

    return SKPREFIXMAP_OK;
}


/* Return the dict_val for the given key, or SKPREFIXMAP_NOT_FOUND */
static uint32_t _prefixMapGet(
    const skPrefixMap_t *map,
    uint32_t             key,
    int                 *depth)
{
    uint32_t node = 0;          /* Start at the root node */

    *depth = 32;                /* Start at the leftmost bit */

    while ( SKPREFIXMAP_IS_NODE(node) ) {
        --*depth;
        if ( *depth < 0 ) {
            /* This should be caught when the map is loaded. */
            skAppPrintErr("Corrupt prefix map.  No result found in 32 bits.");
            return SKPREFIXMAP_NOT_FOUND;
        }
        if ( key & (1 << *depth) ) {
            /* Go right if the bit is 1. */
            node = map->tree[node].right;
        } else {
            /* Go left if the bit is 0. */
            node = map->tree[node].left;
        }
    }
    return SKPREFIXMAP_LEAF_VALUE(node);
}


/*
 *  status = _prefixMapGrowDictionaryBuff(map, bytes);
 *
 *    Grow the dictionary buffer at least enough to hold an entry of
 *    size 'bytes'.  Adjust the 'word' pointers into this buffer as
 *    well.
 */
static skPrefixMapErr_t _prefixMapGrowDictionaryBuff(
    skPrefixMap_t  *map,
    size_t          min_bytes)
{
    char *old_ptr = map->dict_buf;
    size_t grow;
    uint32_t i;

    /* use initial size if this is first time */
    if (map->dict_buf_size == 0) {
        grow = SKPREFIXMAP_DICT_BUF_INIT;
    } else {
        grow = SKPREFIXMAP_DICT_BUF_GROW;
    }

    /* make certain it is big enough */
    while (grow < min_bytes) {
        grow += SKPREFIXMAP_DICT_BUF_GROW;
    }

    /* compute total size to allocate */
    grow += map->dict_buf_size;

    map->dict_buf = realloc(old_ptr, grow * sizeof(char));
    if (map->dict_buf == NULL) {
        map->dict_buf = old_ptr;
        return SKPREFIXMAP_ERR_MEMORY;
    }

    /* clear new memory */
    memset((map->dict_buf + map->dict_buf_size), 0,
           ((grow - map->dict_buf_size) * sizeof(char)));
    map->dict_buf_size = grow;

    /* move the dict_words pointers if they are no longer valid
     * because realloc() moved the memory */
    if (map->dict_buf != old_ptr) {
        for (i = 0; i < map->dict_words_used; ++i) {
            /* take offset from 'old_ptr' and add to new location */
            map->dict_words[i] = (map->dict_buf
                                  + (map->dict_words[i] - old_ptr));
        }
    }

    return SKPREFIXMAP_OK;
}


/*
 *  status = _prefixMapGrowDictionaryWords(map, entries);
 *
 *    Grow the dictionary words list at least enough to hold 'entries'
 *    new entriese.
 */
static skPrefixMapErr_t _prefixMapGrowDictionaryWords(
    skPrefixMap_t  *map,
    size_t          min_entries)
{
    void *old_ptr = map->dict_words;
    size_t grow;

    /* use initial size if this is first time */
    if (map->dict_words_size == 0) {
        grow = SKPREFIXMAP_WORDS_COUNT_INIT;
    } else {
        grow = SKPREFIXMAP_WORDS_COUNT_GROW;
    }

    /* make certain it is big enough */
    while (grow < min_entries) {
        grow += SKPREFIXMAP_WORDS_COUNT_GROW;
    }

    /* compute total size to allocate */
    grow += map->dict_words_size;

    map->dict_words = realloc(old_ptr, grow * sizeof(char*));
    if (map->dict_words == NULL) {
        map->dict_words = old_ptr;
        return SKPREFIXMAP_ERR_MEMORY;
    }

    map->dict_words_size = grow;
    return SKPREFIXMAP_OK;
}


/*
 *  status = _prefixMapGrowTree(map);
 *
 *    Grow the number of nodes in the tree for the prefix map 'map'.
 */
static skPrefixMapErr_t _prefixMapGrowTree(
    skPrefixMap_t  *map)
{
    void *old_ptr = map->tree;
    size_t grow = map->tree_size + SKPREFIXMAP_TREE_SIZE_GROW;

    map->tree = realloc(map->tree, grow * sizeof(skPrefixMapRecord_t));
    if (map->tree == NULL) {
        map->tree = old_ptr;
        return SKPREFIXMAP_ERR_MEMORY;
    }

    map->tree_size = grow;
    return SKPREFIXMAP_OK;
}


/* Set entries from 'low_val' to 'high_val' inclusive to 'dict_val' in 'map' */
skPrefixMapErr_t skPrefixMapAddRange(
    skPrefixMap_t  *map,
    uint32_t        low_val,
    uint32_t        high_val,
    uint32_t        dict_val)
{
    if (dict_val > SKPREFIXMAP_MAX_VALUE) {
        return -1;
    }

    if (high_val < low_val) {
        return SKPREFIXMAP_ERR_ARGS;
    }

    return _prefixMapAdd(map, low_val, high_val,
                         SKPREFIXMAP_MAKE_LEAF(dict_val), 0, 31);
}


/* Create a new prefix map at memory pointed at by 'map' */
skPrefixMapErr_t skPrefixMapCreate(skPrefixMap_t **map)
{
    if (NULL == map) {
        return SKPREFIXMAP_ERR_ARGS;
    }

    *map = calloc(1, sizeof(skPrefixMap_t));
    if (NULL == *map) {
        return SKPREFIXMAP_ERR_MEMORY;
    }

    (*map)->tree_size = SKPREFIXMAP_TREE_SIZE_INIT;
    (*map)->tree = calloc((*map)->tree_size, sizeof(skPrefixMapRecord_t));
    if (NULL == (*map)->tree) {
        free(*map);
        return SKPREFIXMAP_ERR_MEMORY;
    }
    (*map)->tree[0].left = SKPREFIXMAP_MAKE_LEAF(SKPREFIXMAP_MAX_VALUE);
    (*map)->tree[0].right = SKPREFIXMAP_MAKE_LEAF(SKPREFIXMAP_MAX_VALUE);
    (*map)->tree_used = 1;

    return SKPREFIXMAP_OK;
}


/* destroy the prefix map */
void skPrefixMapDelete(skPrefixMap_t *map)
{
    if ( map->tree != NULL ) {
        if (map->dict_buf) {
            free(map->dict_buf);
        }
        if (map->dict_words) {
            free(map->dict_words);
        }
        if (map->tree) {
            free(map->tree);
        }
        memset(map, 0, sizeof(skPrefixMap_t));
    }
    free(map);
}


/* Fill 'out_buf' with dictionary entry given the value 'dict_val' */
int skPrefixMapDictionaryGetEntry(
    const skPrefixMap_t    *map,
    uint32_t                dict_val,
    char                   *out_buf,
    size_t                  bufsize)
{
    if ((map->dict_buf_size == 0) || (dict_val >= map->dict_words_used)) {
        if (dict_val == SKPREFIXMAP_NOT_FOUND
            || dict_val == SKPREFIXMAP_MAX_VALUE)
        {
            return snprintf(out_buf, bufsize, "UNKNOWN");
        }
        return snprintf(out_buf, bufsize, ("%" PRIu32), dict_val);
    } else {
        return snprintf(out_buf, bufsize, "%s", map->dict_words[dict_val]);
    }
}


/* Returns the max length of any word in the dictionary. */
uint32_t skPrefixMapDictionaryGetMaxWordSize(const skPrefixMap_t *map)
{
    if (map->dict_words_used) {
        return map->dict_max_wordlen;
    }
    /* size necessary to hold string representation of UINT32_MAX. */
    return 10;
}


/* Returns the number of words in the prefix map's dictionary. */
uint32_t skPrefixMapDictionaryGetWordCount(const skPrefixMap_t *map)
{
    return map->dict_words_used;
}


/* Create a new dictionary entry mapping 'id' to 'label' */
skPrefixMapErr_t skPrefixMapDictionaryInsert(
    skPrefixMap_t  *map,
    uint32_t        id,
    const char     *word)
{
    uint32_t val;
    size_t len;
    size_t sz;
    uint32_t i;
    char *wp;

    if (map == NULL || word == NULL) {
        return SKPREFIXMAP_ERR_ARGS;
    }

    len = strlen(word);
    if (len == 0) {
        return SKPREFIXMAP_ERR_ARGS;
    }

    if (id > SKPREFIXMAP_MAX_VALUE) {
        return SKPREFIXMAP_ERR_ARGS;
    }

    val = skPrefixMapDictionaryLookup(map, word);
    if (val == id) {
        return SKPREFIXMAP_OK;
    }
    if (val != SKPREFIXMAP_NOT_FOUND) {
        return SKPREFIXMAP_ERR_DUPLICATE;
    }

    if (id < map->dict_words_used) {
        if (map->dict_words[id][0] != '\0') {
            /* error: new word is not same as value at this entry,
             * else we would have caught it above with
             * skPrefixMapDictionaryLookup() */
            return SKPREFIXMAP_ERR_DUPLICATE;
        }

        /* must add to middle of dictionary; note that there is
         * already a NUL byte placeholder in dict_buf for this id.
         * dict_words doesn't need to grow, but we will need to adjust
         * its pointers. */
        if ((map->dict_buf_size - map->dict_buf_used) < len) {
            if (_prefixMapGrowDictionaryBuff(map, len)) {
                return SKPREFIXMAP_ERR_MEMORY;
            }
        }

        /* move existing values 'len' bytes toward end */
        memmove(map->dict_words[id] + len, map->dict_words[id],
                (map->dict_buf_used - (map->dict_words[id]-map->dict_buf)));
        /* copy new value into place */
        strncpy(map->dict_words[id], word, len);
        assert(map->dict_words[id][len] == '\0');

        /* adjust all the 'words' pointers after this 'id' */
        for (i = id + 1; i < map->dict_words_used; ++i) {
            map->dict_words[i] += len;
        }

        map->dict_buf_used += len;
        return SKPREFIXMAP_OK;
    }

    /* We must add this entry to the end of the dictionary, perhaps
     * far beyond the final value */

    /* account for NUL byte */
    ++len;

    /* get number of bytes to add to the dictionary.  the last
     * expression is to handle any empties we need to add */
    sz = len + (id - map->dict_words_used);

    /* grow the dictionary */
    if ((map->dict_buf_size - map->dict_buf_used) < sz) {
        if (_prefixMapGrowDictionaryBuff(map, sz)) {
            return SKPREFIXMAP_ERR_MEMORY;
        }
    }

    /* grow the dict_words */
    if (map->dict_words_size < (1 + id)) {
        if (_prefixMapGrowDictionaryWords(map, 1 + id - map->dict_words_size)){
            return SKPREFIXMAP_ERR_MEMORY;
        }
    }

    wp = &(map->dict_buf[map->dict_buf_used]);
    for (i = map->dict_words_used; i <= id; ++i, ++wp) {
        map->dict_words[i] = wp;
    }

    strncpy(map->dict_words[id], word, len);

    map->dict_buf_used += sz;
    map->dict_words_used = 1 + id;
    return SKPREFIXMAP_OK;
}


/* Returns the dict_val for a given dictionary word
 * (case-insensitive), or SKPREFIXMAP_NOT_FOUND */
uint32_t skPrefixMapDictionaryLookup(
    const skPrefixMap_t    *map,
    const char             *word)
{
    uint32_t i;
    for ( i = 0; i < map->dict_words_used; i++ ) {
        if ( strcasecmp(map->dict_words[i], word) == 0 ) {
            return i;
        }
    }
    return SKPREFIXMAP_NOT_FOUND;
}


/* Create a new dictionary entry mapping 'id' to 'label' */
skPrefixMapErr_t skPrefixMapDictionarySearch(
    skPrefixMap_t  *map,
    const char     *word,
    uint32_t       *out_val)
{
    uint32_t val;
    size_t len;

    if (map == NULL || word == NULL || out_val == NULL) {
        return SKPREFIXMAP_ERR_ARGS;
    }

    /* see if 'word' already exists */
    val = skPrefixMapDictionaryLookup(map, word);
    if (val != SKPREFIXMAP_NOT_FOUND) {
        *out_val = val;
        return SKPREFIXMAP_OK;
    }

    /* Handle the case where 'word' is a number */
    if (0 == skStringParseUint32(&val, word, 0, 0)) {
        if (val <= SKPREFIXMAP_MAX_VALUE) {
            *out_val = val;
            return SKPREFIXMAP_OK;
        }
        return SKPREFIXMAP_ERR_ARGS;
    }

    /* get bytes to add to the dictionary */
    len = 1 + strlen(word);

    /* Grow dictionary to hold new term */
    if ((map->dict_buf_size - map->dict_buf_used) < len) {
        if (_prefixMapGrowDictionaryBuff(map, len)) {
            return SKPREFIXMAP_ERR_MEMORY;
        }
    }

    strncpy(&map->dict_buf[map->dict_buf_used], word,
            (map->dict_buf_size - map->dict_buf_used));

    /* Grow dict_words to hold pointer to new term */
    if (map->dict_words_size == map->dict_words_used) {
        if (_prefixMapGrowDictionaryWords(map, 1)) {
            return SKPREFIXMAP_ERR_MEMORY;
        }
    }

    map->dict_words[map->dict_words_used]
        = &map->dict_buf[map->dict_buf_used];

    map->dict_buf_used += len;
    ++map->dict_words_used;

    *out_val = (map->dict_words_used - 1);
    return SKPREFIXMAP_OK;
}


/* Return the dict_val for the given key, or SKPREFIXMAP_NOT_FOUND */
uint32_t skPrefixMapGet(const skPrefixMap_t *map, uint32_t key)
{
    int depth;
    return _prefixMapGet(map, key, &depth);
}


/* Return a textual representation of the content type. */
const char *skPrefixMapGetContentName(int content_id)
{
    static char buf[256];

    switch ((skPrefixMapContent_t)content_id) {
      case SKPREFIXMAP_CONT_ADDR:
        return "address";
      case SKPREFIXMAP_CONT_PROTO_PORT:
        return "proto-port";
    }

    snprintf(buf, sizeof(buf), "Unrecognized prefixmap content type id %d",
             content_id);
    return buf;
}


/* Returns the content type for a given map */
skPrefixMapContent_t skPrefixMapGetContentType(const skPrefixMap_t *map)
{
    return map->content_type;
}


/* Fill 'out_buf' with dictionary entry name given the key 'key' */
int skPrefixMapGetString(
    const skPrefixMap_t    *map,
    uint32_t                key,
    char                   *out_buf,
    size_t                  bufsize)
{
    int depth;
    return skPrefixMapDictionaryGetEntry(map, _prefixMapGet(map, key, &depth),
                                         out_buf, bufsize);
}


/* Bind an iterator to a prefix map */
int skPrefixMapIteratorBind(
    skPrefixMapIterator_t  *iter,
    const skPrefixMap_t    *map)
{
    if (iter == NULL || map == NULL) {
        return SKPREFIXMAP_ERR_ARGS;
    }

    iter->map = map;
    skPrefixMapIteratorReset(iter);
    return SKPREFIXMAP_OK;
}


/* Create an iterator */
int skPrefixMapIteratorCreate(
    skPrefixMapIterator_t **out_iter,
    const skPrefixMap_t    *map)
{
    assert(out_iter);

    *out_iter = malloc(sizeof(skPrefixMapIterator_t));
    if (*out_iter == NULL) {
        return SKPREFIXMAP_ERR_MEMORY;
    }

    if (skPrefixMapIteratorBind(*out_iter, map)) {
        skPrefixMapIteratorDestroy(out_iter);
        return SKPREFIXMAP_ERR_ARGS;
    }

    return SKPREFIXMAP_OK;
}


/* Destroy the iterator */
void skPrefixMapIteratorDestroy(skPrefixMapIterator_t **out_iter)
{
    if (*out_iter) {
        free(*out_iter);
        *out_iter = NULL;
    }
}


/* Fill 'start' and 'end' with next range */
skIteratorStatus_t skPrefixMapIteratorNext(
    skPrefixMapIterator_t  *iter,
    uint32_t               *out_key_start,
    uint32_t               *out_key_end,
    uint32_t               *out_value)
{
    uint32_t key;
    int depth;
    uint32_t val;
    uint32_t old_val = SKPREFIXMAP_NOT_FOUND;

    assert(out_key_start);
    assert(out_key_end);
    assert(out_value);

    /* check for the stoping condition */
    if (iter->end == UINT32_MAX) {
        return SK_ITERATOR_NO_MORE_ENTRIES;
    }

    /* check for the starting condition */
    if (iter->end < iter->start) {
        iter->start = 0;
    } else {
        /* move key to start of next range */
        iter->start = iter->end + 1;
    }

    key = iter->start;
    while (1) {
        val = _prefixMapGet(iter->map, key, &depth);
        if (old_val == SKPREFIXMAP_NOT_FOUND) {
            old_val = val;
        }
        if (old_val == val) {
            /* grow current range */
            key += (1 << depth);
            if (key == 0) {
                iter->end = UINT32_MAX;
                break;
            }
        } else {
            iter->end = key - 1;
            break;
        }
    }

    /* set the output values to our current location */
    *out_key_start = iter->start;
    *out_key_end = iter->end;
    *out_value = old_val;
    return SK_ITERATOR_OK;
}


/* Reset iterator */
void skPrefixMapIteratorReset(skPrefixMapIterator_t *iter)
{
    assert(iter);
    iter->end = 0;
    iter->start = 1;
}


/* Allocate new prefix map; open and read contents from 'path' */
skPrefixMapErr_t skPrefixMapLoad(skPrefixMap_t **map, const char *path)
{
    skstream_t *in;
    int rv = SKPREFIXMAP_OK;

    /* Check arguments for sanity */
    if ( NULL == map ) {
        skAppPrintErr("No place was provided to store new prefixmap.");
        return SKPREFIXMAP_ERR_ARGS;
    }
    if ( NULL == path ) {
        skAppPrintErr("No input file provided from which to read prefixmap.");
        return SKPREFIXMAP_ERR_ARGS;
    }

    if ((rv = skStreamCreate(&in, SK_IO_READ, SK_CONTENT_SILK))
        || (rv = skStreamBind(in, path))
        || (rv = skStreamOpen(in)))
    {
        skStreamPrintLastErr(in, rv, &skAppPrintErr);
        rv = SKPREFIXMAP_ERR_IO;
        goto END;
    }

    rv = skPrefixMapRead(map, in);

  END:
    skStreamDestroy(&in);
    return rv;
}


/* Allocate new prefix map and read contents from 'in' */
skPrefixMapErr_t skPrefixMapRead(skPrefixMap_t **map, skstream_t *in)
{
    sk_file_header_t *hdr;
    fileVersion_t vers;
    uint32_t record_count;
    uint32_t swapFlag;
    uint32_t i;
    char *current;
    char *start;
    char *end;
    int rv;

    /* Check arguments for sanity */
    if ( NULL == map ) {
        skAppPrintErr("No place was provided to store new prefixmap.");
        return SKPREFIXMAP_ERR_ARGS;
    }
    if ( NULL == in ) {
        skAppPrintErr("No input stream provided from which to read prefixmap");
        return SKPREFIXMAP_ERR_ARGS;
    }

    *map = NULL;

    rv = skStreamReadSilkHeader(in, &hdr);
    if (rv) {
        skStreamPrintLastErr(in, rv, &skAppPrintErr);
        return SKPREFIXMAP_ERR_IO;
    }

    if (skStreamCheckSilkHeader(in, FT_PREFIXMAP, 1, 3, &skAppPrintErr)){
        return SKPREFIXMAP_ERR_IO;
    }
    vers = skHeaderGetRecordVersion(hdr);

    if (SK_COMPMETHOD_NONE != skHeaderGetCompressionMethod(hdr) ) {
        skAppPrintErr("Unrecognized prefix map compression method.");
        return SKPREFIXMAP_ERR_IO;
    }

    swapFlag = !skHeaderIsNativeByteOrder(hdr);

    /* Read record count */
    if (skStreamRead(in, &(record_count), sizeof(record_count))
        != sizeof(record_count))
    {
        skAppPrintErr("Error reading header from input file (short read).");
        return SKPREFIXMAP_ERR_IO;
    }

    if ( swapFlag ) {
        record_count = BSWAP32(record_count);
    }

    if ( record_count < 1 ) {
        skAppPrintErr("Input file contains invalid prefix map (no data).");
        return SKPREFIXMAP_ERR_IO;
    }

    /* Allocate a prefix map, and a storage buffer */
    *map = calloc(1, sizeof(skPrefixMap_t));
    if (NULL == *map) {
        skAppPrintErr("Failed to allocate memory for prefix map.");
        return SKPREFIXMAP_ERR_MEMORY;
    }

    if (3 == vers) {
        (*map)->content_type = SKPREFIXMAP_CONT_PROTO_PORT;
    } else {
        (*map)->content_type = SKPREFIXMAP_CONT_ADDR;
    }

    (*map)->tree = malloc(record_count * sizeof(skPrefixMapRecord_t));
    if (NULL == (*map)->tree) {
        skAppPrintErr("Failed to allocate memory for prefix map data.");
        rv = SKPREFIXMAP_ERR_MEMORY;
        goto ERROR;
    }
    (*map)->tree_size = record_count;
    (*map)->tree_used = record_count;

    /* Allocation completed successfully, read in the records. */
    if (skStreamRead(in, (*map)->tree,
                     (record_count * sizeof(skPrefixMapRecord_t)))
        != (ssize_t)(record_count * sizeof(skPrefixMapRecord_t)))
    {
        skAppPrintErr("Failed to read all records from input file.");
        rv = SKPREFIXMAP_ERR_IO;
        goto ERROR;
    }

    /* Swap the byte order of the data if needed. */
    if ( swapFlag ) {
        for ( i = 0; i < record_count; i++ ) {
            (*map)->tree[i].left = BSWAP32((*map)->tree[i].left);
            (*map)->tree[i].right = BSWAP32((*map)->tree[i].right);
        }
    }

    /* If version is 2, allocate and read dictionary. */
    if ( vers >= 2 ) {

        if (skStreamRead(in, &((*map)->dict_buf_size), sizeof(uint32_t))
            != (ssize_t)sizeof(uint32_t))
        {
            skAppPrintErr("Error reading dictionary from input file.");
            rv = SKPREFIXMAP_ERR_IO;
            goto ERROR;
        }

        if (swapFlag) {
            (*map)->dict_buf_size = BSWAP32((*map)->dict_buf_size);
        }

        (*map)->dict_buf = malloc((*map)->dict_buf_size * sizeof(char));
        if ( NULL == (*map)->dict_buf ) {
            skAppPrintErr("Failed to allocate memory for prefix map dict.");
            rv = SKPREFIXMAP_ERR_MEMORY;
            goto ERROR;
        }

        /* Allocation on the dictionary is done, read in data. */
        if (skStreamRead(in, (*map)->dict_buf, (*map)->dict_buf_size)
            != (ssize_t)(*map)->dict_buf_size)
        {
            skAppPrintErr("Failed to read dictionary from input file.");
            rv = SKPREFIXMAP_ERR_IO;
            goto ERROR;
        }
        (*map)->dict_buf_used = (*map)->dict_buf_size;

        /* Index the dictionary data */

        /* First pass: count the words */
        start = (*map)->dict_buf;
        end = (*map)->dict_buf + (*map)->dict_buf_used;
        (*map)->dict_words_used = 0;
        for ( current = start; current < end; current++ ) {
            if ( (*current) == '\0' ) {
                (*map)->dict_words_used++;
            }
        }
        (*map)->dict_words_size = (*map)->dict_words_used;

        /* Allocate space for index */
        (*map)->dict_words = malloc((*map)->dict_words_size * sizeof(char*));
        if ((*map)->dict_words == NULL) {
            skAppPrintErr("Failed to allocated memory for prefix map index.");
            rv = SKPREFIXMAP_ERR_MEMORY;
            goto ERROR;
        }

        /* Now build index */
        current = (*map)->dict_buf;
        start = current;
        end = current + (*map)->dict_buf_used;
        for ( i = 0; i < (*map)->dict_words_used; i++ ) {
            while ( (*current != '\0') && (current < end) ) {
                current++;
            }
            (*map)->dict_words[i] = start;

            if ((uint32_t)(current - start) > (*map)->dict_max_wordlen) {
                (*map)->dict_max_wordlen = (current - start);
            }

            current++;
            start = current;
        }
    }

#if 0
    /* Check the invariants that ensure that the prefixmap is a total
     * mapping (every input maps to a single output.)
     *
     * The invariants are:
     * 1) No node may point to a non-existent child (>= record_count)
     * 2) No node may point to a node earlier than itself (prevents cycles)
     */
    for ( i = 0; i < record_count; i++ ) {
        uint32_t l = (*map)->tree[i].left;
        uint32_t r = (*map)->tree[i].right;
        if ( (SKPREFIXMAP_IS_NODE(l) && ((l >= record_count) ||
                                         (l <= i)))
             || (SKPREFIXMAP_IS_NODE(r) && ((r >= record_count) ||
                                            (r <= i))) )
        {
            skAppPrintErr("Prefix map is malformed (contains invalid child).");
            free((*map)->tree);
            free(*map);
            *map = NULL;
            return SKPREFIXMAP_ERR_IO;
        }
    }

    /* Hrm.  We should also try to look for chains longer than 32
     * steps.  What's a good way to do that?
     */
#endif

    return SKPREFIXMAP_OK;

  ERROR:
    if (*map) {
        skPrefixMapDelete(*map);
        *map = NULL;
    }
    return rv;
}


/* Write 'map' to the file specified by 'pathname'. Wraps skPrefixMapWrite. */
skPrefixMapErr_t skPrefixMapSave(
    skPrefixMap_t  *map,
    const char     *pathname)
{
    skstream_t *stream = NULL;
    int rv;

    if (pathname == NULL || map == NULL) {
        return SKPREFIXMAP_ERR_ARGS;
    }

    if ((rv = skStreamCreate(&stream, SK_IO_WRITE, SK_CONTENT_SILK))
        || (rv = skStreamBind(stream, pathname))
        || (rv = skStreamOpen(stream)))
    {
        skStreamPrintLastErr(stream, rv, &skAppPrintErr);
        rv = SKPREFIXMAP_ERR_IO;
        goto END;
    }

    rv = skPrefixMapWrite(map, stream);
    if (rv) {
        goto END;
    }

    rv = skStreamClose(stream);
    if (rv) {
        skStreamPrintLastErr(stream, rv, &skAppPrintErr);
        rv = SKPREFIXMAP_ERR_IO;
        goto END;
    }

  END:
    skStreamDestroy(&stream);
    return (skPrefixMapErr_t)rv;
}


/* Set default value in 'map' to 'dict_val'.  'map' must be empty. */
skPrefixMapErr_t skPrefixMapSetDefaultVal(
    skPrefixMap_t  *map,
    uint32_t        dict_val)
{
    if (dict_val > SKPREFIXMAP_MAX_VALUE) {
        return SKPREFIXMAP_ERR_ARGS;
    }

    /* ensure no entries have been added to the tree and default has
     * not been set.  This does not detect if default is set to
     * 0x7fffffff or if 0.0.0.0/1 or 128.0.0.0/1 has been set to
     * 0x7fffffff, but those are extremely rare possibilities. */
    if ((map->tree_used > 1)
        || (map->tree[0].right != SKPREFIXMAP_MAKE_LEAF(SKPREFIXMAP_MAX_VALUE))
        || (map->tree[0].left != SKPREFIXMAP_MAKE_LEAF(SKPREFIXMAP_MAX_VALUE)))
    {
        return SKPREFIXMAP_ERR_NOTEMPTY;
    }

    map->tree[0].left = SKPREFIXMAP_MAKE_LEAF(dict_val);
    map->tree[0].right = SKPREFIXMAP_MAKE_LEAF(dict_val);
    return SKPREFIXMAP_OK;
}


/* Return a textual representation of the specified error code. */
const char *skPrefixMapStrerror(int error_code)
{
    static char buf[256];

    switch ((skPrefixMapErr_t)error_code) {
      case SKPREFIXMAP_OK:
        return "Success";
      case SKPREFIXMAP_ERR_ARGS:
        return "Invalid arguments";
      case SKPREFIXMAP_ERR_MEMORY:
        return "Out of memory";
      case SKPREFIXMAP_ERR_IO:
        return "I/O error";
      case SKPREFIXMAP_ERR_DUPLICATE:
        return "Duplicate dictionary ID or word";
      case SKPREFIXMAP_ERR_NOTEMPTY:
        return "Cannot set default in non-empty map";
    }

    snprintf(buf, sizeof(buf), "Unrecognized prefixmap error code %d",
             error_code);
    return buf;
}


/* Write the binary prefix map 'map' to the specified stream */
skPrefixMapErr_t skPrefixMapWrite(
    skPrefixMap_t  *map,
    skstream_t     *stream)
{
    sk_file_header_t *hdr;
    int rv;
    fileVersion_t vers;

    if (stream == NULL || map == NULL) {
        return SKPREFIXMAP_ERR_ARGS;
    }

    if (map->content_type == SKPREFIXMAP_CONT_PROTO_PORT) {
        vers = 3;
    } else if (map->content_type == SKPREFIXMAP_CONT_ADDR) {
        if (map->dict_buf == NULL) {
            vers = 1;
        } else {
            vers = 2;
        }
    } else {
        return -1;
    }

    /* create and write header */
    hdr = skStreamGetSilkHeader(stream);
    skHeaderSetFileFormat(hdr, FT_PREFIXMAP);
    skHeaderSetRecordVersion(hdr, vers);
    skHeaderSetCompressionMethod(hdr, SK_COMPMETHOD_NONE);
    skHeaderSetRecordLength(hdr, 1);
    rv = skStreamWriteSilkHeader(stream);
    if (rv) {
        skStreamPrintLastErr(stream, rv, &skAppPrintErr);
        return SKPREFIXMAP_ERR_IO;
    }

    /* write the number of records */
    rv = skStreamWrite(stream, &map->tree_used, sizeof(uint32_t));
    if (rv == -1) {
        goto ERROR;
    }

    /* write the records */
    rv = skStreamWrite(stream, map->tree,
                       map->tree_used * sizeof(skPrefixMapRecord_t));
    if (rv == -1) {
        goto ERROR;
    }

    if (map->dict_buf) {
        /* write the number of characters in the dictionary */
        rv = skStreamWrite(stream, &map->dict_buf_used, sizeof(uint32_t));
        if (rv == -1) {
            goto ERROR;
        }

        /* write the dictionary entries */
        rv = skStreamWrite(stream, map->dict_buf,
                           map->dict_buf_used * sizeof(char));
        if (rv == -1) {
            goto ERROR;
        }
    }

    /* Success */
    return SKPREFIXMAP_OK;

  ERROR:
    skStreamPrintLastErr(stream, rv, &skAppPrintErr);
    return SKPREFIXMAP_ERR_IO;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
