/*
** Copyright (C) 2005-2007 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
** Tests for the sklinkedlist library
*/


#include "silk.h"

RCSIDENT("$SiLK: sklinkedlist-test.c 8320 2007-08-07 16:16:11Z mthomas $");

#include "sklinkedlist.h"


static void printList( sk_link_list_t *list );


int main()
{
    sk_link_err_t rv;
    sk_link_list_t *list;
    sk_link_item_t *head;
    sk_link_item_t *item;

    int *p_test;
    int data[] = { 0, 1, 2, 3, 4, 5, 6 };

    /* Allocate list */
    rv = skLinkAllocList( &list, NULL );
    if( rv != SKLINK_OK ) {
        printf( "Error %d allocating list\n", rv );
    }

    /* Append five items */
    rv = skLinkAppendData( list, (void *) &data[1] );
    if( rv != SKLINK_OK ) {
        printf( "Error %d appending data\n", rv );
    }

    rv = skLinkAppendData( list, (void *) &data[3] );
    if( rv != SKLINK_OK ) {
        printf( "Error %d appending data\n", rv );
    }

    rv = skLinkAppendData( list, (void *) &data[5] );
    if( rv != SKLINK_OK ) {
        printf( "Error %d appending data\n", rv );
    }

    /* Step through list and make sure values are the same */
    rv = skLinkGetHead( &head, list );
    if( rv != SKLINK_OK ) {
        printf( "Error %d getting head of list\n", rv );
    }

    rv = skLinkGetData( (void *) &p_test, head );
    if( rv != SKLINK_OK ) {
        printf( "Error %d getting list entry\n", rv );
    }
    if( *p_test != data[1] ) {
        printf( "Error number %d in list should be %d\n", *p_test, data[1] );
    }

    rv = skLinkGetNext( &item, head );
    if( rv != SKLINK_OK ) {
        printf( "Error %d getting list entry\n", rv );
    }
    rv = skLinkGetData( (void *) &p_test, item );
    if( rv != SKLINK_OK ) {
        printf( "Error %d getting list entry\n", rv );
    }
    if( *p_test != data[3] ) {
        printf( "Error number %d in list should be %d\n", *p_test, data[3] );
    }

    head = item;
    rv = skLinkGetNext( &item, head );
    if( rv != SKLINK_OK ) {
        printf( "Error %d getting list entry\n", rv );
    }
    rv = skLinkGetData( (void *) &p_test, item );
    if( rv != SKLINK_OK ) {
        printf( "Error %d getting list entry\n", rv );
    }
    if( *p_test != data[5] ) {
        printf( "Error number %d in list should be %d\n", *p_test, data[5] );
    }

    /* Use insertPrev and insertNext */
    rv = skLinkGetHead( &head, list );
    if( rv != SKLINK_OK ) {
        printf( "Error %d getting head of list\n", rv );
    }

    rv = skLinkInsertPrev( list, head, (void *) &data[0] );
    if( rv != SKLINK_OK ) {
        printf( "Error %d inserting 0 before 1\n", rv );
    }

    rv = skLinkInsertNext( list, head, (void *) &data[2] );
    if( rv != SKLINK_OK ) {
        printf( "Error %d inserting 2 after 1\n", rv );
    }


    /* goto 2 */
    rv = skLinkGetNext( &item, head );
    if( rv != SKLINK_OK ) {
        printf( "Error %d getting next item\n", rv );
    }

    /* goto 3 */
    head = item;
    rv = skLinkGetNext( &item, head );
    if( rv != SKLINK_OK ) {
        printf( "Error %d getting next item\n", rv );
    }

    /* goto 5 */
    head = item;
    rv = skLinkGetNext( &item, head );
    if( rv != SKLINK_OK ) {
        printf( "Error %d getting next item\n", rv );
    }

    rv = skLinkInsertPrev( list, item, (void *) &data[4] );
    if( rv != SKLINK_OK ) {
        printf( "Error %d inserting 0 before 1\n", rv );
    }

    rv = skLinkInsertNext( list, item, (void *) &data[6] );
    if( rv != SKLINK_OK ) {
        printf( "Error %d inserting 2 after 1\n", rv );
    }

    /* go back to start and step through */


    rv = skLinkGetHead( &head, list );
    if( rv != SKLINK_OK ) {
        printf( "Error %d getting head of list\n", rv );
    }

    printf( "list should be numbers 0 through 6 in order:\n" );
    printList( list );

    /* remove even items */
    rv = skLinkGetHead( &head, list );
    if( rv != SKLINK_OK ) {
        printf( "Error %d getting head of list\n", rv );
    }

    item = head;
    rv = skLinkRemoveNode( list, item );
    if( rv != SKLINK_OK ) {
        printf( "Error %d removing item\n", rv );
    }

    rv = skLinkGetHead( &head, list );
    rv += skLinkGetNext( &item, head );
    rv = skLinkRemoveNode( list, item );
    if( rv != SKLINK_OK ) {
        printf( "Error %d removing item\n", rv );
    }

    rv = skLinkGetHead( &head, list );
    rv += skLinkGetNext( &item, head );
    head = item;
    rv += skLinkGetNext( &item, head );
    if( rv != SKLINK_OK ) {
        printf( "Error\n" );
    }

    rv = skLinkRemoveNode( list, item );
    if( rv != SKLINK_OK ) {
        printf( "Error %d removing item\n", rv );
    }


    rv = skLinkGetHead( &head, list );
    rv += skLinkGetNext( &item, head );
    head = item;
    rv += skLinkGetNext( &item, head );
    head = item;
    rv += skLinkGetNext( &item, head );
    if( rv != SKLINK_OK ) {
        printf( "Error\n" );
    }


    rv = skLinkRemoveNode( list, item );
    if( rv != SKLINK_OK ) {
        printf( "Error %d removing item\n", rv );
    }

    printf( "list should be numbers 1 3 5\n" );
    printList( list );

    rv = skLinkFreeList( list );
    if( rv != SKLINK_OK ) {
        printf( "Error %d deallocating\n", rv );
    }


    /*
    ** more interesting memory tests
    */
    fprintf( stderr, "MOOO\n" );

    rv = skLinkAllocList( &list, free );
    assert( rv == SKLINK_OK );

    rv = skLinkAppendData( list, (void *) malloc( 10 ) );
    assert( rv == SKLINK_OK );

    rv = skLinkAppendData( list, (void *) malloc( 100 ) );
    assert( rv == SKLINK_OK );

    rv = skLinkAppendData( list, (void *) malloc( 1000 ) );
    assert( rv == SKLINK_OK );

    rv = skLinkGetHead( &item, list );
    assert( rv == SKLINK_OK );
    rv = skLinkGetNext( &item, item );
    assert( rv == SKLINK_OK );
    rv = skLinkRemoveNode( list, item );
    assert( rv == SKLINK_OK );

    rv = skLinkFreeList( list );
    assert( rv == SKLINK_OK );

    return 0;
}


static void printList( sk_link_list_t *list ) {
    sk_link_item_t *current;
    sk_link_err_t rv;
    int *p_value;

    printf( "printing list:  " );
    rv = skLinkGetHead( &current, list );
    if( rv != SKLINK_OK ) {
        printf( "Error %d getting head during print\n", rv );
    }

    do {
        rv = skLinkGetData( (void *) &p_value, current );
        if( rv != SKLINK_OK ) {
            printf( "Error %d getting data during print\n", rv );
        }
        printf( "%d  ", *p_value );
    } while( skLinkGetNext( &current, current ) == SKLINK_OK );
    printf( "\n" );

}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
