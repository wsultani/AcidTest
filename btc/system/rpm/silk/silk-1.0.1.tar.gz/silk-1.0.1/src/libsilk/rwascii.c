/*
** Copyright (C) 2005-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  Functions to support printing a record as text.
**
*/


#include "silk.h"

RCSIDENT("$SiLK: rwascii.c 11243 2008-04-11 15:34:06Z mthomas $");

#include "skstream_priv.h"
#include "skstringmap.h"


/* error message when out of memory */
#define ERRMSG_ALLOC "memory allocation failed at %s:%d", __FILE__, __LINE__


struct rwAsciiStream_st {
    FILE           *as_out_stream;
    uint8_t         as_widths[RWREC_PRINTABLE_FIELD_COUNT];
    uint32_t       *as_field_list;
    uint32_t        as_field_count;
    uint32_t        as_timeflags;
    sk_ipv6policy_t as_ipv6_policy;
    uint8_t         as_initialized;
    char            as_delimiter;
    unsigned        as_not_columnar     :1;
    unsigned        as_integer_ips      :1;
    unsigned        as_zero_pad_ips     :1;
    unsigned        as_no_titles        :1; /* no titles or printed titles */
    unsigned        as_integer_sensors  :1;
    unsigned        as_no_final_delim   :1;
    unsigned        as_no_newline       :1;
    unsigned        as_legacy_icmp      :1;
    unsigned        as_field_icmp       :1;
};


/*
 * This struct holds the field names and their IDs.  The same names
 * are used for the column titles.
 *
 * Names that map to the same ID must be put together, with the name
 * that you want to use for the title first, then any aliases
 * afterward.

 * NOTE!! We are assuming that the stringmap code leaves things in the
 * order we insert them and doesn't re-arrange them.  Since that code
 * uses a linked-list, we are safe for now.
 */
static const sk_stringmap_entry_t field_map_entries[] = {
    {"sIP",          RWREC_FIELD_SIP},
    {"sip",          RWREC_FIELD_SIP},
    {"1",            RWREC_FIELD_SIP},
    {"dIP",          RWREC_FIELD_DIP},
    {"dip",          RWREC_FIELD_DIP},
    {"2",            RWREC_FIELD_DIP},
    {"sPort",        RWREC_FIELD_SPORT},
    {"sport",        RWREC_FIELD_SPORT},
    {"3",            RWREC_FIELD_SPORT},
    {"dPort",        RWREC_FIELD_DPORT},
    {"dport",        RWREC_FIELD_DPORT},
    {"4",            RWREC_FIELD_DPORT},
    {"protocol",     RWREC_FIELD_PROTO},
    {"5",            RWREC_FIELD_PROTO},
    {"packets",      RWREC_FIELD_PKTS},
    {"pkts",         RWREC_FIELD_PKTS},
    {"6",            RWREC_FIELD_PKTS},
    {"bytes",        RWREC_FIELD_BYTES},
    {"7",            RWREC_FIELD_BYTES},
    {"flags",        RWREC_FIELD_FLAGS},
    {"8",            RWREC_FIELD_FLAGS},
    {"sTime",        RWREC_FIELD_STIME},
    {"stime",        RWREC_FIELD_STIME},
    {"9",            RWREC_FIELD_STIME},
    {"dur",          RWREC_FIELD_ELAPSED},
    {"10",           RWREC_FIELD_ELAPSED},
    {"eTime",        RWREC_FIELD_ETIME},
    {"etime",        RWREC_FIELD_ETIME},
    {"11",           RWREC_FIELD_ETIME},
    {"sensor",       RWREC_FIELD_SID},
    {"12",           RWREC_FIELD_SID},
    {"in",           RWREC_FIELD_INPUT},
    {"13",           RWREC_FIELD_INPUT},
    {"out",          RWREC_FIELD_OUTPUT},
    {"14",           RWREC_FIELD_OUTPUT},
    {"nhIP",         RWREC_FIELD_NHIP},
    {"15",           RWREC_FIELD_NHIP},
#if  SK_ENABLE_INITIAL_TCPFLAGS
    {"initialFlags", RWREC_FIELD_INIT_FLAGS},
    {"initialflags", RWREC_FIELD_INIT_FLAGS},
    {"26",           RWREC_FIELD_INIT_FLAGS},
    {"sessionFlags", RWREC_FIELD_REST_FLAGS},
    {"sessionflags", RWREC_FIELD_REST_FLAGS},
    {"27",           RWREC_FIELD_REST_FLAGS},
    {"attributes",   RWREC_FIELD_TCP_STATE},
    {"28",           RWREC_FIELD_TCP_STATE},
    {"application",  RWREC_FIELD_APPLICATION},
    {"29",           RWREC_FIELD_APPLICATION},
#endif /* SK_ENABLE_INITIAL_TCPFLAGS */
    {"class",        RWREC_FIELD_FTYPE_CLASS},
    {"20",           RWREC_FIELD_FTYPE_CLASS},
    {"type",         RWREC_FIELD_FTYPE_TYPE},
    {"21",           RWREC_FIELD_FTYPE_TYPE},
    {"sTime+msec",   RWREC_FIELD_STIME_MSEC},
    {"stime+msec",   RWREC_FIELD_STIME_MSEC},
    {"22",           RWREC_FIELD_STIME_MSEC},
    {"eTime+msec",   RWREC_FIELD_ETIME_MSEC},
    {"etime+msec",   RWREC_FIELD_ETIME_MSEC},
    {"23",           RWREC_FIELD_ETIME_MSEC},
    {"dur+msec",     RWREC_FIELD_ELAPSED_MSEC},
    {"24",           RWREC_FIELD_ELAPSED_MSEC},
    {"icmpTypeCode", RWREC_FIELD_ICMP_TYPE_CODE},
    {"icmptypecode", RWREC_FIELD_ICMP_TYPE_CODE},
    {"25",           RWREC_FIELD_ICMP_TYPE_CODE}
};

static const size_t field_map_count = (sizeof(field_map_entries)
                                       / sizeof(sk_stringmap_entry_t));


/*
**  rwAsciiSetWidths(ascii_stream);
**
**    Set the column widths for all the columns in the 'ascii_stream'
**    struct.  The column widths will depend on flags set by the user,
**    such as whether the output is columnar, or the form of sensors
**    (names or numbers).
*/
static void rwAsciiSetWidths(rwAsciiStream_t *stream)
{
    uint8_t i;

    if (stream->as_not_columnar) {
        memset(stream->as_widths, 0,
               sizeof(uint8_t)*RWREC_PRINTABLE_FIELD_COUNT);
        return;
    }

    for (i = 0; i < RWREC_PRINTABLE_FIELD_COUNT; i++) {
        switch ((rwrec_printable_fields_t)i) {
          case RWREC_FIELD_SIP:
          case RWREC_FIELD_DIP:
          case RWREC_FIELD_NHIP:
            /* ip numbers */
#if SK_ENABLE_IPV6
            if (stream->as_ipv6_policy >= SK_IPV6POLICY_MIX) {
                /* If IPv6 support is available and IPv6 flows are not
                 * being ignored */
                stream->as_widths[i] = 39;
                break;
            }
#endif /* SK_ENABLE_IPV6 */
            if (stream->as_integer_ips) {
                stream->as_widths[i] = 10;
            } else {
                stream->as_widths[i] = 15;
            }
            break;

          case RWREC_FIELD_SPORT:
          case RWREC_FIELD_DPORT:
            /* sport and dport */
            stream->as_widths[i] = 5;
            break;

          case RWREC_FIELD_PROTO:
            /* proto */
            stream->as_widths[i] = 3;
            break;

          case RWREC_FIELD_PKTS:
          case RWREC_FIELD_BYTES:
            /* packets, bytes */
            stream->as_widths[i] = 10;
            break;

          case RWREC_FIELD_FLAGS:
          case RWREC_FIELD_INIT_FLAGS:
          case RWREC_FIELD_REST_FLAGS:
          case RWREC_FIELD_TCP_STATE:
            /* tcp flags, init-flags, non-init-flags, tcp-state */
            stream->as_widths[i] = 8;
            break;

          case RWREC_FIELD_APPLICATION:
            stream->as_widths[i] = 5;
            break;

          case RWREC_FIELD_ELAPSED:
            /* elapsed/duration */
            if (stream->as_timeflags & SKTIMESTAMP_NOMSEC) {
                stream->as_widths[i] = 5;
                break;
            }
            /* else fallthrough */

          case RWREC_FIELD_ELAPSED_MSEC:
            /* elapsed/duration with milliseconds */
            stream->as_widths[i] = 9;
            break;

          case RWREC_FIELD_STIME:
          case RWREC_FIELD_ETIME:
            /* sTime and end time */
            if (stream->as_timeflags & SKTIMESTAMP_NOMSEC) {
                if (stream->as_timeflags & SKTIMESTAMP_EPOCH) {
                    stream->as_widths[i] = 10;
                } else {
                    stream->as_widths[i] = 19;
                }
                break;
            }
            /* else fallthrough */

          case RWREC_FIELD_STIME_MSEC:
          case RWREC_FIELD_ETIME_MSEC:
            /* sTime and end time with milliseconds */
            if (stream->as_timeflags & SKTIMESTAMP_EPOCH) {
                stream->as_widths[i] = 14;
            } else {
                stream->as_widths[i] = 23;
            }
            break;

          case RWREC_FIELD_SID:
            /* sensor */
            if (stream->as_integer_sensors) {
                stream->as_widths[i] = 5;
            } else {
                stream->as_widths[i] = (uint8_t)sksiteSensorGetMaxNameStrLen();
            }
            break;

          case RWREC_FIELD_INPUT:
          case RWREC_FIELD_OUTPUT:
            /* input,output */
            stream->as_widths[i] = 5;
            break;

          case RWREC_FIELD_FTYPE_CLASS:
            /* flow-type class */
            stream->as_widths[i] = (uint8_t)sksiteClassGetMaxNameStrLen();
            break;

          case RWREC_FIELD_FTYPE_TYPE:
            /* flow-type type */
            stream->as_widths[i] = (uint8_t)sksiteFlowtypeGetMaxNameStrLen();
            break;

          case RWREC_FIELD_ICMP_TYPE_CODE:
            /* ICMP type and code in two columns */
            stream->as_widths[i] = 7;
            break;

        } /* switch */
    }
    return;
}
/* rwAsciiSetWidths */


/*
 *  rwAsciiSetDefaultFields(stream);
 *
 *    Configure the 'stream' to print all fields.
 */
static void rwAsciiSetDefaultFields(rwAsciiStream_t *stream)
{
    uint32_t i;

    stream->as_field_count = RWREC_PRINTABLE_FIELD_COUNT;

    stream->as_field_list = malloc(stream->as_field_count*sizeof(uint32_t));
    if (NULL == stream->as_field_list) {
        /* out of memory */
        skAppPrintErr(ERRMSG_ALLOC);
        exit(EXIT_FAILURE);
    }

    for (i = 0; i < stream->as_field_count; ++i) {
        stream->as_field_list[i] = i;
    }
}
/* rwAsciiSetDefaultFields */


/*
 *  rwAsciiVerifyIcmpColumns(stream);
 *
 *    If the ICMP type and code are to be written, verify that the
 *    sPort and dPort columns are present, adding them if required.
 */
static void rwAsciiVerifyIcmpColumns(rwAsciiStream_t *stream)
{
    uint32_t i;
    int have_sport = 0;
    int have_dport = 0;

    for (i = 0; i < stream->as_field_count; ++i) {
        if (stream->as_field_list[i] == RWREC_FIELD_SPORT) {
            have_sport = 1;
            if (have_dport) {
                return;
            }
        } else if (stream->as_field_list[i] == RWREC_FIELD_DPORT) {
            have_dport = 1;
            if (have_sport) {
                return;
            }
        }
    }

    /* if we make it here, sport and/or dport are needed */
    stream->as_field_list = realloc(stream->as_field_list,
                                    ((2 + stream->as_field_count)
                                     * sizeof(uint32_t)));
    if (NULL == stream->as_field_list) {
        /* out of memory */
        skAppPrintErr(ERRMSG_ALLOC);
        exit(EXIT_FAILURE);
    }

    if (!have_sport) {
        stream->as_field_list[stream->as_field_count]= RWREC_FIELD_SPORT;
        ++stream->as_field_count;
    }
    if (!have_dport) {
        stream->as_field_list[stream->as_field_count]= RWREC_FIELD_DPORT;
        ++stream->as_field_count;
    }
}
/* rwAsciiVerifyIcmpColumns */


/*
 *  rwAsciiPreparePrint(stream);
 *
 *    Do any final initialization prior to printing the column titles
 *    or the first row: Set the field list to the default list if the
 *    caller did not choose specific columns; if ICMP type and code
 *    output was requested, make certain the correct columns exist in
 *    the output; and set the width of the columns.
 */
static void rwAsciiPreparePrint(rwAsciiStream_t *stream)
{
    stream->as_initialized = 1;

    if (stream->as_field_count == 0) {
        rwAsciiSetDefaultFields(stream);
    }

    if (stream->as_legacy_icmp) {
        rwAsciiVerifyIcmpColumns(stream);
    }

    rwAsciiSetWidths(stream);
}
/* rwAsciiPreparePrint */


int rwAsciiFlush(rwAsciiStream_t *stream)
{
    return fflush(stream->as_out_stream);
}


void rwAsciiStreamDestroy(rwAsciiStream_t **stream)
{
    assert(stream);

    if (NULL == *stream) {
        return;
    }

    if ((*stream)->as_field_count > 0) {
        free((*stream)->as_field_list);
    }
    free(*stream);
    *stream = NULL;
}
/* rwAsciiStreamDestroy */


int rwAsciiStreamCreate(rwAsciiStream_t **stream)
{
    assert(stream);

    /* create the object */
    *stream = calloc(1, sizeof(rwAsciiStream_t));
    if (!*stream) {
        /* out of memory */
        skAppPrintErr(ERRMSG_ALLOC);
        return -1;
    }

    /* non-zero defaults */
    (*stream)->as_out_stream = stdout;
    (*stream)->as_delimiter = '|';
#if SK_ENABLE_IPV6
    (*stream)->as_ipv6_policy = SK_IPV6POLICY_MIX;
#else
    (*stream)->as_ipv6_policy = SK_IPV6POLICY_IGNORE;
#endif

    return 0;
}


int rwAsciiSetFields(
    rwAsciiStream_t    *stream,
    const uint32_t     *field_list,
    uint32_t            field_count)
{
    uint8_t i;
    int saw_icmp_field = 0;

    assert(stream);

    /* verify input */
    if ((field_count == 0) || (field_list == NULL)) {
        return -1;
    }

    for (i = 0; i < field_count; ++i) {
        if (field_list[i] >= RWREC_PRINTABLE_FIELD_COUNT) {
            /* bad value */
            skAppPrintErr("Value '%u' is not a value field id",
                          field_list[i]);
            return -1;
        }
        if (field_list[i] == RWREC_FIELD_ICMP_TYPE_CODE) {
            saw_icmp_field = 1;
        }
    }

    /* set fields */
    stream->as_field_list = malloc(field_count * sizeof(uint32_t));
    if (NULL == stream->as_field_list) {
        /* out of memory */
        skAppPrintErr(ERRMSG_ALLOC);
        return -1;
    }

    memcpy(stream->as_field_list, field_list, field_count * sizeof(uint32_t));
    stream->as_field_count = field_count;

    if (saw_icmp_field) {
        stream->as_field_icmp = 1;
    }

    return 0;
}
/* rwAsciiSetFields */


void rwAsciiSetOutputHandle(rwAsciiStream_t *stream, FILE *fh)
{
    assert(stream);
    if (fh == NULL) {
        stream->as_out_stream = stdout;
    } else {
        stream->as_out_stream = fh;
    }
}


void rwAsciiSetDelimiter(rwAsciiStream_t *stream, char delimiter)
{
    assert(stream);
    stream->as_delimiter = delimiter;
}


void rwAsciiSetNoColumns(rwAsciiStream_t *stream)
{
    assert(stream);
    stream->as_not_columnar = 1;
}


void rwAsciiSetIPv6Policy(rwAsciiStream_t *stream, sk_ipv6policy_t policy)
{
    assert(stream);
    stream->as_ipv6_policy = policy;
}


void rwAsciiSetIntegerIps(rwAsciiStream_t *stream)
{
    assert(stream);

    if (stream->as_zero_pad_ips) {
        skAppPrintErr("Printing IPs as integer overrides zero padding IPs");
        stream->as_zero_pad_ips = 0;
    }

    stream->as_integer_ips = 1;
}


void rwAsciiSetZeroPadIps(rwAsciiStream_t *stream)
{
    assert(stream);

    if (stream->as_integer_ips) {
        skAppPrintErr("Printing IPs as integer overrides zero padding IPs");
        return;
    }

    stream->as_zero_pad_ips = 1;
}


void rwAsciiSetNoTitles(rwAsciiStream_t *stream)
{
    assert(stream);
    stream->as_no_titles = 1;
}


void rwAsciiSetTimestampFlags(rwAsciiStream_t *stream, uint32_t time_flags)
{
    assert(stream);
    stream->as_timeflags = time_flags;
}


void rwAsciiSetIntegerSensors(rwAsciiStream_t *stream)
{
    assert(stream);
    stream->as_integer_sensors = 1;
}


void rwAsciiSetIcmpTypeCode(rwAsciiStream_t *stream)
{
    assert(stream);
    stream->as_legacy_icmp = 1;
}


void rwAsciiSetNoNewline(rwAsciiStream_t *stream)
{
    assert(stream);
    stream->as_no_newline = 1;
}


void rwAsciiSetNoFinalDelimiter(rwAsciiStream_t *stream)
{
    assert(stream);
    stream->as_no_final_delim = 1;
}


void rwAsciiGetFieldName(
    char                       *buf,
    size_t                      buf_len,
    rwrec_printable_fields_t    field_id)
{
    size_t i;

    assert(buf);
    assert(buf_len > 0);

    buf[0] = '\0';

    for (i = 0; i < field_map_count; ++i) {
        if (field_map_entries[i].id == field_id) {
            strncpy(buf, field_map_entries[i].name, buf_len-1);
            buf[buf_len-1] = '\0';
            break;
        }
    }
}
/* rwAsciiGetFieldName */


void rwAsciiPrintTitles(rwAsciiStream_t *stream)
{
    char buf[RWREC_PRINTABLE_MAX_NAME_LEN];
    uint32_t i;

    /* initialize */
    if (stream->as_initialized == 0) {
        rwAsciiPreparePrint(stream);
    }

    /* don't print titles if we are not supposed to or if we already
     * have */
    if (stream->as_no_titles) {
        return;
    }
    stream->as_no_titles = 1;

    for (i = 0; i < stream->as_field_count; ++i) {
        if (stream->as_field_list[i] == RWREC_FIELD_ICMP_TYPE_CODE) {
            if (stream->as_not_columnar) {
                fprintf(stream->as_out_stream, "%s%c%s",
                        "iType", stream->as_delimiter, "iCode");
            } else {
                fprintf(stream->as_out_stream, "%s%c%s",
                        "iTy", stream->as_delimiter, "iCo");
            }
        } else {
            rwAsciiGetFieldName(buf, sizeof(buf), stream->as_field_list[i]);
            if (stream->as_not_columnar) {
                fprintf(stream->as_out_stream, "%s", buf);
            } else {
                fprintf(stream->as_out_stream, "%*.*s",
                        stream->as_widths[stream->as_field_list[i]],
                        stream->as_widths[stream->as_field_list[i]],
                        buf);
            }
        }
        if ( !stream->as_no_final_delim || i+1 < stream->as_field_count) {
            fprintf(stream->as_out_stream, "%c", stream->as_delimiter);
        }
    } /* for */

    if ( !stream->as_no_newline) {
        fprintf(stream->as_out_stream, "\n");
    }

    return;
}
/* rwAsciiPrintTitles */


/*  Print 'rwrec' to the ascii stream 'stream'.  See header for details */
void rwAsciiPrintRec(
    rwAsciiStream_t    *stream,
    const rwRec        *rwrec)
{
    static char buffer[128];
    skipaddr_t ip;
    uint32_t ip_flags;
    imaxdiv_t idiv;
    uint32_t i;

    assert(stream);
    assert(rwrec);
    assert(sizeof(buffer) > 1+SK_NUM2DOT_STRLEN);
    assert(sizeof(buffer) > 1+SKTIMESTAMP_STRLEN);

    /* initialize */
    if (stream->as_initialized == 0) {
        rwAsciiPreparePrint(stream);
    }

    /* print titles if we haven't */
    if (stream->as_no_titles == 0) {
        /* print titles */
        rwAsciiPrintTitles(stream);
    }

    ip_flags = 0;
    if (stream->as_integer_ips) {
        ip_flags |= SKIPADDR_DECIMAL;
    } else if (stream->as_zero_pad_ips) {
        ip_flags |= SKIPADDR_ZEROPAD;
    }

    for (i = 0; i < stream->as_field_count; ++i) {
        switch ((rwrec_printable_fields_t)stream->as_field_list[i]) {
          case RWREC_FIELD_SIP:
            rwRecMemGetSIP(rwrec, &ip);
            skipaddrString(buffer, &ip, ip_flags);
            break;

          case RWREC_FIELD_DIP:
            rwRecMemGetDIP(rwrec, &ip);
            skipaddrString(buffer, &ip, ip_flags);
            break;

          case RWREC_FIELD_NHIP:
            rwRecMemGetNhIP(rwrec, &ip);
            skipaddrString(buffer, &ip, ip_flags);
            break;

          case RWREC_FIELD_SPORT:
            if (stream->as_legacy_icmp && rwRecGetProto(rwrec) == 1) {
                /* Put the ICMP type in this column. */
                sprintf(buffer, "%u", rwRecGetIcmpType(rwrec));
            } else {
                /* Put the sPort value here, regardless of protocol */
                sprintf(buffer, "%u", (unsigned int)rwRecGetSPort(rwrec));
            }
            break;

          case RWREC_FIELD_DPORT:
            if (stream->as_legacy_icmp && rwRecGetProto(rwrec) == 1) {
                /* Put the ICMP code in this column. */
                sprintf(buffer, "%u", rwRecGetIcmpCode(rwrec));
            } else {
                /* Put the dPort value here, regardless of protocol */
                sprintf(buffer, "%u", (unsigned int)rwRecGetDPort(rwrec));
            }
            break;

          case RWREC_FIELD_ICMP_TYPE_CODE:
            if (rwRecGetProto(rwrec) != 1) {
                /* not ICMP; leave columns blank */
                if (stream->as_not_columnar) {
                    sprintf(buffer, "%c", stream->as_delimiter);
                } else {
                    sprintf(buffer, "%c   ", stream->as_delimiter);
                }
            } else if (stream->as_not_columnar) {
                sprintf(buffer, "%u%c%u",
                        rwRecGetIcmpType(rwrec), stream->as_delimiter,
                        rwRecGetIcmpCode(rwrec));
            } else {
                sprintf(buffer, "%u%c%3u",
                        rwRecGetIcmpType(rwrec), stream->as_delimiter,
                        rwRecGetIcmpCode(rwrec));
            }
            break;

          case RWREC_FIELD_PROTO:
            sprintf(buffer, "%u", (unsigned int)rwRecGetProto(rwrec));
            break;

          case RWREC_FIELD_PKTS:
            sprintf(buffer, "%u", rwRecGetPkts(rwrec));
            break;

          case RWREC_FIELD_BYTES:
            sprintf(buffer, "%u", rwRecGetBytes(rwrec));
            break;

          case RWREC_FIELD_FLAGS:
            tcpflags_string_r(rwRecGetFlags(rwrec), buffer);
            break;

          case RWREC_FIELD_INIT_FLAGS:
            tcpflags_string_r(rwRecGetInitFlags(rwrec), buffer);
            break;

          case RWREC_FIELD_REST_FLAGS:
            tcpflags_string_r(rwRecGetRestFlags(rwrec), buffer);
            break;

          case RWREC_FIELD_TCP_STATE:
            {
                const uint8_t state = rwRecGetTcpState(rwrec);
                sprintf(buffer, "%c%c%c     ",
                        ((state & SK_TCPSTATE_TIMEOUT_KILLED)
                         ? 'T' : ' '),
                        ((state & SK_TCPSTATE_TIMEOUT_STARTED)
                         ? 'C' : ' '),
                        ((state & SK_TCPSTATE_FIN_FOLLOWED_NOT_ACK)
                         ? 'F' : ' '));
            }
            break;

          case RWREC_FIELD_APPLICATION:
            sprintf(buffer, "%u", (unsigned int)rwRecGetApplication(rwrec));
            break;

          case RWREC_FIELD_ELAPSED:
            if (stream->as_timeflags & SKTIMESTAMP_NOMSEC) {
                sprintf(buffer, "%u", rwRecGetElapsedSeconds(rwrec));
                break;
            }
            /* else fallthough */
          case RWREC_FIELD_ELAPSED_MSEC:
            idiv = imaxdiv(rwRecGetElapsed(rwrec), 1000);
            sprintf(buffer, ("%" PRId64 ".%03" PRId64),
                    idiv.quot, idiv.rem);
            break;

          case RWREC_FIELD_STIME:
            sktimestamp_r(buffer, rwRecGetStartTime(rwrec),
                          stream->as_timeflags);
            break;

          case RWREC_FIELD_STIME_MSEC:
            sktimestamp_r(buffer, rwRecGetStartTime(rwrec),
                          (stream->as_timeflags & ~SKTIMESTAMP_NOMSEC));
            break;

          case RWREC_FIELD_ETIME:
            sktimestamp_r(buffer, rwRecGetEndTime(rwrec),stream->as_timeflags);
            break;

          case RWREC_FIELD_ETIME_MSEC:
            sktimestamp_r(buffer, rwRecGetEndTime(rwrec),
                          (stream->as_timeflags & ~SKTIMESTAMP_NOMSEC));
            break;

          case RWREC_FIELD_SID:
            /* sensor ID */
            if ( !stream->as_integer_sensors ) {
                sksiteSensorGetName(buffer, sizeof(buffer),
                                    rwRecGetSensor(rwrec));
            } else if (SK_INVALID_SENSOR == rwRecGetSensor(rwrec)) {
                strcpy(buffer, "-1");
            } else {
                sprintf(buffer, "%u", (unsigned int)rwRecGetSensor(rwrec));
            }
            break;

          case RWREC_FIELD_INPUT:
            sprintf(buffer, "%u", (unsigned int)rwRecGetInput(rwrec));
            break;

          case RWREC_FIELD_OUTPUT:
            /* output */
            sprintf(buffer, "%u", (unsigned int)rwRecGetOutput(rwrec));
            break;

          case RWREC_FIELD_FTYPE_CLASS:
            sksiteFlowtypeGetClass(buffer, sizeof(buffer),
                                   rwRecGetFlowType(rwrec));
            break;

          case RWREC_FIELD_FTYPE_TYPE:
            sksiteFlowtypeGetType(buffer, sizeof(buffer),
                                  rwRecGetFlowType(rwrec));
            break;

        } /* switch */

        if (stream->as_not_columnar) {
            fprintf(stream->as_out_stream, "%s", buffer);
        } else {
            fprintf(stream->as_out_stream, "%*s",
                    stream->as_widths[stream->as_field_list[i]], buffer);
        }
        if ( !stream->as_no_final_delim || i+1 < stream->as_field_count) {
            fprintf(stream->as_out_stream, "%c", stream->as_delimiter);
        }
    } /* for */

    if ( !stream->as_no_newline) {
        fprintf(stream->as_out_stream, "\n");
    }

    return;
}
/* rwAsciiPrintRec */


int rwAsciiParseFieldList(
    rwrec_printable_fields_t  **field_ids,
    uint32_t                   *field_count,
    const char                 *field_string)
{
    const uint32_t max_field_count = 8 * RWREC_PRINTABLE_FIELD_COUNT;
    unsigned long n, range_start, i;
    const char *sp;
    char *ep;
    rwrec_printable_fields_t *out_array_list = NULL; /* returned array */
    uint32_t out_count = 0; /* returned count */
    uint32_t array_size;
    uint32_t range_length;
    const uint32_t min_value = 1;
    const uint32_t max_value = RWREC_PRINTABLE_FIELD_COUNT;
    /* the last thing we successfully parsed. NUMBER is a single number
     * or start of a range; RANGE is the upper limit of a range. */
    enum {COMMA, HYPHEN, NUMBER, RANGE} parse_state;

    /* check input */
    assert(field_ids);
    assert(field_count);
    assert(field_string);

    /* Create the array to hold the list of values; use 2 * number of
     * possible fields. */
    array_size = RWREC_PRINTABLE_FIELD_COUNT * 2;

    out_array_list = calloc(array_size, sizeof(rwrec_printable_fields_t));
    if (!out_array_list) {
        skAppPrintErr("Out of memory! out_array_list=calloc()");
        goto ERROR;
    }

    /* range_start is non-zero when the number we are about to parse
     * is the upper half of the range m-n */
    range_start = 0;
    parse_state = COMMA;
    sp = field_string;

    /* parse user input */
    while (*sp) {
        if (!isdigit((int)*sp)) {
            if (parse_state == HYPHEN) {
                /* digit must follow a hyphen */
                skAppPrintErr(("Parse error: expecting digit after hyphen; "
                               "saw '%c' at position %u"),
                              *sp, (unsigned int)(1u+(sp - field_string)));
                goto ERROR;
            }
            if (*sp == ',') {
                /* Comma is legal anywhere except after a hyphen,
                 * which we handled above. (we allow double comma) */
                parse_state = COMMA;
                ++sp;
                continue;
            }
            if (parse_state == RANGE) {
                /* range must end with a comma */
                skAppPrintErr(("Parse error: expecting comma after range; "
                               "saw '%c' at position %u"),
                               *sp, (unsigned int)(1u+(sp - field_string)));
                goto ERROR;
            }
            if (parse_state == COMMA) {
                /* a digit or a comma(handled above) must follow a comma */
                skAppPrintErr(("Parse error: expecting digit after comma; "
                               "saw '%c' at position %u"),
                              *sp, (unsigned int)(1u+(sp - field_string)));
                goto ERROR;
            }
            /* if we are here, parse_state must be NUMBER */
            assert(parse_state == NUMBER);
            if (*sp == '-') {
                parse_state = HYPHEN;
                ++sp;
                continue;
            }
            skAppPrintErr(("Parse error: expecting digit, comma, or hyphen; "
                           "saw '%c' at position %u"),
                          *sp, (unsigned int)(1u+(sp - field_string)));
            goto ERROR;
        }

        /* If we make it here, we are looking at a digit; parse_state
         * must be either COMMA or HYPHEN */
        assert(parse_state == COMMA || parse_state == HYPHEN);

        /* parse the number */
        errno = 0;
        n = strtoul(sp, &ep, 10);
        if (sp == ep) {
            skAppPrintErr("Cannot parse '%s' as an integer", sp);
            goto ERROR;
        }
        if (n == ULONG_MAX && errno == ERANGE) {
            skAppPrintErr("The number '%s' overflows the parser", sp);
            goto ERROR;
        }
        if (n < min_value) {
            skAppPrintErr("Value '%lu' is less than minimum of %u",
                          n, min_value);
            goto ERROR;
        }
        if ((max_value != 0) && (n >= max_value)) {
            skAppPrintErr("Value '%lu' is above the maximum of %u",
                          n, max_value);
            goto ERROR;
        }

        /* parsed the number; move pointer to next token */
        sp = ep;

        /* determine if the number we just parsed is the end of a
         * range or a lone number---and potentially the start of a
         * range */
        if (parse_state == COMMA) {
            /* we were not parsing the upper half of a range.  treat
             * it as a range of 1 */
            parse_state = NUMBER;
            range_length = 1;
            range_start = n;
        } else {
            /* parse_state must be HYPHEN: we were parsing a range */
            parse_state = RANGE;

            if (n < range_start) {
                /* user entered 3-2 */
                skAppPrintErr("Bad range: lower > upper: %lu-%lu",
                              range_start, n);
                goto ERROR;
            }

            if (range_start == n) {
                /* user entered 3-3, ignore second '3' */
                continue;
            }

            /* we added range_start on the previous iteration, so add
             * range_start+1 through n now; */
            range_length = n - range_start;
            range_start++;
        }

        /* check number of fields user gave */
        if ((out_count + range_length) > max_field_count) {
            skAppPrintErr("Too many fields provided. Only %u fields allowed",
                          max_field_count);
            goto ERROR;
        }

        /* check if we need to grow array?  If so, realloc the array

         * to double its size and memset the new section to 0. */
        while ((out_count + range_length) > array_size) {
            size_t old_size = array_size;
            array_size *= 2;
            if (array_size > max_field_count) {
                array_size = max_field_count;
            }
            out_array_list = realloc(out_array_list, array_size);
            if (!out_array_list) {
                skAppPrintErr("Out of memory! out_array_list=realloc()");
                goto ERROR;
            }
            memset((out_array_list+old_size), 0, array_size-old_size);
        }

        /* add the entries */
        for (i = range_start; i <= n; ++i) {
            out_array_list[out_count] = i;
            ++out_count;
        }
    } /* while(*sp) */

    *field_count = out_count;
    *field_ids = out_array_list;
    return 0;

  ERROR:
    if (field_ids) {
        free(field_ids);
    }
    *field_count = 0;
    return -1;
}
/* rwAsciiParseFieldList */


int rwAsciiFieldMapAddDefaultFields(sk_stringmap_t **field_map)
{
    assert(field_map);

    /* Create the map if necessary */
    if (NULL == *field_map) {
        if (SKSTRINGMAP_OK != skStringMapCreate(field_map)) {
            return -1;
        }
    }

    /* add entries */
    if (skStringMapAddIDArray(*field_map, field_map_count, field_map_entries)
        != SKSTRINGMAP_OK)
    {
        return -1;
    }

    return 0;
}


int rwAsciiFieldMapParseFields(
    uint32_t              **field_list,
    uint32_t               *field_count,
    const char             *input,
    const sk_stringmap_t   *field_map,
    rwascii_dupes_t         handle_dupes)
{
    int rv = 1; /* return value; assume failure */
    sk_vector_t *entries_vec = NULL;
    sk_stringmap_entry_t *map_entry;
    sk_stringmap_status_t err;
    uint32_t *list = NULL;
    size_t count;
    size_t i;
    uint32_t j;
    char *bad_token = NULL;

    assert(field_list);
    assert(field_count);

    /* initialize field_count */
    *field_count = 0;

    /* create vector to hold match results */
    entries_vec = skVectorNew(sizeof(sk_stringmap_entry_t*));
    if (entries_vec == NULL) {
        skAppPrintErr("Allocation failure at %s:%d",
                      __FILE__, __LINE__);
        goto END;
    }

    /* attempt to match */
    err = skStringMapMatch(entries_vec, &bad_token, field_map, input);
    if (err != SKSTRINGMAP_OK) {
        switch (err) {
          case SKSTRINGMAP_PARSE_NO_MATCH:
            skAppPrintErr("No match was found for the field '%s'", bad_token);
            goto END;
          case SKSTRINGMAP_PARSE_AMBIGUOUS:
            skAppPrintErr("The field '%s' matches multiple keys", bad_token);
            goto END;
          case SKSTRINGMAP_PARSE_UNPARSABLE:
            skAppPrintErr("Unable to parse the field '%s'", bad_token);
            goto END;
          default:
            skAppPrintErr("Unexpected return value from field parser (%d)",
                          err);
            goto END;
        }
    }

    /* put the results into the field_list[] array */
    count = skVectorGetCount(entries_vec);
    list = calloc(count, sizeof(uint32_t));
    if (!list) {
        skAppPrintErr("Allocation failure at %s:%d",
                      __FILE__, __LINE__);
        goto END;
    }

    for (i = 0; i < count; ++i) {
        (void)skVectorGetValue(&map_entry, entries_vec, i);
        if (handle_dupes != RW_ASCII_DUPES_KEEP) {
            /* search for a duplicate */
            for (j = 0; j < *field_count; ++j) {
                if (list[j] != map_entry->id) {
                    continue;
                }
                /* found a dupe */
                switch (handle_dupes) {
                  case RW_ASCII_DUPES_ERROR:
                    skAppPrintErr("Error: multiple occurrences of %u value",
                                  map_entry->id);
                    goto END;

                  case RW_ASCII_DUPES_REMOVE_WARN:
                    skAppPrintErr("Ignoring multiple occurrences of %u value",
                                  map_entry->id);
                    /* FALLTHROUGH */

                  case RW_ASCII_DUPES_REMOVE_SILENT:
                    /* force us out of the for-loop */
                    goto NEXT_MAP_ENTRY;

                  case RW_ASCII_DUPES_KEEP:
                    /* shouldn't be in this loop at all */
                    assert(0);
                    abort();
                }
            }
        }

        /* add the entry */
        list[*field_count] = map_entry->id;
        ++*field_count;

      NEXT_MAP_ENTRY:
        /* NO-OP*/ ;
    }

    /* success */
    *field_list = list;
    rv = 0;

  END:
    if (rv != 0) {
        *field_count = 0;
        if (list != NULL) {
            free(list);
        }
    }
    if (bad_token != NULL) {
        free(bad_token);
    }
    if (entries_vec != NULL) {
        skVectorDestroy(entries_vec);
    }

    return rv;
}


void rwAsciiFieldMapPrintUsage(FILE *fh, sk_stringmap_t *field_map)
{
    const char column_sep = ';';
    const char alias_sep = ',';
    char line_buf[81];
    sk_stringmap_entry_t *entry;
    sk_stringmap_entry_t *old_entry;
    sk_link_item_t *node;
    sk_link_err_t rv;
    int len;
    int indent_len;
    int avail_len;
    int entry_len;
    int total_len;
    int last_field_end;

    fprintf(fh,
            "\t(Semicolon separates unique columns."
            " Comma separates column aliases.\n"
            "\t Names can be abbreviated to shortest unique prefix.)\n");

    /* previous value from map */
    old_entry = NULL;

    /* set indentation */
    indent_len = snprintf(line_buf, sizeof(line_buf), "    ");
    total_len = indent_len;
    avail_len = sizeof(line_buf) - indent_len - 1;
    last_field_end = 0;

    /* loop through all entries in the map */
    for (rv = skLinkGetHead(&node, field_map);
         rv == SKLINK_OK;
         rv = skLinkGetNext(&node, node))
    {
        skLinkGetData((void**)&entry, node);
        entry_len = strlen(entry->name);

        if (last_field_end == 0) {
            /* very first field */
            last_field_end = total_len - 1;
        } else if ((old_entry != NULL) && (old_entry->id == entry->id)) {
            /* 'entry' is an alias for 'old_entry' */
            len = snprintf(&(line_buf[total_len]), avail_len, "%c",
                           alias_sep);
            assert(len < avail_len);
            total_len += len;
            avail_len -= len;
            entry_len += len;
        } else {
            /* start of a new field */
            len = snprintf(&(line_buf[total_len]), avail_len, "%c ",
                           column_sep);
            assert(len < avail_len);
            total_len += len;
            avail_len -= len;
            entry_len += len;
            last_field_end = total_len - 1;
        }

        if (entry_len >= avail_len) {
            /* need to start a new line */
            int to_move;
            if (last_field_end <= indent_len) {
                skAppPrintErr("Too many aliases or switch names too long");
                assert(0);
                abort();
            }
            line_buf[last_field_end] = '\0';
            fprintf(fh, "%s\n", line_buf);
            ++last_field_end;
            to_move = total_len - last_field_end;
            if (to_move > 0) {
                memmove(&(line_buf[indent_len]), &(line_buf[last_field_end]),
                        to_move);
            }
            avail_len = sizeof(line_buf) - indent_len - to_move - 1;
            total_len = indent_len + to_move;
            last_field_end = indent_len - 1;
        }

        old_entry = entry;
        len = snprintf(&(line_buf[total_len]), avail_len, "%s", entry->name);
        assert(len < avail_len);
        total_len += len;
        avail_len -= len;
    }

    /* close out last line */
    if (last_field_end > 0) {
        fprintf(fh, "%s%c\n", line_buf, column_sep);
    }
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
