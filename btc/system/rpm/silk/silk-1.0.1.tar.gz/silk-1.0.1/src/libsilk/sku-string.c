/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  sku-string.c
**
**  A collection of utility routines to manipulate strings
**
*/

#include "silk.h"

RCSIDENT("$SiLK: sku-string.c 11248 2008-04-11 19:07:39Z mthomas $");

#include "utils.h"


#define STRING_PARSE_MIN_YEAR   1970
#define STRING_PARSE_MAX_YEAR   2039
#define STRING_PARSE_MIN_EPOCH  (1 << 29)       /* Mon Jan  5 18:48:32 1987 */
#define STRING_PARSE_MAX_EPOCH  ((1u << 31)-1)  /* Tue Jan 19 03:14:07 2038 */



/* Structure used when parsing a comma-separated list of numbers and ranges */
typedef struct sk_number_parser_st {
    const char *sp;
    const char *end_chars;
    int         base;
    uint32_t    min;
    uint32_t    max;
} sk_number_parser_t;

/* Values used by _skNumberListParser*() to indicate success.  Error
 * values are given by silk_utils_errcode_t. */
typedef enum {
    /* Indicates _skNumberListParserInit() initialized successfully */
    SK_NUM_PARSER_OK = 0,

    /* Indicates _skNumberListParserNext() parsed a single number and
     * an optional trailing comma, e.g. "3" or "5," */
    SK_NUM_PARSER_NUMBER,

    /* Indicates _skNumberListParserNext() parsed a range and an
     * optional trailing comma, e.g., "3-4" or "5-6," */
    SK_NUM_PARSER_RANGE,

    /* Indicates _skNumberListParserNext() parsed an open-ended range
     * and an optional trailing comma, e.g., "3-" or "5-,".  Ranges
     * with open-beginnings (e.g., "-7") are not allowed. */
    SK_NUM_PARSER_RANGE_OPENMAX,

    /* Indicates _skNumberListParserInit() or
     * _skNumberListParserNext() reached the end of the number list;
     * that is, current character is NUL, or whitespace, or a
     * character specified in the end_chars. */
    SK_NUM_PARSER_END_OF_STRING
} sk_number_parser_result_t;


/*
 *  pos = _skNumberParserCurrentChar(p);
 *
 *    Returns the beginning of the token that the parser was parsing
 *    when it encountered the error.
 */
#define _skNumberParserCurrentChar(parser) ((parser)->sp)


/* this should be same magnitude as last error code */
#define PARSE_ERRORCODE_COUNT 12

#define PARSE_ERRORCODE_TO_INDEX(errcode)                               \
    (((errcode + PARSE_ERRORCODE_COUNT) < 0)                            \
     ? (-1)                                                             \
     : (errcode + PARSE_ERRORCODE_COUNT))

#define PARSE_ERRORCODE_MSG(errcode)                                    \
    ((PARSE_ERRORCODE_TO_INDEX(errcode) < 0)                            \
     ? ""                                                               \
     : ((PARSE_ERRORCODE_TO_INDEX(errcode) > PARSE_ERRORCODE_COUNT)     \
        ? ""                                                            \
        : parse_error_default[PARSE_ERRORCODE_TO_INDEX(errcode)]))


static char parse_error_buf[PARSE_ERRORCODE_COUNT+1][2048];

static const char *parse_error_default[PARSE_ERRORCODE_COUNT+1] = {
    "Value is above maximum",           /* SKUTILS_ERR_MAXIMUM */
    "Value is below minimum",           /* SKUTILS_ERR_MINIMUM */
    "NO SUCH ERROR",                    /* */
    "Out of memory",                    /* SKUTILS_ERR_ALLOC */
    "Too many fields provided",         /* SKUTILS_ERR_TOO_MANY_FIELDS */
    "Unexpected end-of-input",          /* SKUTILS_ERR_SHORT */
    "Range is invalid (min > max)",     /* SKUTILS_ERR_BAD_RANGE */
    "Value underflows the parser",      /* SKUTILS_ERR_UNDERFLOW */
    "Value overflows the parser",       /* SKUTILS_ERR_OVERFLOW */
    "Unexpected character",             /* SKUTILS_ERR_BAD_CHAR */
    "Input contains only whitespae",    /* SKUTILS_ERR_EMPTY */
    "Invalid input to function",        /* SKUTILS_ERR_INVALID */
    "Command successful"                /* SKUTILS_OK */
};


#ifdef TEST_PRINTF_FORMATS
#  define _parseError(errcode, ...) printf(__VA_ARGS__)
#  define PE_NULL  "ERROR"
#else
#  define PE_NULL  NULL
static int _parseError(
    silk_utils_errcode_t    errcode,
    const char             *fmt,
    ...)
    SK_CHECK_PRINTF(2, 3);

static int _parseError(
    silk_utils_errcode_t    errcode,
    const char             *fmt,
    ...)
{
    va_list args;
    int idx;
    char *buf;

    idx = PARSE_ERRORCODE_TO_INDEX(errcode);

    if (idx < 0 || idx > PARSE_ERRORCODE_COUNT) {
        return errcode;
    }
    buf = parse_error_buf[idx];

    if (fmt == PE_NULL) {
        snprintf(buf, sizeof(parse_error_buf[0]), "%s",
                 parse_error_default[idx]);
        buf[sizeof(parse_error_buf[0])-1] = '\0';
        return errcode;
    }

    va_start(args, fmt);
    vsnprintf(buf, sizeof(parse_error_buf[0]), fmt, args);
    buf[sizeof(parse_error_buf[0])-1] = '\0';
    va_end(args);
    return errcode;
}
#endif /* TEST_PRINTF_FORMATS */


const char *skStringParseStrerror(int errorcode)
{
    static char tmpbuf[2048];
    int idx = PARSE_ERRORCODE_TO_INDEX(errorcode);

    if (errorcode > 0) {
        return "Extra text follows value";
    }
    if (idx < 0 || idx > PARSE_ERRORCODE_COUNT) {
        snprintf(tmpbuf, sizeof(tmpbuf), "Unrecognized error (%d)", errorcode);
        tmpbuf[sizeof(tmpbuf)-1] = '\0';
        return tmpbuf;
    }

    return parse_error_buf[idx];
}


/* Convert integer 0 to string "0.0.0.0"; uses static buffer */
char *num2dot(uint32_t ip)
{
    static char tmpbuf[SK_NUM2DOT_STRLEN];
    return num2dot_r(ip, tmpbuf);
}


/* Convert integer 0 to string "0.0.0.0"; uses caller's buffer */
char *num2dot_r(uint32_t ip, char *outbuf)
{
    snprintf(outbuf, SK_NUM2DOT_STRLEN, "%u.%u.%u.%u",
             ((ip >> 24) & 0xFF), ((ip >> 16) & 0xFF),
             ((ip >> 8) & 0xFF), (ip & 0xFF));
    outbuf[SK_NUM2DOT_STRLEN-1] = '\0';
    return outbuf;
}


/* Convert integer 0 to string "000.000.000.000"; uses static buffer */
char *num2dot0(uint32_t ip)
{
    static char dotted[SK_NUM2DOT_STRLEN];
    return num2dot0_r(ip, dotted);
}


/* Convert integer 0 to string "000.000.000.000"; uses caller's buffer */
char *num2dot0_r(uint32_t ip, char *outbuf)
{
    snprintf(outbuf, SK_NUM2DOT_STRLEN, "%03u.%03u.%03u.%03u",
             ((ip >> 24) & 0xFF), ((ip >> 16) & 0xFF),
             ((ip >> 8) & 0xFF), (ip & 0xFF));
    outbuf[SK_NUM2DOT_STRLEN-1] = '\0';
    return outbuf;
}


/* Convert a DNS name to an in_addr_t. */
const char *skNameToAddr(const char *name, struct in_addr *addr)
{
    struct addrinfo *addrinfo;
    struct addrinfo hints;
    struct sockaddr_in *sockaddr;
    int rv;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    rv = getaddrinfo(name, NULL, &hints, &addrinfo);
    if (rv != 0) {
        return gai_strerror(rv);
    }
    sockaddr = (struct sockaddr_in *)addrinfo->ai_addr;
    memcpy(&addr->s_addr, &sockaddr->sin_addr, sizeof(*addr));
    freeaddrinfo(addrinfo);
    return NULL;
}


/* Convert integer to FSRPAUEC string; space (' ') represents unset flags. */
char *tcpflags_string(uint8_t flags)
{
    static char flag_string[SK_TCPFLAGS_STRLEN];
    return tcpflags_string_r(flags, flag_string);
}


/* Convert integer to FSRPAUEC string; space (' ') represents unset
 * flags.  Users caller's buffer. */
char *tcpflags_string_r(uint8_t flags, char *outbuf)
{
    outbuf[0] = (char)((flags & FIN_FLAG) ? 'F' : ' ');
    outbuf[1] = (char)((flags & SYN_FLAG) ? 'S' : ' ');
    outbuf[2] = (char)((flags & RST_FLAG) ? 'R' : ' ');
    outbuf[3] = (char)((flags & PSH_FLAG) ? 'P' : ' ');
    outbuf[4] = (char)((flags & ACK_FLAG) ? 'A' : ' ');
    outbuf[5] = (char)((flags & URG_FLAG) ? 'U' : ' ');
    outbuf[6] = (char)((flags & ECE_FLAG) ? 'E' : ' ');
    outbuf[7] = (char)((flags & CWR_FLAG) ? 'C' : ' ');
    outbuf[SK_TCPFLAGS_STRLEN-1] = '\0';
    return outbuf;
}


/* strip whitespace of line in-place; return length */
int skStrip(char *line)
{
    char *sp, *ep;
    int len;

    sp  = line;
    while ( *sp && isspace((int)*sp) ) {
        sp++;
    }
    /* at first non-space char OR at end of line */
    if (*sp == '\0') {
        /* line full of white space. nail at beginning and return with 0 */
        line[0] = '\0';
        return 0;
    }

    /* figure out where to stop the line */
    ep = sp + strlen(sp) - 1;
    while ( isspace((int)*ep) && (ep > sp) ) {
        ep--;
    }
    /* ep at last non-space char. Nail after */
    ep++;
    *ep = '\0';

    len = (int)(ep - sp);
    if (sp == line) {
        /* no shifting required */
        return(len);
    }

    memmove(line, sp, len+1);
    return(len);
}


/* Down-case 'cp' in place */
void skToLower(char *cp)
{
    while (*cp) {
        if (isupper((int)*cp)) {
            *cp = *cp + 32;
        }
        cp++;
    }
    return;
}


/* Up-case 'cp' in place */
void skToUpper(char *cp)
{
    while (*cp) {
        if (islower((int)*cp)) {
            *cp = *cp - 32;
        }
        cp++;
    }
    return;
}


/*
 *  result = _skNumberListParserInit(&p,input,base,end_chars,minimum,maximum);
 *
 *    Fills in the sk_number_parser_t data structure---which should
 *    have been declared and allocated by the caller---pointed at by
 *    'p' with state necessary to call _skNumberListParserNext().
 *
 *    The caller must not modify 'input' while the
 *    _skNumberListParserNext() function is in use.
 *
 *    'end_chars' should be NULL or a string listing characters to be
 *    considered, in addition to whitespace, as end-of-input markers.
 *
 *    'mimimum' and 'maximum' define the allowable range for numbers
 *    in the list.
 *
 *    On success, SK_NUM_PARSER_OK is returned.  If the string is
 *    empty or begins with a character listed in 'end_chars',
 *    SK_NUM_PARSER_END_OF_STRING is returned.  Otherwise, this
 *    function returns a silk_utils_errcode_t value.
 */
static int _skNumberListParserInit(
    sk_number_parser_t *parser,
    const char         *input,
    int                 base,
    const char         *end_chars,
    uint32_t            minimum,
    uint32_t            maximum)
{
    /* check input */
    assert(parser);
    assert(input);
    assert(base == 10 || base == 16);

    if (maximum == 0) {
        maximum = UINT32_MAX;
    } else if (minimum > maximum) {
        return _parseError(SKUTILS_ERR_INVALID,
                           ("Range maximum (%" PRIu32 ") is less than"
                            " range minimum (%" PRIu32 ")"),
                           maximum, minimum);
    }

    if (*input == '\0') {
        return SK_NUM_PARSER_END_OF_STRING;
    }
    if (isspace((int)*input)) {
        return SK_NUM_PARSER_END_OF_STRING;
    }
    if (end_chars && (strchr(end_chars, *input))) {
        return SK_NUM_PARSER_END_OF_STRING;
    }

    if (base == 10 && !isdigit((int)*input)) {
        return _parseError(SKUTILS_ERR_BAD_CHAR, "%s at '%c'",
                           PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR), *input);
    } else if (base == 16 && !isxdigit((int)*input)) {
        return _parseError(SKUTILS_ERR_BAD_CHAR, "%s at '%c'",
                           PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR), *input);
    }

    parser->min = minimum;
    parser->max = maximum;
    parser->sp = input;
    parser->end_chars = end_chars;
    parser->base = base;
    return SK_NUM_PARSER_OK;
}


/*
 *  result = _skNumberListParserNext(&out_val, &out_length, p);
 *
 *    Parse the next number or range in the 'input' that was used to
 *    initialize the sk_number_parser_t 'p'.
 *
 *    If the next token is a single number ("3,"), its value is stored
 *    in 'out_val', 1 is stored in 'out_length', and
 *    SK_NUM_PARSER_NUMBER is returned.
 *
 *    If the next token is a range ("2-4,"), the starting value (2) is
 *    stored in 'out_val', the number of elements in the range (3) is
 *    stored in 'out_length', and SK_NUM_PARSER_RANGE is returned.
 *
 *    When there are no more tokens in 'input',
 *    SK_NUM_PARSER_END_OF_STRING is returned.
 *
 *    Any other return value indicates an error.
 */
static int _skNumberListParserNext(
    uint64_t           *range_length,
    uint32_t           *value,
    sk_number_parser_t *parser)
{
    unsigned long n = 0;
    const char *sp;
    char *ep;
    int rv;

    /* check input */
    assert(parser);
    assert(value);
    assert(range_length);

    /* initialize vars */
    *value = 0;
    *range_length = 0;
    sp = parser->sp;

    /* are we at end of list? */
    if (*sp == '\0') {
        return SK_NUM_PARSER_END_OF_STRING;
    }
    if (isspace((int)*sp)) {
        return SK_NUM_PARSER_END_OF_STRING;
    }
    if (parser->end_chars && (strchr(parser->end_chars, *sp))) {
        return SK_NUM_PARSER_END_OF_STRING;
    }

    while (*sp) {
        /* parse the number */
        errno = 0;
        n = strtoul(sp, &ep, parser->base);
        if (sp == ep) {
            rv = _parseError(SKUTILS_ERR_BAD_CHAR, "%s at '%c'",
                             PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR), *sp);
            goto END;
        }
        if (n == ULONG_MAX && errno == ERANGE) {
            rv = _parseError(SKUTILS_ERR_OVERFLOW, PE_NULL);
            goto END;
        }
        if (n < parser->min) {
            rv = _parseError(SKUTILS_ERR_MINIMUM, "%s of %" PRIu32,
                             PARSE_ERRORCODE_MSG(SKUTILS_ERR_MINIMUM),
                             parser->min);
            goto END;
        }
        if (n > parser->max) {
            rv = _parseError(SKUTILS_ERR_MAXIMUM, "%s of %" PRIu32,
                             PARSE_ERRORCODE_MSG(SKUTILS_ERR_MAXIMUM),
                             parser->max);
            goto END;
        }

        /* parsed the number; move pointer to next token */
        sp = ep;

        /* see if we are parsing a range; if so, store the first
         * number (lower limit) and loop through the while again in
         * order to parse the second number (upper limit). */
        if (*sp != '-') {
            break;
        } else if (*range_length != 0) {
            /* second pass through the while loop yet we're looking at
             * another hyphen.  We've got something like "1-2-".  An
             * error */
            rv = _parseError(SKUTILS_ERR_BAD_CHAR, "%s at '%c'",
                             PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR), *sp);
            goto END;
        } else {
            /* first pass, we just parsed lower limit */
            ++sp;
            if ((parser->base == 10 && isdigit((int)*sp))
                || (parser->base == 16 && isxdigit((int)*sp)))
            {
                /* looks like a good range; store the value we just
                 * parsed, set range_length so we know we're in a
                 * range, and loop again */
                *value = n;
                *range_length = 1;
                continue;
            } else if (*sp == '\0' || *sp == ',') {
                /* open-ended range, store current value, use
                 * range_length to denote open-ended range, set n to
                 * the max */
                *value = n;
                *range_length = 2;
                n = parser->max;
                break;
            } else {
                rv = _parseError(SKUTILS_ERR_BAD_CHAR, "%s at '%c'",
                                 PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                                 *sp);
                goto END;
            }
        }
    }

    /* we've parsed a number or a range */
    if (*range_length == 0) {
        /* single number */
        *value = n;
        *range_length = 1;
        rv =  SK_NUM_PARSER_NUMBER;
    } else if (*range_length == 2) {
        *range_length = (n - *value + 1);
        rv = SK_NUM_PARSER_RANGE_OPENMAX;
    } else if (n == *value) {
        /* range of 3-3; treat as single number */
        rv =  SK_NUM_PARSER_NUMBER;
    } else if (n < *value) {
        rv = _parseError(SKUTILS_ERR_BAD_RANGE,
                         ("%s (%" PRIu32 "-%lu)"),
                         PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_RANGE),
                         *value, n);
        goto END;
    } else {
        *range_length = (n - *value + 1);
        rv =  SK_NUM_PARSER_RANGE;
    }

    /* move forward to the start of the next number. */
    while (*sp) {
        if (isspace((int)*sp)) {
            /* this marks the end of the number list */
            break;
        }
        if (parser->end_chars && (strchr(parser->end_chars, *sp))) {
            /* this also marks the end of the number list */
            break;
        }
        if ((parser->base == 10 && isdigit((int)*sp))
            || (parser->base == 16 && isxdigit((int)*sp)))
        {
            /* this is what we expect*/
            break;
        }
        if (*sp == ',') {
            /* duplicate comma is allowed */
            ++sp;
            continue;
        }
        if (*sp == '-') {
            /* error */
            rv = _parseError(SKUTILS_ERR_BAD_CHAR, "%s at '%c'",
                             PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                             *sp);
            goto END;
        }

        /* error */
        rv = _parseError(SKUTILS_ERR_BAD_CHAR, "%s at '%c'",
                         PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                         *sp);
        goto END;
    }

  END:
    /* store our current location */
    parser->sp = sp;
    return rv;
}


/* parse string "4,3,2-6" to array {4,3,2,3,4,5,6}.  See header for details */
int skStringParseNumberList(
    uint32_t          **number_list,
    uint32_t           *number_count,
    const char         *input,
    uint32_t            min_value,
    uint32_t            max_value,
    uint32_t            max_number_count)
{
    uint64_t range_length;
    uint64_t i;
    uint32_t range_start;
    uint32_t *out_array_list = NULL; /* returned array */
    uint32_t out_count = 0; /* returned count */
    uint32_t array_size;
    sk_number_parser_t parser;
    const char *sp;
    int rv = SKUTILS_OK;

    /* check input */
    assert(number_list);
    assert(number_count);
    if (input == NULL) {
        return _parseError(SKUTILS_ERR_INVALID, PE_NULL);
    }

    /* eat leading whitespace */
    sp = input;
    while (*sp && isspace((int)*sp)) {
        ++sp;
    }
    if ('\0' == *sp) {
        /* whitespace only or empty string */
        return _parseError(SKUTILS_ERR_EMPTY, PE_NULL);
    }

    rv = _skNumberListParserInit(&parser, sp, 10, NULL, min_value, max_value);
    if (rv != SK_NUM_PARSER_OK) {
        return rv;
    }

    /* If no max count was given, assume the user is only allowed to
     * choose each item one time, and set the max_number_count to the
     * number of items. */
    if (max_number_count == 0) {
        if (max_value != 0) {
            max_number_count = 1 + max_value - min_value;
        } else {
            /* something big */
            max_number_count = (1 << 24);
        }
    }

    /* Create the array to hold the list of values.  If
     * max_number_count is greater than 256, use half of it as the
     * initial size; otherwise, create an array of max_number_count
     * entries. */
    if (max_number_count <= 256) {
        array_size = max_number_count;
    } else {
        array_size = max_number_count / 2;
    }
    out_array_list = calloc(array_size, sizeof(uint32_t));
    if (!out_array_list) {
        rv = _parseError(SKUTILS_ERR_ALLOC, PE_NULL);
        goto ERROR;
    }

    while ((rv = _skNumberListParserNext(&range_length, &range_start, &parser))
           != SK_NUM_PARSER_END_OF_STRING)
    {
        if (rv < 0) {
            goto ERROR;
        }
        switch ((sk_number_parser_result_t)rv) {
          case SK_NUM_PARSER_OK:
          case SK_NUM_PARSER_END_OF_STRING:
            /* these should not occur */
            skAppPrintErr("Got impossible value %d at %s:%d",
                          rv, __FILE__, __LINE__);
            abort();

          case SK_NUM_PARSER_RANGE_OPENMAX:
            rv = _parseError(SKUTILS_ERR_BAD_CHAR,
                             ("Range is missing its upper limit"
                              " (open-ended ranges are not supported)"));
            goto ERROR;

          case SK_NUM_PARSER_NUMBER:
          case SK_NUM_PARSER_RANGE:
            /* check number of fields user gave */
            if ((out_count + range_length) > max_number_count) {
                rv = _parseError(SKUTILS_ERR_TOO_MANY_FIELDS,
                                 ("Too many fields (%" PRIu64 ") provided;"
                                  " only %" PRIu32 " fields allowed"),
                                 (range_length + out_count), max_number_count);
                goto ERROR;
            }

            /* check if we need to grow array?  If so, realloc the array
             * to double its size and memset the new section to 0. */
            while ((out_count + range_length) > array_size) {
                size_t old_size = array_size;
                uint32_t *old_array = out_array_list;
                array_size *= 2;
                if (array_size > max_number_count) {
                    array_size = max_number_count;
                }
                out_array_list = realloc(out_array_list,
                                         array_size * sizeof(uint32_t));
                if (!out_array_list) {
                    out_array_list = old_array;
                    rv = _parseError(SKUTILS_ERR_ALLOC, PE_NULL);
                    goto ERROR;
                }
                memset((out_array_list+old_size), 0,
                       (array_size-old_size) * sizeof(uint32_t));
            }

            /* add the entries */
            for (i = 0; i < range_length; ++i, ++range_start, ++out_count) {
                out_array_list[out_count] = range_start;
            }
            break;
        }
    }

    assert(rv == SK_NUM_PARSER_END_OF_STRING);
    rv = SKUTILS_OK;

    /* handle any whitespace at end of string */
    sp = _skNumberParserCurrentChar(&parser);
    while (isspace((int)*sp)) {
        ++sp;
    }
    if (*sp != '\0') {
        rv = _parseError(SKUTILS_ERR_BAD_CHAR,
                         "%s--embedded whitespace found in input",
                         PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR));
        goto ERROR;
    }

    *number_count = out_count;
    *number_list = out_array_list;
    return rv;

  ERROR:
    if (out_array_list) {
        free(out_array_list);
    }
    *number_count = 0;
    return rv;
}


/* parse string "4,3,2-6" to skbitmap.  See header for details */
int skStringParseNumberListToBitmap(
    sk_bitmap_t        *out_bitmap,
    const char         *input)
{
    uint64_t range_length;
    uint64_t i;
    uint32_t value;
    uint32_t bitmap_size;
    sk_number_parser_t parser;
    const char *sp;
    int rv;

    /* check input */
    assert(out_bitmap);
    if (input == NULL) {
        return _parseError(SKUTILS_ERR_INVALID, PE_NULL);
    }

    /* check bitmap size */
    bitmap_size = skBitmapGetSize(out_bitmap);
    if (bitmap_size < 1) {
        /* bitmap too small */
        return _parseError(SKUTILS_ERR_INVALID, "Bitmap is too small");
    }

    /* eat leading whitespace */
    sp = input;
    while (*sp && isspace((int)*sp)) {
        ++sp;
    }
    if ('\0' == *sp) {
        /* whitespace only or empty string */
        return _parseError(SKUTILS_ERR_EMPTY, PE_NULL);
    }

    rv = _skNumberListParserInit(&parser, sp, 10, NULL, 0, bitmap_size-1);
    if (rv != SK_NUM_PARSER_OK) {
        return rv;
    }

    while ((rv = _skNumberListParserNext(&range_length, &value, &parser))
           != SK_NUM_PARSER_END_OF_STRING)
    {
        if (rv < 0) {
            return rv;
        }
        switch ((sk_number_parser_result_t)rv) {
          case SK_NUM_PARSER_NUMBER:
          case SK_NUM_PARSER_RANGE:
          case SK_NUM_PARSER_RANGE_OPENMAX:
            /* add the entries */
            for (i = 0; i < range_length; ++i, ++value) {
                skBitmapSetBit(out_bitmap, value);
            }
            break;

          case SK_NUM_PARSER_OK:
          case SK_NUM_PARSER_END_OF_STRING:
            /* impossible */
            skAppPrintErr("Got impossible value %d at %s:%d",
                          rv, __FILE__, __LINE__);
            abort();
        }
    }

    assert(rv == SK_NUM_PARSER_END_OF_STRING);

    /* handle any whitespace at end of string */
    sp = _skNumberParserCurrentChar(&parser);
    while (isspace((int)*sp)) {
        ++sp;
    }
    if (*sp != '\0') {
        return _parseError(SKUTILS_ERR_BAD_CHAR,
                           "%s--embedded whitespace found in input",
                           PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR));
    }

    return SKUTILS_OK;
}


/*
 *  status = _parseIPv4(&ip_value, ip_string);
 *
 *    A helper function for skStringParseIP().
 *
 *    Parse the IPv4 address at 'ip_string' and put the result--in
 *    native byte order--into the memory pointed at by 'ip_value'.
 *    Return a negative (silk_utils_errcode_t) value on error;
 *    otherwise return a positive value specifying the number of
 *    characters that were parsed.
 */
static int _parseIPv4(uint32_t *ip, const char *ip_string)
{
    /* IPv4 address */
    unsigned long final = 0;
    unsigned long val;
    const char *sp = ip_string;
    char *ep;
    int i;

    for (i = 3; i >= 0; --i) {
        /* number that begins with '-' is not unsigned */
        if ('-' == *sp) {
            return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                               PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                               *sp);
        }

        /* parse the string */
        errno = 0;
        val = strtoul(sp, &ep, 10);
        if (sp == ep) {
            /* parse error */
            return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                               PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR), *sp);
        }
        if (val == ULONG_MAX && errno == ERANGE) {
            /* overflow */
            if (i == 3) {
                /* entire value is too large */
                return _parseError(SKUTILS_ERR_OVERFLOW, PE_NULL);
            }
            /* octet value is too large */
            return _parseError(SKUTILS_ERR_OVERFLOW,
                               "IP octet %d is too large", (4 - i));
        }

        sp = ep;
        if (*sp != '.') {
            if (i == 3) {
                /* treat as a single integer */
                final = val;
                break;
            }
            if (i != 0) {
                /* need a '.' between octets */
                return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                                   PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                                   *sp);
            }
            /* else i == 0 and we've finished parsing */
        } else if (i == 0) {
            /* found a trailing '.' */
            return _parseError(SKUTILS_ERR_BAD_CHAR,
                               "Found '%c' after fourth octet", *sp);
        } else {
            /* move to start of next octet */
            ++sp;
            if (!isdigit((int)*sp)) {
                /* error: only '.' and digits are allowed */
                if (*sp == '\0') {
                    return _parseError(SKUTILS_ERR_SHORT, PE_NULL);
                }
                return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                                   PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                                   *sp);
            }
        }

        if (val > 255) {
            /* value too big for octet */
            return _parseError(SKUTILS_ERR_MAXIMUM,
                               "IP octet %d is too large: %lu", (4 - i), val);
        }
        final |= val << (8 * i);
    }

    *ip = (uint32_t)final;
    return (sp - ip_string);
}


/* Convert string "0" or "0.0.0.0" to integer 0 */
int skStringParseIP(skipaddr_t *out_val, const char *ip_string)
{
    const char *sp;
    const char *dot;
    const char *colon;
    uint32_t ipv4 = 0;
    int rv;
    int i;

    /* verify input */
    if (!ip_string) {
        return _parseError(SKUTILS_ERR_INVALID, PE_NULL);
    }

    /* skip leading whitespace */
    sp = ip_string;
    while (isspace((int)*sp)) {
        ++sp;
    }
    if ('\0' == *sp) {
        /* whitespace only or empty string */
        return _parseError(SKUTILS_ERR_EMPTY, PE_NULL);
    }

    /* determine if IPv4 or IPv6 */
    dot = strchr(sp, '.');
    colon = strchr(sp, ':');
    if (colon == NULL) {
        /* no ':', so must be IPv4 or an integer */
    } else if (dot == NULL) {
        /* no '.', so must be IPv6 */
    } else if ((dot - sp) < (colon - sp)) {
        /* dot appears first, assume IPv4 */
        colon = NULL;
    } else {
        /* colon appears first, assume IPv6 */
        dot = NULL;
    }

    /* parse the address */
    if (colon == NULL) {
        /* an IPv4 address */
        rv = _parseIPv4(&ipv4, sp);
        if (rv < 0) {
            return rv;
        }

        sp += rv;
        skipaddrSetV4(out_val, &ipv4);
    } else {
        /* an IPv6 address */
#if !SK_ENABLE_IPV6
        return _parseError(SKUTILS_ERR_BAD_CHAR,
                           "%s ':'--IPv6 addresses not supported",
                           PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR));
#else
        uint8_t ipv6[16];
        int double_colon = -1;
        unsigned long val;
        char *ep;

        for (i = 0; i < 8; ++i) {
            /* number that begins with '-' is not unsigned */
            if ('-' == *sp) {
                return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                                   PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                                   *sp);
            }
            /* handle section separator */
            if (*sp == ':') {
                ++sp;
                if (*sp == ':') {
                    if (double_colon != -1) {
                        /* parse error */
                        return _parseError(SKUTILS_ERR_BAD_CHAR,
                                           "Only one :: instance allowed");
                    }
                    ++sp;
                    double_colon = i;
                } else if (i == 0) {
                    /* address cannot begin with single ':' */
                    return
                        _parseError(SKUTILS_ERR_BAD_CHAR,
                                    "IP address cannot begin with single ':'");
                } else if (*sp == '\0') {
                    return _parseError(SKUTILS_ERR_SHORT,
                                       "Expecting IP section value after ':'");
                } else if (!isxdigit((int)*sp)) {
                    return
                        _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                                    PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                                    *sp);
                }
            } else if (*sp == '\0') {
                if (double_colon != -1) {
                    /* treat as end of the IP */
                    break;
                }
                return _parseError(SKUTILS_ERR_SHORT,
                                   "Too few IP sections given");
            }

            /* parse the string */
            errno = 0;
            val = strtoul(sp, &ep, 16);
            if (sp == ep) {
                if (*sp == ':') {
                    /* triple colon */
                    return _parseError(SKUTILS_ERR_BAD_CHAR,
                                       "Unexpected character :::");
                }
                if (double_colon != -1) {
                    /* treat as end of string */
                    break;
                }
                /* parse error */
                return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                                   PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                                   *sp);
            }
            if (val == ULONG_MAX && errno == ERANGE) {
                /* overflow */
                return _parseError(SKUTILS_ERR_OVERFLOW, PE_NULL);
            }
            if (val > UINT16_MAX) {
                /* value too big for octet */
                return _parseError(SKUTILS_ERR_MAXIMUM,
                                   "IP section %d is too large", i);
            }

            if (*ep == '.') {
                int j;

                if (i > 6) {
                    return _parseError(SKUTILS_ERR_BAD_CHAR,
                                       ("Too many sections before"
                                        " embedded IPv4"));
                }

                /* IPv4 address */
                rv = _parseIPv4(&ipv4, sp);
                if (rv < 0) {
                    return rv;
                }

                for (j = 0; j < 4; ++j) {
                    ipv6[2*i+j] = ((ipv4 >> (8 * (3 - j))) & 0xFF);
                }
                sp += rv;
                i += 2;
                break;
            }

            ipv6[2*i] = ((val >> 8) & 0xFF);
            ipv6[2*i+1] = (val & 0xFF);
            sp = ep;
        }

        if (*sp == ':') {
            return _parseError(SKUTILS_ERR_BAD_CHAR,
                               "Found '%c' after final section", *sp);
        }

        if (double_colon != -1) {
            if (i == 8) {
                /* error */
                return _parseError(SKUTILS_ERR_BAD_CHAR,
                                   "Cannot have '::' in IP with 8 sections");
            }
            memmove(&ipv6[2*(8+double_colon-i)], &ipv6[2*double_colon],
                    2*(i-double_colon));
            memset(&ipv6[2*double_colon], 0, 2*(8-i));
        } else if (i != 8) {
            /* error */
            return _parseError(SKUTILS_ERR_SHORT,
                               "Only %d/8 IP sections specified", i);
        }

        skipaddrSetV6(out_val, ipv6);
#endif /* SK_ENABLE_IPV6 */
    }

    /* ignore trailing whitespace, but only if we reach the end of the
     * string.  cache the current position. */
    i = (sp - ip_string);
    while (isspace((int)*sp)) {
        ++sp;
    }

    if ('\0' != *sp) {
        /* text after IP, return the cached position */
        return i;
    }
    return SKUTILS_OK;
}


int skStringParseIPWildcard(
    skIPWildcard_t *ipwild,
    const char     *ip_string)
{
    /* number of octets (or hexadectets for IPv6) */
    uint32_t num_blocks = 4;
    /* number of bits per octet/hexadectet */
    uint32_t block_size = 8;
    /* max value for any octet/hexadectet */
    uint32_t block_max_value = ((1 << block_size) - 1);
    /* base to use for parsing octet/hexadectet values */
    int block_base = 10;
    /* character string between octets/hexadectets */
    const char *block_sep = ".";
    uint64_t i;
    uint32_t range_start = 0;
    uint64_t range_length = 0;
    unsigned long val = 0;
    uint32_t block = 0;
    uint32_t double_colon = UINT32_MAX;
    sk_number_parser_t parser;
    skipaddr_t ipaddr;
    uint32_t cidr = 0;
    const char *sp;
    int rv;
#if SK_ENABLE_IPV6
    const char *v4_in_v6 = NULL;
#endif

    /* try to parse as an ordinary IP address */
    rv = skStringParseIP(&ipaddr, ip_string);

    /* return if we get any error other than BAD_CHAR */
    if (rv < 0 && rv != SKUTILS_ERR_BAD_CHAR) {
        return rv;
    }

    /* If rv > 0, we parsed an IP but there is extra text.  We could
     * be looking at the slash for CIDR notation or at a list for the
     * final block; e.g., "0.0.0.1-100" or "0.0.0.1,2".  If we are on
     * the slash, reset rv to SKUTILS_OK; otherwise, if we are looking
     * at anything other than ',' or '-', return error.  For IPv6, we
     * may be looking at "0::x". */
    if (rv > 0) {
        sp = &ip_string[rv];
        if (*sp == '/') {
            ++sp;
            if (*sp == '\0') {
                return _parseError(SKUTILS_ERR_BAD_CHAR,
                                   "%s '%c'--expected CIDR after slash",
                                   PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                                   *sp);
            }
            if (!isdigit((int)*sp)) {
                return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                                   PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                                   *sp);
            }

            /* parse the CIDR value */
            rv = skStringParseUint32(&cidr, sp, 1,
                                     (skipaddrIsV6(&ipaddr) ? 128 : 32));
            if (rv != 0) {
                if (rv < 0) {
                    return rv;
                }
                return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                                   PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                                   sp[rv]);
            }
        } else if (isspace((int)*sp)) {
            return _parseError(SKUTILS_ERR_BAD_CHAR,
                               "%s '%c' embedded whitespace is not allowed",
                               PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                               *sp);
#if SK_ENABLE_IPV6
        } else if (skipaddrIsV6(&ipaddr) && (*sp == 'x' || *sp == 'X')) {
            /* try to parse as wildcard */
#endif /* SK_ENABLE_IPV6 */
        } else if (*sp != '-' && *sp != ',') {
            return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                               PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                               *sp);
        }
    }

    /* clear the ipwildcard */
    skIPWildcardClear(ipwild);

    if (rv == SKUTILS_OK) {
#if SK_ENABLE_IPV6
        if (skipaddrIsV6(&ipaddr)) {
            uint8_t ip6[16];

            skipaddrGetV6(&ipaddr, &ip6);
            ipwild->num_blocks = 8;

            num_blocks = 8;
            block_size = 16;
            block_max_value = (1 << block_size) - 1;

            /* set each block as if no CIDR */
            for (block = 0; block < num_blocks; ++block) {
                val = (ip6[2*block] << 8 | ip6[1+2*block]);
                ipwild->m_blocks[block][_BMAP_INDEX(val)] = _BMAP_OFFSET(val);
                ipwild->m_min[block] = val;
                ipwild->m_max[block] = val;
            }
        } else
#endif /* SK_ENABLE_IPV6 */
        {
            ipwild->num_blocks = 4;

            /* set each block as if no CIDR */
            for (block = 0; block < num_blocks; ++block) {
                val = (block_max_value
                       & (skipaddrGetV4(&ipaddr)
                          >> ((num_blocks - block - 1) * block_size)));
                ipwild->m_blocks[block][_BMAP_INDEX(val)] = _BMAP_OFFSET(val);
                ipwild->m_min[block] = val;
                ipwild->m_max[block] = val;
            }
        }

        if (cidr == 0 || cidr == (num_blocks * block_size)) {
            return SKUTILS_OK;
        }

        for (block = 0; block < num_blocks; ++block) {
            if (cidr <= (block_size * block)) {
                /* this block is all ones */
                memset(ipwild->m_blocks[block], 0xFF,
                       sizeof(ipwild->m_blocks[0]));
                ipwild->m_min[block] = 0;
                ipwild->m_max[block] = block_max_value;
            } else if (cidr < (block_size * (1 + block))) {
                /* partial effect on this block */
                range_length = 1 << ((block_size * (1 + block)) - cidr);
                val = (ipwild->m_min[block] & ~(range_length - 1));
                ipwild->m_min[block] = val;
                for (i = 0; i < range_length; ++i, ++val) {
                    ipwild->m_blocks[block][_BMAP_INDEX(val)]
                        |= _BMAP_OFFSET(val);
                }
                ipwild->m_max[block] = val - 1;
            }
            /* else (cidr >= (block_size*(1+block))) and no effect */
        }
        return SKUTILS_OK;
    }

    /* Parse the input ip from the beginning */
    sp = ip_string;

    /* ignore leading whitespace */
    while (isspace((int)*sp)) {
        ++sp;
    }

    if (strchr(sp, ':')) {
#if !SK_ENABLE_IPV6
        return _parseError(SKUTILS_ERR_BAD_CHAR,
                           "%s '%c'--IPv6 addresses not supported",
                           PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                           *sp);
#else
        ipwild->num_blocks = 8;
        block_sep = ":";
        num_blocks = 8;
        block_size = 16;
        block_base = 16;

        /* check for a v4 section, for example "::FFFF:x.x.x.x".  if
         * we find a '.', move backward to find the ':' and as
         * v4_in_v6 to the character following the ':'. */
        v4_in_v6 = strchr(sp, '.');
        if (v4_in_v6) {
            while (v4_in_v6 > sp) {
                if (*(v4_in_v6 - 1) == ':') {
                    break;
                }
                --v4_in_v6;
            }
            if (v4_in_v6 == sp) {
                /* must have something with ':' following '.' */
                return _parseError(SKUTILS_ERR_BAD_CHAR,
                                   "Found ':' after '.' in IPv6 address");
            }
        }
#endif /* SK_ENABLE_IPV6 */
    } else {
        block_sep = ".";
        ipwild->num_blocks = 4;
        num_blocks = 4;
        block_size = 8;
        block_base = 10;
    }
    block_max_value = (1 << block_size) - 1;

    for (block = 0; block < num_blocks; ++block) {
        if (*sp == ':') {
            ++sp;
            if (*sp == ':') {
                if (double_colon != UINT32_MAX) {
                    /* parse error */
                    return _parseError(SKUTILS_ERR_BAD_CHAR,
                                       "Only one :: instance allowed");
                }
                ++sp;
                double_colon = block;
            } else if (block == 0) {
                /* address cannot begin with single ':' */
                return _parseError(SKUTILS_ERR_BAD_CHAR,
                                   "IP address cannot begin with single ':'");
            } else if (*sp == '\0') {
                return _parseError(SKUTILS_ERR_SHORT,
                                   "Expecting IP block value after ':'");
            }
        } else if (*sp == '.') {
            assert(block_base == 10);
            if (block == 0) {
                return _parseError(SKUTILS_ERR_BAD_CHAR,
                                   "%s--found leading separator '%c'",
                                   PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                                   *sp);
            }
            ++sp;
        } else if (*sp == '\0') {
            if (double_colon != UINT32_MAX) {
                /* treat as end of the IP */
                break;
            }
            return _parseError(SKUTILS_ERR_SHORT,
                               "Too few IP blocks given");
        } else if (block != 0) {
            return _parseError(SKUTILS_ERR_BAD_CHAR,
                               "%s '%c' expecting '%s' between IP blocks",
                               PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR), *sp,
                               block_sep);
        }

#if SK_ENABLE_IPV6
        /* determine if we are at beginning of an embedded IPv4 address */
        if (sp == v4_in_v6) {
            skIPWildcard_t ipwv4;
            uint32_t j, k;

            /* verify we don't have too many IPv6 sections */
            if (block > 6) {
                return _parseError(SKUTILS_ERR_BAD_CHAR,
                                   "Too many sections before embedded IPv4");
            }

            /* parse the remaining part of the address as IPv4 wildcard */
            rv = skStringParseIPWildcard(&ipwv4, sp);
            if (rv < 0) {
                return rv;
            }

            /* move sp to the end of the string */
            sp += strlen(sp);

            /* take the ipv4 wildcard and map it into ipv6 */
            for (i = 0; i < 4; i += 2, ++block) {
                ipwild->m_min[block] = (ipwv4.m_min[i]<<8) | ipwv4.m_min[i+1];
                ipwild->m_max[block] = (ipwv4.m_max[i]<<8) | ipwv4.m_max[i+1];

                /* shortcut the "x.x" case */
                if ((ipwild->m_min[block] == 0)
                    && (ipwild->m_min[block] == 0xFFFF))
                {
                    memset(ipwild->m_blocks[block], 0xFF,
                           sizeof(ipwild->m_blocks[0]));
                    if (memcmp(ipwild->m_blocks[block],
                               ipwv4.m_blocks[i],
                               sizeof(ipwild->m_blocks[0]))
                        && memcmp(ipwild->m_blocks[block],
                               ipwv4.m_blocks[i+1],
                               sizeof(ipwild->m_blocks[0])))
                    {
                        continue;
                    } else {
                        memset(ipwild->m_blocks[block], 0,
                               sizeof(ipwild->m_blocks[0]));
                    }
                }

                for (j = ipwv4.m_min[i]; j <= ipwv4.m_max[i]; ++j) {
                    for (k = ipwv4.m_min[i+1]; k <= ipwv4.m_max[i+1]; ++k) {
                        if (_IPWILD_BLOCK_IS_SET(&ipwv4, i, j)
                            && _IPWILD_BLOCK_IS_SET(&ipwv4, i+1, k))
                        {
                            ipwild->m_blocks[block][_BMAP_INDEX((j << 8) | k)]
                                |= _BMAP_OFFSET((j << 8) | k);
                        }
                    }
                }
            }

            /* done */
            break;
        }
#endif /* SK_ENABLE_IPV6 */

        if (*sp == 'x' || *sp == 'X') {
            /* all ones */
            memset(ipwild->m_blocks[block], 0xFF, sizeof(ipwild->m_blocks[0]));
            ipwild->m_min[block] = 0;
            ipwild->m_max[block] = block_max_value;
            ++sp;
            continue;
        }

        rv = _skNumberListParserInit(&parser, sp, block_base, block_sep,
                                     0, block_max_value);
        if (rv != SK_NUM_PARSER_OK) {
            if (rv != SK_NUM_PARSER_END_OF_STRING) {
                return rv;
            }
            if (*sp == *block_sep) {
                return _parseError(SKUTILS_ERR_BAD_CHAR,
                                   "%s--found double '%c'",
                                   PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                                   *sp);
            }
            if (double_colon == block) {
                /* treat as end of string */
                break;
            }
            if (isspace((int)*sp)) {
                return _parseError(SKUTILS_ERR_BAD_CHAR,
                                   "%s--embedded whitespace found in input",
                                   PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR));
            }
            return _parseError(SKUTILS_ERR_SHORT, "Too few blocks given");
        }

        while ((rv = _skNumberListParserNext(&range_length, &range_start,
                                             &parser))
               != SK_NUM_PARSER_END_OF_STRING)
        {
            switch (rv) {
              case SK_NUM_PARSER_OK:
                /* this should not occur */
                skAppPrintErr("Got impossible value %d at %s:%d",
                              rv, __FILE__, __LINE__);
                abort();

              case SK_NUM_PARSER_RANGE_OPENMAX:
                return _parseError(SKUTILS_ERR_BAD_CHAR,
                                   ("Range is missing its upper limit"
                                    " (open-ended ranges are not supported)"));

              case SK_NUM_PARSER_NUMBER:
              case SK_NUM_PARSER_RANGE:
                /* add the entries */
                if (range_start < ipwild->m_min[block]) {
                    ipwild->m_min[block] = range_start;
                }
                for (i = 0; i < range_length; ++i, ++range_start) {
                    ipwild->m_blocks[block][_BMAP_INDEX(range_start)]
                        |= _BMAP_OFFSET(range_start);
                }
                --range_start;
                if (range_start > ipwild->m_max[block]) {
                    ipwild->m_max[block] = range_start;
                }
                break;

              case SKUTILS_ERR_BAD_CHAR:
              default:
                return rv;
            }
        }

        sp = _skNumberParserCurrentChar(&parser);
    }

    if (double_colon != UINT32_MAX) {
        if (block == num_blocks) {
            /* error */
            return _parseError(SKUTILS_ERR_BAD_CHAR,
                               "Cannot have '::' in IP with 8 blocks");
        }
        memmove(&ipwild->m_min[8 + double_colon - block],
                &ipwild->m_min[double_colon],
                sizeof(ipwild->m_min[0]) * (block - double_colon));
        memmove(&ipwild->m_max[8 + double_colon - block],
                &ipwild->m_max[double_colon],
                sizeof(ipwild->m_max[0]) * (block - double_colon));
        memmove(ipwild->m_blocks[8 + double_colon - block],
                ipwild->m_blocks[double_colon],
                sizeof(ipwild->m_blocks[0]) * (block - double_colon));
        for (i = double_colon; i < (8 + double_colon - block); ++i) {
            memset(ipwild->m_blocks[i], 0, sizeof(ipwild->m_blocks[0]));
            ipwild->m_blocks[i][_BMAP_INDEX(0)] = _BMAP_OFFSET(0);
            ipwild->m_min[i] = 0;
            ipwild->m_max[i] = 0;
        }
    } else if (block != num_blocks) {
        /* error */
        return _parseError(SKUTILS_ERR_SHORT,
                           "Only %d/%d IP blocks specified", block,num_blocks);
    }

    /* ignore trailing whitespace */
    while (isspace((int)*sp)) {
        ++sp;
    }
    if (*sp != '\0') {
        return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                           PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR), *sp);
    }

    return SKUTILS_OK;
}


/* parse an IP with an optional CIDR designation */
int skStringParseCIDR(
    skipaddr_t *out_val,
    uint32_t   *out_cidr,
    const char *ip_string)
{
    const char *sp;
    int rv;

    /* try to parse as an ordinary IP address */
    rv = skStringParseIP(out_val, ip_string);

    /* return if we get an error */
    if (rv < 0) {
        return rv;
    }

    /* check if we only got the IP address */
    if (rv == 0) {
        *out_cidr = (skipaddrIsV6(out_val) ? 128 : 32);
        return SKUTILS_OK;
    }

    /* When rv > 0, we parsed an IP but there is extra text,
     * presumably '/' for the CIDR designation.  Error if it isn't. */
    sp = &ip_string[rv];
    if (*sp != '/') {
        return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                           PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR), *sp);
    }

    ++sp;
    if (*sp == '\0') {
        return _parseError(SKUTILS_ERR_BAD_CHAR,
                           "%s '%c'--expected CIDR after slash",
                           PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                           *sp);
    }

    /* parse the CIDR value */
    rv = skStringParseUint32(out_cidr, sp, 1,
                             (skipaddrIsV6(out_val) ? 128 : 32));
    if (rv > 0) {
        return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                           PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                           sp[rv]);
    }

    return rv;
}


/*  time string to struct sktime_st; see utils.h for details */
int skStringParseDatetime(
    sktime_t   *date_val,
    const char *date_string,
    int        *resulting_precision)
{
    const int min_precision = 3; /* at least day */
    struct tm ts;
    time_t t;
    const char *sp;
    char *ep;
    const char delim[] = {'\0', '/', '/', ':', ':', ':', '.'};
    long val;
    long msec = 0;
    int i;
    int j;

    /* check inputs */
    assert(date_val);
    if (NULL == date_string) {
        return _parseError(SKUTILS_ERR_INVALID, PE_NULL);
    }

    /* initialize */
    memset(&ts, 0, sizeof(struct tm));
    sp = date_string;

    /* ignore leading whitespace */
    while (*sp && isspace((int)*sp)) {
        ++sp;
    }
    if ('\0' == *sp) {
        /* whitespace only or empty string */
        return _parseError(SKUTILS_ERR_EMPTY, PE_NULL);
    }

    /* if the date contains digits, and a decimal point and is at
     * least 9 digits long, treat it as an epoch time */
    if (strspn(sp, ".0123456789") > 8) {
        double epoch;

        /* parse the string */
        errno = 0;
        epoch = strtod(sp, &ep);
        if (sp == ep) {
            return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                               PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR), *sp);
        }
        if (errno == ERANGE) {
            if (epoch == 0) {
                /* underflow */
                return _parseError(SKUTILS_ERR_UNDERFLOW, PE_NULL);
            }
            /* overflow */
            assert(epoch == HUGE_VAL || epoch == -HUGE_VAL);
            return _parseError(SKUTILS_ERR_OVERFLOW, PE_NULL);
        }

        /* handle the end of the string, to see if we are attempting
         * to parse something as epoch that we shouldn't */
        if (*ep != '\0' && !isspace((int)*ep)) {
            return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                               PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR), *ep);
        }

        /* make sure value is in range */
        if (epoch < STRING_PARSE_MIN_EPOCH || epoch > STRING_PARSE_MAX_EPOCH) {
            return _parseError(((epoch < STRING_PARSE_MIN_EPOCH)
                                ? SKUTILS_ERR_MINIMUM
                                : SKUTILS_ERR_MAXIMUM),
                               ("Epoch value (%.0f) out of range:"
                                " use %d <= epoch <= %d"),
                               epoch,
                               STRING_PARSE_MIN_EPOCH, STRING_PARSE_MAX_EPOCH);
        }

        /* ignore trailing whitespace */
        sp = ep;
        while (*sp && isspace((int)*sp)) {
            ++sp;
        }
        if ('\0' != *sp) {
            return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                               PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR), *sp);
        }

        if (resulting_precision) {
            if (strchr(date_string, '.')) {
                *resulting_precision = 7;
            } else {
                *resulting_precision = 6;
            }
        }
        *date_val = (sktime_t)1000 * epoch;
        return SKUTILS_OK;
    }

    /* 'i' is the part of the date we have successfully parsed;
     * 1=year, 2=month, 3=day, 4=hour, 5=min, 6=sec, 7=msec */
    i = 0;
    while (*sp && (i < (int)(sizeof(delim)/sizeof(char)))) {
        /* this will catch things like double ':' in the string */
        if ( !isdigit((int)*sp)) {
            return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                               PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR), *sp);
        }

        /* parse the digit */
        errno = 0;
        val = strtol(sp, &ep, 10);

        if (sp == ep) {
            return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                               PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR), *sp);
        }
        if (val == LONG_MAX && errno == ERANGE) {
            return _parseError(SKUTILS_ERR_OVERFLOW, PE_NULL);
        }
        if (val < 0) {
            return _parseError(SKUTILS_ERR_OVERFLOW, PE_NULL);
        }

        /* check that value is valid given what we are parsing */
        switch (i) {
          case 0: /* year */
            if (val < STRING_PARSE_MIN_YEAR || val > STRING_PARSE_MAX_YEAR) {
                return _parseError(((val < STRING_PARSE_MIN_YEAR)
                                    ? SKUTILS_ERR_MINIMUM
                                    : SKUTILS_ERR_MAXIMUM),
                                   ("Year value (%ld) out of range:"
                                    " use %d <= year <= %d"),
                                   val, STRING_PARSE_MIN_YEAR,
                                   STRING_PARSE_MAX_YEAR);
            }
            ts.tm_year = val - 1900;
            break;
          case 1: /* month */
            if (val < 1 || val > 12) {
                return _parseError(((val < 1)
                                    ? SKUTILS_ERR_MINIMUM
                                    : SKUTILS_ERR_MAXIMUM),
                                   ("Month value (%ld) out of range:"
                                    " use %d <= month <= %d"),
                                   val, 1, 12);
            }
            ts.tm_mon = val - 1;
            break;
          case 2: /* day */
            if (val < 1
                || val > skGetMaxDayInMonth((1900 + ts.tm_year),
                                            (1 + ts.tm_mon)))
            {
                return _parseError(((val < 1)
                                    ? SKUTILS_ERR_MINIMUM
                                    : SKUTILS_ERR_MAXIMUM),
                                   ("Day value (%ld) out of range:"
                                    " use %d <= day <= %d"),
                                   val, 1,
                                   skGetMaxDayInMonth((1900 + ts.tm_year),
                                                      (1 + ts.tm_mon)));
            }
            ts.tm_mday = val;
            break;
          case 3: /* hour */
            if (val > 23) {
                return _parseError(SKUTILS_ERR_MAXIMUM,
                                   ("Hour value (%ld) out of range:"
                                    " use %d <= hour <= %d"),
                                   val, 0, 23);
            }
            ts.tm_hour = val;
            break;
          case 4: /* minute */
            if (val > 59) {
                return _parseError(SKUTILS_ERR_MAXIMUM,
                                   ("Minute value (%ld) out of range:"
                                    " use %d <= minute <= %d"),
                                   val, 1, 59);
            }
            ts.tm_min = val;
            break;
          case 5: /* second */
            if (val > 59) {
                return _parseError(SKUTILS_ERR_MAXIMUM,
                                   ("Second value (%ld) out of range:"
                                    " use %d <= second <= %d"),
                                   val, 1, 59);
            }
            ts.tm_sec = val;
            break;
          case 6: /* fractional seconds */
            if ((ep - sp) < 3) {
                /* multiply to get to milliseconds */
                for (j = (ep - sp); j < 3; ++j) {
                    val *= 10;
                }
            } else if ((ep - sp) > 3) {
                /* divide to get to milliseconds; round final digit */
                ldiv_t q;
                for (j = 4; j < (ep - sp); ++j) {
                    val /= 10;
                }
                q = ldiv(val, 10);
                if (q.rem < 5) {
                    val = q.quot;
                } else {
                    val = q.quot + 1;
                }
            }
            msec = val;
            break;
          default:
            /* should never get here */
            abort();
        }

        /* we parsed the number; move to the delimiter */
        ++i;
        sp = ep;

        /* check for whitespace or end of string */
        if (('\0' == *sp) || isspace((int)*sp)) {
            break;
        }

        /* check that delimiter is what we expect; if so move over it
         * to next character */
        if (delim[i]) {
            if (*sp == delim[i]) {
                ++sp;
            } else if (i == 3 && (*sp == 'T')) {
                /* allow a ':' or a 'T' to separate the day and hour */
                ++sp;
            } else {
                return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                                   PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                                   *sp);
            }
        }
    }

    /* if the caller wants to know the last state parsed, we update
     * their variable. */
    if ( resulting_precision != NULL ) {
        *resulting_precision = i;
    }

    /* need at least year/month/day */
    if (i < min_precision) {
        return _parseError(SKUTILS_ERR_SHORT,
                           "Date '%s' does not have at least day precision",
                           date_string);
    }

    /* space is allowed at end of string; eat it */
    while (*sp && isspace((int)*sp)) {
        ++sp;
    }

    /* check for junk at end of string */
    if ('\0' != *sp) {
        return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                           PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR), *sp);
    }

    /* convert the time */
#if  SK_ENABLE_LOCALTIME
    t = mktime(&ts);
#else
    t = timegm(&ts);
#endif
    if (t == (time_t)-1) {
        return -1;
    }

    *date_val = (sktime_t)t * 1000 + msec;
    return SKUTILS_OK;
}


/* parses string of the form DATETIME[-DATETIME], where DATETIME is
 * parsed by skStringParseDatetime().  see header for details. */
int skStringParseDatetimeRange(
    sktime_t   *start,
    sktime_t   *end,
    const char *s_datetime,
    int        *start_precision,
    int        *end_precision)
{
    char *s_start_time;
    char *s_end_time;
    int rv = 0;

    /* check inputs */
    assert(start);
    assert(end);
    if (s_datetime == NULL) {
        return _parseError(SKUTILS_ERR_INVALID, PE_NULL);
    }

    /* copy the string, since we are going to modify it */
    s_start_time = strdup(s_datetime);
    if (!s_start_time) {
        return _parseError(SKUTILS_ERR_ALLOC, PE_NULL);
    }

    /* search for dash.  if dash does not exist, parse entire string
     * as start date.  if dash does exist, parse string on left as
     * start date and string on right as end date.
     */
    s_end_time = strchr(s_start_time, '-');
    if (s_end_time != NULL) {
        /* change the dash to a NUL to create two seperate strings */
        *s_end_time = '\0';
        /* set the s_end_time pointer to be the char after the dash */
        ++s_end_time;
        /* treat missing end-time as infinity */
        if (*s_end_time == '\0') {
            s_end_time = NULL;
        }
    }

    /* parse start */
    rv = skStringParseDatetime(start, s_start_time, start_precision);
    if (s_end_time == NULL) {
        *end = INT64_MAX;
    } else if (rv == 0) {
        rv = skStringParseDatetime(end, s_end_time, end_precision);
    }

    free(s_start_time);

    /* check error conditions and return error if necessary */
    if (rv) {
        return rv;
    }

    if (*end < *start) {
        return _parseError(SKUTILS_ERR_BAD_RANGE, PE_NULL);
    }

    return SKUTILS_OK;
}


/* set 'ceiling_time' to the greatest value that does not change the
 * 'precision' of 'time_val'.  see header for details. */
int skDatetimeCeiling(
    sktime_t       *ceiling_time,
    const sktime_t *t,
    int             precision)
{
    struct tm ts;
    struct tm *rv;
    time_t t_sec;

    assert(t);
    assert(ceiling_time);

    /* if we're already at max precision, just return what we were given */
    if (precision == 7) {
        *ceiling_time = *t;
        return 0;
    }

    t_sec = (time_t)(*t / 1000);

    /* we must have at least parsed a year */
    if (precision < 1 || precision > 7) {
        return -1;
    }

#if  SK_ENABLE_LOCALTIME
    rv = localtime_r(&t_sec, &ts);
#else
    rv = gmtime_r(&t_sec, &ts);
#endif
    if (NULL == rv) {
        return -1;
    }

    /* 'precision' is what we know; we need to set everything that is
     * "finer" than that value. */
    switch (precision) {
      case 1: /* know year, set month */
        ts.tm_mon = 11;
        /* FALLTHROUGH */

      case 2: /* know month, set month-day */
        ts.tm_mday = skGetMaxDayInMonth((1900 + ts.tm_year), (1 + ts.tm_mon));
        /* FALLTHROUGH */

      case 3: /* know month-day, set hour */
        ts.tm_hour = 23;
        /* FALLTHROUGH */

      case 4: /* know hour, set min */
        ts.tm_min = 59;
        /* FALLTHROUGH */

      case 5: /* know min, set sec */
        ts.tm_sec = 59;
        /* FALLTHROUGH */

      case 6: /* know sec, set fractional-sec (below) */
        break;

      default:
        assert(precision >= 1 && precision <= 7);
        abort();
    }

    ts.tm_wday = -1;
    ts.tm_yday = -1;
#if 0
    /* This should be correct, but fails to calculate the correct
       times under solaris, for unknown reasons. */
    ts.tm_isdst = -1;
#endif

    /* convert the time */
#if  SK_ENABLE_LOCALTIME
    t_sec = mktime(&ts);
#else
    t_sec = timegm(&ts);
#endif
    if (t_sec == (time_t)-1) {
        return -1;
    }

    /* convert seconds to milliseconds */
    *ceiling_time = (sktime_t)1000 * t_sec + 999;

    return 0;
}


/* parse string as TCP flags.  see header for details. */
int skStringParseTCPFlags(
    uint8_t    *result,
    const char *flag_string)
{
    const char *cp = flag_string;

    /* check inputs */
    assert(result);
    if (flag_string == NULL) {
        return _parseError(SKUTILS_ERR_INVALID, PE_NULL);
    }

    /* parse each character, unless it is a terminating NULL or an
     * illegal character.
     */
    *result = 0;
    while (*cp) {
        switch (*cp) {
          case 'f':
          case 'F':
            TCP_FLAG_SET_FLAG(*result, FIN_FLAG);
            break;
          case 's':
          case 'S':
            TCP_FLAG_SET_FLAG(*result, SYN_FLAG);
            break;
          case 'r':
          case 'R':
            TCP_FLAG_SET_FLAG(*result, RST_FLAG);
            break;
          case 'p':
          case 'P':
            TCP_FLAG_SET_FLAG(*result, PSH_FLAG);
            break;
          case 'a':
          case 'A':
            TCP_FLAG_SET_FLAG(*result, ACK_FLAG);
            break;
          case 'u':
          case 'U':
            TCP_FLAG_SET_FLAG(*result, URG_FLAG);
            break;
          case 'e':
          case 'E':
            TCP_FLAG_SET_FLAG(*result, ECE_FLAG);
            break;
          case 'c':
          case 'C':
            TCP_FLAG_SET_FLAG(*result, CWR_FLAG);
            break;
          case ' ':
            break;
          default:
            if (!isspace((int)*cp)) {
                /* reached illegal, non-space character */
                return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                                   PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                                   *cp);
            }
            break;
        }
        ++cp;
    }

    return SKUTILS_OK;
}


/* parse flag definition in the form high/mask.  see header for
 * details. */
int skStringParseTCPFlagsHighMask(
    uint8_t    *high,
    uint8_t    *mask,
    const char *flag_string)
{
    const char *cp = flag_string;
    uint8_t *result;

    /* check inputs */
    assert(high);
    assert(mask);
    if (flag_string == NULL) {
        return _parseError(SKUTILS_ERR_INVALID, PE_NULL);
    }

    *high = 0;
    *mask = 0;
    result = high;

    /* parse each character, unless it is a terminating NULL or an
     * illegal character.
     */
    while (*cp) {
        switch (*cp) {
          case 'f':
          case 'F':
            TCP_FLAG_SET_FLAG(*result, FIN_FLAG);
            break;
          case 's':
          case 'S':
            TCP_FLAG_SET_FLAG(*result, SYN_FLAG);
            break;
          case 'r':
          case 'R':
            TCP_FLAG_SET_FLAG(*result, RST_FLAG);
            break;
          case 'p':
          case 'P':
            TCP_FLAG_SET_FLAG(*result, PSH_FLAG);
            break;
          case 'a':
          case 'A':
            TCP_FLAG_SET_FLAG(*result, ACK_FLAG);
            break;
          case 'u':
          case 'U':
            TCP_FLAG_SET_FLAG(*result, URG_FLAG);
            break;
          case 'e':
          case 'E':
            TCP_FLAG_SET_FLAG(*result, ECE_FLAG);
            break;
          case 'c':
          case 'C':
            TCP_FLAG_SET_FLAG(*result, CWR_FLAG);
            break;
          case '/':
            if (result == mask) {
                /* double slash */
                return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                                   PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                                   *cp);
            }
            result = mask;
            break;
          case ' ':
            break;
          default:
            if (!isspace((int)*cp)) {
                /* reached illegal, non-space character */
                return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                                   PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                                   *cp);
            }
            break;
        }
        ++cp;
    }

    /* check if we reached end of string before '/' character was found */
    if (result == high) {
        if (*high == 0) {
            return _parseError(SKUTILS_ERR_EMPTY, PE_NULL);
        }
        return _parseError(SKUTILS_ERR_SHORT, "Missing '/' character");
    }

    if (*mask == 0) {
        return _parseError(SKUTILS_ERR_SHORT, "Missing masks flags value");
    }

    /* make sure high is a proper subset of mask */
    if ((*high & *mask) != *high) {
        return _parseError(SKUTILS_ERR_BAD_RANGE,
                           "High flags is not subset of mask flags");
    }

    /* success */
    return SKUTILS_OK;
}


/* parse string as uint32_t.  see header for details */
int skStringParseUint32(
    uint32_t   *result_val,
    const char *int_string,
    uint32_t    min_val,
    uint32_t    max_val)
{
    uint64_t tmp;
    int rv;

    rv = skStringParseUint64(&tmp, int_string, min_val,
                             ((max_val == 0) ? UINT32_MAX : max_val));
    if (rv >= 0 || rv == SKUTILS_ERR_MINIMUM || rv == SKUTILS_ERR_MAXIMUM){
        if (tmp > UINT32_MAX) {
            return _parseError(SKUTILS_ERR_OVERFLOW, PE_NULL);
        }
        *result_val = UINT32_MAX & (uint32_t)tmp;
    }
    return rv;
}


/* parse string as uint64_t.  see header for details */
int skStringParseUint64(
    uint64_t   *result_val,
    const char *int_string,
    uint64_t    min_val,
    uint64_t    max_val)
{
    const char *sp;
    char *ep;
#if (SIZEOF_LONG >= 8)
#define  U64_OVERFLOW ULONG_MAX
    unsigned long val;
#else
#define  U64_OVERFLOW ULLONG_MAX
    unsigned long long val;
#endif

    /* check inputs */
    assert(result_val);
    assert(max_val == 0 || min_val <= max_val);
    if (!int_string) {
        return _parseError(SKUTILS_ERR_INVALID, PE_NULL);
    }

    sp = int_string;

    /* ignore leading whitespace */
    while (*sp && isspace((int)*sp)) {
        ++sp;
    }
    if ('\0' == *sp) {
        /* whitespace only or empty string */
        return _parseError(SKUTILS_ERR_EMPTY, PE_NULL);
    }

    /* number that begins with '-' is not unsigned */
    if ('-' == *sp) {
        return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                           PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                           *sp);
    }

    /* parse the string */
    errno = 0;
#if (SIZEOF_LONG >= 8)
    val = strtoul(sp, &ep, 10);
#else
    val = strtoull(sp, &ep, 10);
#endif
    if (sp == ep) {
        /* parse error */
        return _parseError(SKUTILS_ERR_BAD_CHAR, "%s '%c'",
                           PARSE_ERRORCODE_MSG(SKUTILS_ERR_BAD_CHAR),
                           *sp);
    }
    if (val == U64_OVERFLOW && errno == ERANGE) {
        /* overflow */
        return _parseError(SKUTILS_ERR_OVERFLOW, PE_NULL);
    }
#if (U64_OVERFLOW > UINT64_MAX)
    if (val > UINT64_MAX) {
        /* too big */
        return _parseError(SKUTILS_ERR_OVERFLOW, PE_NULL);
    }
#endif

    *result_val = (uint64_t)val;
    if (*result_val < min_val) {
        /* too small */
        return _parseError(SKUTILS_ERR_MINIMUM, ("%s of %" PRIu64),
                           PARSE_ERRORCODE_MSG(SKUTILS_ERR_MINIMUM),
                           min_val);
    }
    if (max_val > 0 && *result_val > max_val) {
        /* too big */
        return _parseError(SKUTILS_ERR_MAXIMUM, ("%s of %" PRIu64),
                           PARSE_ERRORCODE_MSG(SKUTILS_ERR_MAXIMUM),
                           max_val);
    }

    /* ignore trailing whitespace, but only if we reach the end of the
     * string. */
    sp = ep;
    while (*sp && isspace((int)*sp)) {
        ++sp;
    }
    if ('\0' != *sp) {
        /* junk at end, return position of 'ep' */
        return ep - int_string;
    }

    return 0;
}


int skStringParseHumanUint64(
    uint64_t       *result_val,
    const char     *int_string,
    int             parse_flags)
{
    const char *sp;             /* Current parse position */
    const char *tp;             /* Temporary pointer */
    const char *hv;             /* Index into sk_human_value_list */
    char *ep;                   /* End of parsed number */
    int val_index;
    double tmp_val;
    struct {
        const char  c;
        double      si;
        double      trad;
    } sk_human_values[] = {
        {'k', 1.0e3,           1024.0},
        {'m', 1.0e6,        1048576.0},
        {'g', 1.0e9,     1073741824.0},
        {'t', 1.0e12, 1099511627776.0}
    };
    const char sk_human_value_list[] = "kmgt";

    /* check inputs */
    assert(result_val);
    if (!int_string) {
        return _parseError(SKUTILS_ERR_INVALID, PE_NULL);
    }

    /* allow parse_flags of 0 to be default */
    if (parse_flags == 0) {
        parse_flags = SK_HUMAN_NORMAL;
    }

    sp = int_string;

    /* ignore leading whitespace */
    while (*sp && isspace((int)*sp)) {
        ++sp;
    }
    if ('\0' == *sp) {
        /* whitespace only or empty string */
        return _parseError(SKUTILS_ERR_EMPTY, PE_NULL);
    }

    /* parse the string */
    errno = 0;
    tmp_val = strtod(sp, &ep);
    if (sp == ep) {
        /* parse error */
        return _parseError(SKUTILS_ERR_BAD_CHAR, PE_NULL);
    }
    if (errno == ERANGE) {
        if (tmp_val == HUGE_VAL || tmp_val == -HUGE_VAL) {
            /* overflow */
            return _parseError(SKUTILS_ERR_OVERFLOW, PE_NULL);
        }
        return _parseError(SKUTILS_ERR_UNDERFLOW, PE_NULL);
    }
    if (tmp_val < 0) {
        /* underflow */
        return _parseError(SKUTILS_ERR_UNDERFLOW, PE_NULL);
    }
    if (isnan(tmp_val)) {
        /* NAN */
        return _parseError(SKUTILS_ERR_BAD_CHAR, PE_NULL);
    }

    tp = sp = ep;

    /* Possibly eat trailing whitespace (Parse with tp because it
     * might be space at the end (no suffix) when we are not supposed
     * to parse that.) */
    if ((parse_flags & SK_HUMAN_MID_WS)
        || !(parse_flags & SK_HUMAN_END_NO_WS))
    {
        while (*tp && isspace((int)*tp)) {
            ++tp;
        }
    }

    /* No suffix? */
    if ('\0' == *tp) {
        if (!(parse_flags & SK_HUMAN_END_NO_WS)) {
            /* If there was no suffix, and we are supposed to parse
             * trailing whitespace, set pointer to the end. */
            sp = tp;
        }
        goto parsed;
    }

    /* Spaces before suffix allowed? */
    if ((tp != sp) && !(parse_flags & SK_HUMAN_MID_WS)) {
        /* If there is a suffix, and white space in the middle is
         * illegal, treat the suffix as junk at the end of the
         * input. */
        sp = tp;
        goto parsed;
    }

    /* Possible suffix */
    hv = strchr(sk_human_value_list, tolower((int)*tp));
    if (hv != NULL) {
        /* Valid suffix found, set the parse pointer to the end of it */
        sp = tp + 1;

        /* Find suffix information */
        val_index = hv - sk_human_value_list;
        assert((int)sk_human_values[val_index].c == tolower((int)*tp));

        /* Use suffix value */
        if (((parse_flags & SK_HUMAN_LOWER_SI) && islower((int)*tp)) ||
            ((parse_flags & SK_HUMAN_UPPER_SI) && isupper((int)*tp)))
        {
            tmp_val *= sk_human_values[val_index].si;
        } else {
            tmp_val *= sk_human_values[val_index].trad;
        }

        /* eat trailing whitespace */
        if (!(parse_flags & SK_HUMAN_END_NO_WS)) {
            while (*sp && isspace((int)*sp)) {
                ++sp;
            }
        }
    } else if (!(parse_flags & SK_HUMAN_END_NO_WS)) {
        /* No valid suffix, but we allow trailing spaces. */
        sp = tp;
    }

  parsed:
    if (tmp_val > UINT64_MAX) {
        /* overflow */
        return _parseError(SKUTILS_ERR_OVERFLOW, PE_NULL);
    }

    *result_val = tmp_val;

    if ('\0' != *sp) {
        /* junk at end */
        return 1 + sp - int_string;
    }

    return 0;
}


/* parse string as a double.  see header for details */
int skStringParseDouble(
    double     *result_val,
    const char *dbl_string,
    double      min_val,
    double      max_val)
{
    const char *sp;
    char *ep;
    double val;

    /* check inputs */
    assert(result_val);
    assert(max_val == 0 || min_val <= max_val);
    if (!dbl_string) {
        return _parseError(SKUTILS_ERR_INVALID, PE_NULL);
    }

    sp = dbl_string;

    /* ignore leading whitespace */
    while (*sp && isspace((int)*sp)) {
        ++sp;
    }
    if ('\0' == *sp) {
        /* whitespace only or empty string */
        return _parseError(SKUTILS_ERR_EMPTY, PE_NULL);
    }

    /* parse the string */
    errno = 0;
    val = strtod(sp, &ep);
    if (sp == ep) {
        /* parse error */
        return _parseError(SKUTILS_ERR_BAD_CHAR, PE_NULL);
    }
    if (errno == ERANGE) {
        if (val == 0) {
            /* underflow */
            return _parseError(SKUTILS_ERR_UNDERFLOW, PE_NULL);
        }
        /* overflow */
        assert(val == HUGE_VAL || val == -HUGE_VAL);
        return _parseError(SKUTILS_ERR_OVERFLOW, PE_NULL);
    }
    if (isnan(val)) {
        /* NAN */
        return _parseError(SKUTILS_ERR_BAD_CHAR, PE_NULL);
    }

    *result_val = val;
    if (*result_val < min_val) {
        /* too small */
        return _parseError(SKUTILS_ERR_MINIMUM, "%s of %f",
                           PARSE_ERRORCODE_MSG(SKUTILS_ERR_MINIMUM),
                           min_val);
    }
    if (max_val > 0.0 && *result_val > max_val) {
        /* too big */
        return _parseError(SKUTILS_ERR_MAXIMUM, "%s of %f",
                           PARSE_ERRORCODE_MSG(SKUTILS_ERR_MAXIMUM),
                           max_val);
    }

    /* ignore trailing whitespace, but only if we reach the end of the
     * string. */
    sp = ep;
    while (*sp && isspace((int)*sp)) {
        ++sp;
    }
    if ('\0' != *sp) {
        /* junk at end, return position of 'ep' */
        return ep - dbl_string;
    }

    return 0;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
