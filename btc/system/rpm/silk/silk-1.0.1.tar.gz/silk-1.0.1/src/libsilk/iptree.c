/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
 * iptree.c
 *
 * This is a data structure for providing marked sets of ip addresses
 * in a tree format.
 *
 * This revision of the iptree module now moves it off into a cleaner
 * separate space and has replaced the read and write statements with
 * atomic operations.
 */

#include "silk.h"

RCSIDENT("$SiLK: iptree.c 11241 2008-04-11 14:11:12Z mthomas $");

#include "iptree.h"
#include "bits.h"


/* DEFINES AND TYPEDEFS */

/* Version to write into the file's header */
#define IPSET_FILE_VERSION  2

/* macro to convert an IP to a string */
#define IP_TO_STRING(addr, fmt, buf)                            \
    switch (fmt) {                                              \
      case SKIPADDR_DECIMAL:                                    \
        snprintf((buf), sizeof(buf), ("%" PRIu32), (addr));     \
        break;                                                  \
      case SKIPADDR_ZEROPAD:                                    \
        num2dot0_r((addr), (buf));                              \
        break;                                                  \
      case SKIPADDR_CANONICAL:                                  \
      default:                                                  \
        num2dot_r((addr), (buf));                               \
        break;                                                  \
    }


#define skIPTreeNodeMarkSpot(addr, node)                                \
    ((node)->addressBlock[(((addr) & 0xFFFF)>>5)] |= (1 << ((addr)&0x1F)))
/*
 *    Set bit 'addr' in 'node'.  'addr' can be the complete IP
 *    address; 'node' is the skIPNode_t for the 16 most significant
 *    bits of the address.
 */



/* FUNCTION DEFINITIONS */

/* Add addr to ipset */
int skIPTreeAddAddress(skIPTree_t *ipset, uint32_t addr)
{
    assert(ipset);
    if (NULL == ipset->nodes[addr>>16]) {
        ipset->nodes[addr>>16] = calloc(1, sizeof(skIPNode_t));
        if (NULL == ipset->nodes[addr>>16]) {
            return SKIP_ERR_ALLOC;
        }
    }
    skIPTreeNodeMarkSpot(addr,ipset->nodes[addr>>16]);
    return SKIP_OK;
}


/* Add the addresses in an IPWildcard to ipset */
int skIPTreeAddIPWildcard(
    skIPTree_t             *ipset,
    const skIPWildcard_t   *ipwild)
{
    skIPWildcardIterator_t iter;
    skipaddr_t ip;
    uint32_t addr;

    if (skIPWildcardIsV6(ipwild)) {
        return SKIP_ERR_IPV6;
    }

    skIPWildcardIteratorBind(&iter, ipwild);
    while (skIPWildcardIteratorNext(&iter, &ip) == SK_ITERATOR_OK) {
        addr = skipaddrGetV4(&ip);

        /* inline skIPTreeAddAddress() */
        if (NULL == ipset->nodes[addr>>16]) {
            ipset->nodes[addr>>16] = calloc(1, sizeof(skIPNode_t));
            if (NULL == ipset->nodes[addr>>16]) {
                return SKIP_ERR_ALLOC;
            }
        }
        skIPTreeNodeMarkSpot(addr,ipset->nodes[addr>>16]);
    }

    return SKIP_OK;
}


/* Return 1 if the two IPsets have any IPs in common */
int skIPTreeCheckIntersectIPTree(
    const skIPTree_t   *ipset1,
    const skIPTree_t   *ipset2)
{
    int i, j;

    for (i = 0; i < SKIP_BBLOCK_COUNT; ++i) {
        /* check for intersection at the /16 level */
        if ((ipset1->nodes[i] == NULL) || (ipset2->nodes[i] == NULL)) {
            continue;
        }

        /* Need to intersect the bits in the /16 */
        for (j = 0; j < SKIP_BBLOCK_SIZE; ++j) {
            if (ipset1->nodes[i]->addressBlock[j]
                & ipset2->nodes[i]->addressBlock[j])
            {
                return 1;
            }
        }
    }

    /* no intersesction */
    return 0;
}


/* Return 1 if the IPset and IPWildcard have any IPs in common */
int skIPTreeCheckIntersectIPWildcard(
    const skIPTree_t       *ipset,
    const skIPWildcard_t   *ipwild)
{
    skIPWildcardIterator_t iter;
    skipaddr_t ip;

#if SK_ENABLE_IPV6
    if (skIPWildcardIsV6(ipwild)) {
        return 0;
    }
#endif /* SK_ENABLE_IPV6 */

    /* Iterate over the IPs from the wildcard */
    skIPWildcardIteratorBind(&iter, ipwild);
    while (skIPWildcardIteratorNext(&iter, &ip) == SK_ITERATOR_OK) {
        if (skIPTreeCheckAddress(ipset, skipaddrGetV4(&ip))) {
            return 1;
        }
    }

    /* no intersesction */
    return 0;
}


/* Return 1 if the IPset in 'ipset_path' intersects with 'ipset'.
 * Return 0 for no intersect or on error.  */
int skIPTreeCheckIntersectIPTreeFile(
    const skIPTree_t   *ipset,
    const char         *ipset_path,
    skIPTreeErrors_t   *err_code)
{
    skstream_t *stream = NULL;
    sk_file_header_t *hdr;
    int swapFlag;
    uint32_t tBuffer[9];
    ssize_t b;
    int i;
    int rv;
    int intersect = 0;
    skIPTreeErrors_t err = SKIP_OK;
    skIPNode_t *n;

    if (ipset_path == NULL || ipset == NULL) {
         err = SKIP_ERR_BADINPUT;
         goto END;
    }

    if ((rv = skStreamCreate(&stream, SK_IO_READ, SK_CONTENT_SILK))
        || (rv = skStreamBind(stream, ipset_path))
        || (rv = skStreamOpen(stream)))
    {
        err = SKIP_ERR_OPEN;
        goto END;
    }

    rv = skStreamReadSilkHeader(stream, &hdr);
    if (rv) {
        err = SKIP_ERR_FILEIO;
        goto END;
    }

    if (skStreamCheckSilkHeader(stream, FT_IPSET, 0, IPSET_FILE_VERSION,NULL)){
        err = SKIP_ERR_FILETYPE;
        goto END;
    }

    swapFlag = !skHeaderIsNativeByteOrder(hdr);

    /*
     * IPs are stored on disk in blocks of nine 32-bit words which
     * represent a /24.  The first uint32_t is the base IP of the /24
     * (a.b.c.0); the remaining eight uint32_t's have a bit for each
     * address in the /24.
     */
    while ((b = skStreamRead(stream, tBuffer, sizeof(tBuffer)))
           == sizeof(tBuffer))
    {
        if (swapFlag) {
            for (i = 0; i < 9; ++i) {
                tBuffer[i] = BSWAP32(tBuffer[i]);
            }
        }

        n = ipset->nodes[tBuffer[0] >> 16];
        if (NULL == n) {
            /* ignore this block */
            continue;
        }

        for (i = 0; i < 8; ++i) {
            if (n->addressBlock[i] & tBuffer[i+1]) {
                intersect = 1;
                goto END;
            }
        }
    }
    if (b == -1) {
        /* read error */
        err = SKIP_ERR_FILEIO;
        goto END;
    }

  END:
    skStreamDestroy(&stream);
    if (err_code) {
        *err_code = err;
    }
    return intersect;
}


/* Return a count of the number of IPs in tree. */
uint64_t skIPTreeCountIPs(const skIPTree_t *ipset)
{
    int      i, j;
    uint64_t count = 0;
    int      bits;

    for (i = 0; i < SKIP_BBLOCK_COUNT; i++) {
        if (ipset->nodes[i] != NULL) {
            /* Break the abstraction to speed up the counting */
            for (j = 0; j < SKIP_BBLOCK_SIZE; ++j) {
                if (ipset->nodes[i]->addressBlock[j]) {
                    BITS_IN_WORD(&bits, ipset->nodes[i]->addressBlock[j]);
                    count += bits;
                }
            }
        }
    }

    return count;
}


/* Allocate an IPset and set contents to empty */
int skIPTreeCreate(skIPTree_t **ipset)
{
    if (ipset == NULL) {
        return SKIP_ERR_BADINPUT;
    }

    *ipset = calloc(1, sizeof(skIPTree_t));
    if (*ipset == NULL) {
        return SKIP_ERR_ALLOC;
    }
    return SKIP_OK;
}


/* Frees space associated with *ipset. */
void skIPTreeDelete(skIPTree_t **ipset)
{
    int i;

    if (ipset == NULL || *ipset == NULL) {
        return;
    }

    for (i = 0; i < SKIP_BBLOCK_COUNT; i++) {
        if ((*ipset)->nodes[i] != NULL) {
            free((*ipset)->nodes[i]);
            (*ipset)->nodes[i] = NULL;
        }
    }
    free(*ipset);
    *ipset = NULL;
}


/* Turn off bits of 'result_ipset' that are off in 'ipset'. */
void skIPTreeIntersect(
    skIPTree_t         *result_ipset,
    const skIPTree_t   *ipset)
{
    int i, j;

    for (i = 0; i < SKIP_BBLOCK_COUNT; ++i) {
        if (result_ipset->nodes[i] != NULL) {
            if (ipset->nodes[i] == NULL) {
                /* This /16 is off in 'ipset', turn off in 'result_ipset' */
                free(result_ipset->nodes[i]);
                result_ipset->nodes[i] = NULL;
            } else  {
                int nonzero = 0;
                /* Need to intersect the bits in the /16 */
                for (j = 0; j < SKIP_BBLOCK_SIZE; ++j) {
                    result_ipset->nodes[i]->addressBlock[j] &=
                        ipset->nodes[i]->addressBlock[j];
                    nonzero = nonzero ||
                              result_ipset->nodes[i]->addressBlock[j];
                }
                if (!nonzero) {
                    free(result_ipset->nodes[i]);
                    result_ipset->nodes[i] = NULL;
                }
            }
        }
        /* ELSE this /16 is off in the 'result_ipset'.  Leave it alone. */
    }
}


/* Mask the IPs in ipset so only one is set per every (32-mask) bits */
void skIPTreeMask(
    skIPTree_t         *ipset,
    uint32_t            mask)
{
    int step;
    int i, j, k;

    if (mask == 0 || mask >= 32) {
        return;
    }

    if (mask <= 16) {
        step = 1 << (16 - mask);
        for (i = 0; i < SKIP_BBLOCK_COUNT; i += step) {
            for (k = (i + step - 1); k >= i; --k) {
                if (ipset->nodes[k] != NULL) {
                    break;
                }
            }
            if (k < i) {
                continue;
            }
            if (ipset->nodes[i] == NULL) {
                ipset->nodes[i] = ipset->nodes[k];
                ipset->nodes[k] = NULL;
            }
            ipset->nodes[i]->addressBlock[0] = 1;
            for (j = 1; j < SKIP_BBLOCK_SIZE; ++j) {
                ipset->nodes[i]->addressBlock[j] = 0;
            }
            for (k = (i + step - 1); k > i; --k) {
                if (ipset->nodes[k]) {
                    free(ipset->nodes[k]);
                    ipset->nodes[k] = NULL;
                }
            }
        }
        return;
    }

    if (mask <= 27) {
        step = 1 << (27 - mask);
        for (i = 0; i < SKIP_BBLOCK_COUNT; ++i) {
            if (ipset->nodes[i] == NULL) {
                continue;
            }
            for (j = 0; j < SKIP_BBLOCK_SIZE; j += step) {
                for (k = (j + step - 1); k >= j; --k) {
                    if (ipset->nodes[i]->addressBlock[k]) {
                        break;
                    }
                }
                if (k < j) {
                    continue;
                }
                ipset->nodes[i]->addressBlock[j] = 1;
                for (k = (j + step - 1); k > j; --k) {
                    ipset->nodes[i]->addressBlock[k] = 0;
                }
            }
        }
        return;
    }

    /* operate on each integer */
    step = 1 << (32 - mask);
    for (i = 0; i < SKIP_BBLOCK_COUNT; ++i) {
        if (ipset->nodes[i] == NULL) {
            continue;
        }
        for (j = 0; j < SKIP_BBLOCK_SIZE; ++j) {
            for (k = 0; k < 32; k += step) {
                if (GET_MASKED_BITS(ipset->nodes[i]->addressBlock[j],
                                    k, step))
                {
                    SET_MASKED_BITS(ipset->nodes[i]->addressBlock[j],
                                    1, k, step);
                }
            }
        }
    }
}


/* Read IPset from filename---a wrapper around skIPTreeRead(). */
int skIPTreeLoad(skIPTree_t **ipset, const char *filename)
{
    skstream_t *stream = NULL;
    int rv;

    if (filename == NULL || ipset == NULL) {
        return SKIP_ERR_BADINPUT;
    }

    if ((rv = skStreamCreate(&stream, SK_IO_READ, SK_CONTENT_SILK))
        || (rv = skStreamBind(stream, filename))
        || (rv = skStreamOpen(stream)))
    {
        /* skStreamPrintLastErr(stream, rv, &skAppPrintErr); */
        rv = SKIP_ERR_OPEN;
        goto END;
    }

    rv = skIPTreeRead(ipset, stream);
    if (rv) { goto END; }

  END:
    skStreamDestroy(&stream);
    return rv;
}


/* Print a textual prepresenation of the IP Tree. */
void skIPTreePrint(
    const skIPTree_t   *ipset,
    skstream_t         *stream,
    skipaddr_flags_t    ip_format,
    int                 as_cidr)
{
    char buf[SK_NUM2DOT_STRLEN+1];

    if (as_cidr) {
        skIPTreeCIDRBlockIterator_t cidr_iter;
        skIPTreeCIDRBlock_t cidr;

        skIPTreeCIDRBlockIteratorBind(&cidr_iter, ipset);
        while (skIPTreeCIDRBlockIteratorNext(&cidr, &cidr_iter)
               == SK_ITERATOR_OK)
        {
            IP_TO_STRING(cidr.addr, ip_format, buf);
            if (cidr.mask == 32) {
                skStreamPrint(stream, "%s\n", buf);
            } else {
                skStreamPrint(stream, "%s/%d\n", buf, cidr.mask);
            }
        }
    } else {
        skIPTreeIterator_t iter;
        uint32_t addr;

        /* memset to eliminate gcc warning */
        memset(&iter, 0, sizeof(skIPTreeIterator_t));

        skIPTreeIteratorBind(&iter, ipset);
        while (skIPTreeIteratorNext(&addr, &iter) == SK_ITERATOR_OK) {
            IP_TO_STRING(addr, ip_format, buf);
            skStreamPrint(stream, "%s\n", buf);
        }
    }
}


/* Allocate 'ipset' and read it from the data stream 'stream'. */
int skIPTreeRead(skIPTree_t **ipset, skstream_t *stream)
{
    sk_file_header_t *hdr;
    int swapFlag;
    uint32_t tBuffer[9];
    uint32_t blockStart;
    uint32_t rootAddr;
    ssize_t b;
    int i;
    int rv;

    if (stream == NULL || ipset == NULL) {
        return SKIP_ERR_BADINPUT;
    }

    if ((*ipset) != NULL) {
        return SKIP_ERR_NONEMPTY;
    }

    rv = skStreamReadSilkHeader(stream, &hdr);
    if (rv) {
        /* skStreamPrintLastErr(stream, rv, &skAppPrintErr); */
        rv = SKIP_ERR_FILEIO;
        goto END;
    }

    /*
     * There has only been one IPset file format, but it may have
     * version 0, 1, or 2.  Files of v2 support compression on write;
     * for compatibility with SiLK-0.10.0 through 0.10.4, compression
     * on read is supported regardless of version.
     *
     * When first released, the version of the IPset was never
     * initialized.  To work with those files, the version check was
     * never implemented.
     */
    if (skStreamCheckSilkHeader(stream, FT_IPSET, 0, IPSET_FILE_VERSION,NULL)){
        rv = SKIP_ERR_FILETYPE;
        goto END;
    }

    swapFlag = !skHeaderIsNativeByteOrder(hdr);

    rv = skIPTreeCreate(ipset);
    if (rv != SKIP_OK) {
        goto END;
    }

    /*
     * IPs are stored on disk in blocks of nine 32-bit words which
     * represent a /24.  The first uint32_t is the base IP of the /24
     * (a.b.c.0); the remaining eight uint32_t's have a bit for each
     * address in the /24.
     */
    while ((b = skStreamRead(stream, tBuffer, sizeof(tBuffer)))
           == sizeof(tBuffer))
    {
        if (swapFlag) {
            for (i = 0; i < 9; ++i) {
                tBuffer[i] = BSWAP32(tBuffer[i]);
            }
        }

        /* Put the first two octets into rootAddr, and allocate the
         * space for the /16 if we need to */
        rootAddr = (tBuffer[0] >> 16);
        if ((*ipset)->nodes[rootAddr] == NULL) {
            (*ipset)->nodes[rootAddr] = calloc(1, sizeof(skIPNode_t));
            if ((*ipset)->nodes[rootAddr] == NULL) {
                rv = SKIP_ERR_ALLOC;
                goto END;
            }
        }

        /* Locate where this /24 occurs inside the larger /16, then
         * copy it into place.  Following is equivalent to
         * (((tBuffer[0] >> 8) & 0xFF) * 8); */
        blockStart = ((tBuffer[0] & 0x0000FF00) >> 5);
        memcpy(((*ipset)->nodes[rootAddr]->addressBlock + blockStart),
               tBuffer + 1, 8 * sizeof(uint32_t));
    }
    if (b == -1) {
        /* read error */
        rv = SKIP_ERR_FILEIO;
        goto END;
    }

    rv = SKIP_OK;

  END:
    if (rv != SKIP_OK) {
        /* Do cleanup (Delete tree) and return */
        if ((*ipset) != NULL) {
            skIPTreeDelete(ipset);
        }
    }
    return rv;
}


/* Remove all addresses from an IPset */
int skIPTreeRemoveAll(skIPTree_t *ipset)
{
    int i;

    if (ipset == NULL) {
        return SKIP_ERR_BADINPUT;
    }

    /* delete all the nodes */
    for (i = 0; i < SKIP_BBLOCK_COUNT; i++) {
        if (ipset->nodes[i] != NULL) {
            free(ipset->nodes[i]);
        }
    }

    memset(ipset, 0, sizeof(skIPTree_t));
    return SKIP_OK;
}


/* Write 'ipset' to 'filename'--a wrapper around skIPTreeWrite(). */
int skIPTreeSave(const skIPTree_t *ipset, const char *filename)
{
    skstream_t *stream = NULL;
    int rv;

    if (filename == NULL || ipset == NULL) {
        return SKIP_ERR_BADINPUT;
    }

    if ((rv = skStreamCreate(&stream, SK_IO_WRITE, SK_CONTENT_SILK))
        || (rv = skStreamBind(stream, filename))
        || (rv = skStreamOpen(stream)))
    {
        /* skStreamPrintLastErr(stream, rv, &skAppPrintErr); */
        rv = SKIP_ERR_OPEN;
        goto END;
    }

    rv = skIPTreeWrite(ipset, stream);

  END:
    skStreamDestroy(&stream);
    return rv;
}


/* Convert 'error_code' to a string. */
const char *skIPTreeStrError(int error_code)
{
    switch ((skIPTreeErrors_t)error_code) {
      case SKIP_OK:
        return "Success";
      case SKIP_ERR_ALLOC:
        return "Unable to allocate memory";
      case SKIP_ERR_BADINPUT:
        return "Empty input value";
      case SKIP_ERR_FILEIO:
        return "Error in read/write";
      case SKIP_ERR_FILETYPE:
        return "Input is not an IPset";
      case SKIP_ERR_NONEMPTY:
        return "Input IPset is not empty";
      case SKIP_ERR_OPEN:
        return "Error opening file";
      case SKIP_ERR_IPV6:
        return "IPsets do not support IPv6 addresses";
    }

    return "Unrecognized error code";
}


/* Subtract 'ipset' from 'result_ipset' */
void skIPTreeSubtract(
    skIPTree_t         *result_ipset,
    const skIPTree_t   *ipset)
{
    int i, j;

    for (i = 0; i < SKIP_BBLOCK_COUNT; ++i) {
        if ((result_ipset->nodes[i] != NULL) && (ipset->nodes[i] != NULL)) {
            int nonzero = 0;
            /* Need to intersect with the complement in the /16 */
            for (j = 0; j < SKIP_BBLOCK_SIZE; ++j) {
                result_ipset->nodes[i]->addressBlock[j] &=
                    ~(ipset->nodes[i]->addressBlock[j]);
                nonzero = nonzero || result_ipset->nodes[i]->addressBlock[j];
            }
            if (!nonzero) {
                free(result_ipset->nodes[i]);
                result_ipset->nodes[i] = NULL;
            }
        }
        /* ELSE This /16 is off in at least one ipset.  Leave it alone. */
    }
}


/* Merge 'ipset' into 'result_ipset' */
int skIPTreeUnion(
    skIPTree_t         *result_ipset,
    const skIPTree_t   *ipset)
{
    int i, j;

    for (i = 0; i < SKIP_BBLOCK_COUNT; ++i) {
        if (NULL != ipset->nodes[i]) {
            if (NULL != result_ipset->nodes[i]) {
                /* need to merge */
                for (j = 0; j < SKIP_BBLOCK_SIZE; ++j) {
                    result_ipset->nodes[i]->addressBlock[j] |=
                        ipset->nodes[i]->addressBlock[j];
                }
            } else {
                /* copy block from ipset to result_ipset */
                result_ipset->nodes[i] = malloc(sizeof(skIPNode_t));
                if (result_ipset->nodes[i] == NULL) {
                    return SKIP_ERR_ALLOC;
                }
                memcpy(result_ipset->nodes[i], ipset->nodes[i],
                       sizeof(skIPNode_t));
            }
        }
    }

    return SKIP_OK;
}


/* Write 'ipset' to 'stream'. */
int skIPTreeWrite(const skIPTree_t *ipset, skstream_t *stream)
{
    sk_file_header_t *hdr;
    uint32_t i;
    uint32_t j;
    uint32_t jOffset;
    uint32_t class_c;
    skIPNode_t *workNode;
    int rv;

    if (stream == NULL || ipset == NULL) {
        return SKIP_ERR_BADINPUT;
    }

    hdr = skStreamGetSilkHeader(stream);
    skHeaderSetFileFormat(hdr, FT_IPSET);
    skHeaderSetRecordVersion(hdr, IPSET_FILE_VERSION);
    /* skHeaderSetRecordLength(hdr, 9 * sizeof(uint32_t)); */
    skHeaderSetRecordLength(hdr, 1);

    /*
     * Prep and write the IPTree's header information.
     */
    rv = skStreamWriteSilkHeader(stream);
    if (rv) {
        /* skStreamPrintLastErr(stream, rv, &skAppPrintErr); */
        rv = SKIP_ERR_FILETYPE;
        goto END;
    }

    /*
     * IPs are stored on disk in blocks of nine 32-bit words which
     * represent a /24.  The first uint32_t is the base IP of the /24
     * (a.b.c.0); the remaining eight uint32_t's have a bit for each
     * address in the /24.
     */
    for (i = 0; i < SKIP_BBLOCK_COUNT; i++) {
        /* workNode represents a /16 */
        workNode = ipset->nodes[i];
        if (workNode == NULL) {
            continue;
        }

        /*
         * There is data in this /16, now walk over the addressBlocks,
         * which are /27s, and for any which have IP bits set, write
         * the entire /24 to disk.
         */
        j = 0;
        while (j < SKIP_BBLOCK_SIZE) {
            if (workNode->addressBlock[j] == 0) {
                /* nothing in this /27 */
                j = j + 1;
                continue;
            }

            /* there is data in this /27; get the /24 that it is part
             * of, and write that base address. */
            class_c = ((i << 16) | (j << 5)) & 0xFFFFFF00;
            if (skStreamWrite(stream, &class_c, sizeof(uint32_t)) == -1) {
                rv = SKIP_ERR_FILEIO;
                goto END;
            }

            /* compute the first /27 that has data for the /24, then
             * write the complete /24: 8 uint32_t's */
            jOffset = (j & (0xff << 3));
            if (skStreamWrite(stream, (workNode->addressBlock+jOffset),
                              8 * sizeof(uint32_t))
                == -1)
            {
                rv = SKIP_ERR_FILEIO;
                goto END;
            }
            /* move the start of the next /24 */
            j = ((j & (0xff << 3)) + 8);
        }
    }

    rv = skStreamFlush(stream);
    if (rv) {
        /* skStreamPrintLastErr(stream, rv, &skAppPrintErr); */
        rv = SKIP_ERR_FILEIO;
        goto END;
    }

    rv = SKIP_OK;

  END:
    return rv;
}



/* ITERATOR CODE */


/* Bind iterator to ipset */
int skIPTreeIteratorBind(
    skIPTreeIterator_t  *iter,
    const skIPTree_t    *ipset)
{
    if (iter == NULL || ipset == NULL) {
        return SKIP_ERR_BADINPUT;
    }

    iter->tree = ipset;
    skIPTreeIteratorReset(iter);

    return SKIP_OK;
}


/* Create iterator */
int skIPTreeIteratorCreate(
    skIPTreeIterator_t **out_iter,
    const skIPTree_t    *ipset)
{
    assert(out_iter);

    *out_iter = malloc(sizeof(skIPTreeIterator_t));
    if (*out_iter == NULL) {
        return SKIP_ERR_ALLOC;
    }

    if (skIPTreeIteratorBind(*out_iter, ipset)) {
        skIPTreeIteratorDestroy(out_iter);
        return SKIP_ERR_BADINPUT;
    }

    return SKIP_OK;
}


/* Destroy iterator */
void skIPTreeIteratorDestroy(skIPTreeIterator_t **out_iter)
{
    if (*out_iter) {
        (*out_iter)->tree = NULL;
        free(*out_iter);
        *out_iter = NULL;
    }
}


#define FIND_NEXT_ITER_TOP(iter)                                        \
    for ( ; (iter)->top_16 < SKIP_BBLOCK_COUNT; ++(iter)->top_16) {     \
        if ((iter)->tree->nodes[(iter)->top_16] != NULL) {              \
            /* found a /16 with data */                                 \
            break;                                                      \
        }                                                               \
    }


/* Get next entry in tree */
skIteratorStatus_t skIPTreeIteratorNext(
    uint32_t           *out_addr,
    skIPTreeIterator_t *iter)
{
    assert(out_addr);

    while (iter->top_16 < SKIP_BBLOCK_COUNT) {
        for ( ; iter->mid_11 < SKIP_BBLOCK_SIZE ; ++iter->mid_11) {
            if ((iter->tree->nodes[iter->top_16]->addressBlock[iter->mid_11])
                == 0)
            {
                continue;
            }

            for ( ; iter->bot_5 < 32; ++iter->bot_5) {
                if (skIPTreeNodeHasMark(((iter->mid_11 << 5) + iter->bot_5),
                                        (iter->tree->nodes[iter->top_16])))
                {
                    /* Generate the IP address */
                    *out_addr = (((iter->top_16) << 16)
                                 | (iter->mid_11 << 5)
                                 | iter->bot_5);
                    /* Prepare to search from next IP address */
                    ++iter->bot_5;
                    return SK_ITERATOR_OK;
                }
            }

            /* reset bottom counter */
            iter->bot_5 = 0;
        }

        /* reset middle counter; move top counter to next valid block */
        iter->mid_11 = 0;
        ++iter->top_16;
        FIND_NEXT_ITER_TOP(iter);
    }

    return SK_ITERATOR_NO_MORE_ENTRIES;
}


/* Reset iterator */
void skIPTreeIteratorReset(skIPTreeIterator_t *iter)
{
    /* Set everything to zero, then find the first IP address */
    iter->top_16 = iter->mid_11 = iter->bot_5 = 0;

    FIND_NEXT_ITER_TOP(iter);
}


/* Bind a CIDR iterator to an IPset */
int skIPTreeCIDRBlockIteratorBind(
    skIPTreeCIDRBlockIterator_t    *iter,
    const skIPTree_t               *ipset)
{
    /* memset to eliminate gcc warning */
    memset(iter, 0, sizeof(skIPTreeCIDRBlockIterator_t));

    if (skIPTreeIteratorBind(&iter->tree_iter, ipset)) {
        return SKIP_ERR_BADINPUT;
    }
    skIPTreeCIDRBlockIteratorReset(iter);
    return SKIP_OK;
}


/* Create CIDR iterator */
int skIPTreeCIDRBlockIteratorCreate(
    skIPTreeCIDRBlockIterator_t   **out_iter,
    const skIPTree_t               *ipset)
{
    assert(out_iter);

    *out_iter = malloc(sizeof(skIPTreeCIDRBlockIterator_t));
    if (*out_iter == NULL) {
        return SKIP_ERR_ALLOC;
    }

    if (skIPTreeCIDRBlockIteratorBind(*out_iter, ipset)) {
        skIPTreeCIDRBlockIteratorDestroy(out_iter);
        return SKIP_ERR_BADINPUT;
    }

    return SKIP_OK;
}


/* Destroy CIDR iterator */
void skIPTreeCIDRBlockIteratorDestroy(skIPTreeCIDRBlockIterator_t **out_iter)
{
    if (*out_iter) {
        free(*out_iter);
        *out_iter = NULL;
    }
}


skIteratorStatus_t skIPTreeCIDRBlockIteratorNext(
    skIPTreeCIDRBlock_t            *out_cidr,
    skIPTreeCIDRBlockIterator_t    *iter)
{
    assert(out_cidr);

    /* check for the stoping condition */
    if (iter->low > iter->high) {
        return SK_ITERATOR_NO_MORE_ENTRIES;
    }

    /* If 'iter' is at the start of a new block, add IPs to the
     * current continuous list until we get a non-contiguous IP or
     * there is no more data */
    while (iter->high == iter->newlist) {
        if (skIPTreeIteratorNext(&iter->newlist, &iter->tree_iter)
            != SK_ITERATOR_OK)
        {
            /* no more data */
            iter->newlist = 0;
            break;
        }
        if (iter->newlist == (iter->high + 1)) {
            /* Current range is contiguous, expand it. */
            iter->high = iter->newlist;
        }
    }

    out_cidr->addr = iter->low;
    out_cidr->mask = skComputeCIDR(out_cidr->addr, iter->high, &iter->low);

    if (iter->low == 0) {
        /* finished with this contiguous list of IPs, move to start of
         * next list of IPS */
        if (iter->newlist == 0) {
            /* no more IPs */
            iter->high = 0;
            iter->low = 1;
        } else {
            iter->low = iter->high = iter->newlist;
        }
    }

    return SK_ITERATOR_OK;
}


/* Reset CIDR iterator */
void skIPTreeCIDRBlockIteratorReset(skIPTreeCIDRBlockIterator_t *iter)
{
    assert(iter);

    /* reset the IP iterator */
    skIPTreeIteratorReset(&iter->tree_iter);

    /* find the first IP address */
    if (skIPTreeIteratorNext(&iter->newlist, &iter->tree_iter)
        == SK_ITERATOR_OK)
    {
        iter->low = iter->high = iter->newlist;
    } else {
        /* No IPs.  Set to our stopping condition */
        iter->high = iter->newlist = 0;
        iter->low = 1;
    }
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
