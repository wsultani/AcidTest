/*
** Copyright (C) 2006-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  skstream.c
**      Mark Thomas  July-2006
**
**      skstream provides a wrapper around file pointers and file
**      descriptors.  It handles both textual and binary data.
*/


#include "silk.h"

RCSIDENT("$SiLK: skstream.c 11250 2008-04-11 19:09:05Z mthomas $");

#include "skstream.h"
#include "skiobuf.h"
#include "sksite.h"
#include "skstream_priv.h"


#ifndef DEFAULT_FILE_FORMAT
#  if SK_ENABLE_IPV6
#    define DEFAULT_FILE_FORMAT  FT_RWIPV6ROUTING
#  else
#    define DEFAULT_FILE_FORMAT  FT_RWGENERIC
#  endif
#endif


#define STREAM_SET_IS_SILK_FLOW(stream)                         \
    switch (skHeaderGetFileFormat((stream)->silk_hdr)) {        \
      case FT_RWAUGMENTED:                                      \
      case FT_RWAUGROUTING:                                     \
      case FT_RWAUGWEB:                                         \
      case FT_RWAUGSNMPOUT:                                     \
      case FT_RWFILTER:                                         \
      case FT_FLOWCAP:                                          \
      case FT_RWGENERIC:                                        \
      case FT_RWIPV6:                                           \
      case FT_RWIPV6ROUTING:                                    \
      case FT_RWNOTROUTED:                                      \
      case FT_RWROUTED:                                         \
      case FT_RWSPLIT:                                          \
      case FT_RWWWW:                                            \
        (stream)->is_silk_flow = 1;                             \
        break;                                                  \
      default:                                                  \
        (stream)->is_silk_flow = 0;                             \
        break;                                                  \
    }


/* LOCAL FUNCTION PROTOTYPES */

static int streamCheckModifiable(
    skstream_t         *stream);

static int streamCheckOpen(
    const skstream_t   *stream);

static int streamCheckUnopened(
    const skstream_t   *stream);

static void streamCacheHeader(
    skstream_t         *stream);

static int streamGZFlush(
    skstream_t         *stream);

static ssize_t streamGZRead(
    skstream_t         *stream,
    void               *buf,
    size_t              count);

static ssize_t streamGZWrite(
    skstream_t         *stream,
    const void         *buf,
    size_t              count);

static int streamIOBufCreate(
    skstream_t         *stream);

static int streamIOBufGetLine(
    skstream_t         *stream,
    char               *out_buffer,
    size_t              buf_size);

static ssize_t streamIOBufRead(
    skstream_t         *stream,
    void               *buf,
    size_t              count);

static ssize_t streamIOBufWrite(
    skstream_t         *stream,
    const void         *buf,
    size_t              count);

static int streamInvokePager(
    skstream_t         *stream);


static int streamOpenAppend(
    skstream_t         *stream);

static int streamOpenRead(
    skstream_t         *stream);

static int streamOpenWrite(
    skstream_t         *stream);

static int streamPathnameIsCompressed(
    const char         *pathname,
    skstream_mode_t     read_write_append);

static int streamPrepareText(
    skstream_t         *stream);



/* FUNCTION DEFINITIONS */


static const char *streamCallbackStrerror(
    skstream_t         *stream,
    int          UNUSED(errnum))
{
    if (stream->err_info == SKSTREAM_ERR_ZLIB) {
#if SK_ENABLE_ZLIB
        if (stream->gz) {
            int zerr;
            return gzerror(stream->gz, &zerr);
        }
#endif  /* SK_ENABLE_ZLIB */
        return "Interal zlib error";
    }
    return strerror(stream->errnum);
}


/*
 *  status = streamCheckAttributes(stream, io_mode_list, content_type_list);
 *
 */
static int streamCheckAttributes(
    skstream_t         *stream,
    int                 io_mode_list,
    int                 content_type_list)
{
    if (stream == NULL) {
        return SKSTREAM_ERR_NULL_ARGUMENT;
    } else if ( !(stream->io_mode & io_mode_list)) {
        return SKSTREAM_ERR_UNSUPPORT_IOMODE;
    } else if ( !(stream->content_type & content_type_list)) {
        return SKSTREAM_ERR_UNSUPPORT_CONTENT;
    } else {
        return SKSTREAM_OK;
    }
}


/*
 *  status = streamCheckModifiable(stream);
 *
 *    Return SKSTREAM_OK if the caller is still allowed to set aspects
 *    of 'stream'; otherwise return the reason why 'stream' cannot be
 *    modified.
 */
static int streamCheckModifiable(
    skstream_t         *stream)
{
    if (stream == NULL) {
        return SKSTREAM_ERR_NULL_ARGUMENT;
    } else if (stream->is_closed) {
        return SKSTREAM_ERR_CLOSED;
    } else if (stream->is_dirty) {
        return SKSTREAM_ERR_PREV_DATA;
    } else {
        return SKSTREAM_OK;
    }
}


/*
 *  status = streamCheckOpen(stream);
 *
 *    Call this function on a stream which you expect to be open; it
 *    will return SKSTREAM_OK if 'stream' is open, or an error code
 *    explaining why 'stream' is not open.
 *
 *    A stream that has been opened and closed is neither open nor
 *    unopened.
 */
static int streamCheckOpen(
    const skstream_t   *stream)
{
    if (stream == NULL) {
        return SKSTREAM_ERR_NULL_ARGUMENT;
    } else if (stream->is_closed) {
        return SKSTREAM_ERR_CLOSED;
    } else if (stream->fd == -1) {
        return SKSTREAM_ERR_NOT_OPEN;
    } else {
        return SKSTREAM_OK;
    }
}


/*
 *  status = streamCheckUnopened(stream);
 *
 *    Call this function on a stream which you expect to be
 *    unopened---i.e., not yet open.  It will return SKSTREAM_OK if
 *    'stream' is unopened, or an error code explaining why 'stream'
 *    is not considered unopened.
 *
 *    A stream that has been opened and closed is neither open nor
 *    unopened.
 */
static int streamCheckUnopened(
    const skstream_t   *stream)
{
    if (stream == NULL) {
        return SKSTREAM_ERR_NULL_ARGUMENT;
    } else if (stream->is_closed) {
        return SKSTREAM_ERR_CLOSED;
    } else if (stream->fd != -1) {
        return SKSTREAM_ERR_PREV_OPEN;
    } else {
        return SKSTREAM_OK;
    }
}


static void streamCacheHeader(
    skstream_t         *stream)
{
    union h_un {
        sk_header_entry_t          *he;
        sk_hentry_packedfile_t     *pf;
    } h;

    h.he = skHeaderGetFirstMatch(stream->silk_hdr, SK_HENTRY_PACKEDFILE_ID);
    if (h.he) {
        stream->hdr_starttime = skHentryPackedfileGetStartTime(h.pf);
        stream->hdr_sensor    = skHentryPackedfileGetSensorID(h.pf);
        stream->hdr_flowtype  = skHentryPackedfileGetFlowtypeID(h.pf);
    }
}


#if SK_ENABLE_ZLIB
static int streamGZFlush(
    skstream_t         *stream)
{
    int zerr = gzflush(stream->gz, Z_SYNC_FLUSH);
    if (zerr == Z_OK) {
        return 0;
    }
    stream->is_iobuf_error = 1;
    if (zerr == Z_ERRNO) {
        stream->errnum = errno;
        stream->err_info = SKSTREAM_ERR_WRITE;
    } else {
        stream->errnum = zerr;
        stream->err_info = SKSTREAM_ERR_ZLIB;
    }
    return -1;
}


static ssize_t streamGZRead(
    skstream_t         *stream,
    void               *buf,
    size_t              count)
{
    int got = gzread(stream->gz, buf, (unsigned)count);
    if (got == -1) {
        stream->is_iobuf_error = 1;
        (void)gzerror(stream->gz, &stream->errnum);
        if (stream->errnum == Z_ERRNO) {
            stream->errnum = errno;
            stream->err_info = SKSTREAM_ERR_READ;
        } else {
            stream->err_info = SKSTREAM_ERR_ZLIB;
        }
    }
    return (ssize_t)got;
}


static ssize_t streamGZWrite(
    skstream_t         *stream,
    const void         *buf,
    size_t              count)
{
    int written = gzwrite(stream->gz, buf, (unsigned)count);
    if (written > 0 || count == 0) {
        return written;
    }
    stream->is_iobuf_error = 1;
    (void)gzerror(stream->gz, &stream->errnum);
    if (stream->errnum == Z_ERRNO) {
        stream->errnum = errno;
        stream->err_info = SKSTREAM_ERR_WRITE;
    } else {
        stream->err_info = SKSTREAM_ERR_ZLIB;
    }
    return -1;
}
#endif  /* SK_ENABLE_ZLIB */



/*
 *  status = streamIOBufCreate(stream);
 *
 *    Create the skIOBuf that 'stream' will read-from/write-to, and
 *    bind it to the file descriptor or gzfile.  Return SKSTREAM_OK on
 *    success, or an error code on failure.
 */
static int streamIOBufCreate(
    skstream_t         *stream)
{
    int rv = SKSTREAM_OK;
    size_t reclen = 1;
    uint8_t compmethod = SK_COMPMETHOD_NONE;
    skio_abstract_t io_func;

    assert(stream);
    assert(stream->fd != -1);

    if (stream->is_unbuffered) {
        goto END;
    }

    memset(&io_func, 0, sizeof(skio_abstract_t));

    /* store location where the IOBuf was enabled */
    stream->pre_iobuf_pos = lseek(stream->fd, 0, SEEK_CUR);

    /* create the iobuf */
    switch (stream->io_mode) {
      case SK_IO_READ:
        /* create the buffered reader */
        stream->iobuf = skIOBufCreateReader();
        break;

      case SK_IO_WRITE:
      case SK_IO_APPEND:
        stream->iobuf = skIOBufCreateWriter();
        break;
    }
    if (stream->iobuf == NULL) {
        rv = SKSTREAM_ERR_ALLOC;
        goto END;
    }

    /* get the information for SiLK files */
    if (stream->is_silk) {
        /* make certain the record size is non-zero */
        reclen = skHeaderGetRecordLength(stream->silk_hdr);
        if (reclen == 0) {
            reclen = 1;
            skHeaderSetRecordLength(stream->silk_hdr, reclen);
        }

        /* set the record size on the IOBuf */
        if (-1 == skIOBufSetRecordSize(stream->iobuf, reclen)) {
            rv = SKSTREAM_ERR_IOBUF;
            goto END;
        }

        compmethod = skHeaderGetCompressionMethod(stream->silk_hdr);
    }

    /* bind it to the file descriptor or gzfile */
#if SK_ENABLE_ZLIB
    if (stream->gz) {
        io_func.read = (skio_read_fn_t)&streamGZRead;
        io_func.write = (skio_write_fn_t)&streamGZWrite;
        io_func.flush = (skio_flush_fn_t)&streamGZFlush;
        io_func.strerror = (skio_strerror_fn_t)&streamCallbackStrerror;
        if (skIOBufBindAbstract(stream->iobuf, stream, compmethod, &io_func)
            == -1)
        {
            rv = SKSTREAM_ERR_IOBUF;
            goto END;
        }
    } else
#endif  /* SK_ENABLE_ZLIB */
    {
        /* if (skIOBufBind(stream->iobuf, stream->fd, compmethod) == -1) */
        io_func.read = (skio_read_fn_t)&streamIOBufRead;
        io_func.write = (skio_write_fn_t)&streamIOBufWrite;
        io_func.strerror = (skio_strerror_fn_t)&streamCallbackStrerror;
        if (skIOBufBindAbstract(stream->iobuf, stream, compmethod, &io_func)
            == -1)
        {
            rv = SKSTREAM_ERR_IOBUF;
            goto END;
        }
    }

  END:
    return rv;
}


/*
 *  status = streamIOBufGetLine(stream, out_buffer, buf_size);
 *
 *   Fill 'out_buffer' with the next '\n'-delimited line of text from
 *   the IOBuf associated with the 'stream'.  The '\n' is replaced
 *   with '\0'.  If the final input is smaller than 'buf_size' and
 *   does not contain a '\n' it will be copied into 'out_buffer'.
 *   Return SKSTREAM_OK on success.
 *
 *   If there is no '\n' within the first 'buf_size' characters of the
 *   input, return SKSTREAM_ERR_LONG_LINE and read from the IOBuf
 *   until a '\n' is found or until end-of-file is reached.
 *
 *   Return SKSTREAM_ERR_EOF when all input data has been processed.
 *
 *   Return SKSTREAM_ERR_IOBUF is there is a problem reading from the
 *   IOBuf.
 *
 *   This function mimics fgets().
 */
static int streamIOBufGetLine(
    skstream_t         *stream,
    char               *out_buffer,
    size_t              buf_size)
{
    char *eol = NULL;
    ssize_t sz;
    int rv = SKSTREAM_OK;

    while (eol == NULL) {
        /* substract 1 for final '\0' */
        sz = skIOBufReadToChar(stream->iobuf, out_buffer, buf_size-1, '\n');
        if (sz == -1) {
            if (stream->is_iobuf_error) {
                stream->is_iobuf_error = 0;
                rv = stream->err_info;
            } else {
                rv = SKSTREAM_ERR_IOBUF;
            }
            break;
        }
        if (sz == 0) {
            rv = SKSTREAM_ERR_EOF;
            break;
        }
        if ((sz == (ssize_t)buf_size-1) && ('\n' != out_buffer[sz-1])) {
            /* Found no newline in 'buf_size' characters... */
            rv = SKSTREAM_ERR_LONG_LINE;
            /* need to read more from skiobuf to find next '\n' */
            continue;
        }

        /* NUL terminate the string, either by replacing '\n' with a
         * '\0', or by putting a '\0' after the final character. */
        eol = &out_buffer[sz-1];
        if (*eol != '\n') {
            ++eol;
        }
        *eol = '\0';
    }

    return rv;
}


/*
 *  status = streamIOBufRead(stream, buf, count);
 *
 *    Read 'count' bytes from the file descriptor associated with
 *    'stream' and put them into 'buf'.
 *
 *    This function is the callback invoked by skIOBufRead().
 */
static ssize_t streamIOBufRead(
    skstream_t         *stream,
    void               *buf,
    size_t              count)
{
    ssize_t rv;

    rv = skreadn(stream->fd, buf, count);
    if (rv == -1) {
        stream->is_iobuf_error = 1;
        stream->errnum = errno;
        stream->err_info = SKSTREAM_ERR_READ;
    }
    return rv;
}


/*
 *  status = streamIOBufWrite(stream, buf, count);
 *
 *    Write 'count' bytes from 'buf' to the file descriptor associated
 *    with 'stream'.
 *
 *    This function is the callback invoked by skIOBufWrite().
 */
static ssize_t streamIOBufWrite(
    skstream_t         *stream,
    const void         *buf,
    size_t              count)
{
    ssize_t rv;

    rv = skwriten(stream->fd, buf, count);
    if (rv == -1) {
        stream->is_iobuf_error = 1;
        stream->errnum = errno;
        stream->err_info = SKSTREAM_ERR_WRITE;
    }
    return rv;
}


static int streamInvokePager(
    skstream_t         *stream)
{
    int rv;
    pid_t pid;
    int wait_status;

    rv = streamCheckModifiable(stream);
    if (rv) { goto END; }

    if (stream->pager == NULL) {
        goto END;
    }

    if ( !stream->is_terminal) {
        goto END;
    }

#if 1
    /* invoke the pager */
    stream->fp = popen(stream->pager, "w");
    if (NULL == stream->fp) {
        rv = SKSTREAM_ERR_NOPAGER;
        goto END;
    }

    /* see if pager started.  There is a race condition here, and this
     * assumes we have only one child, which should be true. */
    pid = wait4(0, &wait_status, WNOHANG, NULL);
    if (pid) {
        rv = SKSTREAM_ERR_NOPAGER;
        goto END;
    }
#else
    {
    int pipe_des[2];

    /* create pipe and fork */
    if (pipe(pipe_des) == -1) {
        stream->errnum = errno;
        rv = SKSTREAM_ERR_SYS_PIPE;
        goto END;
    }
    pid = fork();
    if (pid < 0) {
        stream->errnum = errno;
        rv = SKSTREAM_ERR_SYS_FORK;
        goto END;
    }

    if (pid == 0) {
        /* CHILD */

        /* close output side of pipe; set input to stdin */
        close(pipe_des[1]);
        if (pipe_des[0] != STDIN_FILENO) {
            dup2(pipe_des[0], STDIN_FILENO);
            close(pipe_des[0]);
        }

        /* invoke pager */
        execlp(pager, NULL);
        skAppPrintErr("Unable to invoke pager '%s': %s",
                      pager, strerror(errno));
        _exit(EXIT_FAILURE);
    }

    /* PARENT */

    /* close input side of pipe */
    close(pipe_des[0]);

    /* try to open the write side of the pipe */
    out = fdopen(pipe_des[1], "w");
    if (NULL == out) {
        stream->errnum = errno;
        rv = SKSTREAM_ERR_SYS_FDOPEN;
        goto END;
    }

    /* it'd be nice to have a slight pause here to give child time to
     * die if command cannot be exec'ed, but it's not worth the
     * trouble to use select(), and sleep(1) is too long. */

    /* see if child died unexpectedly */
    if (waitpid(pid, &wait_status, WNOHANG)) {
        rv = SKSTREAM_ERR_NOPAGER;
        goto END;
    }
    }
#endif /* 1: whether to use popen() */

    /* looks good. */
    stream->is_pager_active = 1;

  END:
    return rv;
}




/*
 *  status = streamOpenAppend(stream);
 *
 *    Open the stream for appending.
 */
static int streamOpenAppend(
    skstream_t         *stream)
{
    int rv = SKSTREAM_OK;
    int flags = O_RDWR | O_APPEND;

    assert(stream);
    assert(stream->pathname);

    /* Open file for read and write; position at start. */
    stream->fd = open(stream->pathname, flags, 0);
    if (stream->fd == -1) {
        stream->errnum = errno;
        rv = SKSTREAM_ERR_SYS_OPEN;
        goto END;
    }
    if (-1 == lseek(stream->fd, 0, SEEK_SET)) {
        stream->errnum = errno;
        rv = SKSTREAM_ERR_SYS_LSEEK;
        goto END;
    }

  END:
    return rv;
}


static int streamOpenGzip(
    skstream_t         *stream)
{
    int is_compressed = 1;
    int num_read;
    uint8_t magic[3];
    int rv = SKSTREAM_OK;

    if (stream->io_mode == SK_IO_READ && stream->is_seekable) {
        /* Read the first two characters to look for the GZIP magic
         * number (31 139 (see RFC1952)) to see if the stream really
         * is compressed. */
        num_read = read(stream->fd, magic, 2);
        if ((num_read != 2) || (magic[0] != 31u) || (magic[1] != 139u)) {
            /* File does not contain the gzip magic number. */
            is_compressed = 0;
        }
        if (0 != lseek(stream->fd, 0, SEEK_SET)) {
            rv = SKSTREAM_ERR_SYS_LSEEK;
            goto END;
        }
    }

    if (is_compressed) {
#if SK_ENABLE_ZLIB
        stream->gz = gzdopen(stream->fd,
                             (stream->io_mode == SK_IO_READ) ? "rb" : "wb");
        if (stream->gz == NULL) {
            rv = SKSTREAM_ERR_ALLOC;
            goto END;
        }
#else
        /* compression not supported */
        rv = SKSTREAM_ERR_COMPRESS_UNAVAILABLE;
        goto END;
#endif /* SK_ENABLE_ZLIB */
    }

  END:
    return rv;
}


/*
 *  status = streamOpenRead(stream);
 *
 *    Open the stream for reading.
 */
static int streamOpenRead(
    skstream_t         *stream)
{
    int rv = SKSTREAM_OK;

    assert(stream);
    assert(stream->pathname);
    assert(stream->io_mode == SK_IO_READ);
    assert(-1 == stream->fd);

    if (stream->is_mpi) {
        /* for now, just set to a valid value.  we should replace the
         * checks of 'fd' with an 'is_open' flag */
        stream->fd = INT32_MAX;
    } else if ((0 == strcmp(stream->pathname, "stdin"))
               || (0 == strcmp(stream->pathname, "-")))
    {
        stream->fd = STDIN_FILENO;
        stream->is_stdio = 1;
    } else {
        stream->fd = open(stream->pathname, O_RDONLY);
        if (stream->fd == -1) {
            rv = SKSTREAM_ERR_SYS_OPEN;
            stream->errnum = errno;
            goto END;
        }
    }

  END:
    /* if something went wrong, close the file */
    if (rv != SKSTREAM_OK) {
        if (stream->fd != -1) {
            close(stream->fd);
            stream->fd = -1;
        }
    }
    return rv;
}


static int streamOpenWrite(
    skstream_t         *stream)
{
    int rv = SKSTREAM_OK;

    assert(stream);
    assert(stream->pathname);
    assert(stream->io_mode == SK_IO_WRITE);

    if ((0 == strcmp(stream->pathname, "stdout"))
        || (0 == strcmp(stream->pathname, "-")))
    {
        stream->fd = STDOUT_FILENO;
        stream->is_stdio = 1;
    } else if (0 == strcmp(stream->pathname, "stderr")) {
        stream->fd = STDERR_FILENO;
        stream->is_stdio = 1;
    } else if (stream->is_mpi) {
        /* for now, just set to a valid value.  we should replace the
         * checks of 'fd' with an 'is_open' flag */
        stream->fd = INT32_MAX;
    } else {
        struct stat stbuf;
        int mode, flags;

        /* standard mode of 0666 */
        mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH;

        /* assume creating previously non-existent file */
        flags = O_WRONLY | O_CREAT | O_EXCL;

        /* try to open as a brand new file */
        stream->fd = open(stream->pathname, flags, mode);
        if (stream->fd == -1) {
            stream->errnum = errno;
            if ((stream->errnum == EEXIST)
                && (0 == stat(stream->pathname, &stbuf)))
            {
                /* file exists.  If it is a FIFO or a character device
                 * ("/dev/null"), try again with different flags */
                if (S_ISFIFO(stbuf.st_mode)) {
                    flags = O_WRONLY;
                } else if (S_ISCHR(stbuf.st_mode)) {
                    flags = O_WRONLY | O_NOCTTY;
                } else {
                    rv = SKSTREAM_ERR_FILE_EXISTS;
                    goto END;
                }

                /* try again with the new flags */
                stream->fd = open(stream->pathname, flags, mode);
            }

            /* if we (still) have an error, return */
            if (stream->fd == -1) {
                /* we set errnum above */
                rv = SKSTREAM_ERR_SYS_OPEN;
                goto END;
            }
        }
    }

  END:
    return rv;
}


/*
 *  is_compressed = streamPathnameIsCompressed(pathname, io_mode);
 *
 *    Return TRUE if 'pathname' should be considered a compressed file
 *    for the given IO mode---that is, where the entire file is
 *    compressed---or FALSE otherwise.
 *
 *    Basically, returns TRUE when 'pathname' ends in ".gz" or when it
 *    is open for reading and contains the substring ".gz."---assuming
 *    the pathname has had a mkstemp() suffix added to it.  In all
 *    other cases, it returns FALSE.
 */
static int streamPathnameIsCompressed(
    const char         *pathname,
    skstream_mode_t     read_write_append)
{
    const char *gz;

    gz = strstr(pathname, ".gz");
    if (gz != NULL) {
        switch (read_write_append) {
          case SK_IO_READ:
          case SK_IO_APPEND:
            if (gz[3] == '.') {
                return 1;
            }
            /* FALLTHROUGH */

          case SK_IO_WRITE:
            if (gz[3] == '\0') {
                return 1;
            }
            break;
        }
    }
    return 0;
}


static int streamPostOpen(
    skstream_t         *stream)
{
    int rv = SKSTREAM_OK;

    assert(stream);
    assert(stream->fd != -1);

    if (!stream->is_mpi) {
        if (isatty(stream->fd)) {
            stream->is_terminal = 1;
        } else if (lseek(stream->fd, 0, SEEK_CUR) != (off_t)-1) {
            stream->is_seekable = 1;
        }

        /* handle compressed files */
        if (streamPathnameIsCompressed(stream->pathname, stream->io_mode)) {
            rv = streamOpenGzip(stream);
            if (rv) { goto END; }
        }
    }

    /* for a non-silk binary file, create the IOBuf now.  If the
     * stream was open for appending, seek to the end of the file */
    if (stream->content_type == SK_CONTENT_OTHERBINARY) {
        if (stream->io_mode == SK_IO_APPEND) {
            if (-1 == lseek(stream->fd, 0, SEEK_END)) {
                stream->errnum = errno;
                rv = SKSTREAM_ERR_SYS_LSEEK;
                goto END;
            }
        }

        rv = streamIOBufCreate(stream);
        if (rv) { goto END; }
    }

    /* for a text file we are reading, create the IOBuf now */
    if (stream->content_type == SK_CONTENT_TEXT
        && stream->io_mode == SK_IO_READ)
    {
        rv = streamIOBufCreate(stream);
        if (rv) { goto END; }
    }

  END:
    return rv;
}


static int streamPrepareFormat(
    skstream_t         *stream)
{
    assert(stream);
    assert(stream->is_silk);
    assert(stream->silk_hdr);

    switch (skHeaderGetFileFormat(stream->silk_hdr)) {
      case FT_RWAUGMENTED:
        return augmentedioPrepare(stream);

      case FT_RWAUGROUTING:
        return augroutingioPrepare(stream);

      case FT_RWAUGWEB:
        return augwebioPrepare(stream);

      case FT_RWAUGSNMPOUT:
        return augsnmpoutioPrepare(stream);

      case FT_RWFILTER:
        return filterioPrepare(stream);

      case FT_FLOWCAP:
        return flowcapioPrepare(stream);

      case FT_RWGENERIC:
        return genericioPrepare(stream);

      case FT_RWIPV6:
        stream->supports_ipv6 = 1;
        return ipv6ioPrepare(stream);

      case FT_RWIPV6ROUTING:
        stream->supports_ipv6 = 1;
        return ipv6routingioPrepare(stream);

      case FT_RWNOTROUTED:
        return notroutedioPrepare(stream);

      case FT_RWROUTED:
        return routedioPrepare(stream);

      case FT_RWSPLIT:
        return splitioPrepare(stream);

      case FT_RWWWW:
        return wwwioPrepare(stream);

      default:
        break;
    }

    return SKSTREAM_ERR_UNSUPPORT_TYPE;
}


static int streamPrepareText(
    skstream_t         *stream)
{
    int rv;

    rv = streamCheckOpen(stream);
    if (rv) { goto END; }

    if (stream->fp == NULL) {
        const char *mode = NULL;
        switch (stream->io_mode) {
          case SK_IO_READ:
            break;

          case SK_IO_WRITE:
            if (stream->pager) {
                rv = streamInvokePager(stream);
                if (rv) { goto END; }
            }
            if (stream->fp == NULL) {
                mode = "w";
            }
            break;

          case SK_IO_APPEND:
            mode = "r+";
            break;
        }
        if (mode) {
            stream->fp = fdopen(stream->fd, mode);
            if (stream->fp == NULL) {
                stream->errnum = errno;
                rv = SKSTREAM_ERR_SYS_FDOPEN;
                goto END;
            }
        }
    }

    stream->is_dirty = 1;

  END:
    return rv;
}


static ssize_t streamReadNullBuffer(
    skstream_t         *stream,
    size_t              count)
{
    uint8_t buf[65536];
    size_t left = count;
    size_t wanted;
    ssize_t saw;

    assert(stream);
    assert(buf);
    assert(stream->io_mode == SK_IO_READ || stream->io_mode == SK_IO_APPEND);
    assert(stream->fd != -1);
    assert(stream->iobuf == NULL);

#if SK_ENABLE_ZLIB
    if (stream->gz != NULL) {
        while (left) {
            /* don't read more than will fit into our buffer */
            wanted = ((left < sizeof(buf)) ? left : sizeof(buf));

            saw = streamGZRead(stream, buf, wanted);
            if (saw == -1) {
                stream->is_iobuf_error = 0;
                return saw;
            }
            if (saw == 0) {
                /* no more to read */
                break;
            }

            left -= saw;
        }

        return (count - left);
    }
#endif  /* SK_ENABLE_ZLIB */

    while (left) {
        /* don't read more than will fit into our buffer */
        wanted = ((left < sizeof(buf)) ? left : sizeof(buf));

        saw = skreadn(stream->fd, buf, wanted);
        if (saw == -1) {
            stream->errnum = errno;
            stream->err_info = SKSTREAM_ERR_READ;
            return saw;
        }
        if (saw == 0) {
            /* no more to read */
            break;
        }
        left -= saw;
    }

    return (count - left);
}


/*
 *  status = skStreamBind(stream, path);
 *
 *    Set 'stream' to operate on the file specified in 'path'; 'path'
 *    may also be one of "stdin", "stdout", or "stderr".  Returns
 *    SKSTREAM_OK on success, or an error code on failure.
 */
int skStreamBind(
    skstream_t         *stream,
    const char         *pathname)
{
    int rv = SKSTREAM_OK;
    FILE *s = NULL;

    /* check name */
    if (NULL == stream || NULL == pathname) {
        rv = SKSTREAM_ERR_NULL_ARGUMENT;
        goto END;
    }
    if ('\0' == *pathname || strlen(pathname) >= PATH_MAX) {
        rv = SKSTREAM_ERR_INVALID_INPUT;
        goto END;
    }

    if (stream->pathname) {
        rv = SKSTREAM_ERR_PREV_BOUND;
        goto END;
    }

    /* copy it into place */
    stream->pathname = strdup(pathname);
    if (stream->pathname == NULL) {
        rv = SKSTREAM_ERR_ALLOC;
        goto END;
    }

    if (0 == strcmp(pathname, "stdin")) {
        switch (stream->io_mode) {
          case SK_IO_READ:
            if (!stream->is_mpi && stream->is_binary && FILEIsATty(stdin)) {
                rv = SKSTREAM_ERR_ISTERMINAL;
                goto END;
            }
            break;
          case SK_IO_WRITE:
          case SK_IO_APPEND:
            /* cannot write or append to stdin */
            rv = SKSTREAM_ERR_UNSUPPORT_IOMODE;
            goto END;
        }
    } else if (0 == strcmp(pathname, "stdout")) {
        s = stdout;
    } else if (0 == strcmp(pathname, "stderr")) {
        s = stderr;
    } else if (0 == strcmp(pathname, "-")) {
        switch (stream->io_mode) {
          case SK_IO_READ:
            if (!stream->is_mpi && stream->is_binary && FILEIsATty(stdin)) {
                rv = SKSTREAM_ERR_ISTERMINAL;
                goto END;
            }
            break;
          case SK_IO_WRITE:
            s = stdout;
            break;
          case SK_IO_APPEND:
            /* cannot append to stdout */
            rv = SKSTREAM_ERR_UNSUPPORT_IOMODE;
            goto END;
        }
    }

    if (s) {
        switch (stream->io_mode) {
          case SK_IO_READ:
          case SK_IO_APPEND:
            /* cannot read or append to stdout/stderr */
            rv = SKSTREAM_ERR_UNSUPPORT_IOMODE;
            goto END;
          case SK_IO_WRITE:
            if (!stream->is_mpi && stream->is_binary && FILEIsATty(s)) {
                rv = SKSTREAM_ERR_ISTERMINAL;
                goto END;
            }
            break;
        }
    }

    /* cannot append to FIFOs or to gzipped files */
    if (stream->io_mode == SK_IO_APPEND) {
        if (streamPathnameIsCompressed(stream->pathname, stream->io_mode)) {
            rv = SKSTREAM_ERR_UNSUPPORT_IOMODE;
            goto END;
        }
        if (isFIFO(pathname)) {
            /* Cannot append to a FIFO */
            rv = SKSTREAM_ERR_UNSUPPORT_IOMODE;
            goto END;
        }
    }

  END:
    return rv;
}


int skStreamCheckCompmethod(
    skstream_t         *stream,
    sk_msg_fn_t         errfn)
{
#ifdef TEST_PRINTF_FORMATS
#  define P_ERR printf
#else
#  define P_ERR if (!errfn) { } else errfn
#endif
    sk_compmethod_t compmethod;
    int is_valid = 0;

    compmethod = skHeaderGetCompressionMethod(stream->silk_hdr);

    if (sksiteCompmethodIsAvailable(compmethod)) {
        return SKSTREAM_OK;
    }

    if (errfn) {
        if (sksiteCompmethodIsValid(compmethod)) {
            char name[64];
            is_valid = 1;
            sksiteCompmethodGetName(name, sizeof(name), compmethod);
            P_ERR("The %s compression method used by '%s' is not available",
                  name, stream->pathname);
        } else {
            P_ERR("File '%s' is compressed with an unrecognized method %d",
                  stream->pathname, compmethod);
        }
    }
    return (is_valid
            ? SKSTREAM_ERR_COMPRESS_UNAVAILABLE
            : SKSTREAM_ERR_COMPRESS_INVALID);
#undef P_ERR
}


int skStreamCheckSilkHeader(
    skstream_t             *stream,
    fileFormat_t            file_format,
    fileVersion_t           min_version,
    fileVersion_t           max_version,
    sk_msg_fn_t             errfn)
{
#ifdef TEST_PRINTF_FORMATS
#  define P_ERR printf
#else
#  define P_ERR if (!errfn) { } else errfn
#endif
    sk_file_header_t *hdr = stream->silk_hdr;
    fileFormat_t fmt = skHeaderGetFileFormat(hdr);
    fileVersion_t vers = skHeaderGetRecordVersion(hdr);
    char fmt_name[SK_MAX_STRLEN_FILE_FORMAT+1];

    /* get the name of the requested format */
    sksiteFileformatGetName(fmt_name, sizeof(fmt_name), file_format);

    if (fmt != file_format) {
        P_ERR("File '%s' is not a %s file; format is 0x%02x",
              stream->pathname, fmt_name, fmt);
        return -1;
    }

    if ((vers < min_version) || (vers > max_version)) {
        P_ERR("This version of SiLK cannot process the %s v%u file %s",
              fmt_name, vers, stream->pathname);
        return -1;
    }

    return skStreamCheckCompmethod(stream, errfn);
#undef errfn
}


int skStreamClose(
    skstream_t         *stream)
{
    int rv;

    rv = streamCheckOpen(stream);
    if (rv) { goto END; }

    if (stream->fp) {
        if (stream->is_pager_active) {
            if (pclose(stream->fp) == -1) {
                stream->errnum = errno;
                if (rv == SKSTREAM_OK) {
                    rv = SKSTREAM_ERR_WRITE;
                }
            }
        } else {
            if (EOF == fclose(stream->fp)) {
                stream->errnum = errno;
                if (rv == SKSTREAM_OK) {
                    rv = SKSTREAM_ERR_WRITE;
                }
            }
        }
    } else if (stream->fd != -1) {
        if (stream->iobuf && stream->io_mode != SK_IO_READ) {
            if (skIOBufFlush(stream->iobuf) == -1) {
                if (stream->is_iobuf_error) {
                    stream->is_iobuf_error = 0;
                    rv = stream->err_info;
                } else {
                    rv = SKSTREAM_ERR_IOBUF;
                }
            }
        }
#if SK_ENABLE_ZLIB
        if (stream->gz) {
            /* Close the gzFile */
            int zerr = gzclose(stream->gz);
            stream->gz = NULL;
            if (zerr != Z_OK) {
                if (zerr == Z_ERRNO) {
                    stream->errnum = errno;
                    rv = SKSTREAM_ERR_WRITE;
                } else {
                    stream->errnum = zerr;
                    rv = SKSTREAM_ERR_ZLIB;
                }
            }
            /* gzclose() closes the file */
            stream->fd = -1;
        } else
#endif /* SK_ENABLE_ZLIB */
        {
            if (stream->is_stdio == 0) {
                if (close(stream->fd) == -1) {
                    stream->errnum = errno;
                    rv = SKSTREAM_ERR_WRITE;
                }
            }
        }
    }

    stream->fd = -1;
    stream->fp = NULL;
    stream->is_closed = 1;

  END:
    return rv;
}


/*
 *  status = skStreamCreate(&out_stream, io_mode, content_type);
 *
 *    Create a stream (skstream_t*) and fill 'out_stream' with the
 *    address of the newly allocated stream.  In addition, bind the
 *    stream to the given 'path', with IO in the specified 'io_mode'.
 *    Return SKSTREAM_OK on success, or an error code on failure.
 */
int skStreamCreate(
    skstream_t        **new_stream,
    skstream_mode_t     read_write_append,
    skcontent_t         content_type)
{
    if (new_stream == NULL) {
        return SKSTREAM_ERR_NULL_ARGUMENT;
    }

    *new_stream = calloc(1, sizeof(skstream_t));
    if (NULL == *new_stream) {
        return SKSTREAM_ERR_ALLOC;
    }

    if (skHeaderCreate(&((*new_stream)->silk_hdr))) {
        free(*new_stream);
        *new_stream = NULL;
        return SKSTREAM_ERR_ALLOC;
    }

    (*new_stream)->io_mode = read_write_append;
    (*new_stream)->content_type = content_type;
    (*new_stream)->fd = -1;

    /* Native format by default, so don't swap */
    (*new_stream)->swapFlag = 0;

    /* Set sensor and flowtype to invalid values */
    (*new_stream)->hdr_sensor = SK_INVALID_SENSOR;
    (*new_stream)->hdr_flowtype = SK_INVALID_FLOWTYPE;

    switch (content_type) {
      case SK_CONTENT_TEXT:
        break;

      case SK_CONTENT_SILK_FLOW:
        (*new_stream)->is_silk_flow = 1;
        /* FALLTHROUGH */

      case SK_CONTENT_SILK:
        (*new_stream)->is_silk = 1;
        /* FALLTHROUGH */

      case SK_CONTENT_OTHERBINARY:
        (*new_stream)->is_binary = 1;
        break;
    }

    return SKSTREAM_OK;
}


int skStreamDestroy(
    skstream_t        **stream)
{
    int rv;

    if ((NULL == stream) || (NULL == *stream)) {
        return SKSTREAM_OK;
    }

    rv = skStreamUnbind(*stream);

    /* Destroy the iobuf */
    if ((*stream)->iobuf) {
        skIOBufDestroy((*stream)->iobuf);
        (*stream)->iobuf = NULL;
    }

    /* Destroy the header */
    skHeaderDestroy(&((*stream)->silk_hdr));

    /* Free the pathname */
    if ((*stream)->pathname) {
        free((*stream)->pathname);
        (*stream)->pathname = NULL;
    }

    free(*stream);
    *stream = NULL;

    return rv;
}


int skStreamFDOpen(
    skstream_t         *stream,
    int                 file_desc)
{
    int rv;

    rv = streamCheckUnopened(stream);
    if (rv) { goto END; }

    if (stream->pathname == NULL) {
        rv = SKSTREAM_ERR_NOT_BOUND;
        goto END;
    }

    if (file_desc == -1) {
        rv = SKSTREAM_ERR_INVALID_INPUT;
        goto END;
    }
    stream->fd = file_desc;

    rv = streamPostOpen(stream);
    if (rv) { goto END; }

  END:
    return rv;
}


int skStreamFlush(
    skstream_t         *stream)
{
    int rv;

    rv = streamCheckOpen(stream);
    if (rv) { goto END; }

    if (stream->io_mode == SK_IO_READ) {
        /* nothing to do for a reader */
        goto END;
    }

    if (stream->fp) {
        if (EOF == fflush(stream->fp)) {
            stream->errnum = errno;
            rv = SKSTREAM_ERR_WRITE;
        }
    } else if (stream->iobuf) {
        if (skIOBufFlush(stream->iobuf) == -1) {
            if (stream->is_iobuf_error) {
                stream->is_iobuf_error = 0;
                rv = stream->err_info;
            } else {
                rv = SKSTREAM_ERR_IOBUF;
            }
            goto END;
        }
#if SK_ENABLE_ZLIB
    } else if (stream->gz) {
        if (streamGZFlush(stream) == -1) {
            stream->is_iobuf_error = 0;
            rv = stream->err_info;
        }
#endif  /* SK_ENABLE_ZLIB */
    }

  END:
    return rv;
}


/* return the cached errno value */
int skStreamGetLastErrno(
    const skstream_t   *stream)
{
    assert(stream);
    return stream->errnum;
}


/* Get the next line from a text file */
int skStreamGetLine(
    skstream_t         *stream,
    char               *out_buffer,
    size_t              buf_size,
    int                *lines_read)
{
    size_t len;
    int rv = SKSTREAM_OK;

    assert(stream);

    if ( !stream->is_dirty) {
        rv = streamCheckOpen(stream);
        if (rv) { goto END; }

        rv = streamCheckAttributes(stream, SK_IO_READ, SK_CONTENT_TEXT);
        if (rv) { goto END; }

        rv = streamPrepareText(stream);
        if (rv) { goto END; }
    }

    assert(out_buffer && buf_size);
    out_buffer[0] = '\0';

    /* read from the stream until we get a good line */
    while (1) {
        rv = streamIOBufGetLine(stream, out_buffer, buf_size);
        if (rv != SKSTREAM_OK) {
            if ((rv == SKSTREAM_ERR_LONG_LINE) && lines_read) {
                ++*lines_read;
            }
            break;
        }
        if (lines_read) {
            ++*lines_read;
        }

        /* Terminate line at first comment char */
        if (stream->comment_start) {
            char *cp = strstr(out_buffer, stream->comment_start);
            if (cp) {
                *cp = '\0';
            }
        }

        /* find first non-space character in the line */
        len = strspn(out_buffer, " \t\v\f\r\n");
        if (out_buffer[len] == '\0') {
            /* line contained whitespace only; ignore */
            continue;
        }

        /* got a line, break out of loop */
        break;
    }

  END:
    return rv;
}


const char *skStreamGetPager(
    const skstream_t   *stream)
{
    if (stream->is_closed) {
        return NULL;
    } else if (stream->is_pager_active) {
        /* stream is open and pager is in use */
        return stream->pager;
    } else if (stream->fd == -1) {
        /* unopened, return pager we *may* use */
        return stream->pager;
    } else {
        /* stream is open and not using pager */
        return NULL;
    }
}


const char *skStreamGetPathname(
    const skstream_t   *stream)
{
    assert(stream);
    return stream->pathname;
}


uint64_t skStreamGetRecordCount(
    const skstream_t   *stream)
{
    assert(stream);
    if (!stream->is_silk_flow) {
        return ((uint64_t)(-1));
    }
    return stream->rec_count;
}


sk_file_header_t *skStreamGetSilkHeader(
    const skstream_t   *stream)
{
    if (!stream->is_silk) {
        return NULL;
    }
    return stream->silk_hdr;
}


int skStreamGetSupportsIPv6(
    const skstream_t   *stream)
{
    return stream->supports_ipv6;
}


off_t skStreamGetUpperBound(
    skstream_t         *stream)
{
    assert(stream);
    assert(stream->fd != -1);

    if (stream->io_mode == SK_IO_READ) {
        return 0;
    }
    if (stream->iobuf) {
        return stream->pre_iobuf_pos + skIOBufTotalUpperBound(stream->iobuf);
    }
    return lseek(stream->fd, 0, SEEK_CUR);
}


int skStreamLockFile(
    skstream_t         *stream)
{
    struct flock lock;
    int rv;

    lock.l_start = 0;             /* at SOF */
    lock.l_whence = SEEK_SET;     /* SOF */
    lock.l_len = 0;               /* EOF */

    rv = streamCheckOpen(stream);
    if (rv) { goto END; }

    /* Don't try to lock anything that is not a real file */
    if ( !stream->is_seekable) {
        goto END;
    }

    /* set the lock type and error code if we fail */
    if (stream->io_mode == SK_IO_READ) {
        lock.l_type = F_RDLCK;
        rv = SKSTREAM_ERR_RLOCK;
    } else {
        lock.l_type = F_WRLCK;
        rv = SKSTREAM_ERR_WLOCK;
    }

    /* get the lock, waiting if we need to */
    if (fcntl(stream->fd, F_SETLKW, &lock) == -1) {
        /* error */
        stream->errnum = errno;
        goto END;
    }

    /* success */
    rv = SKSTREAM_OK;

  END:
    return rv;
}


int skStreamMakeDirectory(
    skstream_t          *stream)
{
    char dir[PATH_MAX];
    int rv;

    rv = streamCheckUnopened(stream);
    if (rv) {
        goto END;
    }

    /* Making directory to file only makes sense for writing */
    if (stream->io_mode != SK_IO_WRITE) {
        rv = SKSTREAM_ERR_UNSUPPORT_IOMODE;
        goto END;
    }

    if (stream->pathname == NULL) {
        rv = SKSTREAM_ERR_NOT_BOUND;
        goto END;
    }

    if (skDirname_r(dir, stream->pathname, sizeof(dir))) {
        if ( !skDirExists(dir)) {
            rv = skMakeDir(dir);
            if (rv) {
                stream->errnum = errno;
                rv = SKSTREAM_ERR_SYS_MKDIR;
                goto END;
            }
        }
    }

  END:
    return rv;
}


int skStreamMakeTemp(
    skstream_t         *stream)
{
    int rv;

    rv = streamCheckUnopened(stream);
    if (rv) { goto END; }

    /* Temp files only make sense for writing */
    if (stream->io_mode != SK_IO_WRITE) {
        rv = SKSTREAM_ERR_UNSUPPORT_IOMODE;
        goto END;
    }

    if (stream->pathname == NULL) {
        rv = SKSTREAM_ERR_NOT_BOUND;
        goto END;
    }

    /* open file */
    stream->fd = mkstemp(stream->pathname);
    if (stream->fd == -1) {
        rv = SKSTREAM_ERR_SYS_MKSTEMP;
        stream->errnum = errno;
        goto END;
    }

    rv = streamPostOpen(stream);
    if (rv) { goto END; }

  END:
    return rv;
}


int skStreamOpen(
    skstream_t         *stream)
{
    int rv;

    rv = streamCheckUnopened(stream);
    if (rv) { goto END; }

    if (stream->pathname == NULL) {
        rv = SKSTREAM_ERR_NOT_BOUND;
        goto END;
    }

    switch (stream->io_mode) {
      case SK_IO_WRITE:
        rv = streamOpenWrite(stream);
        if (rv) { goto END; }
        break;

      case SK_IO_READ:
        rv = streamOpenRead(stream);
        if (rv) { goto END; }
        break;

      case SK_IO_APPEND:
        rv = streamOpenAppend(stream);
        if (rv) { goto END; }
        break;
    }

    rv = streamPostOpen(stream);
    if (rv) { goto END; }

  END:
    return rv;
}


int skStreamPageOutput(
    skstream_t         *stream,
    const char         *pager)
{
    int rv;

    rv = streamCheckModifiable(stream);
    if (rv) { goto END; }

    rv = streamCheckAttributes(stream, SK_IO_WRITE, SK_CONTENT_TEXT);
    if (rv) { goto END; }

    /* get pager from environment if not passed in */
    if (NULL == pager) {
        pager = getenv("SILK_PAGER");
        if (NULL == pager) {
            pager = getenv("PAGER");
        }
    }

    /* a NULL or an empty string pager means do nothing */
    if ((NULL == pager) || ('\0' == pager[0])) {
        if (stream->pager) {
            free(stream->pager);
            stream->pager = NULL;
        }
        goto END;
    }

    if (stream->pager) {
        free(stream->pager);
    }
    stream->pager = strdup(pager);
    if (stream->pager == NULL) {
        rv = SKSTREAM_ERR_ALLOC;
        goto END;
    }

    /* if the stream is open, go ahead and invoke the pager now */
    if (stream->fd != -1) {
        rv = streamPrepareText(stream);
        if (rv) { goto END; }
    }

  END:
    return rv;
}


#if !defined(skStreamPrint)
int skStreamPrint(
    skstream_t         *stream,
    const char         *format,
                        ...)
{
    int rv = SKSTREAM_OK;
    va_list args;

    va_start(args, format);

    if ( !stream->fp) {
        rv = streamCheckOpen(stream);
        if (rv) { goto END; }

        rv = streamCheckAttributes(stream, (SK_IO_WRITE | SK_IO_APPEND),
                                   SK_CONTENT_TEXT);
        if (rv) { goto END; }

        rv = streamPrepareText(stream);
        if (rv) { goto END; }
    }

    if (vfprintf(stream->fp, format, args) == -1) {
        rv = SKSTREAM_ERR_WRITE;
        stream->errnum = errno;
    }

  END:
    va_end(args);
    return rv;
}
#endif /* !defined(skStreamPrint) */


ssize_t skStreamRead(
    skstream_t         *stream,
    void               *buf,
    size_t              count)
{
    ssize_t saw;

    assert(stream);
    assert(stream->io_mode == SK_IO_READ || stream->io_mode == SK_IO_APPEND);
    assert(stream->fd != -1);

    if (stream->iobuf) {
        saw = skIOBufRead(stream->iobuf, buf, count);
        if (saw >= 0) {
            return saw;
        }
        if (stream->is_iobuf_error) {
            stream->is_iobuf_error = 0;
        } else {
            stream->err_info = SKSTREAM_ERR_IOBUF;
        }
        return saw;
    }
    if (buf == NULL) {
        return streamReadNullBuffer(stream, count);
    }
#if SK_ENABLE_ZLIB
    if (stream->gz != NULL) {
        saw = streamGZRead(stream, buf, count);
        if (saw == -1) {
            stream->is_iobuf_error = 0;
        }
        return saw;
    }
#endif

    saw = skreadn(stream->fd, buf, count);
    if (saw == -1) {
        stream->errnum = errno;
        stream->err_info = SKSTREAM_ERR_READ;
    }
    return saw;
}


int skStreamReadRecord(
    skstream_t         *stream,
    rwGenericRec_V5    *rwrec)
{
    uint8_t ar[SK_MAX_RECORD_SIZE];
    ssize_t count;
    int rv = SKSTREAM_OK;

    if (stream->is_eof) {
        rv = SKSTREAM_ERR_EOF;
        goto END;
    }

#if SK_ENABLE_IPV6
  NEXT_RECORD:
#endif

    /* read the packed record as a byte array */
    assert(stream);
    assert(stream->io_mode == SK_IO_READ || stream->io_mode == SK_IO_APPEND);
    assert(stream->content_type != SK_CONTENT_TEXT);
    assert(stream->is_binary);
    assert(stream->fd != -1);

    if (stream->iobuf) {
        /* avoid function call for the common case */
        count = skIOBufRead(stream->iobuf, ar, stream->recLen);
    } else {
        count = skStreamRead(stream, ar, stream->recLen);
    }
    if (count != (ssize_t)stream->recLen) {
        /* EOF or error */
        stream->is_eof = 1;

        if (count == 0) {
            /* 0 means clean record boundary; simple EOF */
            rv = SKSTREAM_ERR_EOF;
        } else if (count == -1) {
            /* error */
            rv = -1;
        } else {
            /* short read */
            rv = SKSTREAM_ERR_READ_SHORT;
        }
        goto END;
    }

    /* clear the caller's record */
    RWREC_CLEAR(rwrec);

    /* convert the byte array to an rwRec in native byte order */
    stream->rwUnpackFn(stream, rwrec, ar);

    /* Write to the copy-input stream */
    if (stream->copyInputFD) {
        rwWrite(stream->copyInputFD, rwrec);
    }

    /* got a record */
    ++stream->rec_count;

#if SK_ENABLE_IPV6
    switch (stream->v6policy) {
      case SK_IPV6POLICY_MIX:
        break;

      case SK_IPV6POLICY_IGNORE:
        if (rwRecIsIPv6(rwrec)) {
            goto NEXT_RECORD;
        }
        break;

      case SK_IPV6POLICY_ASV4:
        if (rwRecIsIPv6(rwrec)) {
            if (rwRecConvertToIPv4(rwrec)) {
                goto NEXT_RECORD;
            }
        }
        break;

      case SK_IPV6POLICY_FORCE:
        if (!rwRecIsIPv6(rwrec)) {
            rwRecConvertToIPv6(rwrec);
        }
        break;

      case SK_IPV6POLICY_ONLY:
        if (!rwRecIsIPv6(rwrec)) {
            goto NEXT_RECORD;
        }
        break;
    }
#endif /* SK_ENABLE_IPV6 */

  END:
    return rv;
}


int skStreamReadSilkHeader(
    skstream_t         *stream,
    sk_file_header_t  **hdr)
{
    int rv = SKSTREAM_OK;

    if (!stream->is_dirty) {
        rv = skStreamReadSilkHeaderStart(stream);
        if (rv) { return rv; }
    }

    if (hdr) {
        *hdr = stream->silk_hdr;
    }

    /* only read the header one time */
    if (stream->have_hdr) {
        goto END;
    }

    rv = skHeaderReadEntries(stream, stream->silk_hdr);
    if (rv) { goto END; }

    skHeaderSetLock(stream->silk_hdr, SKHDR_LOCK_FIXED);

    if (stream->is_silk_flow) {
        /* swap bytes? */
        stream->swapFlag = !skHeaderIsNativeByteOrder(stream->silk_hdr);

        /* Cache values from the packedfile header */
        streamCacheHeader(stream);

        /* Set pointers to the PackFn and UnpackFn functions for this
         * file format. */
        rv = streamPrepareFormat(stream);
        if (rv) { goto END; }
    }

    /* Move to end of file is stream was open for append */
    if (stream->io_mode == SK_IO_APPEND) {
        if (-1 == lseek(stream->fd, 0, SEEK_END)) {
            stream->errnum = errno;
            rv = SKSTREAM_ERR_SYS_LSEEK;
            goto END;
        }
    }

    /* we have the complete header */
    stream->have_hdr = 1;

    rv = streamIOBufCreate(stream);
    if (rv) { goto END; }

  END:
    return rv;
}


int skStreamReadSilkHeaderStart(
    skstream_t         *stream)
{
    int rv;

    rv = streamCheckOpen(stream);
    if (rv) { return rv; }

    if (stream->is_dirty) {
        rv = SKSTREAM_ERR_PREV_DATA;
        goto END;
    }

    rv = streamCheckAttributes(stream, (SK_IO_READ | SK_IO_APPEND),
                               (SK_CONTENT_SILK | SK_CONTENT_SILK_FLOW));
    if (rv) { goto END; }

    stream->is_dirty = 1;

    rv = skHeaderReadStart(stream, stream->silk_hdr);
    if (rv) { goto END; }

    /* check whether this stream contains flow data */
    STREAM_SET_IS_SILK_FLOW(stream);

    skHeaderSetLock(stream->silk_hdr, SKHDR_LOCK_ENTRY_OK);

  END:
    return rv;
}


int skStreamSetCommentStart(
    skstream_t         *stream,
    const char         *comment_start)
{
    int rv;

    rv = streamCheckAttributes(stream, SK_IO_READ, SK_CONTENT_TEXT);
    if (rv) { goto END; }

    /* clear existing value */
    if (stream->comment_start) {
        free(stream->comment_start);
    }

    /* set to new value */
    if (comment_start == NULL) {
        stream->comment_start = NULL;
    } else {
        stream->comment_start = strdup(comment_start);
        if (stream->comment_start == NULL) {
            rv = SKSTREAM_ERR_ALLOC;
            goto END;
        }
    }

  END:
    return rv;
}


int skStreamSetCopyInput(
    skstream_t         *read_stream,
    skstream_t         *write_stream)
{
    assert(read_stream);
    assert(read_stream->is_silk_flow);

    if (write_stream == NULL) {
        return SKSTREAM_ERR_NULL_ARGUMENT;
    }
    if (read_stream->copyInputFD) {
        return SKSTREAM_ERR_PREV_COPYINPUT;
    }
    if (read_stream->rec_count) {
        return SKSTREAM_ERR_PREV_DATA;
    }

    read_stream->copyInputFD = write_stream;
    return SKSTREAM_OK;
}


int skStreamSetIPv6Policy(
    skstream_t         *stream,
    sk_ipv6policy_t     policy)
{
    int rv;

    assert(stream);

    rv = streamCheckAttributes(stream, 0xFF,
                               (SK_CONTENT_SILK | SK_CONTENT_SILK_FLOW));
    if (rv) { goto END; }

    stream->v6policy = policy;

  END:
    return rv;
}




int skStreamSetUnbuffered(
    skstream_t         *stream)
{
    int rv;

    rv = streamCheckUnopened(stream);
    if (rv) { goto END; }

    stream->is_unbuffered = 1;

  END:
    return rv;
}


static int streamSkipRecordsNonIOBuf(
    skstream_t         *stream,
    size_t              skip_count,
    size_t             *records_skipped)
{
#define SKIP_RECORD_COUNT  1024
    uint8_t ar[SKIP_RECORD_COUNT * SK_MAX_RECORD_SIZE];
    ssize_t saw;
    ssize_t tmp;

    if (stream->is_eof) {
        return SKSTREAM_ERR_EOF;
    }

    while (skip_count > 0) {
        /* can only read the number of records our buffer allows */
        if (skip_count > SKIP_RECORD_COUNT) {
            tmp = stream->recLen * SKIP_RECORD_COUNT;
        } else {
            tmp = stream->recLen * skip_count;
        }

        /* read the bytes and check for error or short reads */
        saw = skStreamRead(stream, ar, tmp);
        if (saw != tmp) {
            /* Either error or an incomplete read--assume end of file */
            stream->is_eof = 1;
            if (saw == -1) {
                /* error */
                return -1;
            }
        }

        /* compute the number of records we actually read, update
         * counters, and check for any partially read records. */
        tmp = (saw / stream->recLen);
        stream->rec_count += tmp;
        skip_count -= tmp;
        saw -= tmp * stream->recLen;
        if (records_skipped) {
            *records_skipped += tmp;
        }

        if (saw != 0) {
            return SKSTREAM_ERR_READ_SHORT;
        }
        if (stream->is_eof) {
            return SKSTREAM_ERR_EOF;
        }
    }

    return SKSTREAM_OK;
}


int skStreamSkipRecords(
    skstream_t         *stream,
    size_t              skip_count,
    size_t             *records_skipped)
{
    ssize_t saw;
    ssize_t tmp;

    if (stream->is_eof) {
        return SKSTREAM_ERR_EOF;
    }

    if (records_skipped) {
        *records_skipped = 0;
    }

    if (!stream->iobuf) {
        return streamSkipRecordsNonIOBuf(stream, skip_count, records_skipped);
    }

    while (skip_count > 0) {
        tmp = stream->recLen * skip_count;

        /* read the bytes and check for error or short reads */
        saw = skIOBufRead(stream->iobuf, NULL, tmp);
        if (saw != tmp) {
            /* Either error or an incomplete read--assume end of file */
            stream->is_eof = 1;
            if (saw == -1) {
                /* error */
                return -1;
            }
        }

        /* compute the number of records we actually read, update
         * counters, and check for any partially read records. */
        tmp = (saw / stream->recLen);
        stream->rec_count += tmp;
        skip_count -= tmp;
        saw -= tmp * stream->recLen;
        if (records_skipped) {
            *records_skipped += tmp;
        }

        if (saw != 0) {
            return SKSTREAM_ERR_READ_SHORT;
        }
        if (stream->is_eof) {
            return SKSTREAM_ERR_EOF;
        }
    }

    return SKSTREAM_OK;
}


off_t skStreamTell(
    skstream_t         *stream)
{
    off_t pos;
    int rv;

    rv = streamCheckOpen(stream);
    if (rv) {
        stream->err_info = rv;
        return -1;
    }

    pos = lseek(stream->fd, 0, SEEK_CUR);
    if (pos == (off_t)-1) {
        stream->errnum = errno;
        stream->err_info = SKSTREAM_ERR_SYS_LSEEK;
    }

    return pos;
}


int skStreamUnbind(
    skstream_t         *stream)
{
    int rv = SKSTREAM_OK;

    if (!stream) {
        return rv;
    }
    if (stream->fd != -1) {
        rv = skStreamClose(stream);
    }

    if (stream->comment_start) {
        free(stream->comment_start);
        stream->comment_start = NULL;
    }
    if (stream->pager) {
        free(stream->pager);
        stream->pager = NULL;
    }
    if (stream->pathname) {
        free(stream->pathname);
        stream->pathname = NULL;
    }

    return rv;
}


ssize_t skStreamWrite(
    skstream_t         *stream,
    const void         *buf,
    size_t              count)
{
    ssize_t written;

    assert(stream);
    assert(stream->io_mode == SK_IO_WRITE || stream->io_mode == SK_IO_APPEND);
    assert(stream->is_binary);
    assert(stream->fd != -1);
    assert(buf);

    if (stream->iobuf) {
        written = skIOBufWrite(stream->iobuf, buf, count);
        if (written >= 0) {
            return written;
        }
        if (stream->is_iobuf_error) {
            stream->is_iobuf_error = 0;
        } else {
            stream->err_info = SKSTREAM_ERR_IOBUF;
        }
        return written;
    }
#if SK_ENABLE_ZLIB
    if (stream->gz != NULL) {
        written = streamGZWrite(stream, buf, count);
        if (written == -1) {
            stream->is_iobuf_error = 0;
        }
        return written;
    }
#endif  /* SK_ENABLE_ZLIB */

    written = skwriten(stream->fd, buf, count);
    if (written == -1) {
        stream->errnum = errno;
        stream->err_info = SKSTREAM_ERR_WRITE;
    }
    return written;
}


int skStreamWriteRecord(
    skstream_t             *stream,
    const rwGenericRec_V5  *rwrec)
{
    uint8_t ar[SK_MAX_RECORD_SIZE];
    int rv;
    const rwRec *rp = rwrec;
#if SK_ENABLE_IPV6
    rwRec rec_copy;
#endif

    assert(stream);
    assert(stream->io_mode == SK_IO_WRITE || stream->io_mode == SK_IO_APPEND);
    assert(stream->is_silk_flow);
    assert(stream->fd != -1);

    if (!stream->is_dirty) {
        rv = skStreamWriteSilkHeader(stream);
        if (rv) {
            return rv;
        }
    }

#if SK_ENABLE_IPV6
    if (rwRecIsIPv6(rp)) {
        switch (stream->v6policy) {
          case SK_IPV6POLICY_MIX:
          case SK_IPV6POLICY_FORCE:
          case SK_IPV6POLICY_ONLY:
            /* flow already IPv6; verify that file format supports it */
            if (stream->supports_ipv6 == 0) {
                return SKSTREAM_ERR_UNSUPPORT_IPV6;
            }
            break;

          case SK_IPV6POLICY_IGNORE:
            /* we're ignoring IPv6, return */
            return SKSTREAM_OK;

          case SK_IPV6POLICY_ASV4:
            /* attempt to convert IPv6 flow to v4 */
            memcpy(&rec_copy, rp, sizeof(rwRec));
            if (rwRecConvertToIPv4(&rec_copy)) {
                return SKSTREAM_OK;
            }
            rp = &rec_copy;
            break;
        }
    } else {
        /* flow is IPv4 */
        switch (stream->v6policy) {
          case SK_IPV6POLICY_MIX:
          case SK_IPV6POLICY_IGNORE:
          case SK_IPV6POLICY_ASV4:
            /* flow is already IPv4; all file formats supported */
            break;

          case SK_IPV6POLICY_ONLY:
            /* we're ignoring IPv4 flows; return */
            return SKSTREAM_OK;

          case SK_IPV6POLICY_FORCE:
            /* must convert flow to IPv6, but first verify that file
             * format supports IPv6 */
            if (stream->supports_ipv6 == 0) {
                return SKSTREAM_ERR_UNSUPPORT_IPV6;
            }
            /* convert */
            memcpy(&rec_copy, rp, sizeof(rwRec));
            rp = &rec_copy;
            rwRecConvertToIPv6(&rec_copy);
            break;
        }
    }
#endif /* SK_ENABLE_IPV6 */

    /* Convert the record into a byte array in the appropriate byte order */
    rv = stream->rwPackFn(stream, rp, ar);
    if (rv != SKSTREAM_OK) {
        stream->errobj.rec = rwrec;
        return rv;
    }

    /* write the record */
    if (stream->iobuf) {
        if (skIOBufWrite(stream->iobuf, ar, stream->recLen)
            == (ssize_t)stream->recLen)
        {
            ++stream->rec_count;
            return SKSTREAM_OK;
        } else if (stream->is_iobuf_error) {
            stream->is_iobuf_error = 0;
        } else {
            stream->err_info = SKSTREAM_ERR_IOBUF;
        }
    } else {
        if (skStreamWrite(stream, ar, stream->recLen)
            == (ssize_t)stream->recLen)
        {
            ++stream->rec_count;
            return SKSTREAM_OK;
        }
    }

    return -1;
}


int skStreamWriteSilkHeader(
    skstream_t         *stream)
{
    int rv;

    rv = streamCheckOpen(stream);
    if (rv) { return rv; }

    if (stream->is_dirty) {
        rv = SKSTREAM_ERR_PREV_DATA;
        goto END;
    }

    rv = streamCheckAttributes(stream, SK_IO_WRITE,
                               (SK_CONTENT_SILK | SK_CONTENT_SILK_FLOW));
    if (rv) { goto END; }

    if (skHeaderGetFileFormat(stream->silk_hdr) == UINT8_MAX) {
        rv = skHeaderSetFileFormat(stream->silk_hdr, DEFAULT_FILE_FORMAT);
        if (rv) { goto END; }
    }

    /* check whether this stream contains flow data */
    STREAM_SET_IS_SILK_FLOW(stream);

    if (stream->is_silk_flow) {
        /* handle the case where a specific record type has not yet
         * been specified. */
        if (skHeaderGetFileFormat(stream->silk_hdr) == UINT8_MAX) {
            rv = skHeaderSetFileFormat(stream->silk_hdr, DEFAULT_FILE_FORMAT);
            if (rv) { goto END; }
        }

        /* Set the file version if it is "ANY", and set pointers to
         * the PackFn and UnpackFn functions for this file format. */
        rv = streamPrepareFormat(stream);
        if (rv) { goto END; }

        /* Set the swapFlag */
        stream->swapFlag = !skHeaderIsNativeByteOrder(stream->silk_hdr);

        /* Cache values from the packedfile header */
        streamCacheHeader(stream);
    }

    stream->is_dirty = 1;
    skHeaderSetLock(stream->silk_hdr, SKHDR_LOCK_FIXED);

    if ( !stream->is_mpi) {
        rv = skHeaderWrite(stream, stream->silk_hdr);
        if (rv) { goto END; }
    }

    rv = streamIOBufCreate(stream);
    if (rv) { goto END; }

  END:
    return rv;
}


int rwioCreate(
    skstream_t        **stream,
    const char         *pathname,
    skstream_mode_t     read_write_append)
{
    int rv = SKSTREAM_OK;

    if (stream == NULL) {
        rv = SKSTREAM_ERR_NULL_ARGUMENT;
        goto END;
    }
    *stream = NULL;

    /* Allocate and initialize the stream */
    rv = skStreamCreate(stream, read_write_append, SK_CONTENT_SILK_FLOW);
    if (rv) { goto END; }

    rv = skStreamBind(*stream, pathname);
    if (rv) { goto END; }

  END:
    return rv;
}




int rwioOpen(
    skstream_t         *stream)
{
    int rv;

    rv = skStreamOpen(stream);
    if (rv) { goto END; }

    switch (stream->io_mode) {
      case SK_IO_WRITE:
        break;

      case SK_IO_READ:
      case SK_IO_APPEND:
        rv = skStreamReadSilkHeader(stream, NULL);
        if (rv) {
            skStreamClose(stream);
            goto END;
        }
        break;
    }

  END:
    return rv;
}


/*
 *  Opens a file for reading.  See rwpack.h for details.
 */
skstream_t *rwOpenFile(const char *pathname, skstream_t *copy_target)
{
    skstream_t *stream = NULL;
    int rv = SKSTREAM_OK;

    /* Allocate and initialize the stream */
    rv = skStreamCreate(&stream, SK_IO_READ, SK_CONTENT_SILK);
    if (rv) { goto END; }

    rv = skStreamBind(stream, pathname);
    if (rv) { goto END; }

    rv = skStreamOpen(stream);
    if (rv) { goto END; }

    rv = skStreamReadSilkHeader(stream, NULL);
    if (rv) { goto END; }

    if (copy_target) {
        rv = skStreamSetCopyInput(stream, copy_target);
        if (rv) { goto END; }
    }

  END:
    if (rv) {
        skStreamPrintLastErr(stream, rv, NULL);
        skStreamDestroy(&stream);
    }
    return stream;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
