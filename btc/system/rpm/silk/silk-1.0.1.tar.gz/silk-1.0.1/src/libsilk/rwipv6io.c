/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  rwipv6io.c
**
**    Routines to pack/unpack FT_RWIPV6 records.
*/

#include "silk.h"

RCSIDENT("$SiLK: rwipv6io.c 10470 2008-02-12 23:18:10Z mthomas $");

#include "skstream_priv.h"


/* Version to use when SK_RECORD_VERSION_ANY is specified */
#define DEFAULT_RECORD_VERSION 1


static const uint8_t IP4in6_prefix[12] =
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xFF, 0xFF};


/* ********************************************************************* */

/*
**  RWIPV6 VERSION 1
**
**    int64_t       sTime;       //  0- 7  Flow start time as milliseconds
**                               //        since UNIX epoch
**
**    uint32_t      elapsed;     //  8-11  Duration of flow in milliseconds
**                               //        (Allows for a 49 day flow)
**
**    uint16_t      sPort;       // 12-13  Source port
**    uint16_t      dPort;       // 14-15  Destination port
**
**    uint8_t       proto;       // 16     IP protocol
**    flowtypeID_t  flow_type;   // 17     Class & Type info
**    sensorID_t    sID;         // 18-19  Sensor ID
**
**    uint8_t       flags;       // 20     OR of all flags (Netflow flags)
**    uint8_t       init_flags;  // 21     TCP flags in first packet
**                               //        or blank for "legacy" data
**    uint8_t       rest_flags;  // 22     TCP flags on non-initial packet
**                               //        or blank for "legacy" data
**    uint8_t       tcp_state;   // 23     TCP state machine info (below)
**
**    uint16_t      application; // 24-25  Indication of type of traffic
**    uint16_t      memo;        // 26-27  Application specific field
**
**    uint32_t      pkts;        // 28-31  Count of packets
**    uint32_t      bytes;       // 32-35  Count of bytes
**
**    uint8_t[16]   sIP;         // 36-51  Source IP
**    uint8_t[16]   dIP;         // 52-67  Destination IP
**
**
**  68 bytes on disk.
*/

#define RECLEN_RWIPV6_V1 68


/*
 *    Byte swap the RWIPV6 v1 record 'ar' in place.
 */
#define _ipv6ioRecordSwap_V1(ar)                                \
    {                                                           \
        SWAP_DATA64((ar) +  0);   /* sTime */                   \
        SWAP_DATA32((ar) +  8);   /* elapsed */                 \
        SWAP_DATA16((ar) + 12);   /* sPort */                   \
        SWAP_DATA16((ar) + 14);   /* dPort */                   \
        /* Two single bytes: (16)proto, (17)flow_type */        \
        SWAP_DATA16((ar) + 18);   /* sID */                     \
        /* Four single bytes: (20)flags, (21)init_flags,        \
         *                    (22)rest_flags, (23)tcp_state */  \
        SWAP_DATA16((ar) + 24);   /* application */             \
        SWAP_DATA16((ar) + 26);   /* memo */                    \
        SWAP_DATA32((ar) + 28);   /* pkts */                    \
        SWAP_DATA32((ar) + 32);   /* bytes */                   \
        /* 32 bytes of sIP, dIP always in network byte order */ \
    }


/*
 *  Unpack the array of bytes 'ar' into a record 'rwRP'
 */
static int _ipv6ioRecordUnpack_V1(
    rwIOStruct_t     *rwIOS,
    rwGenericRec_V5  *rwRP,
    uint8_t          *ar)
{
    uint32_t ip;

    /* swap if required */
    if (rwIOS->swapFlag) {
        _ipv6ioRecordSwap_V1(ar);
    }

    rwRecMemSetStartTime(rwRP, &ar[0]);
    rwRecMemSetElapsed(rwRP, &ar[8]);
    rwRecMemSetSPort(rwRP, &ar[12]);
    rwRecMemSetDPort(rwRP, &ar[14]);
    rwRecMemSetProto(rwRP, &ar[16]);
    rwRecMemSetFlowType(rwRP, &ar[17]);
    rwRecMemSetSensor(rwRP, &ar[18]);
    rwRecMemSetFlags(rwRP, &ar[20]);
    rwRecMemSetInitFlags(rwRP, &ar[21]);
    rwRecMemSetRestFlags(rwRP, &ar[22]);
    rwRecMemSetTcpState(rwRP, &ar[23]);
    rwRecMemSetApplication(rwRP, &ar[24]);
    rwRecMemSetMemo(rwRP, &ar[26]);
    rwRecMemSetPkts(rwRP, &ar[28]);
    rwRecMemSetBytes(rwRP, &ar[32]);

    if (ar[23] & 0x80) {
        /* Record is IPv6 */
#if !SK_ENABLE_IPV6
        return SKSTREAM_ERR_UNSUPPORT_IPV6;
#else
        rwRecSetIPv6(rwRP);
        rwRecMemSetSIPv6(rwRP, &ar[36]);
        rwRecMemSetDIPv6(rwRP, &ar[52]);
#endif /* SK_ENABLE_IPV6 */
    } else {
        /* Record is IPv4 */

        /* sIP */
        memcpy(&ip, &ar[48], sizeof(ip));
        rwRecSetSIPv4(rwRP, ntohl(ip));

        /* dIP */
        memcpy(&ip, &ar[64], sizeof(ip));
        rwRecSetDIPv4(rwRP, ntohl(ip));
    }

    return RWIO_OK;
}


/*
 *  Pack the record 'rwRP' into an array of bytes 'ar'
 */
static int _ipv6ioRecordPack_V1(
    rwIOStruct_t           *rwIOS,
    const rwGenericRec_V5  *rwRP,
    uint8_t                *ar)
{
    uint32_t ip;

    rwRecMemGetStartTime(rwRP, &ar[0]);
    rwRecMemGetElapsed(rwRP, &ar[8]);
    rwRecMemGetSPort(rwRP, &ar[12]);
    rwRecMemGetDPort(rwRP, &ar[14]);
    rwRecMemGetProto(rwRP, &ar[16]);
    rwRecMemGetFlowType(rwRP, &ar[17]);
    rwRecMemGetSensor(rwRP, &ar[18]);
    rwRecMemGetFlags(rwRP, &ar[20]);
    rwRecMemGetInitFlags(rwRP, &ar[21]);
    rwRecMemGetRestFlags(rwRP, &ar[22]);
    rwRecMemGetTcpState(rwRP, &ar[23]);
    rwRecMemGetApplication(rwRP, &ar[24]);
    rwRecMemGetMemo(rwRP, &ar[26]);
    rwRecMemGetPkts(rwRP, &ar[28]);
    rwRecMemGetBytes(rwRP, &ar[32]);

    if (rwRecIsIPv6(rwRP)) {
        /* Record is IPv6 */
#if !SK_ENABLE_IPV6
        return SKSTREAM_ERR_UNSUPPORT_IPV6;
#else
        ar[23] |= 0x80;
        rwRecMemGetSIPv6(rwRP, &ar[36]);
        rwRecMemGetDIPv6(rwRP, &ar[52]);
#endif /* SK_ENABLE_IPV6 */
    } else {
        /* Record is IPv4, but encode as IPv6 */

        /* sIP */
        ip = htonl(rwRecGetSIPv4(rwRP));
        memcpy(&ar[36], IP4in6_prefix, sizeof(IP4in6_prefix));
        memcpy(&ar[48], &ip, sizeof(ip));

        /* dIP */
        ip = htonl(rwRecGetDIPv4(rwRP));
        memcpy(&ar[52], IP4in6_prefix, sizeof(IP4in6_prefix));
        memcpy(&ar[64], &ip, sizeof(ip));
    }

    /* swap if required */
    if (rwIOS->swapFlag) {
        _ipv6ioRecordSwap_V1(ar);
    }

    return RWIO_OK;
}


/* ********************************************************************* */

/*
 *  Return length of record of specified version, or 0 if no such
 *  version exists.  See skstream_priv.h for details.
 */
uint16_t ipv6ioGetRecLen(fileVersion_t vers)
{
    switch (vers) {
      case 1:
        return RECLEN_RWIPV6_V1;
      default:
        return 0;
    }
}


/*
 *  status = ipv6ioPrepare(&rwIOSPtr);
 *
 *    Sets the record version to the default if it is unspecified,
 *    checks that the record format supports the requested record
 *    version, sets the record length, and sets the pack and unpack
 *    functions for this record format and version.
 */
int ipv6ioPrepare(rwIOStruct_t *rwIOS)
{
#define FILE_FORMAT "FT_RWIPV6"
    sk_file_header_t *hdr = rwIOS->silk_hdr;
    int rv = RWIO_OK; /* return value */

    assert(skHeaderGetFileFormat(hdr) == FT_RWIPV6);

    /* Set version if none was selected by caller */
    if ((rwIOS->io_mode == SK_IO_WRITE)
        && (skHeaderGetRecordVersion(hdr) == SK_RECORD_VERSION_ANY))
    {
        skHeaderSetRecordVersion(hdr, DEFAULT_RECORD_VERSION);
    }

    /* version check; set values based on version */
    switch (skHeaderGetRecordVersion(hdr)) {
      case 1:
        rwIOS->rwUnpackFn = &_ipv6ioRecordUnpack_V1;
        rwIOS->rwPackFn   = &_ipv6ioRecordPack_V1;
        break;
      case 0:
      default:
        rv = SKSTREAM_ERR_UNSUPPORT_VERSION;
        goto END;
    }

    rwIOS->recLen = ipv6ioGetRecLen(skHeaderGetRecordVersion(hdr));

    /* verify lengths */
    if (rwIOS->recLen == 0) {
        skAppPrintErr("Record length not set for %s version %u",
                      FILE_FORMAT, skHeaderGetRecordVersion(hdr));
        abort();
    }
    if (rwIOS->recLen != skHeaderGetRecordLength(hdr)) {
        if (0 == skHeaderGetRecordLength(hdr)) {
            skHeaderSetRecordLength(hdr, rwIOS->recLen);
        } else {
            skAppPrintErr(("Record length mismatch for %s version %u\n"
                           "\tcode = %" PRIu16 " bytes;  header = %lu bytes"),
                          FILE_FORMAT, skHeaderGetRecordVersion(hdr),
                          rwIOS->recLen,
                          (unsigned long)skHeaderGetRecordLength(hdr));
            abort();
        }
    }

  END:
    return rv;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
