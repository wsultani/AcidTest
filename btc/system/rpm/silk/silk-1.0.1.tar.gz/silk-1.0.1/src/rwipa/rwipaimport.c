/*
** Copyright (C) 2007-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

#include "silk.h"

RCSIDENT("$SiLK: rwipaimport.c 10949 2008-03-18 15:43:56Z mthomas $");

#include "rwipa.h"
#include "sksite.h"


/* LOCAL DEFINES AND TYPEDEFS */

/* where to write output from --help */
#define USAGE_FH stdout


/* LOCAL VARIABLES */

/* Name of the IPA catalog to import to */
static char *catalog_name = NULL;

/* A short description of the catalog */
static char *catalog_desc = NULL;

/* Date/time string specifying beginning of validity interval */
static char *start_time_str = NULL;

/* Date/time string specifying end of validity interval */
static char *end_time_str = NULL;

/* Start and end times are converted into sktime_t */
static sktime_t start_time, end_time;

/* index of first option that is not handled by the options handler. */
static int arg_index = 0;


/* OPTIONS SETUP */

typedef enum {
    OPT_CATALOG_NAME,
    OPT_CATALOG_DESC,
    OPT_START_TIME,
    OPT_END_TIME
} appOptionsEnum;

static struct option appOptions[] = {
    {"catalog",     REQUIRED_ARG, 0, OPT_CATALOG_NAME},
    {"description", REQUIRED_ARG, 0, OPT_CATALOG_DESC},
    {"start-time",  REQUIRED_ARG, 0, OPT_START_TIME  },
    {"end-time",    REQUIRED_ARG, 0, OPT_END_TIME    },
    {            0,            0, 0,                0} /* sentinel entry */
};

static const char *appHelp[] = {
    ("Import the data into the named IPA catalog; the catalog\n"
     "\twill be created if necessary"),
    ("Describe the catalog's contents (for new catalogs)"),
    ("Specify the time when the data is first valid, in\n"
     "\tYYYY/MM/DD[:HH[:MM[:SS]]] format. Def. None.  Requires --end-time"),
    ("Specify end of validity interval. Def. None"),
    (char *) NULL
};


/* LOCAL FUNCTION PROTOTYPES */

static void appUsageLong(
    void);
static void appTeardown(
    void);
static void appSetup(
    int    argc,
    char **argv);
static int  appOptionsHandler(
    clientData cData,
    int        opt_index,
    char      *opt_arg);


/* FUNCTION DEFINITIONS */

/*
 *  appUsageLong();
 *
 *    Print complete usage information to USAGE_FH.  Pass this
 *    function to skOptionsSetUsageCallback(); skOptionsParse() will
 *    call this funciton and then exit the program when the --help
 *    option is given.
 */
static void appUsageLong(
    void)
{
#define USAGE_MSG                                                       \
    ("--catalog=CATALOG [SWITCHES] INPUT_FILE\n"                        \
     "\tImport a SiLK IPSet, Bag, or Prefix Map from the named\n"       \
     "\tINPUT_FILE to an IP Address Association (IPA) catalog.\n")

    FILE *fh = USAGE_FH;

    skAppStandardUsage(fh, USAGE_MSG, appOptions, appHelp);
}


/*
 *  appTeardown()
 *
 *    Teardown all modules, close all files, and tidy up all
 *    application state.
 *
 *    This function is idempotent.
 */
static void appTeardown(
    void)
{
    static int teardownFlag = 0;

    if (teardownFlag) {
        return;
    }
    teardownFlag = 1;

    skAppUnregister();
}


/*
 *  appSetup(argc, argv);
 *
 *    Perform all the setup for this application include setting up
 *    required modules, parsing options, etc.  This function should be
 *    passed the same arguments that were passed into main().
 *
 *    Returns to the caller if all setup succeeds.  If anything fails,
 *    this function will cause the application to exit with a FAILURE
 *    exit status.
 */
static void appSetup(
    int    argc,
    char **argv)
{
    int rv;

    /* verify same number of options and help strings */
    assert((sizeof(appHelp) / sizeof(char *)) ==
           (sizeof(appOptions) / sizeof(struct option)));

    /* register the application */
    skAppRegister(argv[0]);
    skOptionsSetUsageCallback(&appUsageLong);

    /* register the options */
    if (skOptionsRegister(appOptions, &appOptionsHandler, NULL)) {
        skAppPrintErr("Unable to register options");
        exit(EXIT_FAILURE);
    }

    /* parse options */
    arg_index = skOptionsParse(argc, argv);
    assert(arg_index <= argc);
    if (arg_index < 0) {
        /* skOptionsParse() printed the error */
        skAppUsage();           /* never returns */
    }

    /* Make sure there's a filename to process */
    if (arg_index == argc) {
        skAppPrintErr("No input file given on the command line");
        skAppUsage();
    }

    /* Make certain there is only one file name */
    if (arg_index + 1 < argc) {
        skAppPrintErr("Too many arguments or unrecognized switch '%s'",
                      argv[arg_index+1]);
        skAppUsage();           /* never returns */
    }

    /* A catalog name must be specified */
    if (catalog_name == NULL) {
        skAppPrintErr("You must specify a catalog name with the --%s option",
                      appOptions[OPT_CATALOG_NAME].name);
        skAppUsage();
    }

    /* A time period (start time and end time) is optional, but if present,
     *  both must be specified */
    if ( (start_time_str == NULL) ^ (end_time_str == NULL)  ) {
        skAppPrintErr(("Incomplete time range specified."
                       "  If the imported data is\n"
                       "\tassociated with specific dates,"
                       " you must specify both the\n"
                       "\t--%s and --%s options"),
                      appOptions[OPT_START_TIME].name,
                      appOptions[OPT_END_TIME].name);
        skAppUsage();
    } else if ( (start_time_str != NULL) && (end_time_str != NULL) ) {
        rv = skStringParseDatetime(&start_time, start_time_str, NULL);
        if (rv) {
            skAppPrintErr("Invalid %s '%s': %s",
                          appOptions[OPT_START_TIME].name, start_time_str,
                          skStringParseStrerror(rv));
            skAppUsage();
        }
        rv = skStringParseDatetime(&end_time, end_time_str, NULL);
        if (rv) {
            skAppPrintErr("Invalid %s '%s': %s",
                          appOptions[OPT_END_TIME].name, end_time_str,
                          skStringParseStrerror(rv));
            skAppUsage();
        }
    }

    if (atexit(appTeardown) < 0) {
        skAppPrintErr("Unable to register appTeardown() with atexit()");
        appTeardown();
        exit(EXIT_FAILURE);
    }

    return;                     /* OK */
}


/*
 *  status = appOptionsHandler(cData, opt_index, opt_arg);
 *
 *    This function is passed to skOptionsRegister(); it will be called
 *    by skOptionsParse() for each user-specified switch that the
 *    application has registered; it should handle the switch as
 *    required---typically by setting global variables---and return 1
 *    if the switch processing failed or 0 if it succeeded.  Returning
 *    a non-zero from from the handler causes skOptionsParse() to return
 *    a negative value.
 *
 *    The clientData in 'cData' is typically ignored; 'opt_index' is
 *    the index number that was specified as the last value for each
 *    struct option in appOptions[]; 'opt_arg' is the user's argument
 *    to the switch for options that have a REQUIRED_ARG or an
 *    OPTIONAL_ARG.
 */
static int appOptionsHandler(
    clientData UNUSED (cData),
    int                opt_index,
    char              *opt_arg)
{
    switch ((appOptionsEnum) opt_index) {
      case OPT_CATALOG_NAME:
        catalog_name = opt_arg;
        break;

      case OPT_CATALOG_DESC:
        catalog_desc = opt_arg;
        break;

      case OPT_START_TIME:
        start_time_str = opt_arg;
        break;

      case OPT_END_TIME:
        end_time_str = opt_arg;
        break;
    }

    return 0;                   /* OK */
}


static int import_set(
    IPAContext *ipa,
    skstream_t *stream)
{
    skIPTree_t                 *set    = NULL;
    skIPTreeCIDRBlockIterator_t cidr_iter;
    skIPTreeCIDRBlock_t         cidr;
    int                         rv = 0;

    /* Read ipTree from file */
    if (0 != skIPTreeRead(&set, stream)) {
        skAppPrintErr("Error reading binary IPset from %s",
                      skStreamGetPathname(stream));
        rv = -1;
        goto done;
    }

    skIPTreeCIDRBlockIteratorBind(&cidr_iter, set);

    while (skIPTreeCIDRBlockIteratorNext(&cidr, &cidr_iter)
           == SK_ITERATOR_OK)
    {
        ipa_add_cidr(ipa, cidr.addr, cidr.mask, "", 0);
    }

  done:
    skIPTreeDelete(&set);

    return rv;
}


static int import_bag(
    IPAContext *ipa,
    skstream_t *stream)
{
    skBag_t         *bag      = NULL;
    skBagIterator_t *bag_iter = NULL;
    skBagKey_t       key;
    skBagCounter_t   count;

    int rv = 0;

    /* Read Bag from file */
    if (skBagRead(&bag, stream) != SKBAG_OK) {
        skAppPrintErr("Error reading Bag from file %s",
                      skStreamGetPathname(stream));
        rv = -1;
        goto done;
    }

    if (skBagAllocIterator(bag, &bag_iter) != SKBAG_OK) {
        skAppPrintErr("Could not create Bag iterator");
        rv = -1;
        goto done;
    }

    while (SKBAG_OK == skBagGetNext(bag_iter, &key, &count)) {
        /* FIXME: do we want to CIDRize if adjacent counts are the same? */
        ipa_add_assoc(ipa, key, key, "", count);
    }

  done:
    if (bag_iter) {
        skBagFreeIterator(bag_iter);
    }
    if (bag) {
        skBagFree(bag);
    }
    return rv;
}


/*
 *  pmap = openMapFile(path);
 *
 *    Open the prefix map file at 'path' and verify that it can be
 *    processed by this program.
 */
static skPrefixMap_t *openMapFile(
    skstream_t *stream)
{
    skPrefixMap_t   *map    = NULL;
    skPrefixMapErr_t map_error;

    /* read in the prefixmap file */
    map_error = skPrefixMapRead(&map, stream);

    if (SKPREFIXMAP_OK != map_error) {
        if (SKPREFIXMAP_ERR_ARGS == map_error) {
            skAppPrintErr("Failed to read pmap file '%s': Invalid arguments",
                          skStreamGetPathname(stream));
        } else if (SKPREFIXMAP_ERR_MEMORY == map_error) {
            skAppPrintErr("Failed to read pmap file '%s': Out of memory",
                          skStreamGetPathname(stream));
        } else if (SKPREFIXMAP_ERR_IO == map_error) {
            skAppPrintErr("Failed to read pmap file '%s': I/O error",
                          skStreamGetPathname(stream));
        }
        map = NULL;
        goto ERROR;
    }

    /* verify that the prefix map is of the correct generation */
    if (skPrefixMapDictionaryGetWordCount(map) == 0) {
        skAppPrintErr("The pmap file'%s' cannot be processed by this program",
                      skStreamGetPathname(stream));
        goto ERROR;
    }

    /* complain if ranges were requested and the file does not contain
     * address data.  if only ranges were requested, destroy the map. */
    if (SKPREFIXMAP_CONT_ADDR != skPrefixMapGetContentType(map)) {
        skAppPrintErr(("The pmap file '%s'"
                       " does not contain an address prefix map"),
                      skStreamGetPathname(stream));
    }

    /* Success */
    return map;

  ERROR:
    if (map) {
        skPrefixMapDelete(map);
    }
    return NULL;
}

static int import_pmap(
    IPAContext *ipa,
    skstream_t *stream)
{
    skPrefixMap_t        *pmap = NULL;
    skPrefixMapIterator_t iter;
    char                  label[1024];
    uint32_t              start_addr;
    uint32_t              end_addr;
    uint32_t              val;

    /* open the prefix map file */
    pmap = openMapFile(stream);
    if (pmap == NULL) {
        return -1;
    }

    skPrefixMapIteratorBind(&iter, pmap);
    while (skPrefixMapIteratorNext(&iter, &start_addr, &end_addr, &val)
           != SK_ITERATOR_NO_MORE_ENTRIES)
    {
        skPrefixMapDictionaryGetEntry(pmap, val, label, sizeof(label));
        ipa_add_assoc(ipa, start_addr, end_addr, label, val);
    }

    return 0;
}


int main(int argc, char **argv)
{
    char                format_name[128];
    const char         *filename     = NULL;
    skstream_t         *stream       = NULL;
    sk_file_header_t   *hdr          = NULL;
    int                catalog_type  = IPA_CAT_NONE;
    int                 rv           = 1;
    char               *ipa_db_url   = NULL;
    IPAContext         *ipa;

    appSetup(argc, argv);       /* never returns on error */

    filename = argv[arg_index];

    if ((rv = skStreamCreate(&stream, SK_IO_READ, SK_CONTENT_SILK))
        || (rv = skStreamBind(stream, filename))
        || (rv = skStreamOpen(stream))
        || (rv = skStreamReadSilkHeader(stream, &hdr)))
    {
        skStreamPrintLastErr(stream, rv, &skAppPrintErr);
        rv = -1;
        goto done;
    }

    switch (skHeaderGetFileFormat(hdr)) {
      case FT_IPSET:
        catalog_type = IPA_CAT_SET;
        break;

      case FT_RWBAG:
        catalog_type = IPA_CAT_BAG;
        break;

      case FT_PREFIXMAP:
        catalog_type = IPA_CAT_PMAP;
        break;

      default:
        sksiteFileformatGetName(format_name, sizeof(format_name),
                                skHeaderGetFileFormat(hdr));
        skAppPrintErr("Files in the %s format are not supported",
                      format_name);
        rv = -1;
        goto done;
    }

    ipa_db_url = get_ipa_config();

    if (ipa_db_url == NULL) {
        skAppPrintErr("Could not get IPA configuration");
        rv = EXIT_FAILURE;
        goto done;
    }

    ipa_create_context(&ipa, ipa_db_url);

    if (ipa == NULL) {
        skAppPrintErr("Could not create IPA context");
        rv = EXIT_FAILURE;
        goto done;
    }

    ipa_begin(ipa);

    if (ipa_add_dataset(ipa, catalog_name, catalog_desc, catalog_type,
                        start_time_str, end_time_str) != IPA_OK)
    {
        rv = -1;
        goto done;
    }


    switch (catalog_type) {
      case IPA_CAT_SET:
        rv = import_set(ipa, stream);
        break;

      case IPA_CAT_BAG:
        rv = import_bag(ipa, stream);
        break;

      case IPA_CAT_PMAP:
        rv = import_pmap(ipa, stream);
        break;

      default:
        skAppPrintErr("Bad catalog_type value %d", catalog_type);
        abort();
    }

    if (!rv) {
        ipa_commit(ipa);
    } else {
        skAppPrintErr("Warning: rolling back IPA transaction");
        ipa_rollback(ipa);
    }

  done:
    skStreamDestroy(&stream);
    if (ipa_db_url) {
        free(ipa_db_url);
    }
    appTeardown();
    return rv;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
