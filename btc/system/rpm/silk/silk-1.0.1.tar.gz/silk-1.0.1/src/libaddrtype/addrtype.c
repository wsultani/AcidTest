/*
** Copyright (C) 2004-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
** addrtype.c
**
** John McClary Prevost
** May 25th, 2006
**
** Plugin for address type lookups using the prefixmap data structure.
*/

#include "silk.h"

RCSIDENT("$SiLK: addrtype.c 11248 2008-04-11 19:07:39Z mthomas $");

#include "utils.h"
#include "dynlib.h"
#include "rwpack.h"
#include "skstringmap.h"
#include "skprefixmap.h"
#include "addrtype_priv.h"


/* EXPORTED FUNCTIONS */

/* these are called by dynlib */
int dynlib_api_version(void);
int setup(dynlibInfoStruct *dlISP, dynlibSymbolId appType);
int configure(dynlibInfoStruct *dlISP, void *data);
void teardown(dynlibSymbolId appType);
void optionsUsage(dynlibSymbolId appType, FILE *fh);
int initialize(dynlibInfoStruct *dlISP, dynlibSymbolId appType);
int filter(rwRec *rwrec);
int cut(unsigned int field, char *out, size_t len_out, rwRec *rwrec);
int sort(unsigned int field, uint8_t *bin_value, rwRec *rwrec);
int uniq(
    unsigned int    field,
    uint8_t        *bin_value,
    char           *text_value,
    size_t          text_len,
    rwRec          *rwrec);


/* LOCAL VARIABLES */

/* which addrtypes are to be allowed/disallowed */
static addrType_addrtype_t srcAddrType = ADDRTYPE_FILT_NONE;
static addrType_addrtype_t destAddrType = ADDRTYPE_FILT_NONE;


/* the prefixmap used to look up addrtypes */
static skPrefixMap_t *prefixMap = NULL;

/* Plugin's name */
static const char *pluginName = "addrtype";


/* OPTIONS SETUP */

/* option tags */
typedef enum addrType_args_e {
    ADDRTYPE_OPT_STYPE,
    ADDRTYPE_OPT_DTYPE
} addrType_args_t;

/*
 * The options and help strings.  Since these vary depending on the
 * type of app that is using the plugin, they get set to one of the
 * options below once we know which app called us.
 */
static struct option *libOptions = NULL;
static const char **libOptionsHelp = NULL;

/* Options and Help for filtering */
static struct option filterOptions[] = {
    {"stype", REQUIRED_ARG, 0, ADDRTYPE_OPT_STYPE},
    {"dtype", REQUIRED_ARG, 0, ADDRTYPE_OPT_DTYPE},
    {0,0,0,0}
};

static const char *filterOptionsHelp[] = {
    ("Source address mapped by \"address_types.pmap\" has this value.\n"
     "\tOne of: 0=non-routable; 1=internal; 2=external; 3=not-internal"),
    "Destination address maps to the specified type",
    NULL
};

/* Fields that get added to rwcut, rwsort, rwuniq */
static sk_stringmap_entry_t addrtype_fields[] = {
    {"stype", 1},
    {"16",  1},
    {"dtype", 2},
    {"17",  2},
    {NULL,  UINT32_MAX}         /* sentinel */
};


/* PRIVATE FUNCTION PROTOTYPES */

static addrType_err_t libOptionsSetup(dynlibInfoStruct *dlISP,
                                      dynlibSymbolId aType);
static int optionsHandler(clientData cData, int opt_index, char *opt_arg);
static addrType_err_t addrTypeInit(dynlibInfoStruct *dlISP);
static int local_cut(
    unsigned int    field,
    char           *out,
    size_t          len_out,
    rwRec          *rwrec);


/* FUNCTION DEFINITIONS */

/*
 *  int dynlib_api_version(void);
 *
 *    Return the dynlib API version that this plugin was compiled
 *    against.
 */
int dynlib_api_version(void)
{
    return DYNLIB_API_VERSION;
}


/*
 * int setup(dynlibInfoStruct *dlISP, dynlibSymbolId appType)
 *
 * Called by dynlib interface code to set up the plugin.  This routine
 * should set up options handling if required.  Arguments: pointer to
 * the dynamic library interface structure, application type that is
 * using this plugin.  Returns DYNLIB_FAILED if processing fails,
 * DYNLIB_WONTPROCESS if the application should do normal output, and
 * DYNLIB_WILLPROCESS if this plugin takes over output.
 */
int setup(dynlibInfoStruct *dlISP, dynlibSymbolId appType)
{
    /* Make the plugin use the application's context, so we can add
     * options to main app. */
    skAppContextSet(dynlibGetAppContext(dlISP));

    if (libOptionsSetup(dlISP, appType) != ADDRTYPE_OK) {
        return DYNLIB_FAILED;
    }
    return DYNLIB_WONTPROCESS;
}


/*
 *  int configure(dynlibInfoStruct *dlISP, void *data)
 *
 *    Perform additional configuration of the plug-in prior to
 *    processing the options.
 */
int configure(dynlibInfoStruct *dlISP, void *data)
{
    const dynlibSymbolId appType = dynlibGetAppType(dlISP);

    switch(appType) {
      case DYNLIB_CUT:
      case DYNLIB_SORT:
      case DYNLIB_UNIQ:
        /* for these apps, data is a pointer into which we should copy
         * the address of the fields this plug-in provides to the
         * application */
        if (data == NULL) {
            return -1;
        } else {
            sk_stringmap_entry_t **fields_ptr = (sk_stringmap_entry_t **)data;
            *fields_ptr = addrtype_fields;
        }
        break;

      default:
        /* nothing to do */
        break;
    }

    return 0;
}


/*
 * void teardown(dynlibSymbolId appType);
 *
 * Called by dynlib interface code to tear down this plugin.
 */
void teardown(dynlibSymbolId UNUSED(appType))
{
    if ( NULL != prefixMap ) {
        skPrefixMapDelete(prefixMap);
    }
}

/*
 * int initialize(dynlibInfoStruct *dlISP, dynlibSymbolId appType);
 *
 * Does any expensive initialization required by the plugin.  Returns
 * 0 on success, 1 on failure.  Note that initialization for filtering
 * is handled in the options parsing, so that it is only done when the
 * plugin is actually going to be used.
 */
int initialize(dynlibInfoStruct *dlISP, dynlibSymbolId appType)
{
    switch (appType) {
      case DYNLIB_CUT:
      case DYNLIB_SORT:
      case DYNLIB_UNIQ:
        if ( ADDRTYPE_OK != addrTypeInit(dlISP) ) {
            return 1;           /* Failed */
        }
        break;

      default:
        /* nothing to do */
        break;
    }

    return 0;
}

/*
 * void optionsUsage(dynlibSymbolId UNUSED(appType), FILE *fh);
 *
 * Called by the dynlib interface to allow this plugin to print the
 * options it accepts.
 */
void optionsUsage(dynlibSymbolId UNUSED(appType), FILE *fh)
{
    int i;
    if ( libOptions == NULL ) {
        return;
    }
    for (i = 0; libOptions[i].name; i++) {
        fprintf(fh, "--%s %s. %s\n", libOptions[i].name,
                SK_OPTION_HAS_ARG(libOptions[i]), libOptionsHelp[i]);
    }
}

/*
 * ccFilter_err_t libOptionsSetup(dynlibInfoStruct *dlISP,
 *                                dynlibSymbolId appType);
 *
 * Sets up the options handler for this plugin.
 */
static addrType_err_t libOptionsSetup(
    dynlibInfoStruct   *dlISP,
    dynlibSymbolId      appType)
{
    if ( NULL != libOptions ) {
        /* Already initialized. */
        return ADDRTYPE_OK;
    }

    /* verify same number of options and help strings */
    assert((sizeof(filterOptions)/sizeof(struct option))
           == (sizeof(filterOptionsHelp)/sizeof(char*)));

    switch (appType) {
      case DYNLIB_SHAR_FILTER:
        libOptions = filterOptions;
        libOptionsHelp = filterOptionsHelp;
        break;

      case DYNLIB_CUT:
      case DYNLIB_SORT:
      case DYNLIB_UNIQ:
        /* no options for these apps */
        return ADDRTYPE_OK;

      default:
        skAppPrintErr("Cannot use %s plug-in with %s application",
                      pluginName, skAppName());
        return ADDRTYPE_ERR_REGISTER;
    }

    /* register the options */
    if ( skOptionsRegister(libOptions, &optionsHandler, (clientData)dlISP) ) {
        skAppPrintErr("%s: Unable to register options.", pluginName);
        return ADDRTYPE_ERR_REGISTER;
    }

    return ADDRTYPE_OK;
}

/*
 * int optionsHandler(clientData cData, int opt_index, char *opt_arg);
 *
 * Handles options for the plugin.  cData is the dynlib ISP (which can
 * be used to find which application we are, among other things.)
 * opt_index is the enum passed in with the options descriptions.  opt_arg
 * is the argument, or NULL if no argument was given.  Returns 0 on
 * success, or 1 if there was a problem.
 */
static int optionsHandler(clientData cData, int opt_index, char *opt_arg)
{
    uint32_t opt_val;
    int rv;

    const dynlibSymbolId appType =
        dynlibGetAppType((dynlibInfoStruct*)cData);

    if ( DYNLIB_SHAR_FILTER != appType ) {
        skAppPrintErr("This plug-in does not support this application");
        return 1;
    }

    if ( ADDRTYPE_OK != addrTypeInit((dynlibInfoStruct*)cData) ) {
        skAppPrintErr("%s: Initialization failure.", pluginName);
        return 1;
    }

    rv = skStringParseUint32(&opt_val, opt_arg,
                             ADDRTYPE_FILT_NR, ADDRTYPE_FILT_NONINT);

    switch ( opt_index ) {
      case ADDRTYPE_OPT_STYPE:
        if ( rv != 0 ) {
            skAppPrintErr("Invalid %s '%s': %s",
                          filterOptions[opt_index].name, opt_arg,
                          skStringParseStrerror(rv));
            return 1;
        }
        srcAddrType = opt_val;
        break;

    case ADDRTYPE_OPT_DTYPE:
        if ( rv != 0 ) {
            skAppPrintErr("Invalid %s '%s': %s",
                          filterOptions[opt_index].name, opt_arg,
                          skStringParseStrerror(rv));
            return 1;
        }
        destAddrType = opt_val;
        break;

    default:
        skAppPrintErr("%s: Unrecognized option: %d", pluginName, opt_index);
        return 1;
    }
    return 0;
}


/*
 *  int filter(rwRec *rwrec);
 *
 *    The function actually used to implement filtering for the filter
 *    plugin.  Returns 0 if the record passes the filter, 1 if it
 *    fails the filter.
 */
int filter(rwRec *rwrec)
{
    uint32_t code;
    if ( srcAddrType != ADDRTYPE_FILT_NONE ) {
        code = skPrefixMapGet(prefixMap, rwRecGetSIPv4(rwrec));
        if ( srcAddrType == 3 ) {
            /* Not 1 */
            if ( code == 1 ) {
                return 1;       /* Reject */
            }
        } else if ( srcAddrType != (int)code ) {
            return 1;           /* Reject */
        }
    }
    if ( destAddrType != ADDRTYPE_FILT_NONE ) {
        code = skPrefixMapGet(prefixMap, rwRecGetDIPv4(rwrec));
        if ( destAddrType == 3 ) {
            /* Not 1 */
            if ( code == 1 ) {
                return 1;       /* Reject */
            }
        } else if ( destAddrType != (int)code ) {
            return 1;           /* Reject */
        }
    }
    return 0;                   /* Accept */
}


/*
 * int cut(unsigned int field, char *out, size_t len_out, rwRec *rwrec);
 *
 * If "field" is 0, then returns the number of supported fields.
 *
 * If "out" is NULL and "rwrec" is NULL, returns the size of the buffer
 * needed to store the title for this field.
 *
 * If "out" is NULL and "rwrec" is non-NULL, returns the size of the
 * buffer needed to store the value for this field.
 *
 * If "out" is non-NULL and "rwrec" is NULL, writes the title into "out",
 * and returns the number of bytes needed to store that string.
 *
 * If "out" is non-NULL and "rwrec" is non-NULL, writes the value for
 * that record into "out", and returns the number of bytes needed to
 * store that string.
 */
int cut(unsigned int field, char *out, size_t len_out, rwRec *rwrec)
{
    return local_cut(field, out, len_out, rwrec);
}

static int local_cut(
    unsigned int    field,
    char           *out,
    size_t          len_out,
    rwRec          *rwrec)
{
    int len;
    uint32_t code;

    if ( field == 0 ) {
        /* Request for number of supported fields */
        return 2;
    }

    if ( field > 2 ) {
        return -1;              /* Error: We don't support that field */
    }

    if ((out == NULL) && (rwrec == NULL)) {
        /* Request for buffer size for field title */
        return 6;               /* Five for "stype" or "dtype" plus \0 */
    }

    if ((out != NULL) && (rwrec == NULL)) {
        /* Request for field title */
        switch ( field ) {
          case 1:
            len = snprintf(out, len_out, "sType");
            return len;
          case 2:
            len = snprintf(out, len_out, "dType");
            return len;
          default:
            return -1;
        }
    }

    if ((out == NULL) && (rwrec != NULL)) {
        /* Request for buffer size for field value */
        return 2;               /* One digit plus \0 */
    }

    if ((out != NULL) && (rwrec != NULL)) {
        /* Request for field value */
        switch ( field ) {
          case 1:
            code = skPrefixMapGet(prefixMap, rwRecGetSIPv4(rwrec));
            len = snprintf(out, len_out, "%u", code);
            return len;
          case 2:
            code = skPrefixMapGet(prefixMap, rwRecGetDIPv4(rwrec));
            len = snprintf(out, len_out, "%u", code);
            return len;
          default:
            return -1;
        }
    }

    /* Should never get here */
    return -1;
}


/*
 *  int sort(unsigned int field, uint8_t *bin_value, rwRec *rwrec);
 *
 *  Arguments:
 *      f:        field to get the binary or textual value of
 *      bin_val:  buffer to fill with a binary value that rwsort will
 *                use for sorting; rwsort will not ask the plug-in for
 *                more data; this value should be everything rwsort
 *                needs to know.  rwsort will use memcmp() to compare
 *                values; the values should be in big-endian byte
 *                order.  THIS BUFFER MAY NOT BE WORD ALIGNED.
 *      rec:      SiLK flow record
 *  Returns:
 *      when 'f' is zero
 *        => the number of supported fields
 *      when 'f' is non-zero
 *        when 'bin_val' or 'rec' is NULL
 *          => the number of bytes required to hold the binary value
 *             of field 'f'
 *        when 'bin_val' and 'rec' are non-NULL
 *          => length of the binary value; uses 'rec' to compute the
 *             value of field 'f' and writes that binary value into
 *             'bin_val'.  ASSUMES 'bin_val' IS BIG ENOUGH!
 */
int sort(unsigned int field, uint8_t *bin_value, rwRec *rwrec)
{
    uint32_t code = 0;

    if (field == 0) {
        /* Request for number of supported fields */
        return 2;
    }

    if (bin_value && rwrec) {
        switch (field) {
        case 1:
            code = skPrefixMapGet(prefixMap, rwRecGetSIPv4(rwrec));
            *bin_value = (uint8_t) code;
            break;

        case 2:
            code = skPrefixMapGet(prefixMap, rwRecGetDIPv4(rwrec));
            *bin_value = (uint8_t) code;
            break;

        default:
            return 0;
        }
    }

    /* return width of binary value */
    return 1;
}


/*
 *  int uniq(unsigned int f, uint8_t bin_val, char *text_val, size_t text_len, rwRec *rec)
 *
 *  Arguments:
 *      f:        field to get the binary or textual value of
 *      bin_val:  buffer to fill with binary value, or buffer to pass
 *                in the binary value when converting to text.
 *      text_val: buffer to fill with the textual value
 *      text_len: length of the buffer 'out'
 *      rec:      SiLK flow record
 *  Returns:
 *      when 'f' is zero
 *        => the number of supported fields
 *      when 'f' is non-zero
 *        when 'bin_val' is NULL
 *          => the result of running cut(f, text_val, text_len, rwrec)
 *        when 'bin_val' is non-NULL
 *          when 'text_val' is non-NULL and 'rec' has any value
 *            => length of buffer necessary to hold the complete
 *               textual value; fills 'text_val' with the first
 *               'text_len'-1 bytes of converting the binary value in
 *               'bin_val', corresponding to field 'f', to text.
 *          when 'text_val' is NULL and 'text_len' has any value
 *            when 'rec' is non-NULL
 *              => length of the binary value; uses 'rec' to compute
 *                 the value of field 'f' and writes that binary value
 *                 into 'bin_val'.  ASSUMES 'bin_val' IS BIG ENOUGH!
 *             when 'rec' is NULL
 *               => the number of bytes required to hold the binary
 *                  value of field 'f'
 */
int uniq(
    unsigned int    field,
    uint8_t        *bin_value,
    char           *text_value,
    size_t          text_len,
    rwRec          *rwrec)
{
    uint32_t code;

    if (field == 0) {
        return 2;
    } else if (bin_value) {
        if (text_value) {
            /* return the text value given the binary value */
            int len;
            len = snprintf(text_value, text_len, "%u", *bin_value);
            return len;
        } else if (rwrec) {
            /* return the binary value for the given rwrec */
            switch (field) {
            case 1:
                code = skPrefixMapGet(prefixMap, rwRecGetSIPv4(rwrec));
                break;

            case 2:
                code = skPrefixMapGet(prefixMap, rwRecGetDIPv4(rwrec));
                break;

            default:
                return -1;
            }

            *bin_value = (uint8_t) code;

            return 1;
        } else {
            /* return the number of bytes in the binary value */
            return 1;
        }
    } else {
        /* either return the title's width---when text_value and rwrec
         * are both NULL, the textual field width---when text_value is
         * NULL and rwrec is non-NULL, or the title---when text_value
         * is non-NULL and rwrec is NULL. */
        return local_cut(field, text_value, text_len, rwrec);
    }

    return -1; /* NOTREACHED */
}


/*
 * addrType_err_t addrTypeInit(dynlibInfoStruct *dlISP);
 *
 *    The one-time-only initialization code.  This is called by
 *    initialize for rwcut, rwsort, and rwuniq, and by the option
 *    parsing code for rwfilter.  Returns ADDRTYPE_OK on success.
 */
addrType_err_t addrTypeInit(dynlibInfoStruct *dlISP)
{
    static int initialized = 0;
    char filename[PATH_MAX];
    skPrefixMapErr_t map_error = SKPREFIXMAP_OK;

    if ( initialized ) {
        return ADDRTYPE_OK;
    }

    /* Read in the data file */
    if (NULL == skFindFile(DEFAULT_ADDRTYPE_FILENAME,
                           filename, sizeof(filename), 1))
    {
        skAppPrintErr("%s: Could not locate data file '%s'.",
                      pluginName, DEFAULT_ADDRTYPE_FILENAME);
        return ADDRTYPE_ERR_DATA;
    }

    map_error = skPrefixMapLoad(&prefixMap, filename);
    if ( SKPREFIXMAP_OK != map_error ) {
        prefixMap = NULL;
        if ( SKPREFIXMAP_ERR_ARGS == map_error ) {
            skAppPrintErr("%s: Failed to read data file: Invalid arguments.",
                          pluginName);
        } else if ( SKPREFIXMAP_ERR_MEMORY == map_error ) {
            skAppPrintErr("%s: Failed to read data file: Out of memory.",
                          pluginName);
        } else if ( SKPREFIXMAP_ERR_IO == map_error ) {
            skAppPrintErr("%s: Failed to read data file: I/O error.",
                          pluginName);
        } else {
            skAppPrintErr("%s: Failed to read data file: Unknown error.",
                          pluginName);
        }
        return ADDRTYPE_ERR_DATA;
    }
    dynlibMakeActive(dlISP);
    initialized = 1;
    return ADDRTYPE_OK;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
