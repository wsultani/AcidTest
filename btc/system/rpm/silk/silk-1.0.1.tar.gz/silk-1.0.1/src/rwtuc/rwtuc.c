/*
** Copyright (C) 2006-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  rwtuc - Text Utility Converter
**
**  Takes the output from rwcut and generates SiLK flow records from it.
**
**  Mark Thomas, March 2006
**
*/


#include "silk.h"

RCSIDENT("$SiLK: rwtuc.c 11248 2008-04-11 19:07:39Z mthomas $");

#include "sksite.h"
#include "utils.h"
#include "rwpack.h"


/* LOCAL DEFINES AND TYPEDEFS */

/* where to write --help output */
#define USAGE_FH stdout

/* the identifier for fields to ignore */
#define IGNORED_FIELD   RWREC_PRINTABLE_FIELD_COUNT

/* depending on what we are parsing, there may be various parts of the
 * time we need to calculate */
typedef enum {
    /* sTime and elapsed are being set; nothing to calculate */
    CALC_NONE,
    /* must calculate sTime from eTime - elapsed */
    CALC_STIME,
    /* must calculate elapsed from eTime - sTime */
    CALC_ELAPSED
} time_calc_t;


/* various values that get parsed; either from the fixed values the
 * user enters on the command line or one per line that is read. */
typedef struct parsed_values_st {
    rwRec       rec;
    char       *class;
    char       *type;
    sktime_t    eTime;
    int         bytes_equals_pkts;
    time_calc_t handle_time;
} parsed_values_t;


/* LOCAL VARIABLES */

/* where to send output */
static const char *output_path = "stdout";

/* where to send output */
static rwIOStruct *out_ios = NULL;

/* where to copy bad input lines, and how to close the stream */
static char *bad_input_lines = NULL;
static FILE *bad_stream = NULL;
static int (*bad_stream_closef)(FILE*) = NULL;

/* available fields */
static sk_stringmap_t *field_map;

/* character that separates input fields (the delimiter) */
static char column_separator = '|';

/* first file option to process */
static int arg_index;

/* the fields (columns) to print in the order to print them; each
 * value is an ID from field_map */
static uint32_t *field_list = NULL;

/* number of fields to print; length of field_list */
static uint32_t num_fields = 0;

/* default values from user */
static char *default_val[RWREC_PRINTABLE_FIELD_COUNT];

/* the compression method to use when writing the file.
 * sksiteCompmethodOptionsRegister() will set this to the default or
 * to the value the user specifies. */
static sk_compmethod_t comp_method;


/* OPTIONS SETUP */

typedef enum {
    OPT_FIELDS, OPT_COLUMN_SEPARATOR, OPT_OUTPUT_PATH, OPT_BAD_INPUT_LINES
} appOptionsEnum;


static struct option appOptions[] = {
    {"fields",              REQUIRED_ARG, 0, OPT_FIELDS},
    {"column-separator",    REQUIRED_ARG, 0, OPT_COLUMN_SEPARATOR},
    {"output-path",         REQUIRED_ARG, 0, OPT_OUTPUT_PATH},
    {"bad-input-lines",     REQUIRED_ARG, 0, OPT_BAD_INPUT_LINES},
    {0,0,0,0}               /* sentinel entry */
};

static const char *appHelp[] = {
    NULL, /* generated dynamically */
    "Character that separates the input fields. Def. '|'",
    "Output path for the SiLK flow records. Def. stdout",
    ("Stream to write each bad input line to.\n"
     "\tLines will be have file name and line number prepended"),
    (char *)NULL
};

static struct option defaultValueOptions[RWREC_PRINTABLE_FIELD_COUNT+1] = {
    {"saddress",          REQUIRED_ARG, 0, RWREC_FIELD_SIP},
    {"daddress",          REQUIRED_ARG, 0, RWREC_FIELD_DIP},
    {"sport",             REQUIRED_ARG, 0, RWREC_FIELD_SPORT},
    {"dport",             REQUIRED_ARG, 0, RWREC_FIELD_DPORT},
    {"protocol",          REQUIRED_ARG, 0, RWREC_FIELD_PROTO},

    {"packets",           REQUIRED_ARG, 0, RWREC_FIELD_PKTS},
    {"bytes",             REQUIRED_ARG, 0, RWREC_FIELD_BYTES},
    {"flags-all",         REQUIRED_ARG, 0, RWREC_FIELD_FLAGS},

    {"stime",             REQUIRED_ARG, 0, RWREC_FIELD_STIME},
    {"duration",          REQUIRED_ARG, 0, RWREC_FIELD_ELAPSED},
    {"etime",             REQUIRED_ARG, 0, RWREC_FIELD_ETIME},

    {"sensor",            REQUIRED_ARG, 0, RWREC_FIELD_SID},

    {"input-index",       REQUIRED_ARG, 0, RWREC_FIELD_INPUT},
    {"output-index",      REQUIRED_ARG, 0, RWREC_FIELD_OUTPUT},
    {"next-hop-ip",       REQUIRED_ARG, 0, RWREC_FIELD_NHIP},

    {"flags-initial",     REQUIRED_ARG, 0, RWREC_FIELD_INIT_FLAGS},
    {"flags-session",     REQUIRED_ARG, 0, RWREC_FIELD_REST_FLAGS},
    {"attributes",        REQUIRED_ARG, 0, RWREC_FIELD_TCP_STATE},
    {"application",       REQUIRED_ARG, 0, RWREC_FIELD_APPLICATION},

    {"class",             REQUIRED_ARG, 0, RWREC_FIELD_FTYPE_CLASS},
    {"type",              REQUIRED_ARG, 0, RWREC_FIELD_FTYPE_TYPE},

    {"stime+msec",        REQUIRED_ARG, 0, RWREC_FIELD_STIME_MSEC},
    {"etime+msec",        REQUIRED_ARG, 0, RWREC_FIELD_ETIME_MSEC},
    {"duration+msec",     REQUIRED_ARG, 0, RWREC_FIELD_ELAPSED_MSEC},

    {0,0,0,0}       /* sentinel entry */
};



/* LOCAL FUNCTION PROTOTYPES */

static void appUsageLong(void);
static void appOptionsUsage(FILE*);          /* application options usage */
static void appTeardown(void);
static void appSetup(int argc, char **argv);
static int  appOptionsHandler(clientData cData, int opt_index, char *opt_arg);
static int  defaultValueHandler(clientData cData, int opt_ind, char *opt_arg);
static int  parseFields(const char *field_string);
static void usageFields(FILE *fh);
static int  processFields(
    parsed_values_t    *val,
    uint32_t            field_count,
    uint32_t           *field_type,
    char              **field_val);
static int firstLineIsTitle(char *first_line);
static int  processFirstLine(
    uint32_t          **field_type,
    char             ***field_val,
    parsed_values_t    *defaults,
    char               *first_line);
static int  processFile(FILE *handle, const char *filename);


/* FUNCTION DEFINITIONS */

/*
 *  appUsageLong();
 *
 *    Print complete usage information to USAGE_FH.  Pass this
 *    function to skOptionsSetUsageCallback(); skOptionsParse() will
 *    call this funciton and then exit the program when the --help
 *    option is given.
 */
static void appUsageLong(void)
{
#define USAGE_MSG                                                             \
    ("[SWITCHES] [FILES]\n"                                                   \
     "\tGenerate SiLK flow records from textual input; the input should be\n" \
     "\tin a form similar to what rwcut generates.\n")

    FILE *fh = USAGE_FH;

    fprintf(fh, "%s %s", skAppName(), USAGE_MSG);
    appOptionsUsage(fh);
    sksiteCompmethodOptionsUsage(fh);
}


/*
 *  appOptionsUsage(fh);
 *
 *    For each option defined in this application, print its name,
 *    whether it takes an option, and its help string.  Print to the
 *    specified file handle, 'fh'.
 */
static void appOptionsUsage(FILE *fh)
{
    int i;
    fprintf(fh, "\nSWITCHES:\n");
    skOptionsDefaultUsage(fh);
    sksiteOptionsUsage(fh);
    for (i = 0; appOptions[i].name; i++) {
        fprintf(fh, "--%s %s. ", appOptions[i].name,
                SK_OPTION_HAS_ARG(appOptions[i]));
        switch (i) {
          case OPT_FIELDS:
            /* Dynamically build the help */
            usageFields(fh);
            break;
          default:
            /* Simple static help text from the appHelp array */
            fprintf(fh, "%s\n", appHelp[i]);
            break;
        }
    }
    for (i = 0; defaultValueOptions[i].name; ++i) {
        fprintf(fh, "--%s %s. Fixed value for the %s field.\n",
                defaultValueOptions[i].name,
                SK_OPTION_HAS_ARG(defaultValueOptions[i]),
                defaultValueOptions[i].name);
    }
}


/*
 *  appTeardown()
 *
 *    Teardown all modules, close all files, and tidy up all
 *    application state.
 *
 *    This function is idempotent.
 */
static void appTeardown(void)
{
    static int teardownFlag = 0;

    if (teardownFlag) {
        return;
    }
    teardownFlag = 1;

    if (out_ios) {
        int rv = rwioClose(out_ios);
        if (rv) {
            rwioPrintLastErr(out_ios, rv, &skAppPrintErr);
        }
        rwioDestroy(&out_ios);
    }

    if (bad_stream && bad_stream_closef) {
        if (bad_stream_closef(bad_stream)) {
            skAppPrintErr("Error closing '%s': %s",
                          bad_input_lines, strerror(errno));
        } else if (skFileSize(bad_input_lines) == 0) {
            /* remove an empty file */
            unlink(bad_input_lines);
        }
    }
    bad_stream = NULL;

    skAppUnregister();
}


/*
 *  appSetup(argc, argv);
 *
 *    Perform all the setup for this application include setting up
 *    required modules, parsing options, etc.  This function should be
 *    passed the same arguments that were passed into main().
 *
 *    Returns to the caller if all setup succeeds.  If anything fails,
 *    this function will cause the application to exit with a FAILURE
 *    exit status.
 */
static void appSetup(int argc, char **argv)
{
    int rv;

    /* verify same number of options and help strings */
    assert((sizeof(appHelp)/sizeof(char *)) ==
           (sizeof(appOptions)/sizeof(struct option)));

    /* register the application */
    skAppRegister(argv[0]);
    skOptionsSetUsageCallback(&appUsageLong);

    /* initialize globals */
    memset(default_val, 0, sizeof(default_val));

    /* register the options */
    if (skOptionsRegister(appOptions, &appOptionsHandler, NULL)
        || skOptionsRegister(defaultValueOptions, &defaultValueHandler, NULL)
        || sksiteCompmethodOptionsRegister(&comp_method)
        || sksiteOptionsRegister(SK_SITE_FLAG_CONFIG_FILE))
    {
        skAppPrintErr("Unable to register options");
        exit(EXIT_FAILURE);
    }

    /* initialize string-map of field identifiers, and add an
     * "ignored" field. */
    if (rwAsciiFieldMapAddDefaultFields(&field_map)) {
        skAppPrintErr("Unable to setup fields stringmap");
        exit(EXIT_FAILURE);
    }
    skStringMapAddID(field_map, "ignore", IGNORED_FIELD);

    /* parse the options */
    arg_index = skOptionsParse(argc, argv);
    if (arg_index < 0) {
        /* options parsing should print error */
        skAppUsage();           /* never returns */
    }

    /* try to load site config file; if it fails, we will not be able
     * to resolve flowtype and sensor from input file names */
    sksiteConfigure(0);

    /* arg_index is looking at first file name to process */
    if (arg_index == argc) {
        if (FILEIsATty(stdin)) {
            skAppPrintErr("No input files on command line and"
                          " stdin is connected to a terminal");
            skAppUsage();
        }
    }

    /* open bad output */
    if (bad_input_lines) {
        if (0 == strcmp(bad_input_lines, output_path)) {
            skAppPrintErr("Cannot use same stream for bad input and records");
            skAppUsage();
        }
        if (0 == strcmp("stderr", bad_input_lines)) {
            bad_stream = stderr;
        } else if (0 == strcmp("stdout", bad_input_lines)) {
            bad_stream = stdout;
        } else {
            int is_pipe;
            if (skOpenFile(bad_input_lines, 1, &bad_stream, &is_pipe)) {
                skAppPrintErr("Cannot open output stream '%s'",
                              bad_input_lines);
                exit(EXIT_FAILURE);
            }
            if (is_pipe) {
                bad_stream_closef = &pclose;
            } else {
                bad_stream_closef = &fclose;
            }
        }
    }

    /* open output */
    if ((rv = rwioCreate(&out_ios, output_path, SK_IO_WRITE))
        || (rv = rwioSetCompression(out_ios, comp_method))
        || (rv = skHeaderAddInvocation(rwGetHeader(out_ios), 1, argc, argv))
        || (rv = rwioOpen(out_ios)))
    {
        rwioPrintLastErr(out_ios, rv, &skAppPrintErr);
        skAppPrintErr("Couldn't open output file.  Exiting.");
        exit(EXIT_FAILURE);
    }

    if (atexit(appTeardown) < 0) {
        skAppPrintErr("Unable to register appTeardown() with atexit()");
        appTeardown();
        exit(EXIT_FAILURE);
    }

    return;  /* OK */
}


/*
 *  status = appOptionsHandler(cData, opt_index, opt_arg);
 *
 *    This function is passed to skOptionsRegister(); it will be called
 *    by skOptionsParse() for each user-specified switch that the
 *    application has registered; it should handle the switch as
 *    required---typically by setting global variables---and return 1
 *    if the switch processing failed or 0 if it succeeded.  Returning
 *    a non-zero from from the handler causes skOptionsParse() to return
 *    a negative value.
 *
 *    The clientData in 'cData' is typically ignored; 'opt_index' is
 *    the index number that was specified as the last value for each
 *    struct option in appOptions[]; 'opt_arg' is the user's argument
 *    to the switch for options that have a REQUIRED_ARG or an
 *    OPTIONAL_ARG.
 */
static int appOptionsHandler(
    clientData  UNUSED(cData),
    int         opt_index,
    char       *opt_arg)
{
    switch ((appOptionsEnum)opt_index) {

      case OPT_FIELDS:
        return parseFields(opt_arg);

      case OPT_COLUMN_SEPARATOR:
        /* column_separator */
        column_separator = *opt_arg;
        if ('\0' == column_separator) {
            skAppPrintErr("Empty string not valid argument for --%s",
                          appOptions[opt_index].name);
            return 1;
        }
        break;

      case OPT_OUTPUT_PATH:
        output_path = opt_arg;
        break;

      case OPT_BAD_INPUT_LINES:
        bad_input_lines = opt_arg;
        break;
    }

    return 0;  /* OK */
}


/*
 *  ok = defaultValueHandler(cData, opt_index, opt_arg);
 *
 *    Like appOptionsHandler(), except it handles the options
 *    specified in the defaultValueOptions[] array.
 */
static int defaultValueHandler(
    clientData  UNUSED(cData),
    int         opt_index,
    char       *opt_arg)
{
    assert(opt_index >= 0 && opt_index < RWREC_PRINTABLE_FIELD_COUNT);
    default_val[opt_index] = opt_arg;
    return 0;
}


/*
 *  usageFields(fh);
 *
 *    Print the usage (help) message for --fields to the 'fh' file pointer
 */
static void usageFields(FILE *fh)
{
    fprintf(fh, "Field(s) to print. List columns separated by commas:\n");

    rwAsciiFieldMapPrintUsage(fh, field_map);
}


/*
 *  status = parseFields(fields_string);
 *
 *    Parse the user's option for the --fields switch and fill in the
 *    global 'outputs[]' array of out_stream_t's.  Return 0 on
 *    success; 1 on failure.
 */
static int parseFields(const char *field_string)
{
    /* have we been here before? */
    if (field_list != NULL) {
        skAppPrintErr("--%s option given multiple times",
                      appOptions[OPT_FIELDS].name);
        return 1;
    }

    if (field_string == NULL || field_string[0] == '\0') {
        skAppPrintErr("Missing --fields value");
        return 1;
    }

    if (rwAsciiFieldMapParseFields(&field_list, &num_fields, field_string,
                                   field_map, RW_ASCII_DUPES_ERROR))
    {
        /* library printed the error */
        return 1;
    }

    return 0;
}


/*
 *  is_title = firstLineIsTitle(first_line);
 *
 *    Determine if the input line in 'first_line' is a title line.
 *    Return 1 if it is, 0 if it is not.  Return -1 on error due
 *    memory allocation or no delimiters.
 */
static int firstLineIsTitle(char *first_line)
{
    sk_stringmap_entry_t *entry;
    char *cp;
    char *ep;
    uint32_t i;
    int is_title = 0;

    /* we have the fields, need to determine if first_line is a
     * title line. */
    cp = first_line;
    for (i = 0; i < num_fields; ++i) {
        ep = strchr(cp, column_separator);
        if (field_list[i] == IGNORED_FIELD) {
            if (ep == NULL) {
                skAppPrintErr("Cannot find delimiter in first line");
                return -1;
            }
            cp = ep + 1;
        } else {
            /* see if the value in this column maps to a valid
             * stringmap-entry; if so, assume the row is a title
             * row */
            if (ep) {
                *ep = '\0';
            }
            while ((isspace((int)*cp))) {
                ++cp;
            }
            if (skStringMapGetEntry(&entry, field_map, cp) == SKSTRINGMAP_OK) {
                is_title = 1;
                break;
            }
            if (ep) {
                *ep = column_separator;
            }
        }
    }

    return is_title;
}


/*
 *  is_title = processFirstLine(&field_type, &field_val, &defaults, firstline);
 *
 *    Set the types of fields to be parsed in this file (field_type),
 *    an array to hold the strings to be parsed on each row
 *    (field_val), and the default values for this file (defaults).
 *    When finished with the file, the caller should free the
 *    'field_type' and 'field_val' arrays.
 *
 *    The set of field_type's will be determined from the --fields
 *    value if present, otherwise from the firstline of the file,
 *    which must be a title-line.  If the user provided a fixed value
 *    for the field, any field having that type will be set to
 *    'ignore'.
 *
 *    Return 0 if the first line contains data to be parsed; 1 if it
 *    contains a title; or -1 on error.
 *
 *    We should be smarter; if the user provided a --fields switch,
 *    there is no need to recompute the defaults each time, and the
 *    field_type and field_val arrays will have fixed sizes, so they
 *    would not need to be reallocated each time.
 */
static int processFirstLine(
    uint32_t          **field_type,
    char             ***field_val,
    parsed_values_t    *defaults,
    char               *first_line)
{
    uint32_t have_field[RWREC_PRINTABLE_FIELD_COUNT];
    uint32_t default_list[RWREC_PRINTABLE_FIELD_COUNT];
    char *active_defaults[RWREC_PRINTABLE_FIELD_COUNT];
    uint32_t num_defaults;
    uint32_t i;
    int is_title = 0;
    int per_file_field_list = 0;
    int have_stime, have_etime, have_elapsed;

    memset(defaults, 0, sizeof(parsed_values_t));
    memset(have_field, 0, sizeof(have_field));

    if (field_list != NULL) {
        is_title = firstLineIsTitle(first_line);
        if (is_title < 0) {
            return is_title;
        }
    } else {
        /* need to get fields from the first line */
        char *cp, *ep;
        cp = ep = first_line;
        while (*cp) {
            if (*cp == column_separator) {
                /* convert column_separator to comma for parseFields() */
                *ep++ = ',';
                ++cp;
            } else if (isspace((int)*cp)) {
                /* ignore spaces */
                ++cp;
            } else {
                /* copy character */
                *ep++ = *cp++;
            }
        }
        *ep = *cp;
        if (parseFields(first_line)) {
            skAppPrintErr("Unable to guess fields from first line of file");
            return -1;
        }
        is_title = 1;
        per_file_field_list = 1;
    }

    /* create an array to hold a copy of the field_list */
    *field_type = calloc(num_fields, sizeof(uint32_t));
    if (*field_type == NULL) {
        skAppPrintErr("Out of memory");
        exit(EXIT_FAILURE);
    }

    /* create an array to hold the field values */
    *field_val = calloc(num_fields, sizeof(char*));
    if (*field_val == NULL) {
        skAppPrintErr("Out of memory");
        exit(EXIT_FAILURE);
    }

    /* copy the field_list into the copy (field_type), but set any
     * fields that have default values to 'ignore' */
    for (i = 0; i < num_fields; ++i) {
        have_field[field_list[i]] = 1;
        if (default_val[field_list[i]] == NULL) {
            (*field_type)[i] = field_list[i];
        } else {
            (*field_type)[i] = IGNORED_FIELD;
        }
    }

    /* destroy the field_list if we created it above */
    if (per_file_field_list) {
        free(field_list);
        field_list = NULL;
    }

    /* set have_field for all values that have defaults */
    for (i = 0; i < RWREC_PRINTABLE_FIELD_COUNT; ++i) {
        if (default_val[i] != NULL) {
            have_field[i] = 1;
        }
    }

    /* if there is no packets value, set to 1 */
    if ( !have_field[RWREC_FIELD_PKTS]) {
        rwRecSetPkts(&defaults->rec, 1);
    }

    /* if no bytes value, we will set it to the packets value */
    if ( !have_field[RWREC_FIELD_BYTES]) {
        if ( !have_field[RWREC_FIELD_PKTS]) {
            /* packets field is fixed, so bytes field can be fixed too */
            rwRecSetBytes(&defaults->rec, 1);
        } else {
            /* must do calculation each time */
            defaults->bytes_equals_pkts = 1;
        }
    }

    /* must have both or neither initial and session flags */
    if (have_field[RWREC_FIELD_INIT_FLAGS]
        != have_field[RWREC_FIELD_REST_FLAGS])
    {
        skAppPrintErr("Either both initial- and session-flags must be parsed\n"
                      "\tor neither may be parsed.");
        return -1;
    }
    if (have_field[RWREC_FIELD_INIT_FLAGS]) {
        rwRecSetTcpState(&defaults->rec, SK_TCPSTATE_EXPANDED);
    }

    /* attributes or application only valid when initial/session flags */
    if ((have_field[RWREC_FIELD_TCP_STATE]
         || have_field[RWREC_FIELD_APPLICATION])
         && !have_field[RWREC_FIELD_INIT_FLAGS])
    {
        skAppPrintErr("Must have initial- and session-flag fields whenever\n"
                      "\tthe attributes or application fields are parsed");
        return -1;
    }

    /* need a time */
    have_stime = (have_field[RWREC_FIELD_STIME]
                  || have_field[RWREC_FIELD_STIME_MSEC]);
    have_etime = (have_field[RWREC_FIELD_ETIME]
                  || have_field[RWREC_FIELD_ETIME_MSEC]);
    have_elapsed = (have_field[RWREC_FIELD_ELAPSED]
                    || have_field[RWREC_FIELD_ELAPSED_MSEC]);
    if (have_stime) {
        if (have_elapsed) {
            defaults->handle_time = CALC_NONE;
            if (have_etime) {
                /* we will set etime from stime+elapsed */
                default_val[RWREC_FIELD_ETIME] = NULL;
                default_val[RWREC_FIELD_ETIME_MSEC] = NULL;
                for (i = 0; i < num_fields; ++i) {
                    if (((*field_type)[i] == RWREC_FIELD_ETIME)
                        || ((*field_type)[i] == RWREC_FIELD_ETIME_MSEC))
                    {
                        (*field_type)[i] = IGNORED_FIELD;
                    }
                }
            }
        } else if (have_etime) {
            /* must compute elapsed from eTime - sTime */
            defaults->handle_time = CALC_ELAPSED;
        }
        /* else elapsed is fixed at 0 */
    } else if (have_etime) {
        /* must calculate stime from etime and duration */
        defaults->handle_time = CALC_STIME;

        /* we could be smarter here: if we have etime but no elapsed
         * time, then stime and etime will be equal, and we could just
         * set the stime instead of the etime */
    } else {
        /* have no stime or etime.  set stime to now */
        time_t t;
        time(&t);
        rwRecSetStartTime(&defaults->rec, (sktime_t)1000 * t);
        defaults->handle_time = CALC_NONE;
    }

    /* create a list of fields for which we have default values */
    num_defaults = 0;
    for (i = 0; i < RWREC_PRINTABLE_FIELD_COUNT; ++i) {
        if (default_val[i] != NULL) {
            default_list[num_defaults] = i;
            active_defaults[num_defaults] = default_val[i];
            ++num_defaults;
        }
    }

    /* process the fields */
    if (processFields(defaults, num_defaults, default_list, active_defaults)) {
        skAppPrintErr("Error processing default values");
        return -1;
    }

    /* verify class and type */
    if (defaults->class && defaults->type) {
        if (rwRecGetFlowType(&defaults->rec) == SK_INVALID_FLOWTYPE) {
            skAppPrintErr("Bad default class/type combination: %s/%s",
                          defaults->class, defaults->type);
            return -1;
        }
        /* we have set the flow_type on the default record, there is
         * no need to look it up for each line. */
        defaults->class = defaults->type = NULL;
    }

    return is_title;
}


/*
 *  convertOldTime(old_time_str);
 *
 *    Convert the 'old_time_str' that should have a form of
 *
 *        MM/DD/YYYY hh:mm:ss[.sss]
 *
 *    to the new form of YYYY/MM/DD:hh:mm:ss[.sss]
 */
static void convertOldTime(char *old_time_str)
{
    char tmp;
    int i;

    for (i = 0; i < 5; ++i) {
        tmp = old_time_str[i];
        old_time_str[i] = old_time_str[i+6];
        old_time_str[i+5] = tmp;
    }
    old_time_str[4] = '/';
    old_time_str[10] = ':';
}


/*
 *  ok = processFields(val, field_count, field_types, field_values);
 *
 *    Parse the 'field_count' fields whose types and string-values are
 *    given in the 'field_types' and 'field_values' arrays,
 *    respectively.  Set the fields specified in the 'val' structure.
 *
 *    Return 0 on success, non-zero on failure.
 */
static int processFields(
    parsed_values_t    *val,
    uint32_t            field_count,
    uint32_t           *field_type,
    char              **field_val)
{
    sktime_t t;
    skipaddr_t ipaddr;
    uint32_t tmp32;
    uint8_t flags;
    uint8_t tcp_state = 0;
    uint32_t i;
    char *cp;
    char *ep;

    for (i = 0; i < field_count; ++i) {
        cp = field_val[i];
        while (isspace((int)*cp)) {
            ++cp;
        }

        switch (field_type[i]) {
          case IGNORED_FIELD:
            break;

          case RWREC_FIELD_SIP:
            if (skStringParseIP(&ipaddr, cp)) {
                return -1;
            }
            rwRecMemSetSIP(&val->rec, &ipaddr);
            break;

          case RWREC_FIELD_DIP:
            if (skStringParseIP(&ipaddr, cp)) {
                return -1;
            }
            rwRecMemSetDIP(&val->rec, &ipaddr);
            break;

          case RWREC_FIELD_SPORT:
            if (skStringParseUint32(&tmp32, cp, 0, UINT16_MAX)) {
                return -1;
            }
            rwRecSetSPort(&val->rec, (uint16_t)tmp32);
            break;

          case RWREC_FIELD_DPORT:
            if (skStringParseUint32(&tmp32, cp, 0, UINT16_MAX)) {
                return -1;
            }
            rwRecSetDPort(&val->rec, (uint16_t)tmp32);
            break;

          case RWREC_FIELD_PROTO:
            if (skStringParseUint32(&tmp32, cp, 0, UINT8_MAX)) {
                return -1;
            }
            rwRecSetProto(&val->rec, (uint8_t)tmp32);
            break;

          case RWREC_FIELD_PKTS:
            if (skStringParseUint32(&tmp32, cp, 1, 0)) {
                return -1;
            }
            rwRecSetPkts(&val->rec, tmp32);
            break;

          case RWREC_FIELD_BYTES:
            if (skStringParseUint32(&tmp32, cp, 1, 0)) {
                return -1;
            }
            rwRecSetBytes(&val->rec, tmp32);
            break;

          case RWREC_FIELD_FLAGS:
            if (skStringParseTCPFlags(&flags, cp)) {
                return -1;
            }
            rwRecSetFlags(&val->rec, flags);
            break;

          case RWREC_FIELD_STIME:
          case RWREC_FIELD_STIME_MSEC:
            if ((NULL != (ep = strchr(cp, ' '))) && ((ep - cp) == 10)) {
                convertOldTime(cp);
            }
            if (skStringParseDatetime(&t, cp, NULL)) {
                return -1;
            }
            rwRecSetStartTime(&val->rec, t);
            break;

          case RWREC_FIELD_ELAPSED:
          case RWREC_FIELD_ELAPSED_MSEC:
            {
                double dur;
                if (skStringParseDouble(&dur, cp, 0.0, ((double)UINT32_MAX
                                                        / 1e3)))
                {
                    /* parse error */
                    return -1;
                }
                /* add a bit of slop since doubles aren't exact */
                rwRecSetElapsed(&val->rec, (uint32_t)1000 * (dur + 5e-7));
            }
            break;

          case RWREC_FIELD_ETIME:
          case RWREC_FIELD_ETIME_MSEC:
            if ((NULL != (ep = strchr(cp, ' '))) && ((ep - cp) == 10)) {
                convertOldTime(cp);
            }
            if (skStringParseDatetime(&(val->eTime), cp, NULL)) {
                return -1;
            }
            break;

          case RWREC_FIELD_SID:
            if (isdigit((int)*cp)) {
                if (skStringParseUint32(&tmp32, cp, 0, SK_INVALID_SENSOR-1)) {
                    return -1;
                }
                rwRecSetSensor(&val->rec, (sensorID_t)tmp32);
            } else {
                rwRecSetSensor(&val->rec, sksiteSensorLookup(cp));
            }
            break;

          case RWREC_FIELD_INPUT:
            if (skStringParseUint32(&tmp32, cp, 0, UINT16_MAX)) {
                return -1;
            }
            rwRecSetInput(&val->rec, (uint16_t)tmp32);
            break;

          case RWREC_FIELD_OUTPUT:
            if (skStringParseUint32(&tmp32, cp, 0, UINT16_MAX)) {
                return -1;
            }
            rwRecSetOutput(&val->rec, (uint16_t)tmp32);
            break;

          case RWREC_FIELD_NHIP:
            if (skStringParseIP(&ipaddr, cp)) {
                return -1;
            }
            rwRecMemSetNhIP(&val->rec, &ipaddr);
            break;

          case RWREC_FIELD_INIT_FLAGS:
            if (skStringParseTCPFlags(&flags, cp)) {
                return -1;
            }
            rwRecSetInitFlags(&val->rec, flags);
            break;

          case RWREC_FIELD_REST_FLAGS:
            if (skStringParseTCPFlags(&flags, cp)) {
                return -1;
            }
            rwRecSetRestFlags(&val->rec, flags);
            break;

          case RWREC_FIELD_TCP_STATE:
            while (*cp) {
                switch (*cp) {
                  case 'F':
                    tcp_state |= (SK_TCPSTATE_FIN_FOLLOWED_NOT_ACK
                                  | SK_TCPSTATE_EXPANDED);
                    break;
                  case 'T':
                    tcp_state |= (SK_TCPSTATE_TIMEOUT_KILLED
                                  | SK_TCPSTATE_EXPANDED);
                    break;
                  case 'C':
                    tcp_state |= (SK_TCPSTATE_TIMEOUT_STARTED
                                  | SK_TCPSTATE_EXPANDED);
                    break;
                  case ' ':
                    break;
                  default:
                    return -1;
                }
                ++cp;
            }
            break;

          case RWREC_FIELD_APPLICATION:
            if (skStringParseUint32(&tmp32, cp, 0, UINT16_MAX)) {
                return -1;
            }
            rwRecSetApplication(&val->rec, (uint16_t)tmp32);
            break;

          case RWREC_FIELD_FTYPE_CLASS:
            val->class = cp;
            break;

          case RWREC_FIELD_FTYPE_TYPE:
            val->type = cp;
            break;

          default:
            abort();

        } /* switch */
    }

    /* handle class and type */
    if (val->class && val->type) {
        rwRecSetFlowType(&val->rec,
                         sksiteFlowtypeLookupByClassType(val->class,
                                                         val->type));
    }

    /* if no overall-flags but initial and session are given, compute
     * the overall flags */
    if (!rwRecGetFlags(&val->rec)) {
        rwRecSetFlags(&val->rec, (rwRecGetInitFlags(&val->rec)
                                  | rwRecGetRestFlags(&val->rec)));
    }

    /* set the EXPANDED flag on the TCP_STATE field if we have any
     * extra info */
    if (tcp_state ||rwRecGetInitFlags(&val->rec)||rwRecGetRestFlags(&val->rec))
    {
        tcp_state |= SK_TCPSTATE_EXPANDED;
    }
    rwRecSetTcpState(&val->rec, tcp_state);

    return 0;
}


/*
 *  ok = processFile(handle, name);
 *
 *    Read the records from the 'handle', create an rwRec from the
 *    fields on each line of the file, and write the records to the
 *    global out_ios stream.
 *
 *    Return 0 on success, non-zero on failure.
 */
static int processFile(FILE *handle, const char *filename)
{
#define PRINT_BAD_LINE                                                  \
    if (bad_stream == NULL) { /* empty */ } else {                      \
        fprintf(bad_stream, "%s:%lu:%s", filename, lineno, line_cpy);   \
    }


    static char line[2048];
    static char line_cpy[2048];
    unsigned long lineno = 0;
    parsed_values_t defaults;
    parsed_values_t currents;
    uint32_t *field_type = NULL;
    char **field_val = NULL;
    char *cp;
    char *ep;
    uint32_t field;
    int is_title = -1;

    /* read from handle until EOF */
    while (!feof(handle)) {
        if (!fgets(line, sizeof(line), handle)) {
            continue;
        }
        if (bad_stream) {
            ++lineno;
            strcpy(line_cpy, line);
        }
        ep = strchr(line, '\n');
        if (ep == line) {
            /* empty line; ignore */
            continue;
        }

        if (NULL != ep) {
            /* expected behavior: read an entire line */
            *ep = '\0';
        } else if (feof(handle)) {
            /* okay: last line did not end in newline */
        } else {
            /* bad: line was longer than sizeof(line).  read until newline
             * or eof, then throw away the line */
            if (bad_stream) {
                PRINT_BAD_LINE;
                fprintf(bad_stream, "...\n");
            }
            while (fgets(line, sizeof(line), handle) && !strchr(line, '\n'))
                ; /* empty */
            goto NEXT_LINE;
        }

        /* do special processing on first line in file */
        if (is_title < 0) {
            /* fill in the defaults */
            is_title = processFirstLine(&field_type, &field_val,
                                        &defaults, line);
            if (is_title < 0) {
                /* error */
                return 1;
            }
            if (is_title > 0) {
                /* goto next line */
                continue;
            }
        }

        /* We have a line; process it */
        cp = line;
        field = 0;
        memcpy(&currents, &defaults, sizeof(parsed_values_t));

        while (*cp) {
            if (field >= num_fields) {
                PRINT_BAD_LINE;
                goto NEXT_LINE;
            }

            /* find end of current field */
            ep = strchr(cp, column_separator);
            if (ep) {
                *ep = '\0';
            }

            field_val[field] = cp;
            ++field;

            if (NULL == ep) {
                /* at end of line; break out of while() */
                break;
            }

            /* we saw a column_separator earlier; goto next field */
            cp = ep + 1;
        } /* inner while over fields */

        if (field != num_fields) {
            PRINT_BAD_LINE;
            goto NEXT_LINE;
        }

        /* process fields */
        if (processFields(&currents, num_fields, field_type, field_val)) {
            PRINT_BAD_LINE;
            goto NEXT_LINE;
        }

        /* verify bytes */
        if (currents.bytes_equals_pkts) {
            rwRecSetBytes(&currents.rec, rwRecGetPkts(&currents.rec));
        }

        /* handle time */
        switch (currents.handle_time) {
          case CALC_STIME:
            rwRecSetStartTime(&currents.rec,
                              (currents.eTime
                               - rwRecGetElapsed(&currents.rec)));
            break;

          case CALC_ELAPSED:
            rwRecSetElapsed(&currents.rec,
                            (currents.eTime-rwRecGetStartTime(&currents.rec)));
            break;

          case CALC_NONE:
            break;
        }

        /* output binary rwrec */
        rwWrite(out_ios, &currents.rec);

      NEXT_LINE:
        ; /* empty */
    } /* outer loop over lines  */

    if (field_type) {
        free(field_type);
    }
    if (field_val) {
        free(field_val);
    }

    return 0;
}


int main(int argc, char **argv)
{
    int i;
    int rv = 0;
    int is_pipe;
    FILE *f;

    appSetup(argc, argv);                       /* never returns on error */

    if (argc == arg_index) {
        rv = processFile(stdin, "stdin");
    } else {
        for (i = arg_index; i < argc; ++i) {
            if (skOpenFile(argv[i], 0, &f, &is_pipe)) {
                skAppPrintErr("Unable to open %s", argv[i]);
                return 1;
            }
            rv = processFile(f, argv[i]);
            if (rv != 0) {
                break;
            }
            if (is_pipe) {
                pclose(f);
            } else {
                fclose(f);
            }
        }
    }

    /* if everything went well, make certain there are headers in our
     * output */
    if (rv == 0) {
        rv = rwioWriteHeader(out_ios);
        if (rv) {
            if (rv == SKSTREAM_ERR_PREV_DATA) {
                /* headers already printed */
                rv = 0;
            } else {
                rwioPrintLastErr(out_ios, rv, &skAppPrintErr);
            }
        }
    }

    return rv;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
