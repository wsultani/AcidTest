/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**
**  num2doc.c
**
**  Suresh L Konda
**  7/31/2002
**      "filter" to convert numeric ip to dotted ip. The default field
**      delimiter is '|' in deference to our internal default.  The
**      default field is 1 (numbering starts at 1).  Changes can be
**      provided via options --ip-fields=<range> and
**      --delimiter=<char>.
*/

#include "silk.h"

RCSIDENT("$SiLK: num2dot.c 11351 2008-04-23 21:50:59Z mthomas $");

#include "utils.h"


/* LOCAL DEFINES AND TYPEDEFS */

/* where to send usage output */
#define USAGE_FH stdout

#define MAX_FIELD_COUNT         15


/* LOCAL VARIABLES */

static uint8_t ipFields[3];             /* at most sIP,dIP,nhIP */
static uint8_t ipCount;                 /* # of above */
static char delimChar;                  /* field delimiter */


/* OPTIONS SETUP */

enum {
    N2D_IP_FIELDS, N2D_DELIMITER
};

static struct option appOptions[] = {
    {"ip-fields", REQUIRED_ARG, 0, N2D_IP_FIELDS},
    {"delimiter", REQUIRED_ARG, 0, N2D_DELIMITER},
    {0,0,0,0}     /* sentinel entry */
};

static const char *appHelp[] = {
    "IP number fields (starting at 1). Default 1",
    "which delimiter to use. Default |",
    (char *)NULL
};


/* LOCAL FUNCTION PROTOTYPES */

static void appUsageLong(void);
static void appTeardown(void);
static void appSetup(int argc, char **argv);
static int  appOptionsHandler(clientData cData, int opt_index, char *opt_arg);
static int  parseIPFields(const char *b);


/* FUNCTION DEFINITIONS */

/*
 *  appUsageLong();
 *
 *    Print complete usage information to USAGE_FH.  Pass this
 *    function to skOptionsSetUsageCallback(); skOptionsParse() will
 *    call this funciton and then exit the program when the --help
 *    option is given.
 */
static void appUsageLong(void)
{
#define USAGE_MSG                                                            \
    ("[SWITCHES]\n"                                                          \
     "\tRead pipe (|) delimited text from the standard input, convert\n"     \
     "\tinteger values in the specified column(s) (default first column)\n"  \
     "\tto dotted-decimal IP addresss, and print result to standard output.\n")

    FILE *fh = USAGE_FH;

    skAppStandardUsage(fh, USAGE_MSG, appOptions, appHelp);
}


/*
 *  appTeardown()
 *
 *    Teardown all modules, close all files, and tidy up all
 *    application state.
 *
 *    This function is idempotent.
 */
static void appTeardown(void)
{
    static int teardownFlag = 0;

    if (teardownFlag) {
        return;
    }
    teardownFlag = 1;

    skAppUnregister();
}


/*
 *  appSetup(argc, argv);
 *
 *    Perform all the setup for this application include setting up
 *    required modules, parsing options, etc.  This function should be
 *    passed the same arguments that were passed into main().
 *
 *    Returns to the caller if all setup succeeds.  If anything fails,
 *    this function will cause the application to exit with a FAILURE
 *    exit status.
 */
static void appSetup(int argc, char **argv)
{
    int arg_index;

    /* verify same number of options and help strings */
    assert((sizeof(appHelp)/sizeof(char *)) ==
           (sizeof(appOptions)/sizeof(struct option)));

    /* register the application */
    skAppRegister(argv[0]);
    skOptionsSetUsageCallback(&appUsageLong);

    /* initialize globals */
    memset(ipFields, 0, sizeof(ipFields));
    ipFields[0] = 1;
    ipCount = 1;
    delimChar = '|';

    /* register the options */
    if (skOptionsRegister(appOptions, &appOptionsHandler, NULL))
    {
        skAppPrintErr("Unable to register options");
        exit(EXIT_FAILURE);
    }

    /* parse options */
    arg_index = skOptionsParse(argc, argv);
    if (arg_index < 0) {
        skAppUsage();           /* never returns */
    }

    if (atexit(appTeardown) < 0) {
        skAppPrintErr("Unable to register appTeardown() with atexit()");
        appTeardown();
        exit(EXIT_FAILURE);
    }

    return;                     /* OK */
}


/*
 *  status = appOptionsHandler(cData, opt_index, opt_arg);
 *
 *    This function is passed to skOptionsRegister(); it will be called
 *    by skOptionsParse() for each user-specified switch that the
 *    application has registered; it should handle the switch as
 *    required---typically by setting global variables---and return 1
 *    if the switch processing failed or 0 if it succeeded.  Returning
 *    a non-zero from from the handler causes skOptionsParse() to return
 *    a negative value.
 *
 *    The clientData in 'cData' is typically ignored; 'opt_index' is
 *    the index number that was specified as the last value for each
 *    struct option in appOptions[]; 'opt_arg' is the user's argument
 *    to the switch for options that have a REQUIRED_ARG or an
 *    OPTIONAL_ARG.
 */
static int appOptionsHandler(
    clientData  UNUSED(cData),
    int         opt_index,
    char       *opt_arg)
{
    switch (opt_index) {
      case N2D_IP_FIELDS:
        /* ip fields */
        parseIPFields(opt_arg);          /* never returns on error */
        break;

      case N2D_DELIMITER:
        /* delimiter */
        delimChar = *opt_arg;
        if ('\0' == delimChar) {
            skAppPrintErr("Empty string not valid argument for --delimiter");
            return 1;
        }
        break;

      default:
        skAppPrintErr("Option %d not handled in switch() at %s:%d",
                      opt_index, __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }
    return 0;                   /* OK */
}


/*
 * parseIPFields:
 *      given a list (i.e., comma or - delimited set of numbers), set the
 *      element in fields to 1 if the fields are wanted.
 * Input:
 *      char *
 * Return:
 *      0 if OK. 1 else;
 * Side Effects:
 *      fields[]
 */
#define BUMP_IPFIELDCOUNT(f)                               \
    {                                                      \
        if (ipCount > 2) {                                 \
            skAppPrintErr("Too many ip fields given");     \
            exit(EXIT_FAILURE);                            \
        }                                                  \
        ipFields[ipCount++] = f;                           \
    }

static int parseIPFields(const char *b)
{
    int n, m, i;
    const char *sp;
    char *ep;
    sp = b;

    memset(ipFields, 0, sizeof(ipFields));
    ipCount = 0;
    while(*sp) {
        n = (int)strtol(sp, &ep, 10);
        if (n < 0 || n > MAX_FIELD_COUNT) {
            skAppPrintErr("Invalid ip field list %d", n+1);
            return 1;                   /* error */
        }
        BUMP_IPFIELDCOUNT(n);

        switch (*ep) {
          case ',':
            sp = ep + 1;
            break;

          case '-':
            sp = ep + 1;
            m = (int) strtoul(sp, &ep, 10);
            if (m <= n || m > MAX_FIELD_COUNT) {
                skAppPrintErr("Invalid ip field list %d", m);
                return 1;                       /* error */
            }
            /* start of range already record; record only the remainder */
            for (i = n+1; i <= m; i++) {
                BUMP_IPFIELDCOUNT(i);
            }
            if (*ep == '\0') {
                return 0;               /* OK */
            }
            if (*ep == ',') {
                sp = ep + 1;
            } else {
                skAppPrintErr("Invalid ip field list %d", n);
                return 1;                       /* error */
            }
            break;

          case '\0':
            return 0;

          default:
            skAppPrintErr("Invalid ip field list %s", b);
            return 1;                   /* error */
        }
    }

    return 0;                   /* OK */
}


int main(int argc, char **argv)
{
    char line[2048];
    register char *cp, *ep;
    int fn;
    uint32_t ip;

    appSetup(argc, argv);                       /* never returns */

    while (1) {
        if ( fgets(line, sizeof(line), stdin) == (char *)NULL) {
            break;
        }

        cp = line;
        fn = 0;
        if (*cp != delimChar) {
            /* trick to deal with the lack of a leading delimiter */
            cp--;
        }
        do {
            cp++;
            ep = strchr(cp, delimChar);
            fn++;                       /* next field # */
            if (ipFields[0] == fn ||ipFields[1] == fn ||ipFields[2] == fn) {
                ip = (unsigned int) strtoul(cp, (char **)NULL, 10);
                fprintf(stdout, "%15s%c", num2dot(ip),delimChar);
            } else {
                /* this is not a ip number field. dump it */
                if (!ep) {
                    /* to eol */
                    fprintf(stdout, "%s", cp);
                    if (cp[strlen(cp) -1] != '\n') {
                        fprintf(stdout, "\n");
                    }
                } else {
                    *ep = '\0';
                    fprintf(stdout, "%s%c", cp, delimChar);
                }
            }
            cp = ep;     /* point to the start of the next field */
        } while(cp);
    } /* outer loop over lines  */

    appTeardown();
    exit(EXIT_SUCCESS);
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
