/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
 * rwsetbuild.c
 *
 * Build an IP Set from textual data.
 */

#include "silk.h"

RCSIDENT("$SiLK: rwsetbuild.c 11041 2008-03-25 16:27:21Z mthomas $");

#include "iptree.h"
#include "skstream.h"
#include "sksite.h"


/* LOCAL DEFINES AND TYPEDEFS */

/* where to write output from --help */
#define USAGE_FH stdout

#define EXIT_NO_MEMORY                                               \
    do {                                                             \
        skAppPrintErr("Out of memory at %s:%d", __FILE__, __LINE__); \
        exit(EXIT_FAILURE);                                          \
    } while(0)


/* LOCAL VARIABLES */

/* the IPset the application creates. */
static skIPTree_t *ipset = NULL;

/* input and output streams */
static skstream_t *in_stream = NULL;
static skstream_t *out_stream = NULL;

/* the compression method to use when writing the file.
 * sksiteCompmethodOptionsRegister() will set this to the default or
 * to the value the user specifies. */
static sk_compmethod_t comp_method;

/* whether the input contains IP ranges; default 0 == no */
static int ip_ranges = 0;

/* the separator to use between the two IPs */
static char range_sep = '-';


/* OPTIONS SETUP */

typedef enum {
    OPT_IP_RANGES
} appOptionsEnum;

static struct option appOptions[] = {
    {"ip-ranges",       OPTIONAL_ARG, 0, OPT_IP_RANGES},
    {0,0,0,0}           /* sentinel entry */
};

static const char *appHelp[] = {
    ("Allow input to contain IP-IP or NUM-NUM. Def. No.\n"
     "\tUse of this switch disables support for SiLK Wildcard IPs"),
    (char *)NULL
};



/* LOCAL FUNCTION PROTOTYPES */

static void appUsageLong(void);
static void appTeardown(void);
static void appSetup(int argc, char **argv);
static int  appOptionsHandler(clientData cData, int opt_index, char *opt_arg);


/* FUNCTION DEFINITIONS */

/*
 *  appUsageLong();
 *
 *    Print complete usage information to USAGE_FH.  Pass this
 *    function to skOptionsSetUsageCallback(); skOptionsParse() will
 *    call this funciton and then exit the program when the --help
 *    option is given.
 */
static void appUsageLong(void)
{
#define USAGE_MSG                                                             \
    ("<INPUT_FILE> <OUTPUT_FILE>\n"                                           \
     "\tReads IP addresses in dotted-quad or CIDR notation from input-file\n" \
     "\tand writes a binary IPset file to output-file.  Use \"stdin\" as\n"   \
     "\tthe input-file to read the IPs from the standard input, and use\n"    \
     "\t\"stdout\" as the output-file to write the IPset to the standard\n"   \
     "\toutput when the standard output is not a terminal.\n")

    FILE *fh = USAGE_FH;

    skAppStandardUsage(fh, USAGE_MSG, appOptions, appHelp);
    skOptionsNotesUsage(fh);
    sksiteCompmethodOptionsUsage(fh);
}


/*
 *  appTeardown()
 *
 *    Teardown all modules, close all files, and tidy up all
 *    application state.
 *
 *    This function is idempotent.
 */
static void appTeardown(void)
{
    static int teardownFlag = 0;

    if (teardownFlag) {
        return;
    }
    teardownFlag = 1;

    if (ipset) {
        skIPTreeDelete(&ipset);
    }
    skStreamDestroy(&in_stream);
    skStreamDestroy(&out_stream);

    skAppUnregister();
}


/*
 *  appSetup(argc, argv);
 *
 *    Perform all the setup for this application include setting up
 *    required modules, parsing options, etc.  This function should be
 *    passed the same arguments that were passed into main().
 *
 *    Returns to the caller if all setup succeeds.  If anything fails,
 *    this function will cause the application to exit with a FAILURE
 *    exit status.
 */
static void appSetup(int argc, char **argv)
{
    const char *in_fname;
    const char *out_fname;
    int arg_index;
    int rv;

    /* verify same number of options and help strings */
    assert((sizeof(appHelp)/sizeof(char *)) ==
           (sizeof(appOptions)/sizeof(struct option)));

    /* register the application */
    skAppRegister(argv[0]);
    skOptionsSetUsageCallback(&appUsageLong);

    /* register the options */
    if (skOptionsRegister(appOptions, &appOptionsHandler, NULL)
        || skOptionsNotesRegister(NULL)
        || sksiteCompmethodOptionsRegister(&comp_method))
    {
        skAppPrintErr("Unable to register options");
        exit(EXIT_FAILURE);
    }

    /* parse the options */
    arg_index = skOptionsParse(argc, argv);
    if (arg_index < 0) {
        skAppUsage(); /* never returns */
    }

    /* get name of input file */
    if (arg_index == argc) {
        skAppPrintErr("Missing input and output file names");
        skAppUsage();
    }
    in_fname = argv[arg_index];
    ++arg_index;

    /* get name of output file */
    if (arg_index == argc) {
        skAppPrintErr("Missing output file name");
        skAppUsage();
    }
    out_fname = argv[arg_index];
    ++arg_index;

    /* check for extra arguments */
    if (arg_index != argc) {
        skAppPrintErr("Too many arguments or unrecognized switch '%s'",
                      argv[arg_index]);
        skAppUsage();
    }

    /* register the teardown function */
    if (atexit(appTeardown) < 0) {
        skAppPrintErr("Unable to register appTeardown() with atexit()");
        appTeardown();
        exit(EXIT_FAILURE);
    }

    /* create the IPset */
    if (skIPTreeCreate(&ipset)) {
        EXIT_NO_MEMORY;
    }

    /* open input */
    if ((rv = skStreamCreate(&in_stream, SK_IO_READ, SK_CONTENT_TEXT))
        || (rv = skStreamBind(in_stream, in_fname))
        || (rv = skStreamSetCommentStart(in_stream, "#"))
        || (rv = skStreamOpen(in_stream)))
    {
        skStreamPrintLastErr(in_stream, rv, &skAppPrintErr);
        exit(EXIT_FAILURE);
    }

    /* open output */
    if ((rv = skStreamCreate(&out_stream, SK_IO_WRITE, SK_CONTENT_SILK))
        || (rv = skStreamBind(out_stream, out_fname))
        || (rv = skStreamSetCompressionMethod(out_stream, comp_method))
        || (rv = skStreamOpen(out_stream)))
    {
        skStreamPrintLastErr(out_stream, rv, &skAppPrintErr);
        exit(EXIT_FAILURE);
    }

    /* add notes if given */
    rv = skOptionsNotesAddToStream(out_stream);
    if (rv) {
        skStreamPrintLastErr(out_stream, rv, &skAppPrintErr);
        exit(EXIT_FAILURE);
    }
    skOptionsNotesTeardown();

    return;
}


/*
 *  status = appOptionsHandler(cData, opt_index, opt_arg);
 *
 *    This function is passed to skOptionsRegister(); it will be called
 *    by skOptionsParse() for each user-specified switch that the
 *    application has registered; it should handle the switch as
 *    required---typically by setting global variables---and return 1
 *    if the switch processing failed or 0 if it succeeded.  Returning
 *    a non-zero from from the handler causes skOptionsParse() to return
 *    a negative value.
 *
 *    The clientData in 'cData' is typically ignored; 'opt_index' is
 *    the index number that was specified as the last value for each
 *    struct option in appOptions[]; 'opt_arg' is the user's argument
 *    to the switch for options that have a REQUIRED_ARG or an
 *    OPTIONAL_ARG.
 */
static int appOptionsHandler(
    clientData  UNUSED(cData),
    int         opt_index,
    char       *opt_arg)
{
    switch ((appOptionsEnum)opt_index) {
      case OPT_IP_RANGES:
        ip_ranges = 1;
        if (opt_arg && opt_arg[0]) {
            range_sep = opt_arg[0];
        }
        break;
    }

    return 0;
}


/*
 *  buildIPTreeFromStream(stream);
 *
 *    Read IP addresses from the stream named by 'stream' and use them
 *    to build the global ipset.  Return 0 on success or -1 on
 *    failure.
 */
static int buildIPTreeFromStream(skstream_t *stream)
{
    int lc = 0;
    char line_buf[512];
    char *sep;
    skIPWildcard_t ipwild;
    skipaddr_t ip;
    skipaddr_t ip_min;
    skipaddr_t ip_max;
    uint32_t cidr;
    uint32_t min;
    uint32_t max;
    int rv;

    /* read until end of file */
    while ((rv = skStreamGetLine(stream, line_buf, sizeof(line_buf), &lc))
           != SKSTREAM_ERR_EOF)
    {
        switch (rv) {
          case SKSTREAM_OK:
            /* good, we got our line */
            break;
          case SKSTREAM_ERR_LONG_LINE:
            /* bad: line was longer than sizeof(line_buf) */
            skAppPrintErr("Input line %d too long. ignored",
                          lc);
            continue;
          default:
            /* unexpected error */
            skStreamPrintLastErr(stream, rv, &skAppPrintErr);
            goto END;
        }

        if (ip_ranges) {
            /* support whitespace separators */
            if (!isspace((int)range_sep)) {
                sep = strchr(line_buf, range_sep);
            } else {
                /* ignore leading whitespace */
                sep = line_buf;
                while (isspace((int)*sep)) {
                    ++sep;
                }
                sep = strchr(sep, range_sep);
                if (sep) {
                    /* allow a lone IP to have trailing whitespace */
                    char *cp = sep;
                    while (isspace((int)*cp)) {
                        ++cp;
                    }
                    if (*cp == '\0') {
                        sep = NULL;
                    }
                }
            }
            if (sep == NULL) {
                /* parse as IP with possible CIDR designation */
                rv = skStringParseCIDR(&ip, &cidr, line_buf);
                if (rv != 0) {
                    skAppPrintErr("Invalid IP on line %d: %s",
                                  lc, skStringParseStrerror(rv));
                    goto END;
                }
                skCIDR2IPRange(&ip, cidr, &ip_min, &ip_max);
            } else {
                /* parse two IP addresses */
                *sep = '\0';
                ++sep;
                rv = skStringParseIP(&ip_min, line_buf);
                if (rv != 0) {
                    skAppPrintErr("Invalid minimum IP on line %d: %s",
                                  lc, skStringParseStrerror(rv));
                    goto END;
                }
                rv = skStringParseIP(&ip_max, sep);
                if (rv != 0) {
                    skAppPrintErr("Invalid maximum IP on line %d: %s",
                                  lc, skStringParseStrerror(rv));
                    goto END;
                }
            }

#if SK_ENABLE_IPV6
            if (skipaddrIsV6(&ip_min)) {
                continue;
            }
            if (skipaddrIsV6(&ip_max)) {
                continue;
            }
#endif /* SK_ENABLE_IPV6 */
            min = skipaddrGetV4(&ip_min);
            max = skipaddrGetV4(&ip_max);
            if (min > max) {
                skAppPrintErr("Invalid IP range on line %d: min > max",
                              lc);
                rv = -1;
                goto END;
            }
            /* use strict < here to avoid rollover issue */
            for ( ; min < max; ++min) {
                rv = skIPTreeAddAddress(ipset, min);
                if (rv) {
                    skAppPrintErr("Error adding IP to IPset: %s",
                                  skIPTreeStrError(rv));
                    goto END;
                }
            }
            rv = skIPTreeAddAddress(ipset, max);
            if (rv) {
                skAppPrintErr("Error adding IP to IPset: %s",
                              skIPTreeStrError(rv));
                goto END;
            }
        } else {
            /* parse the line: fill in octet_bitmap */
            rv = skStringParseIPWildcard(&ipwild, line_buf);
            if (rv != 0) {
                skAppPrintErr("Invalid IP on line %d: %s",
                              lc, skStringParseStrerror(rv));
                goto END;
            }
#if SK_ENABLE_IPV6
            if (skIPWildcardIsV6(&ipwild)) {
                continue;
            }
#endif /* SK_ENABLE_IPV6 */

            rv = skIPTreeAddIPWildcard(ipset, &ipwild);
            if (rv) {
                skAppPrintErr("Error adding IP to IPset: %s",
                              skIPTreeStrError(rv));
                goto END;
            }
        }
    }

    /* success */
    rv = 0;

  END:
    if (rv != 0) {
        return -1;
    }
    return 0;
}


int main(int argc, char **argv)
{
    appSetup(argc, argv);

    /* read input file */
    if (buildIPTreeFromStream(in_stream)) {
        return -1;
    }

    /* write output to stream */
    if (skIPTreeWrite(ipset, out_stream)) {
        return -1;
    }

    skStreamDestroy(&in_stream);
    skStreamDestroy(&out_stream);

    /* done */
    return 0;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
