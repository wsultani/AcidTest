/*
** Copyright (C) 2006-2007 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/
#ifndef _SKTHREAD_H
#define _SKTHREAD_H

#include "silk.h"
#include "sklog.h"

RCSIDENTVAR(rcsID_SKTHREAD_H, "$SiLK: skthread.h 8622 2007-08-24 17:14:55Z mthomas $");

/*
**  skthread.h
**
**  Common thread routines.
**
*/

/* Intitialize the skthread module.  Sets the name of the current
   thread to `name'.   Returns 0 on success, -1 on failure. */
int skthread_init(const char *name);

/* Creates a simple thread with a given name.  Returns 0 on success,
   errno on failure. */
int skthread_create(
    const char *name,
    pthread_t *thread,
    void *(*fn)(void *),
    void *arg);

/* Creates a simple detatched thread with a given name.  Returns 0 on
   success, errno on failure. */
int skthread_create_detatched(
    const char *name,
    pthread_t *thread,
    void *(*fn)(void *),
    void *arg);

/* Returns the name of the calling thread. */
const char *skthread_name(void);

/* Returns the id of the calling thread. */
uint32_t skthread_id(void);
#define SKTHREAD_UNKNOWN_ID UINT32_MAX

/* Logging debugging */
#define SKTHREAD_DEBUG_PRINT1(x)                \
    DEBUGMSG("%s:%d <%s:%" PRId32 "> " x,       \
             __FILE__, __LINE__,                \
             skthread_name(), skthread_id())
#define SKTHREAD_DEBUG_PRINT2(x, y)             \
    DEBUGMSG("%s:%d <%s:%" PRId32 "> " x,       \
             __FILE__, __LINE__,                \
             skthread_name(), skthread_id(),    \
             (y))
#define SKTHREAD_DEBUG_PRINT3(x, y, z)          \
    DEBUGMSG("%s:%d <%s:%" PRId32 "> " x,       \
             __FILE__, __LINE__,                \
             skthread_name(),                   \
             skthread_id(),                     \
             (y), (z))
#define SKTHREAD_DEBUG_PRINT4(x, y, z, zz)      \
    DEBUGMSG("%s:%d <%s:%" PRId32 "> " x,       \
             __FILE__, __LINE__,                \
             skthread_name(),                   \
             skthread_id(),                     \
             (y), (z), (zz))


/* Mutex debugging */

#ifndef SKTHREAD_DEBUG_MUTEX

#define MUTEX_LOCK pthread_mutex_lock
#define MUTEX_UNLOCK pthread_mutex_unlock
#define MUTEX_WAIT pthread_cond_wait
#define MUTEX_SIGNAL pthread_cond_signal
#define MUTEX_BROADCAST pthread_cond_broadcast

#else  /* SKTHREAD_DEBUG_MUTEX */

/* Wrapper around pthread_mutex_lock */
#define MUTEX_LOCK(x)                                           \
    do {                                                        \
        SKTHREAD_DEBUG_PRINT2("MUTEX LOCKING %p", (void*)x);    \
        pthread_mutex_lock(x);                                  \
        SKTHREAD_DEBUG_PRINT2("MUTEX IN LOCK %p", (void*)x);    \
    } while (0)

/* Wrapper around pthread_mutex_unlock */
#define MUTEX_UNLOCK(x)                                        \
    do {                                                       \
        SKTHREAD_DEBUG_PRINT2("MUTEX UNLOCKING %p", (void*)x); \
        pthread_mutex_unlock(x);                               \
    } while (0)

/* Wrapper around pthread_cond_wait */
#define MUTEX_WAIT(x, y)                                                \
    do {                                                                \
        SKTHREAD_DEBUG_PRINT3("MUTEX WAIT %p (Unlocked %p)",            \
                              (void*)x, (void*)y);                      \
        pthread_cond_wait(x, y);                                        \
        SKTHREAD_DEBUG_PRINT2("MUTEX RESUME (Locked %p)", (void*)y);    \
    } while (0)

/* Wrapper around pthread_cond_signal */
#define MUTEX_SIGNAL(x)                                         \
    do {                                                        \
        SKTHREAD_DEBUG_PRINT2("SIGNALLING %p", (void*)x);       \
        pthread_cond_signal(x);                                 \
    } while (0)


/* Wrapper around pthread_cond_broadcast */
#define MUTEX_BROADCAST(x)                                      \
    do {                                                        \
        SKTHREAD_DEBUG_PRINT2("BROADCASTING %p", (void*)x);     \
        pthread_cond_broadcast(x);                              \
    } while (0)

#endif  /* SKTHREAD_DEBUG_MUTEX */


#endif /* _SKTHREAD_H */


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
