/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/
#ifndef _RWPACK_H
#define _RWPACK_H

#include "silk.h"

RCSIDENTVAR(rcsID_RWPACK_H, "$SiLK: rwpack.h 10925 2008-03-14 17:47:45Z mthomas $");

#include "rwrec.h"
#include "skstream.h"
#include "skiobuf.h"
#include "skstringmap.h"


#define rwIOStruct    skstream_t
#define rwIOStruct_t  skstream_t
#define rwIOStructPtr skstream_t*


#define RWIO_ERROR_IS_FATAL(err)   SKSTREAM_ERROR_IS_FATAL(err)


/* macros for accessing header fields */
#define rwGetFileName(rwIOS)        skStreamGetPathname(rwIOS)
#define rwGetHeader(rwIOS)          skStreamGetSilkHeader(rwIOS)

#define rwioClose(rwIOS)            skStreamClose(rwIOS)
#define rwioDestroy(rwIOS)          skStreamDestroy(rwIOS)

#define rwioReadRecord(rwIOS, rec)  skStreamReadRecord((rwIOS), (rec))
#define rwioWriteRecord(rwIOS, rec) skStreamWriteRecord((rwIOS), (rec))

#define rwioWriteHeader(rwIOS)      skStreamWriteSilkHeader(rwIOS)

#define rwioPrintLastErr            skStreamPrintLastErr

#define rwioSetCompression(rwIOS, comp_method)                          \
    skHeaderSetCompressionMethod(rwGetHeader(rwIOS), (comp_method))


int rwioCreate(
    rwIOStruct    **rwIOS,
    const char     *pathname,
    skstream_mode_t read_write_append);
/*
 *    Create a new rwio Stream at the location pointed to by rwIOS.
 *    The new stream is bound to the file at 'pathname', and is
 *    created for read (SK_IO_READ), write (SK_IO_WRITE), or append
 *    (SK_IO_APPEND) according to the value in 'read_write_append'.
 *
 *    For write, the file's format is set to the default version of
 *    FT_RWGENERIC using the machine's native byte order and the
 *    default compression specified when SiLK was configured.
 *
 *    The function returns a value defined in rwioErrorCodes_t.
 */




int rwioOpen(
    rwIOStruct     *rwIOS);
/*
 *    Open the pathname that 'rwIOS' is bound to.  For an 'rwIOS' that
 *    were created for read or append, this will read the file's
 *    header.
 *
 *    The function returns a value defined in rwioErrorCodes_t.
 */



/* Older API */
#define rwRead(rwIOS, rec)      (!(skStreamReadRecord((rwIOS), (rec))))
#define rwWrite(rwIOS, rec)     skStreamWriteRecord((rwIOS), (rec))

rwIOStruct *rwOpenFile(const char *fPath, rwIOStruct *copyInput);
/*
 *  rwIOSPtr = rwOpenFile(filename, copy_stream);
 *
 *    Open the given file 'filename' and based on the header
 *    information setup everything we need to read through the file
 *    always returning rwRec.
 *
 *    If 'copy_stream' is not-NULL, it should be an open rwIOStruct*
 *    stream to copy the input to.
 *
 *    Return a pointer to a new struct to contain all the information
 *    needed to traverse the file.  Return NULL on error.
 *
 *    If 'filename' is "stdin", then read binary input stream from
 *    stdin.
 */


#define rwCloseFile(rwio)                                       \
    (((rwio) == NULL) ? RWIO_OK : rwioDestroy(&(rwio)))



/* ***  Printing rwRec as ASCII  *** */

/* Number of fields we can print; should be one more than the last ID
 * in rwrec_printable_fields_t */
#define  RWREC_PRINTABLE_FIELD_COUNT  25

/* Maximum width of the name of a field */
#define RWREC_PRINTABLE_MAX_NAME_LEN 16

/* An identifier for each field */
typedef enum {
    RWREC_FIELD_SIP,
    RWREC_FIELD_DIP,
    RWREC_FIELD_SPORT,
    RWREC_FIELD_DPORT,
    RWREC_FIELD_PROTO,
    RWREC_FIELD_PKTS,
    RWREC_FIELD_BYTES,
    RWREC_FIELD_FLAGS,
    RWREC_FIELD_STIME,
    RWREC_FIELD_ELAPSED,
    RWREC_FIELD_ETIME,
    RWREC_FIELD_SID,
    RWREC_FIELD_INPUT,
    RWREC_FIELD_OUTPUT,
    RWREC_FIELD_NHIP,
    RWREC_FIELD_INIT_FLAGS,
    RWREC_FIELD_REST_FLAGS,
    RWREC_FIELD_TCP_STATE,
    RWREC_FIELD_APPLICATION,
    RWREC_FIELD_FTYPE_CLASS,
    RWREC_FIELD_FTYPE_TYPE,
    RWREC_FIELD_STIME_MSEC,
    RWREC_FIELD_ETIME_MSEC,
    RWREC_FIELD_ELAPSED_MSEC,
    RWREC_FIELD_ICMP_TYPE_CODE
} rwrec_printable_fields_t;

/* A type for printing records as ASCII.  Created via
 * rwAsciiStreamCreate() */
typedef struct rwAsciiStream_st rwAsciiStream_t;

int rwAsciiStreamCreate(rwAsciiStream_t **stream);
/*
 *  Create a new output stream for printing rwRec records in a human
 *  readable form. Store the newly allocated rwAsciiStream_t in the
 *  memory pointed to by **stream.  Return 0 on success or non-zero if
 *  allocation fails.
 *
 *  The caller may immediately call rwAsciiPrintRec() to print records
 *  to the stream, or the caller may use the functions listed below to
 *  change the defaults.  Calling an rwAsciiSet*() function once
 *  titles or records have been printed may result in strange output.
 *
 *  The defaults are (function that modifies this behavior):
 *  -- Output is sent to the standard output (rwAsciiSetOutputHandle)
 *  -- All fields are printed (rwAsciiSetFields)
 *  -- Column titles are printed before first record (rwAsciiSetNoTitles)
 *  -- Fields are printed in a columnar format (rwAsciiSetNoColumns)
 *  -- Delimiter between columns is '|'
 *  -- A delimiter is printed after the final column
 *     (rwAsciiSetNoFinalDelimiter)
 *  -- A newline is printed after final column (rwAsciiSetNoNewline)
 *  -- IPs are printed in dotted quad (rwAsciiSetIntegerIps,
 *     rwAsciiSetZeroPadIps)
 *  -- Sensor names are printed (rwAsciiSetIntegerSensors)
 *  -- No special handling of ICMP (rwAsciiSetIcmpTypeCode)
 */

void rwAsciiStreamDestroy(rwAsciiStream_t **stream);
/*
 *    Free all memory associated with the stream.  It is the caller's
 *    responsibility to fflush() the underlying file pointer.
 */

void rwAsciiPrintRec(
    rwAsciiStream_t    *stream,
    const rwRec        *rwrec);
/*
 *    Print 'rwrec' in a human-readable form to 'stream'.  Will print
 *    the column titles when the stream is configured to have titles
 *    and the titles have not yet been printed.
 */

void rwAsciiPrintTitles(rwAsciiStream_t *stream);
/*
 *    Print the column titles when the stream is configured to have
 *    titles and they have not been printed.
 */

void rwAsciiSetOutputHandle(rwAsciiStream_t *stream, FILE *fh);
/*
 *    Configure the 'stream' to print the output to 'fh'.  If 'fh' is
 *    NULL, stdout is used.
 */

int rwAsciiSetFields(
    rwAsciiStream_t    *stream,
    const uint32_t     *field_list,
    uint32_t            field_count);
/*
 *    Configure the 'stream' to print the fields listed in
 *    'field_list', which is an array of 'field_count' elements.  If
 *    field_list is NULL or field_count is 0, returns non-zero.  Any
 *    previously configured field_list will be lost.
 */

void rwAsciiSetNoTitles(rwAsciiStream_t *stream);
/*
 *    Configure the 'stream' not to print titles before the first
 *    record of output.
 */

void rwAsciiSetDelimiter(rwAsciiStream_t *stream, char delimiter);
/*
 *    Configure the 'stream' to put the character 'delimiter' between
 *    columns.  Does not effect the columnar setting.
 */

void rwAsciiSetNoColumns(rwAsciiStream_t *stream);
/*
 *    Configure the 'stream' not to use fixed size columns.  This
 *    avoids extra whitespace, but makes the output difficult for
 *    humans to read.
 */

void rwAsciiSetNoNewline(rwAsciiStream_t *stream);
/*
 *    Configure the 'stream' not to print a newline after the final
 *    field.
 */

void rwAsciiSetNoFinalDelimiter(rwAsciiStream_t *stream);
/*
 *    Configure the 'stream' not to print a delimiter after the final
 *    field.
 */

void rwAsciiSetIPv6Policy(rwAsciiStream_t *stream, sk_ipv6policy_t policy);
/*
 *    Configure how the 'stream' handles IPv6 flows.
 *
 *    CURRENTLY THIS IS USED ONLY TO DETERMINE THE COLUMN WIDTH OF IP
 *    COLUMNS.
 */

void rwAsciiSetIntegerIps(rwAsciiStream_t *stream);
/*
 *    Configure the 'stream' to print IP addresses as integers (0)
 *    instead of as dotted quad (0.0.0.0).  This function will
 *    override rwAsciiSetZeroPadIps().
 */

void rwAsciiSetZeroPadIps(rwAsciiStream_t *stream);
/*
 *    Configure the 'stream' to print each octet of an IP with extra
 *    0's; e.g., print "10.1.2.3" as "010.001.002.003"; useful for
 *    sorting with text-based sortes.  rwAsciiSetIntegerIps() will
 *    override this function.
 */

void rwAsciiSetTimestampFlags(rwAsciiStream_t *stream, uint32_t time_flags);
/*
 *    Set the argument that the 'stream' will pass to sktimestamp() to
 *    print the times.
 */

void rwAsciiSetIntegerSensors(rwAsciiStream_t *stream);
/*
 *    Configure the 'stream' to print sensors as integers.  Usually
 *    the name of the sensor is printed.
 */

void rwAsciiSetIcmpTypeCode(rwAsciiStream_t *stream);
/*
 *    Configure the 'stream' to use a slightly different output for
 *    ICMP records (proto==1); when active and an ICMP record is given
 *    (proto==1), the sPort and dPort columns will hold the ICMP type
 *    and code, respectively.
 */

void rwAsciiGetFieldName(
    char                       *buf,
    size_t                      buf_len,
    rwrec_printable_fields_t    field_id);
/*
 *    Put the first 'buf_len'-1 characters of the name of the
 *    field/column denoted by 'field_id' into the buffer 'buf'.  The
 *    caller should ensure that 'buf' is 'buf_len' characters long.
 *
 *    A 'buf' of at least RWREC_PRINTABLE_MAX_NAME_LEN characters will
 *    be large enough to hold the entire field name.
 */

int rwAsciiFlush(rwAsciiStream_t *stream);
/*
 *    Call flush() on the I/O object that 'stream' wraps.
 */

typedef enum {
    RW_ASCII_DUPES_KEEP = 0,
    RW_ASCII_DUPES_REMOVE_SILENT,
    RW_ASCII_DUPES_REMOVE_WARN,
    RW_ASCII_DUPES_ERROR
} rwascii_dupes_t;

void rwAsciiFieldMapPrintUsage(FILE *fh, sk_stringmap_t *field_map);

int rwAsciiFieldMapAddDefaultFields(sk_stringmap_t **field_map);

int rwAsciiFieldMapParseFields(
    uint32_t              **field_list,
    uint32_t               *field_count,
    const char             *input,
    const sk_stringmap_t   *field_map,
    rwascii_dupes_t         handle_dupes);

int rwAsciiParseFieldList(
    rwrec_printable_fields_t  **field_ids,
    uint32_t                   *field_count,
    const char                 *field_string);
/* NOT IMPLEMENTED FULLY */



#endif /* _RWPACK_H */

/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
