/*
** Copyright (C) 2006-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/
#ifndef _POLLDIR_H
#define _POLLDIR_H

#include "silk.h"

RCSIDENTVAR(rcsID_POLLDIR_H, "$SiLK: skpolldir.h 10004 2008-01-04 23:08:59Z mthomas $");

/*
**  polldir.h
**
**  Library for polling directories for new files
**
*/

#include "skdeque.h"

/* Add additional #includes and your protypes/types/#defines here */

/* The type of directory polling objects. */
typedef struct sk_polldir_st *skPollDir_t;
typedef struct sk_polldir_queue_st *skPollDirQueue_t;

/* The type of polldir errors */
typedef enum { PDERR_NONE = 0, PDERR_MEMORY, PDERR_FILESYSTEM } skpdErr_t;

/* Create a directory polling queue. */
skPollDirQueue_t skPollDirQueueCreate(void);

/* Destroy a directory polling queue. */
void skPollDirQueueDestroy(skPollDirQueue_t queue);


/* Create a directory polling object.
 *
 *   Creates a polldir object for directory.  The poll_interval is the
 *   number of seconds between polls of the directory for new files.
 *   The queue argument is used to synchronize the return of files
 *   from multiple polldir objects; i.e., to allow one to monitor
 *   several directories simultaneously.
 */
skPollDir_t skPollDirCreate(
    const char      *directory,
    uint32_t         poll_interval,
    skPollDirQueue_t queue);

/* Destroy a directory polling object. */
void skPollDirDestroy(skPollDir_t pd);

/* Get the next added filename entry to a directory.
 *
 *   This function blocks on the existance of a new file entry to the
 *   polldir directory.  The buffer 'path' will be filled with the
 *   full path to the file entry.  It is up to the caller to make sure
 *   that 'path' is at least PATH_MAX bytes in size.  If
 *   'filename_ptr' is non-NULL, it will set it to point to the
 *   position in 'path' where the filename begins.
 *
 *   If the polldir object is destroyed, returns 1. If an error
 *   occurs, returns -1.  Otherwise returns 0.
 */
int skPollDirGetNextFile(
    skPollDirQueue_t queue,
    char *path,
    char **filename_ptr);


/* Get the error state of a polldir object. */
skpdErr_t skPollDirGetError(skPollDir_t pd);

/* Get the directory being polled by a polldir object. */
const char *skPollDirGetDir(skPollDir_t pd);

#endif /* _POLLDIR_H */

/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
