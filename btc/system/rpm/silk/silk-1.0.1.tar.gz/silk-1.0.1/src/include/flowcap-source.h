/*
** Copyright (C) 2005-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/
#ifndef _FLOWCAP_SOURCE_H
#define _FLOWCAP_SOURCE_H

#include "silk.h"

RCSIDENTVAR(rcsID_FLOWCAP_SOURCE_H, "$SiLK: flowcap-source.h 10960 2008-03-19 19:08:22Z mthomas $");

#include "rwrec.h"
#include "probeconf.h"


/*
**  flowcap-source.h
**
**  Interface to pull a single flow from a flowcap file.
**
*/

/* The type of flowcap sources */
typedef struct flowcap_source_st *flowcapSource_t;


/*
 *    Creates a flowcap source from a path.  Returns NULL for the
 *    following error conditions:
 *
 *    -- 'path' is NULL.
 *    -- unable to open file
 *    -- file is not a valid SiLK file
 *    -- file does not contain a Probename Header
 *    -- the probe_name does not map to a valid probe in probeconf
 *
 *    NOTES:
 *
 *    Flowcap V16 files have the probe name in the header.
 *
 *    Flowcap Files V2-V5 have the sensor name and probe name in the
 *    header.  When these are processed in SiLK 1.0, these get mapped
 *    to the probe name "<sensor>_<probe>".
 *
 *    Flowcap Files V1 have no probe information and are no longer
 *    supported.
 */
flowcapSource_t flowcapSourceCreateFromFile(
    const char *path);

/*
 *    Returns the path name that was passed into
 *    flowcapSourceCreateFromFile().  Returns NULL if the
 *    flowcapSource_t was not created from a file.
 */
const char *flowcapSourceFileName(const flowcapSource_t source);


/*
 *    Returns the probe object associated a flowcap source.  This will
 *    only return NULL when 'source' is NULL.
 */
const skpc_probe_t *flowcapSourceGetProbe(const flowcapSource_t source);

/*
 *    Returns the number of records processed (so far) from the
 *    flowcap source (0 if error).
 */
uint32_t flowcapSourceNumRecs(const flowcapSource_t source);


/*
 *    Closes the flowcap source.
 */
int flowcapSourceClose(flowcapSource_t source);


/*
 *    Destroys a flowcap source.
 */
void flowcapSourceDestroy(flowcapSource_t source);


/*
 *    Gets a single record from a flowcap source.  Returns -1 on EOF
 *    or error, 0 on success.
 */
int flowcapSourceGetGeneric(
    flowcapSource_t source,
    rwRec          *rec);

#endif /* _FLOWCAP_SOURCE_H */

/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
