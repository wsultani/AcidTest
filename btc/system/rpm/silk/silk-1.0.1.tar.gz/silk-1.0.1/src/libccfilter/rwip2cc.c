/*
** Copyright (C) 2004-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  rwip2cc.c
**
**  Mark Thomas
**
**  Small application to read in IP addresses and print out the
**  corresponding country code.  Can read addresses from the command
**  line, from a file, or from stdin.  One can specify the map file on
**  the command line, or it will use the default.  Probably knows more
**  about the country code map than it should.
**
**  Based on
**
**      skprefixmap-test.c by John McClary Prevost, December 3rd, 2004
*/


#include "silk.h"

RCSIDENT("$SiLK: rwip2cc.c 10649 2008-02-26 12:41:33Z mthomas $");

#include "utils.h"
#include "ccfilter_priv.h"

/* LOCAL DEFINES AND TYPEDEFS */

/* where to write --help output */
#define USAGE_FH stdout

/* value signaling an unset IP address */
#define ADDRESS_UNSET 0xFFFFFFFF

/* convert integer to country code */
#define PRINT_INT_AS_CC(out, val)                                       \
    do {                                                                \
        int len;                                                        \
        char buffer[32];                                                \
        CODE_TO_CC(len, buffer, sizeof(buffer), (val));                 \
        fprintf((out), "%s\n", buffer);                                 \
    } while(0)


/* LOCAL VARIABLES */

/* the output stream */
static FILE *outf;

/* the map file location */
static char map_path[PATH_MAX];


/* OPTIONS SETUP */

typedef enum {
    OPT_MAP_FILE, OPT_ADDRESS, OPT_INPUT_FILE
} appOptionsEnum;

static struct option appOptions[] = {
    {"map-file",        REQUIRED_ARG, 0, OPT_MAP_FILE},
    {"address",         REQUIRED_ARG, 0, OPT_ADDRESS},
    {"input-file",      REQUIRED_ARG, 0, OPT_INPUT_FILE},
    {0,0,0,0}           /* sentinel entry */
};

static const char *appHelp[] = {
    "Path name of the map file.",
    "IP address to look up",
    ("Path from which to read IP addresses, one per line\n"
     "\tUse \"stdin\" to read from the standard input"),
    (char *)NULL
};

static struct {
    /* filename of map file */
    const char *map_file;
    /* IP address to look up */
    uint32_t    address;
    /* filename to read IPs from */
    const char *input_file;
} app_opt = {
    NULL, ADDRESS_UNSET, NULL
};



/* LOCAL FUNCTION PROTOTYPES */

static void appUsageLong(void);
static void appTeardown(void);
static void appSetup(int argc, char **argv);
static int  appOptionsHandler(clientData cData, int opt_index, char *opt_arg);
static int  processInputFile(FILE *in, skPrefixMap_t *prefix_map);


/* FUNCTION DEFINITIONS */

/*
 *  appUsageLong();
 *
 *    Print complete usage information to USAGE_FH.  Pass this
 *    function to skOptionsSetUsageCallback(); skOptionsParse() will
 *    call this funciton and then exit the program when the --help
 *    option is given.
 */
static void appUsageLong(void)
{
#define USAGE_MSG                                                            \
    ("[SWITCHES]\n"                                                          \
     "\tMaps from IP address to country code using the specified MAP file\n" \
     "\tor the default map. Either one or more addresses must be specified\n")

    FILE *fh = USAGE_FH;

    skAppStandardUsage(fh, USAGE_MSG, appOptions, appHelp);
}


/*
 *  appTeardown()
 *
 *    Teardown all modules, close all files, and tidy up all
 *    application state.
 *
 *    This function is idempotent.
 */
static void appTeardown(void)
{
    static int teardownFlag = 0;

    if (teardownFlag) {
        return;
    }
    teardownFlag = 1;

    skAppUnregister();
}


/*
 *  appSetup(argc, argv);
 *
 *    Perform all the setup for this application include setting up
 *    required modules, parsing options, etc.  This function should be
 *    passed the same arguments that were passed into main().
 *
 *    Returns to the caller if all setup succeeds.  If anything fails,
 *    this function will cause the application to exit with a FAILURE
 *    exit status.
 */
static void appSetup(int argc, char **argv)
{
    int arg_index;

    /* verify same number of options and help strings */
    assert((sizeof(appHelp)/sizeof(char *)) ==
           (sizeof(appOptions)/sizeof(struct option)));

    /* register the application */
    skAppRegister(argv[0]);
    skOptionsSetUsageCallback(&appUsageLong);

    /* initialize globals */
    outf = stdout;

    /* register the options */
    if (skOptionsRegister(appOptions, &appOptionsHandler, NULL))
    {
        skAppPrintErr("Unable to register options");
        exit(EXIT_FAILURE);
    }

    /* parse the options */
    arg_index = skOptionsParse(argc, argv);
    if (arg_index < 0) {
        /* options parsing should print error */
        skAppUsage();           /* never returns */
    }

    /* check for extraneous arguments */
    if (arg_index != argc) {
        skAppPrintErr("Too many arguments or unrecognized switch '%s'",
                      argv[arg_index]);
        skAppUsage();             /* never returns */
    }

    if (NULL != app_opt.map_file) {
        strncpy(map_path, app_opt.map_file, sizeof(map_path));
        if ('\0' != map_path[sizeof(map_path)-1]) {
            skAppPrintErr("Path name to --%s switch is too long",
                          appOptions[OPT_MAP_FILE].name);
            exit(EXIT_FAILURE);
        }
    } else {
        if (NULL == skFindFile(DEFAULT_CCFILTER_FILENAME,
                               map_path, sizeof(map_path), 0))
        {
            skAppPrintErr(("Could not locate default map file '%s'\n"
                           "\tand the --%s switch was not provided."),
                          DEFAULT_CCFILTER_FILENAME,
                          appOptions[OPT_MAP_FILE].name);
            exit(EXIT_FAILURE);
        }
    }

    if (NULL != app_opt.input_file) {
        if (ADDRESS_UNSET != app_opt.address) {
            skAppPrintErr("Only one of --%s or --%s may be specified.",
                          appOptions[OPT_ADDRESS].name,
                          appOptions[OPT_INPUT_FILE].name);
            skAppUsage();
        }
    } else if (ADDRESS_UNSET == app_opt.address) {
        skAppPrintErr("Either the --%s or --%s option is required.",
                      appOptions[OPT_ADDRESS].name,
                      appOptions[OPT_INPUT_FILE].name);
        skAppUsage();
    }

    if (atexit(appTeardown) < 0) {
        skAppPrintErr("Unable to register appTeardown() with atexit()");
        appTeardown();
        exit(EXIT_FAILURE);
    }

    return;  /* OK */
}


/*
 *  status = appOptionsHandler(cData, opt_index, opt_arg);
 *
 *    This function is passed to skOptionsRegister(); it will be called
 *    by skOptionsParse() for each user-specified switch that the
 *    application has registered; it should handle the switch as
 *    required---typically by setting global variables---and return 1
 *    if the switch processing failed or 0 if it succeeded.  Returning
 *    a non-zero from from the handler causes skOptionsParse() to return
 *    a negative value.
 *
 *    The clientData in 'cData' is typically ignored; 'opt_index' is
 *    the index number that was specified as the last value for each
 *    struct option in appOptions[]; 'opt_arg' is the user's argument
 *    to the switch for options that have a REQUIRED_ARG or an
 *    OPTIONAL_ARG.
 */
static int appOptionsHandler(
    clientData  UNUSED(cData),
    int         opt_index,
    char       *opt_arg)
{
    int rv;
    skipaddr_t ip;

    switch ((appOptionsEnum)opt_index) {
      case OPT_MAP_FILE:
        app_opt.map_file = opt_arg;
        break;

      case OPT_ADDRESS:
        rv = skStringParseIP(&ip, opt_arg);
        if (rv) {
            skAppPrintErr("Invalid %s '%s': %s",
                          appOptions[opt_index].name, opt_arg,
                          skStringParseStrerror(rv));
            return 1;
        }
#if SK_ENABLE_IPV6
        if (skipaddrIsV6(&ip)) {
            skAppPrintErr("Invalid %s '%s': IPv6 addresses not supported",
                          appOptions[opt_index].name, opt_arg);
            return 1;
        }
#endif /* SK_ENABLE_IPV6 */
        app_opt.address = skipaddrGetV4(&ip);
        break;

      case OPT_INPUT_FILE:
        app_opt.input_file = opt_arg;
        break;
    }

    return 0;  /* OK */
}


/*
 *  status = processInputFile(filein, prefix_map);
 *
 *    For every line in 'filein', look up the address in 'prefix_map'
 *    and print out the corresponding country code.  There should be
 *    as many lines of output as there are of input.
 */
static int processInputFile(FILE *in, skPrefixMap_t *prefix_map)
{
    char line[2048];
    skIPWildcardIterator_t iter;
    skIPWildcard_t ipwild;
    int current_line = 0;
    skipaddr_t ip;
    uint32_t val;
    int rv;
    int lc;

    /* read from 'in' until EOF */
    while ((lc = skGetLine(line, sizeof(line), in, "#")) > 0) {
        current_line += lc;

        if ( !line[0]) {
            /* bad: line was longer than sizeof(line) */
            skAppPrintErr("Input line %d too long. ignored",
                          current_line);
            continue;
        }

        /* parse the line: fill in octet_bitmap */
        rv = skStringParseIPWildcard(&ipwild, line);
        if (rv && rv != SKUTILS_ERR_EMPTY) {
            /* error */
            skAppPrintErr("Error on line %d: %s\n",
                          current_line, skStringParseStrerror(rv));
            return -1;
        }
#if SK_ENABLE_IPV6
        if (skIPWildcardIsV6(&ipwild)) {
            continue;
        }
#endif /* SK_ENABLE_IPV6 */

        skIPWildcardIteratorBind(&iter, &ipwild);
        while (skIPWildcardIteratorNext(&iter, &ip) == SK_ITERATOR_OK) {
            val = skPrefixMapGet(prefix_map, skipaddrGetV4(&ip));
            PRINT_INT_AS_CC(outf, val);
        }
    }

    return 0;
}


int main(int argc, char **argv)
{
    FILE *input_filep;
    skPrefixMap_t *prefix_map;
    skPrefixMapErr_t map_error = SKPREFIXMAP_OK;
    uint32_t val;

    appSetup(argc, argv);                       /* never returns on error */

    /* Okay.  Now we should open the prefixmap file, read it in, and
     * then look up our address! */

    map_error = skPrefixMapLoad(&prefix_map, map_path);
    if ( SKPREFIXMAP_OK != map_error ) {
        if ( SKPREFIXMAP_ERR_ARGS == map_error ) {
            skAppPrintErr("Failed to read map file: Invalid arguments");
        } else if ( SKPREFIXMAP_ERR_MEMORY == map_error ) {
            skAppPrintErr("Failed to read map file: Out of memory");
        } else if ( SKPREFIXMAP_ERR_IO == map_error ) {
            skAppPrintErr("Failed to read map file: I/O error");
        }
        exit(EXIT_FAILURE);
    }

    if (ADDRESS_UNSET != app_opt.address) {
        val = skPrefixMapGet(prefix_map, app_opt.address);
        PRINT_INT_AS_CC(outf, val);
    } else {
        if (0 == strcmp("stdin", app_opt.input_file)) {
            input_filep = stdin;
        } else {
            input_filep = fopen(app_opt.input_file, "r");
            if (NULL == input_filep) {
                skAppPrintErr("Failed to open %s '%s': %s",
                              appOptions[OPT_INPUT_FILE].name,
                              app_opt.input_file, strerror(errno));
                exit(EXIT_FAILURE);
            }
        }
        processInputFile(input_filep, prefix_map);
        if (input_filep != stdin) {
            fclose(input_filep);
        }
    }

    skPrefixMapDelete(prefix_map);

    /* done */
    appTeardown();
    return 0;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
