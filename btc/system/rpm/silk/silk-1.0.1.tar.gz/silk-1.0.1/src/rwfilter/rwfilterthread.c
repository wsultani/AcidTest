/*
** Copyright (C) 2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  Add your description here
**
*/

#include "silk.h"

RCSIDENT("$SiLK: rwfilterthread.c 10656 2008-02-26 17:38:10Z mthomas $");

#include "rwfilter.h"
#include <pthread.h>


/* TYPEDEFS AND DEFINES */

/*
 *    Size of buffer, in bytes, for storing records prior to writing
 *    them.  There will be one of these buffers per destination type
 *    per thread.
 */
#define THREAD_RECBUF_SIZE   0x10000


typedef struct filter_thread_st {
    rwRec          *recbuf[DESTINATION_TYPES];
    filter_stats_t  stats;
    pthread_t       thread;
    int             rv;
} filter_thread_t;


/* LOCAL VARIABLE DEFINITIONS */

static pthread_mutex_t next_file_mutex = PTHREAD_MUTEX_INITIALIZER;

static pthread_mutex_t dest_mutex[DESTINATION_TYPES];

/* max number of records the recbuf can hold */
static const size_t recbuf_max_recs = THREAD_RECBUF_SIZE / sizeof(rwRec);


/* FUNCTION DEFINITIONS */


/*
 *  ok = appSetSignalHandler(sig_fn)
 *
 *    Call sig_fn whenever we get a signal.
 */
static int appSetSignalHandler(void (*sig_fn)(int))
{
    /* list of handled signals */
    int sigs[] = {SIGINT, SIGPIPE, SIGQUIT, SIGTERM};
    struct sigaction act;
    size_t i;

    act.sa_handler = sig_fn;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;
#ifdef SA_INTERRUPT
    act.sa_flags |= SA_INTERRUPT;
#endif

    for (i = 0; i < (sizeof(sigs)/sizeof(int)); ++i) {
        if (sigaction(sigs[i], &act, NULL) < 0) {
            skAppPrintErr("Cannot register handler for signal #%d",
                          sigs[i]);
            return -1;
        }
    }
    return 0;
}



/*
 *  appHandleSignal(signal_value)
 *
 *    Set the 'reading_records' global to 0 which will begin the
 *    shutdown process.  Print a message unless the signal is SIGPIPE.
 */
static void appHandleSignal(int sig)
{
    reading_records = 0;

    if (sig == SIGPIPE) {
        /* we get SIGPIPE if something downstream, like rwcut, exits
         * early, so don't bother to print a warning, and exit
         * successfully */
        exit(EXIT_SUCCESS);
    } else {
        skAppPrintErr("Caught signal..cleaning up and exiting");
    }
}


static int dumpBuffer(
    int             dest_id,
    const rwRec    *recbuf,
    uint32_t        reccount)
{
    destination_t *dest;
    const rwRec *recbuf_pos;
    const rwRec *end_rec;
    uint64_t total_rec_count;
    int close_after_add = 0;
    int rv = RWIO_OK;

    pthread_mutex_lock(&dest_mutex[dest_id]);

    dest = dest_type[dest_id].dest_list;

    /* if an output limit was specified, see if we will hit it while
     * adding these records.  If so, adjust the reccount and set a
     * flag to close the output after adding the records. */
    if (dest_type[dest_id].max_records) {
        if (dest == NULL) {
            goto END;
        }
        total_rec_count = skStreamGetRecordCount(dest->ios);
        if (total_rec_count + reccount > dest_type[dest_id].max_records) {
            reccount = dest_type[dest_id].max_records - total_rec_count;
            close_after_add = 1;
        }
    }

    /* find location of our stopping condition */
    end_rec = recbuf + reccount;

    for ( ; dest != NULL; dest = dest->next){
        for (recbuf_pos = recbuf; recbuf_pos < end_rec; ++recbuf_pos) {
            rv = rwioWriteRecord(dest->ios, recbuf_pos);
            if (RWIO_ERROR_IS_FATAL(rv)) {
                /* print the error and return */
                rwioPrintLastErr(dest->ios, rv, &skAppPrintErr);
                goto END;
            }
        }
    }

    if (close_after_add) {
        reading_records = closeOutputDests(dest_id, 0);
    }

    rv = RWIO_OK;

  END:
    pthread_mutex_unlock(&dest_mutex[dest_id]);
    return rv;
}


/*
 *  ok = filterFile(datafile, ipfile_basename, stats);
 *
 *    This is the actual filtering of the file 'datafile'.  The
 *    function will call the function to write the header if required.
 *    The 'ipfile_basename' parameter is passed to filterCheckFile();
 *    it should be NULL or contain the full-path (minus extension) the
 *    file that contains Bloom filter or IPset information about the
 *    'datafile'.  The function returns 0 on success; or 1 if the
 *    input file could not be opened.
 */
static int filterFileThreaded(
    const char     *datafile,
    const char     *ipfile_basename,
    filter_stats_t *stats,
    rwRec          *recbuf[],
    uint32_t        recbuf_count[])
{
    rwRec rwrec;
    rwIOStruct_t *rwio_in;
    int i;
    int fail_entire_file = 0;
    int fail = 0;
    int rv = RWIO_OK;
    int r_rv = RWIO_OK;
    rwRec *recbuf_pos[DESTINATION_TYPES];

    /* nothing to do in dry-run mode but print the file names */
    if (dryrun_fp) {
        fprintf(dryrun_fp, "%s\n", datafile);
        return 0;
    }

    if (!reading_records) {
        return 0;
    }

    /* initialize: set each buffer's current record pointer to the
     * appropriate location */
    for (i = 0; i < DESTINATION_TYPES; ++i) {
        if (recbuf[i]) {
            recbuf_pos[i] = recbuf[i] + recbuf_count[i];
        }
    }

    /* print filenames if requested */
    if (filenames_fp) {
        fprintf(filenames_fp, "%s\n", datafile);
    }

    /* open the input file */
    if ((r_rv = skStreamCreate(&rwio_in, SK_IO_READ, SK_CONTENT_SILK_FLOW))
        || (r_rv = skStreamBind(rwio_in, datafile))
        || (r_rv = skStreamOpen(rwio_in))
        || (r_rv = skStreamReadSilkHeader(rwio_in, NULL)))
    {
        goto END;
    }

    ++stats->files;

    /* fail all the records in the file if we can */
    if (filterCheckFile(rwio_in, ipfile_basename) == 1) {
        /* all records in the file will fail the user's tests */
        fail_entire_file = 1;
        fail = 1;

        /* we can completely skip this file as long as we are not
         * computing statistics or generating DEST_ALL or DEST_FAIL
         * output. */
        if ((print_stat == NULL)
            && (dest_type[DEST_ALL].count == 0)
            && (dest_type[DEST_FAIL].count == 0))
        {
            /* no need to process file; move to next one */
            goto END;
        }
    }

    /* read and process each record */
    while (reading_records
           && RWIO_OK == (r_rv = skStreamReadRecord(rwio_in, &rwrec)))
    {
        /* increment number of read records */
        INCR_REC_COUNT(stats->read, &rwrec);

        /* the all-dest */
        if (dest_type[DEST_ALL].count) {
            memcpy(recbuf_pos[DEST_ALL], &rwrec, sizeof(rwRec));
            ++recbuf_pos[DEST_ALL];
            ++recbuf_count[DEST_ALL];
            if (recbuf_count[DEST_ALL] == recbuf_max_recs) {
                rv = dumpBuffer(DEST_ALL, recbuf[DEST_ALL],
                                recbuf_count[DEST_ALL]);
                if (rv) {
                    reading_records = 0;
                    goto END;
                }
                recbuf_pos[DEST_ALL] = recbuf[DEST_ALL];
                recbuf_count[DEST_ALL] = 0;
            }
        }

        if (!fail_entire_file) {
            /* run all checker()'s until end or one fails */
            for (i=0, fail=0; i < checker_count && !fail; ++i) {
                fail = (*(checker[i]))(&rwrec);
            }
        }

        if (!fail) {

            /* increment number of record that pass */
            INCR_REC_COUNT(stats->pass, &rwrec);

            /* the pass-dest */
            if (dest_type[DEST_PASS].count) {
                memcpy(recbuf_pos[DEST_PASS], &rwrec, sizeof(rwRec));
                ++recbuf_pos[DEST_PASS];
                ++recbuf_count[DEST_PASS];
                if (recbuf_count[DEST_PASS] == recbuf_max_recs) {
                    rv = dumpBuffer(DEST_PASS, recbuf[DEST_PASS],
                                    recbuf_count[DEST_PASS]);
                    if (rv) {
                        reading_records = 0;
                        goto END;
                    }
                    recbuf_pos[DEST_PASS] = recbuf[DEST_PASS];
                    recbuf_count[DEST_PASS] = 0;
                }
            }
        } else {

            /* the fail-dest */
            if (dest_type[DEST_FAIL].count) {
                memcpy(recbuf_pos[DEST_FAIL], &rwrec, sizeof(rwRec));
                ++recbuf_pos[DEST_FAIL];
                ++recbuf_count[DEST_FAIL];
                if (recbuf_count[DEST_FAIL] == recbuf_max_recs) {
                    rv = dumpBuffer(DEST_FAIL, recbuf[DEST_FAIL],
                                    recbuf_count[DEST_FAIL]);
                    if (rv) {
                        reading_records = 0;
                        goto END;
                    }
                    recbuf_pos[DEST_FAIL] = recbuf[DEST_FAIL];
                    recbuf_count[DEST_FAIL] = 0;
                }
            }
        }

    } /* while (reading_records && rwRead()) */

  END:
    if (r_rv == RWIO_OK || r_rv == SKSTREAM_ERR_EOF) {
        r_rv = 0;
    } else {
        skStreamPrintLastErr(rwio_in, r_rv, &skAppPrintErr);
        r_rv = 1;
    }

    /* close input */
    skStreamDestroy(&rwio_in);

    if (rv) {
        return -1;
    }
    return r_rv;
}


static char *nextInputThreaded(char *buf, size_t bufsize)
{
    char *fname;

    pthread_mutex_lock(&next_file_mutex);
    fname = appNextInput(buf, bufsize);
    pthread_mutex_unlock(&next_file_mutex);

    return fname;
}


static void *workerThread(void *v_thread)
{
    filter_stats_t *stats = &(((filter_thread_t*)v_thread)->stats);
    rwRec **recbuf = ((filter_thread_t*)v_thread)->recbuf;
    uint32_t recbuf_count[DESTINATION_TYPES];
    char datafile[PATH_MAX];
    int rv = 0;
    int i;

    memset(recbuf_count, 0, sizeof(recbuf_count));

    ((filter_thread_t*)v_thread)->rv = 0;

    while (nextInputThreaded(datafile, sizeof(datafile)) != NULL) {
        rv = filterFileThreaded(datafile, NULL, stats, recbuf, recbuf_count);
        if (rv) {
            ((filter_thread_t*)v_thread)->rv = rv;
            if (rv < 0) {
                /* fatal error */
                return NULL;
            }
        }
    }

    /* dump any records still in the buffers */
    for (i = 0; i < DESTINATION_TYPES; ++i) {
        if (recbuf_count[i]) {
            dumpBuffer(i, recbuf[i], recbuf_count[i]);
        }
    }

    return NULL;
}


int threadedFilter(filter_stats_t *stats)
{
    filter_thread_t *thread;
    int i;
    uint32_t j;
    int rv = 1;

    /* set a signal handler */
    if (appSetSignalHandler(&appHandleSignal)) {
        skAppPrintErr("Unable to set signal handler");
        exit(EXIT_FAILURE);
    }

    /* initialize the mutexes for each destination type */
    for (i = 0; i < DESTINATION_TYPES; ++i) {
        pthread_mutex_init(&dest_mutex[i], NULL);
    }

    /* create the data structures used by each thread */
    thread = calloc(thread_count, sizeof(filter_thread_t));
    if (thread == NULL) {
        goto END;
    }
    for (i = 0; i < DESTINATION_TYPES; ++i) {
        if (dest_type[i].count) {
            for (j = 0; j < thread_count; ++j) {
                thread[j].recbuf[i] = malloc(recbuf_max_recs * sizeof(rwRec));
                if (thread[j].recbuf[i] == NULL) {
                    goto END;
                }
            }
        }
    }

    /* create the threads, skip 0 since that is the main thread */
    for (j = 1; j < thread_count; ++j) {
        pthread_create(&thread[j].thread, NULL, &workerThread, &thread[j]);
    }

    /* allow the main thread to also process files */
    workerThread(&thread[0]);

    /* join with the threads as they die off */
    for (j = 0; j < thread_count; ++j) {
        if (j > 0) {
            pthread_join(thread[j].thread, NULL);
        }
        rv |= thread[j].rv;
        stats->read.flows += thread[j].stats.read.flows;
        stats->read.pkts  += thread[j].stats.read.pkts;
        stats->read.bytes += thread[j].stats.read.bytes;
        stats->pass.flows += thread[j].stats.pass.flows;
        stats->pass.pkts  += thread[j].stats.pass.pkts;
        stats->pass.bytes += thread[j].stats.pass.bytes;
        stats->files      += thread[j].stats.files;
#if 0
        fprintf(stderr,
                "thread %d processed %" PRIu32 " files and "
                "passed %" PRIu64 "/%" PRIu64 " flows\n",
                j, thread[j].stats.files, thread[j].stats.pass.flows,
                thread[j].stats.read.flows);
#endif
    }

  END:
    if (thread) {
        for (i = 0; i < DESTINATION_TYPES; ++i) {
            for (j = 0; j < thread_count; ++j) {
                if (thread[j].recbuf[i]) {
                    free(thread[j].recbuf[i]);
                }
            }
        }
        free(thread);
    }

    return rv;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
