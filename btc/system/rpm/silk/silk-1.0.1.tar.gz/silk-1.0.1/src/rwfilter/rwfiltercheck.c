/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
 *  filteropts.c
 *
 *  Suresh Konda
 *
 *  parsing and setting up filter options
 *
 *  10/21/01
 *
 */

#include "silk.h"

RCSIDENT("$SiLK: rwfiltercheck.c 11022 2008-03-24 16:10:47Z mthomas $");

#include "rwfilter.h"
#include "iptree.h"


/* TYPEDEFS AND DEFINES */

/* number of ports and protocols */
#define MAX_PORTS      65536
#define MAX_PROTOCOLS    256

/* number of sensors and flow-types; these must agree with rwpack.h */
#define MAX_SENSORS    65536
#define MAX_FLOW_TYPES   256

/* number of TCP flag checks we support */
#define MAX_TCPFLAG_CHECKS  16

/* number of filter checks.  Approx equal to number of options */
#define FILTER_CHECK_MAX 64

/* multipler to convert a floating point number to a unit64_t */
#define PRECISION      10000

/* number of IP Wildcards and IPsets */
#define IP_INDEX_COUNT     4

/* indexes into the arrays of IP Wildcards and IPsets */
enum ip_index {
    SRC=0, DST, ANY, NHIP,
    _IP_INDEX_FINAL_ /* must be last */
};

/* holds a range */
typedef struct value_range_st {
    uint64_t max;
    uint64_t min;
} value_range_t;

/*
 *  CHECK_RANGE(v, r)
 *
 *    Returns 1 if value 'v' is within the range 'r'; 0 otherwise.
 */
#define CHECK_RANGE(v, r)   ((((v) >= (r).min) && ((v) <= (r).max)) ? 1 : 0)


/* holds TCP flags high/mask; e.g., S/SA */
typedef struct high_mask_st {
    uint8_t  high;
    uint8_t  mask;
} high_mask_t;

/* Test to see if TCP flags in 'var' meet the requirements of 'high_mask' */
#define CHECK_TCP_HIGH_MASK(var, high_mask) \
    TCP_FLAG_TEST_HIGH_MASK((var), (high_mask).high, (high_mask).mask)

/* The filters */
typedef struct filter_checks_st {
    /* times */
    value_range_t sTime, eTime, activeTime, elapsed;

    /* flow volume */
    value_range_t bytes, pkts, bytesPerPacket;

    /* IP Wildcard Values */
    skIPWildcard_t ipwild[IP_INDEX_COUNT];
    int ipwild_negate[IP_INDEX_COUNT];

    /* IP sets */
    skIPTree_t *ipset[IP_INDEX_COUNT];
    int ipset_reject[IP_INDEX_COUNT];

    /* Source and Dest ports */
    sk_bitmap_t *sPort;
    sk_bitmap_t *dPort;
    sk_bitmap_t *any_port;

    /* IP Protocol */
    sk_bitmap_t *proto;

    /* ICMP type and code */
    sk_bitmap_t *icmp_type;
    sk_bitmap_t *icmp_code;

    /* sensors and class/type */
    sk_bitmap_t *sID;
    sk_bitmap_t *flow_type;

    /* SNMP interfaces */
    sk_bitmap_t *input;
    sk_bitmap_t *output;

    /* tcp flags (old style tcp flags) */
    uint8_t flags;

    /* flags_all, flags_init, flags_session */
    high_mask_t flags_all[MAX_TCPFLAG_CHECKS];
    high_mask_t flags_init[MAX_TCPFLAG_CHECKS];
    high_mask_t flags_session[MAX_TCPFLAG_CHECKS];
    uint8_t count_flags_all;
    uint8_t count_flags_init;
    uint8_t count_flags_session;

    /* TCP state aka attributes */
    high_mask_t attributes;

    /* application */
    sk_bitmap_t *application;

    /* ip-version */
    sk_ipv6policy_t ipv6_policy;

    /*
     *  entry in checkSet[i] == checkNumber if desired.  maxCheckseUsed
     *  is the number of checks actually used in this run
     */
    uint8_t checkSet[FILTER_CHECK_MAX];
    uint8_t check_count;

} filter_checks_t;



/* LOCAL VARIABLES */

static filter_checks_t static_checks;
static filter_checks_t * const checks = &static_checks;


/* OPTION SETUP */

/* struct implementer uses to define options */
typedef struct filter_switch_st {
    struct option   option;
    const char     *help;
} filter_switch_t;

enum {
    OPT_STIME = 0, OPT_ETIME, OPT_ACTIVE_TIME, OPT_DURATION,
    OPT_SPORT, OPT_DPORT, OPT_APORT, OPT_PROTOCOL,
    OPT_ICMP_TYPE, OPT_ICMP_CODE,
    OPT_BYTES, OPT_PACKETS, OPT_BYTES_PER_PACKET,

    /* ordering for the IP Octet Maps and IPsets must be consistent
     * with that given by the ip_index enum. */
    OPT_SADDRESS, OPT_DADDRESS, OPT_ANY_ADDRESS, OPT_NEXT_HOP_ID,
    OPT_NOT_SADDRESS, OPT_NOT_DADDRESS,
    OPT_NOT_ANY_ADDRESS, OPT_NOT_NEXT_HOP_ID,
    OPT_SET_SIP, OPT_SET_DIP, OPT_SET_ANY, OPT_SET_NHIP,
    OPT_NOT_SET_SIP, OPT_NOT_SET_DIP, OPT_NOT_SET_ANY, OPT_NOT_SET_NHIP,

    OPT_INPUT_INDEX, OPT_OUTPUT_INDEX, OPT_TCP_FLAGS,
    OPT_FIN_FLAG, OPT_SYN_FLAG, OPT_RST_FLAG, OPT_PSH_FLAG,
    OPT_ACK_FLAG, OPT_URG_FLAG, OPT_ECE_FLAG, OPT_CWR_FLAG,
    OPT_FLAGS_ALL, OPT_FLAGS_INITIAL, OPT_FLAGS_SESSION, OPT_ATTRIBUTES,
    OPT_APPLICATION, OPT_IP_VERSION,
    OPT_SENSORS, OPT_FLOW_TYPE,
    _OPT_FINAL_OPTION_ /* must be last */
};

/* options as used by getopt_long() */
static struct option *filterOptions = NULL;

/* options and their help strings */
static filter_switch_t filterSwitch[] = {
    {{"stime",             REQUIRED_ARG, 0, OPT_STIME},
     ("Start time is within this time window:\n"
      "\tYYYY/MM/DD[:HH[:MM[:SS[.sss]]]][-YYYY/MM/DD[:HH[:MM[:SS[.sss]]]]]\n"
      "\tIf no window closing time, use start time. Window closing\n"
      "\ttime is rounded to final millisecond of specified precision.")},
    {{"etime",             REQUIRED_ARG, 0, OPT_ETIME},
     ("Ending time is within this time window.")},
    {{"active-time",       REQUIRED_ARG, 0, OPT_ACTIVE_TIME},
     ("Flow was active at any time during this time window.")},
    {{"duration",          REQUIRED_ARG, 0, OPT_DURATION},
     ("Duration in seconds falls within integer range N-M.")},

    {{"sport",             REQUIRED_ARG, 0, OPT_SPORT},
     ("Source port is contained in this list.\n"
      "\tA comma separated list of numbers and ranges between 0 and 65535.")},
    {{"dport",             REQUIRED_ARG, 0, OPT_DPORT},
     ("Destination port is contained in this list.\n"
      "\tA comma separated list of numbers and ranges between 0 and 65535.")},
    {{"aport",             REQUIRED_ARG, 0, OPT_APORT},
     ("Source or destination port is contained in this list.\n"
      "\tA comma separated list of numbers and ranges between 0 and 65535.")},
    {{"protocol",          REQUIRED_ARG, 0, OPT_PROTOCOL},
     ("Protocol is contained in this list.\n"
      "\tA comma separated list of numbers and ranges between 0 and 255.")},

    {{"icmp-type",         REQUIRED_ARG, 0, OPT_ICMP_TYPE},
     ("ICMP Type is contained in this list.\n"
      "\tA comma separated list of numbers and ranges between 0 and 255;\n"
      "\tadditionally, sets protocol to 1 (ICMP)")},
    {{"icmp-code",         REQUIRED_ARG, 0, OPT_ICMP_CODE},
     ("ICMP Code is contained in this list.\n"
      "\tA comma separated list of numbers and ranges between 0 and 255;\n"
      "\tadditionally, sets protocol to 1 (ICMP)")},

    {{"bytes",             REQUIRED_ARG, 0, OPT_BYTES},
     ("Byte count is within the integer range N-M.")},
    {{"packets",           REQUIRED_ARG, 0, OPT_PACKETS},
     ("Packet count is within the integer range N-M.")},
    {{"bytes-per-packet",  REQUIRED_ARG, 0, OPT_BYTES_PER_PACKET},
     ("Byte-per-packet count is within decimal range X-Y.")},

    /* Wildcard IPs */
    {{"saddress",          REQUIRED_ARG, 0, OPT_SADDRESS},
     ("Source address matches this wildcard IP.\n"
      "\tWildcard IP is a dotted quad where each octet is a number,\n"
      "\ta comma-separted list of numbers and/or ranges, or 'x' for 0-255")},
    {{"daddress",          REQUIRED_ARG, 0, OPT_DADDRESS},
     ("Destination address matches this wildcard IP.")},
    {{"any-address",       REQUIRED_ARG, 0, OPT_ANY_ADDRESS},
     ("Source or destination address matches this wildcard IP.")},
    {{"next-hop-id",       REQUIRED_ARG, 0, OPT_NEXT_HOP_ID},
     ("Next Hop address matches this wildcard IP.")},
    {{"not-saddress",      REQUIRED_ARG, 0, OPT_NOT_SADDRESS},
     ("Source address does not match this wildcard IP.")},
    {{"not-daddress",      REQUIRED_ARG, 0, OPT_NOT_DADDRESS},
     ("Destination address does not match this wildcard IP.")},
    {{"not-any-address",   REQUIRED_ARG, 0, OPT_NOT_ANY_ADDRESS},
     ("Neither source nor destination address matches\n"
      "\tthis wildcard IP.")},
    {{"not-next-hop-id",   REQUIRED_ARG, 0, OPT_NOT_NEXT_HOP_ID},
     ("Next Hop address does not match this wildcard IP.")},

    /* IP sets */
    {{"sipset",      REQUIRED_ARG, 0, OPT_SET_SIP},
     ("Source address is in this IPset")},
    {{"dipset",      REQUIRED_ARG, 0, OPT_SET_DIP},
     ("Destination address is in this set")},
    {{"anyset",      REQUIRED_ARG, 0, OPT_SET_ANY},
     ("Either source or destination address is in this set")},
    {{"nhipset",     REQUIRED_ARG, 0, OPT_SET_NHIP},
     ("Next Hop address is in this set")},
    {{"not-sipset",  REQUIRED_ARG, 0, OPT_NOT_SET_SIP},
     ("Source address is not in this set")},
    {{"not-dipset",  REQUIRED_ARG, 0, OPT_NOT_SET_DIP},
     ("Destination address is not in this set")},
    {{"not-anyset",  REQUIRED_ARG, 0, OPT_NOT_SET_ANY},
     ("Neither source nor destination address is in this set")},
    {{"not-nhipset", REQUIRED_ARG, 0, OPT_NOT_SET_NHIP},
     ("Next Hop address is not in this set")},

    {{"input-index",       REQUIRED_ARG, 0, OPT_INPUT_INDEX},
     ("SNMP input interface  is contained in this list.\n"
      "\tA comma separated list of numbers and ranges between 0 and 65535.")},
    {{"output-index",      REQUIRED_ARG, 0, OPT_OUTPUT_INDEX},
     ("SNMP output interface  is contained in this list.\n"
      "\tA comma separated list of numbers and ranges between 0 and 65535.")},

    {{"tcp-flags",         REQUIRED_ARG, 0, OPT_TCP_FLAGS},
     ("TCP flags are in the list in [FSRPAUEC] where\n"
      "\tF=FIN;S=SYN;R=RST;P=PSH;A=ACK;U=URG;E=ECE;C=CWR")},
    {{"fin-flag",          REQUIRED_ARG, 0, OPT_FIN_FLAG},
     ("FIN flag is present if arg is 1, absent if arg is 0")},
    {{"syn-flag",          REQUIRED_ARG, 0, OPT_SYN_FLAG},
     ("SYN flag is present if arg is 1, absent if arg is 0")},
    {{"rst-flag",          REQUIRED_ARG, 0, OPT_RST_FLAG},
     ("RST flag is present if arg is 1, absent if arg is 0")},
    {{"psh-flag",          REQUIRED_ARG, 0, OPT_PSH_FLAG},
     ("PSH flag is present if arg is 1, absent if arg is 0")},
    {{"ack-flag",          REQUIRED_ARG, 0, OPT_ACK_FLAG},
     ("ACK flag is present if arg is 1, absent if arg is 0")},
    {{"urg-flag",          REQUIRED_ARG, 0, OPT_URG_FLAG},
     ("URG flag is present if arg is 1, absent if arg is 0")},
    {{"ece-flag",          REQUIRED_ARG, 0, OPT_ECE_FLAG},
     ("ECE flag is present if arg is 1, absent if arg is 0")},
    {{"cwr-flag",          REQUIRED_ARG, 0, OPT_CWR_FLAG},
     ("CWR flag is present if arg is 1, absent if arg is 0")},
    {{"flags-all",         REQUIRED_ARG, 0, OPT_FLAGS_ALL},
     ("Union of TCP flags on all packets match the masked flags\n"
      "\tcollection specified by <high-flags>/<mask-flags>")},
#if  SK_ENABLE_INITIAL_TCPFLAGS
    {{"flags-initial",     REQUIRED_ARG, 0, OPT_FLAGS_INITIAL},
     ("Flags on first packet match <high>/<mask>")},
    {{"flags-session",     REQUIRED_ARG, 0, OPT_FLAGS_SESSION},
     ("Flags on all but first packet match <high>/<mask>")},
    {{"attributes",        REQUIRED_ARG, 0, OPT_ATTRIBUTES},
     ("TCP termination condition determined by flow generation\n"
      "\tsoftware match the masked list <high>/<mask>. Available conditions:\n"
      "\tF=Pkts after FIN; T=Timeout(active); C=Continuation of timed-out")},
    {{"application",       REQUIRED_ARG, 0, OPT_APPLICATION},
     ("Packet signature indicates one of these applications or\n"
      "\tservices, a comma separated list of integers. Indicate application\n"
      "\tby its standard port: HTTP=80,SMPT=25,DNS=53,etc")},
#endif /* SK_ENABLE_INITIAL_TCPFLAGS */
    {{"ip-version",        REQUIRED_ARG, 0, OPT_IP_VERSION},
#if SK_ENABLE_IPV6
     ("IP Version is contained in this list. Def 4,6")
#else
     ("IP Version is contained in this list. Def 4\n"
      "\tIPv6 support not available. All IPv6 flows will be ignored")
#endif
    },
    {{0, 0, 0, 0}, /* sentinel */
     NULL}
};


/* LOCAL FUNCTION DECLARARTIONS */

static int parseTimeIntoValueRange(
    value_range_t      *p_vr,
    int                 opt_index,
    const char         *s_time);
static uint32_t parseIntegerRange(
    value_range_t      *tgtRange,
    int                 opt_index,
    const char         *rangeString);
static uint32_t parseDecimalRange(
    value_range_t      *tgtRange,
    int                 opt_index,
    const char         *rangeString);
static int parseFlags(
    int                 opt_index,
    const char         *opt_arg);
static int setFilterCheckBinaryFlag(
    int                 opt_index,
    const char         *opt_arg);
static int parseAttributes(
    int                 opt_index,
    const char         *opt_arg);



/* FUNCTION DEFINITIONS */

/* Print usage to specified file handle */
void filterUsage(FILE *fh)
{
    int i;

    fprintf(fh, ("\nPARTITIONING SWITCHES determine whether to pass"
                 " or fail a flow-record.\n\tThe flow will fail unless"
                 " each of the following is true:\n\n"));
    for (i = 0; filterSwitch[i].option.name; i++) {
        fprintf(fh, "--%s %s. %s\n", filterSwitch[i].option.name,
                SK_OPTION_HAS_ARG(filterSwitch[i].option),
                filterSwitch[i].help);
    }
}


/*
 *    The options handler for the switches that this file registers.
 *
 *    Parses the user's values to the switches and fills in the global
 *    'checks' variable.  Returns 0 on success or 1 on failure.
 */
static int filterOptionsHandler(
    clientData  UNUSED(cData),
    int         opt_index,
    char       *opt_arg)
{
    static int option_seen[FILTER_CHECK_MAX];
    int check_key = opt_index;
    int found_dup = 0;
    int rv = 1;
    int i;

    /* Make certain this check is not a repeat */
    switch (opt_index) {
      case OPT_ICMP_TYPE:
      case OPT_ICMP_CODE:
        if (option_seen[opt_index]) {
            skAppPrintErr("A --%s filter has already been set",
                          filterOptions[opt_index].name);
            return 1;
        }
        if (option_seen[OPT_PROTOCOL]) {
            if ((skBitmapGetHighCount(checks->proto) != 1) ||
                (1 != skBitmapGetBit(checks->proto, 1)))
            {
                skAppPrintErr(("May only use --%s=1 when using --%s or --%s"),
                              filterOptions[OPT_PROTOCOL].name,
                              filterOptions[OPT_ICMP_TYPE].name,
                              filterOptions[OPT_ICMP_CODE].name);
                return 1;
            }
        } else if (checks->proto == NULL) {
            /* act as if --proto=1 was given */
            if (skBitmapCreate(&(checks->proto), MAX_PROTOCOLS)) {
                return 1;
            }
            skBitmapSetBit(checks->proto, 1)
            checks->checkSet[checks->check_count] = OPT_PROTOCOL;
            checks->check_count++;
        }
        option_seen[opt_index] = 1;
        break;

      case OPT_PROTOCOL:
        if (option_seen[opt_index]) {
            skAppPrintErr("A --%s filter has already been set",
                          filterOptions[opt_index].name);
            return 1;
        }
        if (option_seen[OPT_ICMP_TYPE] || option_seen[OPT_ICMP_CODE]) {
            if (0 != strcmp("1", opt_arg)) {
                skAppPrintErr("May only use --%s=1 when using --%s or --%s",
                              filterOptions[opt_index].name,
                              filterOptions[OPT_ICMP_TYPE].name,
                              filterOptions[OPT_ICMP_CODE].name);
                return 1;
            }
            /* the protocol filter has already been set; see
             * OPT_ICMP_TYPE above. */
            option_seen[opt_index] = 1;
            return 0;
        }
        option_seen[opt_index] = 1;
        break;

      case OPT_SADDRESS:
      case OPT_DADDRESS:
      case OPT_ANY_ADDRESS:
      case OPT_NEXT_HOP_ID:
      case OPT_NOT_SADDRESS:
      case OPT_NOT_DADDRESS:
      case OPT_NOT_ANY_ADDRESS:
      case OPT_NOT_NEXT_HOP_ID:
        {
            int ip_partner = (opt_index + (((opt_index < OPT_NOT_SADDRESS)
                                            ? 1 : -1) * IP_INDEX_COUNT));
            if (option_seen[opt_index]) {
                skAppPrintErr("A --%s filter has already been set",
                              filterOptions[opt_index].name);
                return 1;
            }
            if (option_seen[ip_partner]) {
                skAppPrintErr(("A --%s filter has already been set;\n"
                               "\tonly one of --%s and --%s are allowed"),
                              filterOptions[ip_partner].name,
                              filterOptions[opt_index].name,
                              filterOptions[ip_partner].name);
                return 1;
            }
            check_key = ((opt_index - OPT_SADDRESS) % IP_INDEX_COUNT
                        + OPT_SADDRESS);
        }
        option_seen[opt_index] = 1;
        break;

      case OPT_SET_SIP:
      case OPT_SET_DIP:
      case OPT_SET_ANY:
      case OPT_SET_NHIP:
      case OPT_NOT_SET_SIP:
      case OPT_NOT_SET_DIP:
      case OPT_NOT_SET_ANY:
      case OPT_NOT_SET_NHIP:
        {
            int ip_partner = (opt_index + (((opt_index < OPT_NOT_SET_SIP)
                                            ? 1 : -1) * IP_INDEX_COUNT));
            if (option_seen[opt_index]) {
                skAppPrintErr("A --%s filter has already been set",
                              filterOptions[opt_index].name);
                return 1;
            }
            if (option_seen[ip_partner]) {
                skAppPrintErr(("A --%s filter has already been set;\n"
                               "\tonly one of --%s and --%s are allowed"),
                              filterOptions[ip_partner].name,
                              filterOptions[opt_index].name,
                              filterOptions[ip_partner].name);
                return 1;
            }
            check_key = ((opt_index - OPT_SET_SIP) % IP_INDEX_COUNT
                        + OPT_SET_SIP);
        }
        option_seen[opt_index] = 1;
        break;

      case OPT_FIN_FLAG:
      case OPT_SYN_FLAG:
      case OPT_RST_FLAG:
      case OPT_PSH_FLAG:
      case OPT_ACK_FLAG:
      case OPT_URG_FLAG:
      case OPT_ECE_FLAG:
      case OPT_CWR_FLAG:
        if (option_seen[opt_index]) {
            skAppPrintErr("A --%s filter has already been set",
                          filterOptions[opt_index].name);
            return 1;
        }
        check_key = OPT_FLAGS_ALL;
        option_seen[opt_index] = 1;
        break;

      case OPT_FLAGS_ALL:
      case OPT_FLAGS_INITIAL:
      case OPT_FLAGS_SESSION:
        /* these can be repeated */
        break;

      default:
        if (option_seen[opt_index]) {
            skAppPrintErr("A --%s filter has already been set",
                          filterOptions[opt_index].name);
            return 1;
        }
        option_seen[opt_index] = 1;
        break;
    }

    /* check that this is not a repeated check */
    for (i = 0; i < checks->check_count; ++i) {
        if (check_key == checks->checkSet[i]) {
            found_dup = 1;
            break;
        }
    }

    if (found_dup == 0) {
        /* First time for this check */
        checks->checkSet[checks->check_count] = check_key;
        checks->check_count++;
    }


    /* Parse the parameter to the check */
    switch (opt_index) {

      case OPT_STIME:
        rv = parseTimeIntoValueRange(&checks->sTime, opt_index, opt_arg);
        break;

      case OPT_ETIME:
        rv = parseTimeIntoValueRange(&checks->eTime, opt_index, opt_arg);
        break;

      case OPT_ACTIVE_TIME:
        rv = parseTimeIntoValueRange(&checks->activeTime, opt_index, opt_arg);
        break;

      case OPT_DURATION:
        rv = parseIntegerRange(&checks->elapsed, opt_index, opt_arg);
        break;

      case OPT_SPORT:
        rv = (skBitmapCreate(&(checks->sPort), MAX_PORTS) ||
              skStringParseNumberListToBitmap(checks->sPort, opt_arg));
        break;

      case OPT_DPORT:
        rv = (skBitmapCreate(&(checks->dPort), MAX_PORTS) ||
              skStringParseNumberListToBitmap(checks->dPort, opt_arg));
        break;

      case OPT_APORT:
        rv = (skBitmapCreate(&(checks->any_port), MAX_PORTS) ||
              skStringParseNumberListToBitmap(checks->any_port, opt_arg));
        break;

      case OPT_PROTOCOL:
        rv = (skBitmapCreate(&(checks->proto), MAX_PROTOCOLS) ||
              skStringParseNumberListToBitmap(checks->proto, opt_arg));
        break;

      case OPT_ICMP_TYPE:
        rv = (skBitmapCreate(&(checks->icmp_type), MAX_PORTS >> 8) ||
              skStringParseNumberListToBitmap(checks->icmp_type, opt_arg));
        break;

      case OPT_ICMP_CODE:
        rv = (skBitmapCreate(&(checks->icmp_code), MAX_PORTS >> 8) ||
              skStringParseNumberListToBitmap(checks->icmp_code, opt_arg));
        break;

      case OPT_BYTES:
        rv = parseIntegerRange(&checks->bytes, opt_index, opt_arg);
        break;

      case OPT_PACKETS:
        rv = parseIntegerRange(&checks->pkts, opt_index, opt_arg);
        break;

      case OPT_BYTES_PER_PACKET:
        rv = parseDecimalRange(&checks->bytesPerPacket, opt_index, opt_arg);
        break;

      case OPT_SADDRESS:
      case OPT_DADDRESS:
      case OPT_ANY_ADDRESS:
      case OPT_NEXT_HOP_ID:
      case OPT_NOT_SADDRESS:
      case OPT_NOT_DADDRESS:
      case OPT_NOT_ANY_ADDRESS:
      case OPT_NOT_NEXT_HOP_ID:
        {
            int ip_idx = (opt_index - OPT_SADDRESS);
            if (ip_idx >= IP_INDEX_COUNT) {
                ip_idx -= IP_INDEX_COUNT;
                checks->ipwild_negate[ip_idx] = 1;
            }
            rv = skStringParseIPWildcard(&checks->ipwild[ip_idx], opt_arg);
        }
        break;

      case OPT_SET_SIP:
      case OPT_SET_DIP:
      case OPT_SET_ANY:
      case OPT_SET_NHIP:
      case OPT_NOT_SET_SIP:
      case OPT_NOT_SET_DIP:
      case OPT_NOT_SET_ANY:
      case OPT_NOT_SET_NHIP:
        {
            skstream_t *stream;
            int ip_idx = (opt_index - OPT_SET_SIP);
            if (ip_idx >= IP_INDEX_COUNT) {
                ip_idx -= IP_INDEX_COUNT;
                checks->ipset_reject[ip_idx] = 1;
            }
            rv = filterOpenInputData(&stream, SK_CONTENT_SILK, opt_arg);
            if (rv == -1) {
                /* error has been printed */
                rv = 1;
            } else if (rv == 1) {
                /* ignore the stream, but no error */
                rv = 0;
            } else {
                rv = skIPTreeRead(&(checks->ipset[ip_idx]), stream);
                skStreamDestroy(&stream);
            }
        }
        break;

      case OPT_INPUT_INDEX:
        rv = (skBitmapCreate(&(checks->input), SK_SNMP_INDEX_LIMIT) ||
              skStringParseNumberListToBitmap(checks->input, opt_arg));
        break;

      case OPT_OUTPUT_INDEX:
        rv = (skBitmapCreate(&(checks->output), SK_SNMP_INDEX_LIMIT) ||
              skStringParseNumberListToBitmap(checks->output, opt_arg));
        break;

      case OPT_TCP_FLAGS:
        rv = skStringParseTCPFlags(&checks->flags, opt_arg);
        break;

      case OPT_FLAGS_ALL:
      case OPT_FLAGS_INITIAL:
      case OPT_FLAGS_SESSION:
        rv = parseFlags(opt_index, opt_arg);
        break;

        /*
         * This section is all flag wonking
         */
      case OPT_FIN_FLAG:
      case OPT_SYN_FLAG:
      case OPT_RST_FLAG:
      case OPT_PSH_FLAG:
      case OPT_ACK_FLAG:
      case OPT_URG_FLAG:
      case OPT_ECE_FLAG:
      case OPT_CWR_FLAG:
        rv = setFilterCheckBinaryFlag(opt_index, opt_arg);
        break;

      case OPT_ATTRIBUTES:
        rv = parseAttributes(opt_index, opt_arg);
        break;

      case OPT_APPLICATION:
        rv = (skBitmapCreate(&(checks->application), MAX_PORTS) ||
              skStringParseNumberListToBitmap(checks->application, opt_arg));
        break;

      case OPT_IP_VERSION:
        {
            uint32_t *ipversion;
            uint32_t count;
#if SK_ENABLE_IPV6
            rv = skStringParseNumberList(&ipversion, &count, opt_arg, 4, 6, 2);
#else
            rv = skStringParseNumberList(&ipversion, &count, opt_arg, 4, 4, 1);
#endif
            if (rv != 0) {
                break;
            }
            /* verify no --ip-version=5 */
            if ((ipversion[0] == 5) || ((count == 2) && (ipversion[1] == 5))) {
                rv = 1;
                break;
            }
            if (count == 2) {
                ipversion[0] += ipversion[1];
            }
            switch (ipversion[0]) {
              case 4:
              case 8:
                checks->ipv6_policy = SK_IPV6POLICY_IGNORE;
                break;
              case 6:
              case 12:
                checks->ipv6_policy = SK_IPV6POLICY_ONLY;
                break;
              case 10:
                checks->ipv6_policy = SK_IPV6POLICY_MIX;
                break;
              default:
                assert(0);
            }
            free(ipversion);
        }
        break;

      default:
        skAppPrintErr("Option %d not handled in switch() at %s:%d",
                      opt_index, __FILE__, __LINE__);
        abort();

    } /* switch */


    if (rv != 0) {
        skAppPrintErr("Error processing --%s option: '%s'",
                      filterOptions[opt_index].name, opt_arg);
        return 1;
    }
    return 0;                     /* OK */
}


/*
 *  pass = filterCheck(&rwrec)
 *
 *    Check the rw record 'rwrec' against all of the checks the user
 *    specified.  If the record fails any check, the (check_number+1) is
 *    returned.  If the record passes all of the checks, 0 is returned.
 */
int filterCheck(const rwRec *rwrec)
{
    unsigned int i;
    int j;
    int wanted;

/* If (test) is zero, the record fails the filter and a non-zero value
 * is returned.  Else we continue with additional checks. */
#define FILTER_CHECK(test) \
    if (test) {/*pass*/} else return (1 + checks->checkSet[j])


    for (j = 0; j < checks->check_count; j++) {
        switch (checks->checkSet[j]) {

          case OPT_STIME:
            FILTER_CHECK(CHECK_RANGE((uint64_t)rwRecGetStartTime(rwrec),
                                     checks->sTime));
            break;

          case OPT_ETIME:
            FILTER_CHECK(CHECK_RANGE((uint64_t)rwRecGetEndTime(rwrec),
                                     checks->eTime));
            break;

          case OPT_ACTIVE_TIME:
            /* to pass the record; check that flow's start time is
             * less than the max value of range and that flow's end
             * time is greater than the min value of the range. */
            FILTER_CHECK((uint64_t)rwRecGetStartTime(rwrec)
                         <= checks->activeTime.max);
            FILTER_CHECK((uint64_t)rwRecGetEndTime(rwrec)
                         >= checks->activeTime.min);
            break;

          case OPT_DURATION:
            FILTER_CHECK(CHECK_RANGE(rwRecGetElapsedSeconds(rwrec),
                                     checks->elapsed));
            break;

          case OPT_SPORT:
            FILTER_CHECK(skBitmapGetBit(checks->sPort, rwRecGetSPort(rwrec)));
            break;

          case OPT_DPORT:
            FILTER_CHECK(skBitmapGetBit(checks->dPort, rwRecGetDPort(rwrec)));
            break;

          case OPT_APORT:
            FILTER_CHECK(skBitmapGetBit(checks->any_port, rwRecGetSPort(rwrec))
                         || skBitmapGetBit(checks->any_port,
                                           rwRecGetDPort(rwrec)));
            break;

          case OPT_PROTOCOL:
            FILTER_CHECK(skBitmapGetBit(checks->proto, rwRecGetProto(rwrec)));
            break;

          case OPT_ICMP_TYPE:
            FILTER_CHECK(skBitmapGetBit(checks->icmp_type,
                                        rwRecGetIcmpType(rwrec)));
            break;

          case OPT_ICMP_CODE:
            FILTER_CHECK(skBitmapGetBit(checks->icmp_code,
                                        rwRecGetIcmpCode(rwrec)));
            break;

          case OPT_BYTES:
            FILTER_CHECK(CHECK_RANGE(rwRecGetBytes(rwrec), checks->bytes));
            break;

          case OPT_PACKETS:
            FILTER_CHECK(CHECK_RANGE(rwRecGetPkts(rwrec), checks->pkts));
            break;

          case OPT_BYTES_PER_PACKET:
            FILTER_CHECK(CHECK_RANGE((((uint64_t)(rwRecGetBytes(rwrec)))
                                      * PRECISION
                                      / ((uint64_t)(rwRecGetPkts(rwrec)))),
                                     checks->bytesPerPacket));
            break;

          case OPT_NOT_SADDRESS:
          case OPT_SADDRESS:
            /* Check if record's sIP matches the bitmap.  The record
             * FAILS the filter when the result of the check MATCHES
             * the status of the negate flag.  E.g., the record
             * matches the address-bitmap (skIPWildcardCheckIp()==1)
             * and the user entered --not-saddr (ipwild_negate==1).
             * Since the record FAILS when the values are equal, it
             * will PASS when they are not-equal; i.e., when the
             * XOR(^) of the two values is true.
             */
            {
                skipaddr_t ip;
                rwRecMemGetSIP(rwrec, &ip);
                FILTER_CHECK(skIPWildcardCheckIp(&checks->ipwild[SRC], &ip)
                             ^ checks->ipwild_negate[SRC]);
            }
            break;

          case OPT_NOT_DADDRESS:
          case OPT_DADDRESS:
            {
                skipaddr_t ip;
                rwRecMemGetDIP(rwrec, &ip);
                FILTER_CHECK(skIPWildcardCheckIp(&checks->ipwild[DST], &ip)
                             ^ checks->ipwild_negate[DST]);
            }
            break;

          case OPT_NOT_NEXT_HOP_ID:
          case OPT_NEXT_HOP_ID:
            {
                skipaddr_t ip;
                rwRecMemGetNhIP(rwrec, &ip);
                FILTER_CHECK(skIPWildcardCheckIp(&checks->ipwild[NHIP], &ip)
                             ^ checks->ipwild_negate[NHIP]);
            }
            break;

          case OPT_NOT_ANY_ADDRESS:
          case OPT_ANY_ADDRESS:
            {
                skipaddr_t sip;
                skipaddr_t dip;
                rwRecMemGetSIP(rwrec, &sip);
                rwRecMemGetDIP(rwrec, &dip);
                FILTER_CHECK((skIPWildcardCheckIp(&checks->ipwild[ANY], &sip)
                              | skIPWildcardCheckIp(&checks->ipwild[ANY],&dip))
                             ^ checks->ipwild_negate[ANY]);
            }
            break;

          case OPT_NOT_SET_SIP:
          case OPT_SET_SIP:
            /* As with OPT_SADDRESS, for the record to pass the
             * filter, the result of the check must not equal the
             * result of the negate flag. */
            FILTER_CHECK(skIPTreeCheckAddress(checks->ipset[SRC],
                                              rwRecGetSIPv4(rwrec))
                         ^ checks->ipset_reject[SRC]);
            break;

          case OPT_NOT_SET_DIP:
          case OPT_SET_DIP:
            FILTER_CHECK(skIPTreeCheckAddress(checks->ipset[DST],
                                              rwRecGetDIPv4(rwrec))
                         ^ checks->ipset_reject[DST]);
            break;

          case OPT_NOT_SET_NHIP:
          case OPT_SET_NHIP:
            FILTER_CHECK(skIPTreeCheckAddress(checks->ipset[NHIP],
                                              rwRecGetNhIPv4(rwrec))
                         ^ checks->ipset_reject[NHIP]);
            break;

          case OPT_NOT_SET_ANY:
          case OPT_SET_ANY:
            FILTER_CHECK((skIPTreeCheckAddress(checks->ipset[ANY],
                                               rwRecGetSIPv4(rwrec))
                          | skIPTreeCheckAddress(checks->ipset[ANY],
                                                 rwRecGetDIPv4(rwrec)))
                         ^ checks->ipset_reject[ANY]);
            break;

          case OPT_INPUT_INDEX:
            FILTER_CHECK(skBitmapGetBit(checks->input, rwRecGetInput(rwrec)));
            break;

          case OPT_OUTPUT_INDEX:
            FILTER_CHECK(skBitmapGetBit(checks->output,
                                        rwRecGetOutput(rwrec)));
            break;

            /*
             * TCP check.  Passes if there's an intersection between
             * the raised flags and the filter flags.
             */
          case OPT_TCP_FLAGS:
            FILTER_CHECK(checks->flags & rwRecGetFlags(rwrec));
            break;

          case OPT_FLAGS_ALL:
            wanted = 0;
            for (i = 0; i < checks->count_flags_all; ++i) {
                if (CHECK_TCP_HIGH_MASK(rwRecGetFlags(rwrec),
                                        checks->flags_all[i]))
                {
                    wanted = 1;
                    break; /* wanted */
                }
            }
            FILTER_CHECK(wanted);
            break;

          case OPT_FLAGS_INITIAL:
            wanted = 0;
            for (i = 0; i < checks->count_flags_init; ++i) {
                if (CHECK_TCP_HIGH_MASK(rwRecGetInitFlags(rwrec),
                                        checks->flags_init[i]))
                {
                    wanted = 1;
                    break; /* wanted */
                }
            }
            FILTER_CHECK(wanted);
            break;

          case OPT_FLAGS_SESSION:
            wanted = 0;
            for (i = 0; i < checks->count_flags_session; ++i) {
                if (CHECK_TCP_HIGH_MASK(rwRecGetRestFlags(rwrec),
                                        checks->flags_session[i]))
                {
                    wanted = 1;
                    break;
                }
            }
            FILTER_CHECK(wanted);
            break;

          case OPT_ATTRIBUTES:
            FILTER_CHECK(CHECK_TCP_HIGH_MASK(rwRecGetTcpState(rwrec),
                                             checks->attributes));
            break;

          case OPT_APPLICATION:
            FILTER_CHECK(skBitmapGetBit(checks->application,
                                        rwRecGetApplication(rwrec)));
            break;

          case OPT_IP_VERSION:
            switch (checks->ipv6_policy) {
              case SK_IPV6POLICY_MIX:
                break;
              case SK_IPV6POLICY_ONLY:
                FILTER_CHECK(rwRecIsIPv6(rwrec));
                break;
              case SK_IPV6POLICY_IGNORE:
                FILTER_CHECK(!rwRecIsIPv6(rwrec));
                break;
              case SK_IPV6POLICY_ASV4:
              case SK_IPV6POLICY_FORCE:
                /* can't happen */
                abort();
            }
            break;

          case OPT_SENSORS:
            FILTER_CHECK(skBitmapGetBit(checks->sID, rwRecGetSensor(rwrec)));
            break;

          case OPT_FLOW_TYPE:
            FILTER_CHECK(skBitmapGetBit(checks->flow_type,
                                        rwRecGetFlowType(rwrec)));
            break;

          default:
            skAppPrintErr("Unhandled value '%d' in switch() at %s:%d",
                          checks->checkSet[j], __FILE__, __LINE__);
            return (1 + checks->checkSet[j]);
        } /* switch */
    } /* outer for */

    return 0;                     /* WANTED! */
}


/*
 *  pass = filterCheckFile(rwio, ip_dir)
 *
 *    Check whether the SiLK Packed data file 'rwio' contains records
 *    that match the user's query.  This function uses information
 *    from the file's header and/or outside the data file---such as
 *    external IPsets or Bloom filters located in the 'ip_dir'---to
 *    see if pathname should be opened and its records read.
 *
 *    Returns 1 if the file at 'pathname' should be skipped, 0 if the
 *    file should be read, and -1 on error.
 */
int filterCheckFile(rwIOStruct_t *rwio, const char *ip_dir)
{
    sk_header_entry_t *pfh;
    char ippath[PATH_MAX];
    sktime_t t = -1;
    int wanted;
    int i;
    int j;
    int skip_file = 0;
    sk_file_header_t *hdr;
    fileFormat_t file_format;

    skIPTree_t *set[2] = {NULL, NULL};
    int tried_set[2] = {0, 0};
    const char *suffix_set[2] = {".sip", ".dip"};

#define LOAD_IPSET(idx)                                         \
    {                                                           \
        if (tried_set[(idx)] == 0) {                            \
            tried_set[(idx)] = 1;                               \
            if (ip_dir != NULL) {                               \
                snprintf(ippath, sizeof(ippath), "%s%s",        \
                         ip_dir, suffix_set[(idx)]);            \
                skIPTreeLoad(&(set[(idx)]), ippath);            \
            }                                                   \
        }                                                       \
    }

    hdr = rwGetHeader(rwio);
    file_format = skHeaderGetFileFormat(hdr);

    /* get handle to the header and the file's start time */
    pfh = skHeaderGetFirstMatch(hdr, SK_HENTRY_PACKEDFILE_ID);
    if (pfh) {
        t = skHentryPackedfileGetStartTime((sk_hentry_packedfile_t*)pfh);
    }

    for (j = 0; ((0 == skip_file) && (j < checks->check_count)); ++j) {

        switch (checks->checkSet[j]) {
          case OPT_STIME:
            /* ignore files where the range of possible start-times
             * for this file is outside the sTime window; that is,
             * where the range is either completely below or
             * completely above the window */
            if ((t != -1)
                && ((t > (sktime_t)checks->sTime.max)
                    || ((t + 3600999) < (sktime_t)checks->sTime.min)))
            {
                skip_file = 1;
            }
            break;

          case OPT_ETIME:
            /* ignore files where the possible end-time range (this
             * hour or the next hour allowing for durations of 3600)
             * is outside the eTime window */
            if ((t != -1)
                && ((t > (sktime_t)checks->eTime.max)
                    || ((t + 7200999) < (sktime_t)checks->sTime.min)))
            {
                skip_file = 1;
            }
            break;

          case OPT_ACTIVE_TIME:
            /* ignore files where the end time range is outside the
             * active time window---start time range is a sub-range of
             * the possible end-times */
            if ((t != -1)
                && ((t > (sktime_t)checks->activeTime.max)
                    || ((t + 7200999) < (sktime_t)checks->activeTime.min)))
            {
                skip_file = 1;
            }
            break;

          case OPT_PROTOCOL:
            if (skBitmapGetBit(checks->proto, 6) == 0) {
                /* user is not interested in TCP flows; ignore files
                 * containing web-only data */
                switch (file_format) {
                  case FT_RWAUGWEB:
                  case FT_RWWWW:
                    skip_file = 1;
                    break;
                }
            }
            break;

          case OPT_SADDRESS:
            if (set[SRC] == NULL) {
                LOAD_IPSET(SRC);
                if (set[SRC] == NULL) {
                    break;
                }
            }
            skip_file =
                !skIPTreeCheckIntersectIPWildcard(set[SRC],
                                                  &checks->ipwild[SRC]);
            break;

          case OPT_SET_SIP:
#if 1
            if (set[SRC] == NULL) {
                LOAD_IPSET(SRC);
                if (set[SRC] == NULL) {
                    break;
                }
            }
            skip_file = !skIPTreeCheckIntersectIPTree(set[SRC],
                                                      checks->ipset[SRC]);
#else
            snprintf(ippath, sizeof(ippath), "%s%s",
                     ip_dir, suffix_set[SRC]);
            skip_file = skIPTreeCheckIntersectIPTreeFile(checks->ipset[SRC],
                                                         ippath, NULL);
#endif
            break;

          case OPT_DADDRESS:
            if (set[DST] == NULL) {
                LOAD_IPSET(DST);
                if (set[DST] == NULL) {
                    break;
                }
            }
            skip_file =
                !skIPTreeCheckIntersectIPWildcard(set[DST],
                                                  &checks->ipwild[DST]);
            break;

          case OPT_SET_DIP:
#if 1
            if (set[DST] == NULL) {
                LOAD_IPSET(DST);
                if (set[DST] == NULL) {
                    break;
                }
            }
            skip_file = !skIPTreeCheckIntersectIPTree(set[DST],
                                                      checks->ipset[DST]);
#else
            snprintf(ippath, sizeof(ippath), "%s%s",
                     ip_dir, suffix_set[DST]);
            skip_file = skIPTreeCheckIntersectIPTreeFile(checks->ipset[DST],
                                                         ippath, NULL);
#endif
            break;

          case OPT_ANY_ADDRESS:
            if (set[SRC] == NULL) {
                LOAD_IPSET(SRC);
            }
            if (set[SRC]) {
                wanted =
                    skIPTreeCheckIntersectIPWildcard(set[SRC],
                                                     &checks->ipwild[ANY]);
                if (wanted == 1) {
                    break;
                }
            }
            if (set[DST] == NULL) {
                LOAD_IPSET(DST);
            }
            if (set[DST]) {
                skip_file =
                    !skIPTreeCheckIntersectIPWildcard(set[DST],
                                                      &checks->ipwild[ANY]);
            }
            break;

          case OPT_SET_ANY:
            if (set[SRC] == NULL) {
                LOAD_IPSET(SRC);
            }
            if (set[SRC]) {
                wanted = skIPTreeCheckIntersectIPTree(set[SRC],
                                                      checks->ipset[ANY]);
                if (wanted == 1) {
                    break;
                }
            }
            if (set[DST] == NULL) {
                LOAD_IPSET(DST);
            }
            if (set[DST]) {
                skip_file = !skIPTreeCheckIntersectIPTree(set[DST],
                                                          checks->ipset[ANY]);
            }
            break;

          case OPT_NEXT_HOP_ID:
            {
                skipaddr_t ip;
                memset(&ip, 0, sizeof(skipaddr_t));
                if (skIPWildcardCheckIp(&checks->ipwild[NHIP], &ip) == 0) {
                    /* user wants flows where nhIP is non-zero; ignore
                     * files that do not have nhIP info */
                    switch (file_format) {
                      case FT_RWAUGMENTED:
                      case FT_RWAUGWEB:
                      case FT_RWAUGSNMPOUT:
                      case FT_RWIPV6:
                      case FT_RWSPLIT:
                      case FT_RWWWW:
                        skip_file = 1;
                        break;
                    }
                }
            }
            break;

          case OPT_SET_NHIP:
            if (skIPTreeCheckAddress(checks->ipset[NHIP], 0) == 0) {
                /* user wants flows were nhIP is non-zero; ignore
                 * files that do not have nhIP info */
                switch (file_format) {
                  case FT_RWAUGMENTED:
                  case FT_RWAUGWEB:
                  case FT_RWAUGSNMPOUT:
                  case FT_RWIPV6:
                  case FT_RWSPLIT:
                  case FT_RWWWW:
                    skip_file = 1;
                    break;
                }
            }
            break;

          case OPT_INPUT_INDEX:
            if (skBitmapGetBit(checks->input, 0) == 0) {
                /* user wants flows were input is non-zero; ignore
                 * files that do not have incoming SNMP info */
                switch (file_format) {
                  case FT_RWAUGMENTED:
                  case FT_RWAUGWEB:
                  case FT_RWAUGSNMPOUT:
                  case FT_RWIPV6:
                  case FT_RWSPLIT:
                  case FT_RWWWW:
                    skip_file = 1;
                    break;
                }
            }
            break;

          case OPT_OUTPUT_INDEX:
            if (skBitmapGetBit(checks->output, 0) == 0) {
                /* user wants flows were output is non-zero; ignore
                 * files that do not have outgoing SNMP info */
                switch (file_format) {
                  case FT_RWAUGMENTED:
                  case FT_RWAUGWEB:
                  case FT_RWIPV6:
                  case FT_RWNOTROUTED:
                  case FT_RWSPLIT:
                  case FT_RWWWW:
                    skip_file = 1;
                    break;
                }
            }
            break;

          case OPT_FLAGS_INITIAL:
            wanted = 0;
            for (i = 0; i < checks->count_flags_init; ++i) {
                if (CHECK_TCP_HIGH_MASK(0, checks->flags_init[i])) {
                    wanted = 1;
                    break; /* wanted */
                }
            }
            if (wanted == 0) {
                /* user only wants flows where initial flags has some
                 * non-zero value; ignore files that do not have
                 * initial flags info */
                switch (file_format) {
                  case FT_RWNOTROUTED:
                  case FT_RWROUTED:
                  case FT_RWSPLIT:
                  case FT_RWWWW:
                    skip_file = 1;
                    break;
                }
            }
            break;

          case OPT_FLAGS_SESSION:
            wanted = 0;
            for (i = 0; i < checks->count_flags_session; ++i) {
                if (CHECK_TCP_HIGH_MASK(0, checks->flags_session[i])) {
                    wanted = 1;
                    break;
                }
            }
            if (wanted == 0) {
                /* user only wants flows where session flags has some
                 * non-zero value; ignore files that do not have
                 * session flags info */
                switch (file_format) {
                  case FT_RWNOTROUTED:
                  case FT_RWROUTED:
                  case FT_RWSPLIT:
                  case FT_RWWWW:
                    skip_file = 1;
                    break;
                }
            }
            break;

          case OPT_ATTRIBUTES:
            if (CHECK_TCP_HIGH_MASK(0, checks->attributes) == 0) {
                /* user only wants flows where attributes has some
                 * non-zero value; ignore files that do not have
                 * attributes info */
                switch (file_format) {
                  case FT_RWNOTROUTED:
                  case FT_RWROUTED:
                  case FT_RWSPLIT:
                  case FT_RWWWW:
                    skip_file = 1;
                    break;
                }
            }
            break;

          case OPT_APPLICATION:
            if (skBitmapGetBit(checks->application, 0) == 0) {
                /* user wants flows were application is non-zero;
                 * ignore files that do not have this info */
                switch (file_format) {
                  case FT_RWNOTROUTED:
                  case FT_RWROUTED:
                  case FT_RWSPLIT:
                  case FT_RWWWW:
                    skip_file = 1;
                    break;
                }
            }
            break;

          case OPT_IP_VERSION:
            if (checks->ipv6_policy == SK_IPV6POLICY_ONLY) {
                /* the user wants only IPv6 data; ignore files that
                 * contain only IPv4 data */
                switch (file_format) {
                  case FT_RWAUGMENTED:
                  case FT_RWAUGROUTING:
                  case FT_RWAUGWEB:
                  case FT_RWAUGSNMPOUT:
                  case FT_RWFILTER:
                  case FT_FLOWCAP:
                  case FT_RWGENERIC:
                  case FT_RWNOTROUTED:
                  case FT_RWROUTED:
                  case FT_RWSPLIT:
                  case FT_RWWWW:
                    skip_file = 1;
                    break;
                }
            }
            break;

#if 0
          case OPT_SENSORS:
            FILTER_CHECK(skBitmapGetBit(checks->sID, rwRecGetSensor(rwrec)));
            break;

          case OPT_FLOW_TYPE:
            FILTER_CHECK(skBitmapGetBit(checks->flow_type,
                                        rwRecGetFlowType(rwrec)));
            break;
#endif
          default:
            break;
        }
    }

    if (set[SRC]) {
        skIPTreeDelete(&set[SRC]);
    }
    if (set[DST]) {
        skIPTreeDelete(&set[DST]);
    }

    return skip_file;
}


/*
 * int filterSetup()
 *
 * SUMMARY:
 *
 * Called by the application to let the filter library setup for
 * options processing.
 *
 * RETURNS:
 *
 * on failure, returns 1
 * on success, returns 0
 *
 * SIDE EFFECTS:
 *
 * Initializes the filter library options with the options processing library.
 *
 * NOTES:
 *
 */
int filterSetup(void)
{
    int i;

    /* make certain we have enough space  */
    assert(_OPT_FINAL_OPTION_ < FILTER_CHECK_MAX);
    assert(_IP_INDEX_FINAL_ == IP_INDEX_COUNT);

    /* make certain enums are in sync */
    assert((OPT_SET_SIP  - OPT_SET_SIP)==(OPT_NOT_SET_SIP  - OPT_NOT_SET_SIP));
    assert((OPT_SET_DIP  - OPT_SET_SIP)==(OPT_NOT_SET_DIP  - OPT_NOT_SET_SIP));
    assert((OPT_SET_ANY  - OPT_SET_SIP)==(OPT_NOT_SET_ANY  - OPT_NOT_SET_SIP));
    assert((OPT_SET_NHIP - OPT_SET_SIP)==(OPT_NOT_SET_NHIP - OPT_NOT_SET_SIP));

    /* clear memory */
    memset(checks, 0, sizeof(filter_checks_t));

    /* copy options from filterSwitch[] to filterOptions[] */
    if (filterOptions == NULL) {
        filterOptions = calloc(sizeof(filterSwitch)/sizeof(filter_switch_t),
                               sizeof(struct option));
        for (i = 0; filterSwitch[i].option.name != NULL; ++i) {
            memcpy(&(filterOptions[i]), &(filterSwitch[i].option),
                   sizeof(struct option));
        }
    }

    /* register the options */
    if (skOptionsRegister(filterOptions, &filterOptionsHandler, NULL))
    {
        return 1;
    }

    return 0;
}


/*
 * void filterTeardown()
 *
 */
void filterTeardown(void)
{
    if (checks->sPort) {
        skBitmapDestroy(&checks->sPort);
        checks->sPort = NULL;
    }
    if (checks->dPort) {
        skBitmapDestroy(&checks->dPort);
        checks->dPort = NULL;
    }
    if (checks->any_port) {
        skBitmapDestroy(&checks->any_port);
        checks->any_port = NULL;
    }
    if (checks->proto) {
        skBitmapDestroy(&checks->proto);
        checks->proto = NULL;
    }
    if (checks->icmp_type) {
        skBitmapDestroy(&checks->icmp_type);
        checks->icmp_type = NULL;
    }
    if (checks->icmp_code) {
        skBitmapDestroy(&checks->icmp_code);
        checks->icmp_code = NULL;
    }
    if (checks->sID) {
        skBitmapDestroy(&checks->sID);
        checks->sID = NULL;
    }
    if (checks->flow_type) {
        skBitmapDestroy(&checks->flow_type);
        checks->flow_type = NULL;
    }
    if (checks->input) {
        skBitmapDestroy(&checks->input);
        checks->input = NULL;
    }
    if (checks->output) {
        skBitmapDestroy(&checks->output);
        checks->output = NULL;
    }
    if (checks->application) {
        skBitmapDestroy(&checks->application);
        checks->application = NULL;
    }

    if (filterOptions) {
        free(filterOptions);
        filterOptions = NULL;
    }
}


/* Return number of checks active. */
int  filterGetCheckCount(void)
{
    return checks->check_count;
}


/*
 *  status = filterGetFGlobFilters();
 *
 *    Create filter checks that correspond to the --sensor, --class,
 *    --type switches from the fglob() code by getting those values
 *    from fglob and creating filters for them.
 */
int filterGetFGlobFilters(void)
{
    int rv;

    /* Let fglob fill in the bitmaps with the sensors and class/types
     * to filter over. */
    rv = fglobSetFilters(&(checks->sID), &(checks->flow_type));

    if (rv < 0) {
        /* error */
        return rv;
    }
    if (rv & 1) {
        /* need to filter over sensor */
        checks->checkSet[checks->check_count] = OPT_SENSORS;
        checks->check_count++;
    }
    if (rv & 2) {
        /* need to filter over class/type */
        checks->checkSet[checks->check_count] = OPT_FLOW_TYPE;
        checks->check_count++;
    }

    return 0;
}


/*
 * static int parseTimeIntoValueRange(*p_vr, opt_index, *s_time)
 *
 * SUMMARY:
 *
 * Parses a time string using skStringParseDatetimeRange().  Stores
 * the result in the value_range_t pointed to by p_vr.
 *
 * PARAMETERS:
 *
 * value_range_t *p_vr = pointer to the time range storage variable
 * char *s_time = a string containing a time value to parse
 *
 * RETURNS:
 *
 * 0 on success
 * -1 on error, such as a badly formatted string, an end time occurring
 *   before a start time, etc.
 *
 * SIDE EFFECTS:
 *
 * on success, p_vr is set to [start,end], or if no end-time was parsed,
 * p_vr is set to [start,start]
 *
 * on failures, the contents of p_vr are not modified
 */
static int parseTimeIntoValueRange(
    value_range_t  *p_vr,
    int             opt_index,
    const char     *s_time)
{
    sktime_t min, max;
    int max_precision = 0;
    int rv;

    /* parse the time */
    rv = skStringParseDatetimeRange(&min, &max, s_time, NULL, &max_precision);
    if (rv) {
        skAppPrintErr("Invalid %s '%s': %s",
                      filterOptions[opt_index].name, s_time,
                      skStringParseStrerror(rv));
        return -1;
    }

    p_vr->min = (uint64_t)min;

    /* maximum */
    if (max == INT64_MAX) {
        /* there was no max date parsed */
        p_vr->max = p_vr->min;
    } else if (max_precision < 7) {
        /* the max date precision is less than (courser than)
         * millisecond resolution, so "round" the date up */
        if (skDatetimeCeiling(&max, &max, max_precision) != 0) {
            return -1;
        }
        p_vr->max = (uint64_t)max;
    } else {
        p_vr->max = (uint64_t)max;
    }

    return 0;
}


/*
 * uint32_t parseIntegerRange(value_range_t *tgtRange, char *rangeString)
 *
 * SUMMARY:
 *
 * parses a range of values (i.e.: a-b)
 *
 * PARAMETERS:
 *
 * value_range_t *tgtRange: the resulting range.
 * char *rangeString: a string containing a representation of the range.
 *
 * RETURNS:
 *
 * 0 on success; 1 on failure.
 *
 * SIDE EFFECTS:
 *
 * value_range_t is altered.
 */
static uint32_t parseIntegerRange(
    value_range_t  *tgtRange,
    int             opt_index,
    const char     *rangeString)
{
    int rv;

    /* parse first part of range; rv, if positive, will be location of
     * start of upper half of range. */
    rv = skStringParseUint64(&tgtRange->min, rangeString, 0, 0);
    if (rv < 0) {
        /* error */
        skAppPrintErr("Invalid %s lower bound in '%s': %s",
                      filterOptions[opt_index].name, rangeString,
                      skStringParseStrerror(rv));
        return 1;
    }

    if (rv == 0) {
        /* missing upper half */
        skAppPrintErr("Invalid %s '%s': Range missing upper limit",
                      filterOptions[opt_index].name, rangeString);
        return 1;
    }

    /* check for the hyphen */
    if (rangeString[rv] != '-') {
        /* stopped on non-hyphen */
        skAppPrintErr("Invalid %s lower bound in '%s': Unrecognized character",
                      filterOptions[opt_index].name, rangeString);
        return 1;
    }

    /* see if open-ended range: "3-" */
    if (rangeString[rv+1] == '\0') {
        tgtRange->max = UINT64_MAX;
        return 0;
    }

    /* parse upper part of range */
    rv = skStringParseUint64(&tgtRange->max, &rangeString[rv+1], 0, 0);
    if (rv != 0) {
        /* error */
        skAppPrintErr("Invalid %s upper bound in '%s': %s",
                      filterOptions[opt_index].name, rangeString,
                      skStringParseStrerror(rv));
        return 1;
    }

    if (tgtRange->max < tgtRange->min) {
        skAppPrintErr("Invalid %s '%s': Maximum less than minimum",
                      filterOptions[opt_index].name, rangeString);
        return 1;
    }

    return 0;
}


/*
 * uint32_t parseDecimalRange(value_range_t *tgtRange, char *rangeString)
 *
 * SUMMARY:
 *
 * parses a range of values (i.e.: a-b)
 *
 * PARAMETERS:
 *
 * value_range_t *tgtRange: the resulting range.
 * char *rangeString: a string containing a representation of the range.
 *
 * RETURNS:
 *
 * 0 on success; 1 on failure.
 *
 * SIDE EFFECTS:
 *
 * value_range_t is altered.
 *
 * NOTES:
 *
 * rename this to parsefixedpointrange at some point.
 */
static uint32_t parseDecimalRange(
    value_range_t  *tgtRange,
    int             opt_index,
    const char     *rangeString)
{
    double val;
    int rv;

    /* parse first part of range; rv, if positive, will be location of
     * start of upper half of range. */
    rv = skStringParseDouble(&val, rangeString, 0, UINT32_MAX);
    if (rv < 0) {
        /* error */
        skAppPrintErr("Invalid %s lower bound in '%s': %s",
                      filterOptions[opt_index].name, rangeString,
                      skStringParseStrerror(rv));
        return 1;
    }

    tgtRange->min = (uint64_t)PRECISION * val;

    if (rv == 0) {
        /* missing upper half */
        skAppPrintErr("Invalid %s '%s': Range missing upper limit",
                      filterOptions[opt_index].name, rangeString);
        return 1;
    }

    /* check for the hyphen */
    if (rangeString[rv] != '-') {
        /* stopped on non-hyphen */
        skAppPrintErr("Invalid %s lower bound in '%s': Unrecognized character",
                      filterOptions[opt_index].name, rangeString);
        return 1;
    }

    /* see if open-ended range: "3.5-" */
    if (rangeString[rv+1] == '\0') {
        tgtRange->max = UINT64_MAX;
        return 0;
    }

    /* parse upper part of range */
    rv = skStringParseDouble(&val, &rangeString[rv+1], 0, UINT32_MAX);
    if (rv != 0) {
        /* error */
        skAppPrintErr("Invalid %s upper bound in '%s': %s",
                      filterOptions[opt_index].name, rangeString,
                      skStringParseStrerror(rv));
        return 1;
    }

    tgtRange->max = (uint64_t)PRECISION * val;

    if (tgtRange->max < tgtRange->min) {
        skAppPrintErr("Invalid %s '%s': Maximum less than minimum",
                      filterOptions[opt_index].name, rangeString);
        return 1;
    }

    return 0;
}


/*
 *  status = parseFlagsHelper(opt_index, high_mask_string)
 *
 *    Parse a single HIGH/MASK pair.  Return 0 on success, and
 *    non-zero on failure.
 */
static int parseFlagsHelper(
    int                 opt_index,
    const char         *high_mask_string)
{
    uint8_t *check_count;
    high_mask_t *h_m;
    int rv;

    /* set 'check_count' to the current number of checks for the
     * specified test, and have 'h_m' point to the location in which
     * to add the next check. */
    switch (opt_index) {
      case OPT_FLAGS_ALL:
        check_count = &checks->count_flags_all;
        h_m = &(checks->flags_all[*check_count]);
        break;
      case OPT_FLAGS_INITIAL:
        check_count = &checks->count_flags_init;
        h_m = &(checks->flags_init[*check_count]);
        break;
      case OPT_FLAGS_SESSION:
        check_count = &checks->count_flags_session;
        h_m = &(checks->flags_session[*check_count]);
        break;
      default:
        skAppPrintErr("Unhandled value '%d' in switch() at %s:%d",
                      opt_index, __FILE__, __LINE__);
        assert(0);
        exit(EXIT_FAILURE);
    }

    if (*check_count >= MAX_TCPFLAG_CHECKS) {
        skAppPrintErr("May only specify %d %s checks",
                      MAX_TCPFLAG_CHECKS, filterOptions[opt_index].name);
        return 1;
    }

    rv = skStringParseTCPFlagsHighMask(&(h_m->high), &(h_m->mask),
                                       high_mask_string);
    if (rv) {
        skAppPrintErr("Invalid %s '%s': %s",
                      filterOptions[opt_index].name, high_mask_string,
                      skStringParseStrerror(rv));
        return 1;
    }

    ++*check_count;
    return 0;
}


/*
 *  status = parseFlags(opt_index, opt_arg)
 *
 *    Parse the value passed to the --flags-all, --flags-initial and
 *    --flags-sesion switches, which expect a flags in the form
 *    HIGH/MASK.  Multiple HIGH/MASK sets may be specified by
 *    separating them with comma.
 *
 *    Return 0 on success, and non-zero on failure.
 */
static int parseFlags(
    int                 opt_index,
    const char         *opt_arg)
{
    char buf[32];
    const char *cp;
    const char *sp = opt_arg;
    size_t len;

    while (*sp) {
        cp = strchr(sp, ',');

        /* if there is no ',' in the (remaining) input, just pass the
         * input to the helper function for parsing. */
        if (cp == NULL) {
            return parseFlagsHelper(opt_index, sp);
        }
        if (cp == sp) {
            /* double comma */
            ++sp;
            continue;
        }

        /* copy this flag combination into 'buf' */
        len = cp - sp;
        if (len > sizeof(buf)-1) {
            return 1;
        }
        strncpy(buf, sp, len);
        buf[len] = '\0';
        sp = cp + 1;
        if (parseFlagsHelper(opt_index, buf)) {
            return 1;
        }
    }

    return 0;
}


/*
 *  status = setFilterCheckBinaryFlag(opt_index, opt_arg);
 *
 *    Set the 'flagMark' and 'flagCare' for the TCP flag 'flag'
 *    according to whether 'opt_arg' parses as a 0 or a 1.
 *    'opt_index' is used to report an error.
 */
static int setFilterCheckBinaryFlag(
    int             opt_index,
    const char     *opt_arg)
{
    static uint8_t binary_flag_pos = MAX_TCPFLAG_CHECKS;
    uint8_t flag;
    unsigned long i;

    if (binary_flag_pos == MAX_TCPFLAG_CHECKS) {
        /* first time we've called this function */
        if (checks->count_flags_all >= MAX_TCPFLAG_CHECKS) {
            skAppPrintErr("May only specify %d tcp-flags checks",
                          MAX_TCPFLAG_CHECKS);
            return 1;
        }
        binary_flag_pos = checks->count_flags_all;
        ++checks->count_flags_all;
    }

    switch (opt_index) {
      case OPT_FIN_FLAG:  flag = FIN_FLAG;  break;
      case OPT_SYN_FLAG:  flag = SYN_FLAG;  break;
      case OPT_RST_FLAG:  flag = RST_FLAG;  break;
      case OPT_PSH_FLAG:  flag = PSH_FLAG;  break;
      case OPT_ACK_FLAG:  flag = ACK_FLAG;  break;
      case OPT_URG_FLAG:  flag = URG_FLAG;  break;
      case OPT_ECE_FLAG:  flag = ECE_FLAG;  break;
      case OPT_CWR_FLAG:  flag = CWR_FLAG;  break;
      default:
        skAppPrintErr("Unhandled value '%d' in switch() at %s:%d",
                      opt_index, __FILE__, __LINE__);
        assert(0);
        exit(EXIT_FAILURE);
    }

    i = strtoul(opt_arg, (char **)NULL, 10);
    switch (i) {
      case 1:
        TCP_FLAG_SET_FLAG(checks->flags_all[binary_flag_pos].high, flag);
        /* FALLTHROUGH */
      case 0:
        TCP_FLAG_SET_FLAG(checks->flags_all[binary_flag_pos].mask, flag);
        break;
      default:
        skAppPrintErr("Error parsing --%s option: '%s'",
                      filterOptions[opt_index].name, opt_arg);
        return 1;
    }

    return 0;
}


/*
 *  status = parseAttributes(opt_index, opt_arg);
 *
 */
static int parseAttributes(
    int             opt_index,
    const char     *opt_arg)
{
    const char *cp = opt_arg;
    uint8_t *p;

    checks->attributes.high = checks->attributes.mask = 0;

    p = &checks->attributes.high;
    while (*cp) {
        switch (*cp) {
          case 'F':
            *p |= SK_TCPSTATE_FIN_FOLLOWED_NOT_ACK;
            break;
          case 'T':
            *p |= SK_TCPSTATE_TIMEOUT_KILLED;
            break;
          case 'C':
            *p |= SK_TCPSTATE_TIMEOUT_STARTED;
            break;
          case '/':
            if (p == &checks->attributes.mask) {
                skAppPrintErr("Only one slash allowed in input to %s switch",
                              filterOptions[opt_index].name);
                return 1;
            }
            p = &checks->attributes.mask;
            break;
          default:
            skAppPrintErr("Unrecognized character '%c' in %s switch",
                          *cp, filterOptions[opt_index].name);
            return 1;
        }
        ++cp;
    }

    if ((checks->attributes.high & checks->attributes.mask)
        != checks->attributes.high)
    {
        skAppPrintErr("High-value is not a subset of care-value in %s switch",
                      filterOptions[opt_index].name);
        return 1;
    }
    if (checks->attributes.mask == 0) {
        skAppPrintErr("Must provide at least one care-value in %s switch",
                      filterOptions[opt_index].name);
        return 1;
    }

    return 0;
}

/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
