/*
** Copyright (C) 2001-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**
**  10/14/2002
** Suresh L. Konda
**
** fglob.c
**
** routines for globbing files in the special dir hierarchy we have for
** packed files.
**
** There are three externally visible routines:
**  fglobSetup(): setup stuff
**  fglobNext():  call repeatedly till no more files
**  fglobTeardown(): clean up
**  fglobValid(): 1 if user specified any params; 0 else.
**
**  There is also a set of GetXX routines to gain access to the internals
**  of the fglob data structure.
**
** Details are given as block comments before these routines.
**
*/

#include "silk.h"

RCSIDENT("$SiLK: fglob.c 11248 2008-04-11 19:07:39Z mthomas $");

#include "rwfilter.h"


/* LOCAL TYPEDEFS AND DEFINES */

/* Whether the --class switch supports multiple classes. */
#define FGLOB_MULTIPLE_CLASSES 0

/*
 * The maximum number of classes supported: Set this to
 * (sksiteClassGetMaxID()+1) (from sksite.h) for multiple class
 * support, or 1 to support a single class.  THIS SHOULD NOT BE 0.
 */
#if FGLOB_MULTIPLE_CLASSES
#  define FGLOB_NUM_CLASSES (sksiteClassGetMaxID()+1)
#else
#  define FGLOB_NUM_CLASSES 1
#endif

/* Output handle for --print-missing-files output */
#define MISSING_FH stderr


#define PERROR_MEM skAppPrintErr("Out of memory at %s:%d", __FILE__, __LINE__)

/*
 *  Structure for all pertinent information for a given find request.
 */
typedef struct fglobListStruct_st {
    /* flag: number of globbing options specified */
    int8_t          fg_user_option_count;
    /* flag: 1 if the globber was partly initialized; 2 if completely init'd */
    int8_t          fg_initialized;
    /* flag: 1 to print msg about existence of each file */
    int8_t          fg_missing;

    /* specified class/types */
    flowtypeID_t   *fg_flowtype_list;
    /* number of class/type pairs designated: length of fg_flowtype_list */
    int             fg_flowtype_count;
    /* current class/type when globbing; index into fg_flowtype_list */
    int             fg_flowtype_idx;

    /* list of sensor IDs wanted for each class/type */
    int           **fg_sensor_list;
    /* for each class/type, number of sensors: length of fg_sensor_list[i] */
    int            *fg_sensor_count;
    /* current sensor when globbing; index into
     * fg_sensor_list[fg_flowtype_idx] */
    int             fg_sensor_idx;

    /* start, end, current time---as milliseconds since the UNIX epoch
     * in UTC */
    sktime_t        fg_time_start;
    sktime_t        fg_time_end;
    sktime_t        fg_time_idx;

    /* user's input to various options.  This will be an array of
     * char*, index by the FGLOB_OPT_* enum.  The array will be
     * created once we know the number of options.*/
    char          **fg_option;

} fglobListStruct_t;



/* INTERNAL FUNCTIONS */

static int fglobAdjustCountersFlowtype(void);
static int fglobParseWordList(
    char   *string,
    char  **word_list,
    int     max_word_list);
static int fglobCheckTypesForClass(void);
static int fglobCheckClass(int *num_classes, int *class_list);
static int fglobCheckSensors(void);

static int fglobInit(void);
static int fglobLoadSiteConfig(void);
static int fglobInitTimes(void);
static int fglobHandler(clientData cData, int opt_index, char *opt_arg);
static void fglobEnableAllSensors(void);
static int fglobParseSensorCmdLine(
    const char     *sensor_list,
    sk_bitmap_t    *sensor_bits);


/* INTERNAL VARIABLES */

static fglobListStruct_t fglob_list;
static fglobListStruct_t * const fList = &fglob_list;




/* OPTIONS SETUP */

enum fglobOptionEnum {
    FGLOB_OPT_CLASS, FGLOB_OPT_TYPE, FGLOB_OPT_SENSORS,
    FGLOB_OPT_START_DATE, FGLOB_OPT_END_DATE,
    FGLOB_OPT_PRINT_MISSING_FILES,
    FGLOB_OPT_DATA_ROOTDIR
};

static struct option fglobOptions[] = {
    {"class",                REQUIRED_ARG, 0, FGLOB_OPT_CLASS},
    {"type",                 REQUIRED_ARG, 0, FGLOB_OPT_TYPE},
    {"sensors",              REQUIRED_ARG, 0, FGLOB_OPT_SENSORS},
    {"start-date",           REQUIRED_ARG, 0, FGLOB_OPT_START_DATE},
    {"end-date",             REQUIRED_ARG, 0, FGLOB_OPT_END_DATE},
    {"print-missing-files",  NO_ARG,       0, FGLOB_OPT_PRINT_MISSING_FILES},
    {"data-rootdir",         REQUIRED_ARG, 0, FGLOB_OPT_DATA_ROOTDIR},
    {0, 0, 0, 0}
};

static const char *fglobHelp[] = {
    NULL, /* class:     text is generated by fglobUsage() */
    NULL, /* type:      text is generated by fglobUsage() */
    NULL, /* sensor:    text is generated by fglobUsage() */
    "YYYY/MM/DD[:HH]. Def. start of today",
    "YYYY/MM/DD[:HH]. Def. start-date",
    ("Print the names of missing files to STDERR.\n"
     "\tDef. No"),
    NULL, /* data-rootdir: text is generated by fglobUsage() */
    (char *)NULL
};



/*
 *  is_ok = fglobSetup();
 *
 *    Initialize the values in the global fList structure: set
 *    everything to zero; set times to -1.  Register fglob options and
 *    handler.  Check the environment for variable giving the location
 *    of the data.
 *
 *    Return 0 if OK. 1 else.
 */
int fglobSetup(void)
{
    /* Verify programmer set options and help structs correctly */
    assert((sizeof(fglobHelp)/sizeof(char *))
           == (sizeof(fglobOptions)/sizeof(struct option)));

    /* zero out everything */
    memset(fList, 0, sizeof(fglobListStruct_t));

    /* Create the array to hold the option strings */
    fList->fg_option = calloc(1, sizeof(fglobHelp));
    if (NULL == fList->fg_option) {
        PERROR_MEM;
        return 1;
    }

    /* set start/end days/hours to be able to trap whether user gave
     * it explicitly
     */
    fList->fg_time_start = 0;
    fList->fg_time_end = 0;

    /* register the options */
    if (skOptionsRegister(fglobOptions, &fglobHandler, (clientData)fList)
        || sksiteOptionsRegister(SK_SITE_FLAG_CONFIG_FILE))
    {
        skAppPrintErr("Unable to register options");
        return 1;
    }

    return 0;                     /* OK */
}


/*
 *  fglobUsageClass(fh)
 *
 *    Print the usage for the --class switch to the specified file
 *    handle.
 */
static void fglobUsageClass(FILE *fh)
{
    classID_t class_id;
    class_iter_t ci;
    char class_name[SK_MAX_STRLEN_FLOWTYPE+1];
    int class_count = 0;

    /* CLASS: Use sksite to get list of classes */

    fprintf(fh, "Class name: ");
    sksiteClassIterator(&ci);
    while (sksiteClassIteratorNext(&ci, &class_id)) {
        sksiteClassGetName(class_name, sizeof(class_name), class_id);
        ++class_count;
        if (class_count == 1) {
            /* print first class */
            fprintf(fh, "(%s", class_name);
        } else {
            fprintf(fh, ",%s", class_name);
        }
    }
    if (class_count > 0) {
        fprintf(fh, ").");
    }
    class_id = sksiteClassGetDefault();
    if ( class_id != SK_INVALID_CLASS ) {
        sksiteClassGetName(class_name, sizeof(class_name), class_id);
        fprintf(fh, "  Def. %s", class_name);
    }
    fprintf(fh, "\n");
}


/*
 *  fglobUsageType(fh)
 *
 *    Print the usage for the --type switch to the specified file
 *    handle.
 */
static void fglobUsageType(FILE *fh)
{
    classID_t class_id;
    class_iter_t ci;
    flowtypeID_t flowtype_id;
    flowtype_iter_t fi;
    char name[SK_MAX_STRLEN_FLOWTYPE+1];
    char buf[128 + SK_MAX_STRLEN_FLOWTYPE];
    char *pos;
    int len;
    int flowtype_count;
    char *maybe_wrap;
    char old_char;
    const char *line_leader = "\t  * ";
    const char *cont_line_leader = "\t    ";
    const int wrap_col = 79 - 7;

    /* TYPE: For each class, read the list of types and
     * default list of types from sksite. */

    fprintf(fh, ("Type names and the default type(s) vary by class;\n"
                 "\tthe value 'all' will process every type for"
                 " the specified class.\n"
                 "\tThe following list shows"
                 " 'class (available types) default type(s)':\n"));

    /* loop over all the classes */
    sksiteClassIterator(&ci);
    while ( sksiteClassIteratorNext(&ci, &class_id) ) {
        pos = buf;

        /* print class name */
        sksiteClassGetName(name, sizeof(name), class_id);
        len = snprintf(pos, sizeof(buf)-(pos-buf), "%s%s", line_leader, name);
        pos += len;

        /* loop over the flowtypes in the class */
        flowtype_count = 0;
        sksiteClassFlowtypeIterator(class_id, &fi);
        while (sksiteFlowtypeIteratorNext(&fi, &flowtype_id)) {
            sksiteFlowtypeGetType(name, sizeof(name), flowtype_id);
            ++flowtype_count;
            maybe_wrap = pos;
            if (flowtype_count == 1) {
                /* print first type for this class */
                len = snprintf(pos, sizeof(buf)-(pos-buf), " (%s", name);
                pos += len;
            } else {
                /* print remaining types for the class */
                len = snprintf(pos, sizeof(buf)-(pos-buf), ",%s", name);
                pos += len;
            }
            /* check if we need to wrap the line */
            if ((pos - buf) > wrap_col) {
                if (flowtype_count > 1) {
                    ++maybe_wrap;
                }
                old_char = *maybe_wrap;
                *maybe_wrap = '\0';
                fprintf(fh, "%s\n", buf);
                *maybe_wrap = old_char;
                pos = buf;
                len = snprintf(pos, sizeof(buf)-(pos-buf), "%s%s",
                              cont_line_leader, maybe_wrap);
                pos += len;
            }
        }
        if (flowtype_count > 0) {
            len = snprintf(pos, sizeof(buf)-(pos-buf), ").");
            pos += len;
        }
        /* loop over the default flowtypes in the class */
        flowtype_count = 0;
        sksiteClassDefaultFlowtypeIterator(class_id, &fi);
        while (sksiteFlowtypeIteratorNext(&fi, &flowtype_id)) {
            sksiteFlowtypeGetType(name, sizeof(name), flowtype_id);
            ++flowtype_count;
            maybe_wrap = pos;
            if (flowtype_count == 1) {
                /* print first default type for this class */
                len = snprintf(pos, sizeof(buf)-(pos-buf), " Def. %s", name);
                pos += len;
            } else {
                len = snprintf(pos, sizeof(buf)-(pos-buf), ",%s", name);
                pos += len;
            }
            /* check if we need to wrap the line */
            if ((pos - buf) > wrap_col) {
                if (flowtype_count > 1) {
                    ++maybe_wrap;
                }
                old_char = *maybe_wrap;
                *maybe_wrap = '\0';
                fprintf(fh, "%s\n", buf);
                if (old_char == ' ') {
                    ++maybe_wrap;
                } else {
                    *maybe_wrap = old_char;
                }
                pos = buf;
                len = snprintf(pos, sizeof(buf)-(pos-buf), "%s%s",
                              cont_line_leader, maybe_wrap);
                pos += len;
            }
        }
        fprintf(fh, "%s\n", buf);
    }
}


/*
 *  fglobUsageSensors(fh)
 *
 *    Print the usage for the --sensor switch to the specified file
 *    handle.
 */
static void fglobUsageSensors(FILE *fh)
{
    fprintf(fh, ("Comma separated list of sensor names and/or IDs (0-%u).\n"
                 "\tUse 'mapsid' to see mapping of sensor names to IDs\n"),
            sksiteSensorGetMaxID());
}


/*
 *  fglobUsageDataRootdir(fh)
 *
 *    Print the usage for the --root-directory switch to the specified
 *    file handle.
 */
static void fglobUsageDataRootdir(FILE *fh)
{
    char rootdir[PATH_MAX];

    fprintf(fh, ("Root of directory tree containing packed data\n"
                 "\tDef. $SILK_DATA_ROOTDIR or '%s'\n"),
            sksiteGetRootDir(rootdir, sizeof(rootdir)));
}


/*
 *  fglobUsage(fh);
 *
 *    Print, to the given file handle, the usage for the command-line
 *    switches provided by the fglob library.
 */
void fglobUsage(FILE *fh)
{
    int opt;

    fprintf(fh, ("\nSELECTION SWITCHES choose which files to read"
                 " from the data store:\n\n"));

    if (sksiteConfigure(0)) {
        fprintf(fh, ("WARNING: site configuration file was not found"
                     " or contains errors\n"));
    }

    for (opt = 0; fglobOptions[opt].name; ++opt) {
        fprintf(fh, "--%s %s. ", fglobOptions[opt].name,
                SK_OPTION_HAS_ARG(fglobOptions[opt]));
        switch (fglobOptions[opt].val) {

          case FGLOB_OPT_CLASS:
            fglobUsageClass(fh);
            break;

          case FGLOB_OPT_TYPE:
            fglobUsageType(fh);
            break;

          case FGLOB_OPT_SENSORS:
            fglobUsageSensors(fh);
            break;

          case FGLOB_OPT_DATA_ROOTDIR:
            fglobUsageDataRootdir(fh);
            break;

          default:
            /* Simple help text is in fglobHelp[] array */
            fprintf(fh, "%s\n", fglobHelp[opt]);
        }
    } /* for */

    sksiteOptionsUsage(fh);
}


/*
 *  fglobTeardown()
 *
 *    Free the elements in fList which were malloc'ed.  Do not free
 *    the fList struct itself---it is a global static.  Multiple calls
 *    to this function are handled gracefully.
 */
void fglobTeardown(void)
{
    static int teardownFlag = 0;
    int i;

    /* Idempotency check. */
    if (teardownFlag) {
        return;
    }
    teardownFlag = 1;

    /* free our data structures */
    if (fList->fg_flowtype_list) {
        free(fList->fg_flowtype_list);
        fList->fg_flowtype_list = NULL;
    }
    if (fList->fg_sensor_list) {
        for (i = sksiteFlowtypeGetMaxID(); i >= 0; --i) {
            if (fList->fg_sensor_list[i]) {
                free(fList->fg_sensor_list[i]);
            }
        }
        free(fList->fg_sensor_list);
        fList->fg_sensor_list = NULL;
    }
    if (fList->fg_sensor_count) {
        free(fList->fg_sensor_count);
        fList->fg_sensor_count = NULL;
    }

    /* free the options */
    if (fList->fg_option) {
        free(fList->fg_option);
        fList->fg_option = NULL;
    }

    return;
}


/*
 *  filename = fglobNext();
 *
 *    Return the name of next available file.  Returns NULL if all
 *    files have been processed.
 *
 *    Will complete the initialization of the library if required.
 */
char *fglobNext(char *buf, size_t bufsize)
{
    int (*file_exists_fn)(const char *path);
    char *ext;

    {
        file_exists_fn = &skFileExists;
    }

    if (!fList->fg_initialized) {
        if (fglobInit()) {
            /* error */
            return NULL;
        }
    }

    /* keep adjusting the counters until we find a file that exists */
    while (fglobAdjustCountersFlowtype()) {
        /* Create the full path to the data file from the root dir,
         * pathPrefix, year, month, day, hour, flow-type dependent
         * file prefix, and sensor name.  Create the name with a '.gz'
         * extention, but hide the extension the first time we look
         * for the file. */
        sksiteGeneratePathname(
            buf, bufsize,
            fList->fg_flowtype_list[fList->fg_flowtype_idx],
            fList->fg_sensor_list[fList->fg_flowtype_idx]
                                 [fList->fg_sensor_idx],
            fList->fg_time_idx, ".gz", NULL, NULL);

        /* hide the compression extension */
        ext = &buf[strlen(buf) - 3];
        assert(*ext == '.');
        *ext = '\0';

        if ( !file_exists_fn(buf)) {
            /* check for compressed version of file */
            *ext = '.';

            if ( !file_exists_fn(buf)) {
                if (fList->fg_missing) {
                    *ext = '\0';
                    fprintf(MISSING_FH, "Missing %s\n", buf);
                }
                continue;
            }
        }

        return buf;
    }

    return NULL;
}


/*
 *  is_ok = fglobInit();
 *
 *    This is an internal function and should be called to initialize
 *    things based on the options given by the user.  Hence this must
 *    be called after the options are parsed.  To make life easier for
 *    the application programmer, this routine is called by the first
 *    call to fglobNext().
 *
 *    Return 0 for OK. 1 else;
 */
static int fglobInit(void)
{
    fList->fg_initialized = 1;

    /* load the site config */
    if (fglobLoadSiteConfig()) {
        /* error */
        return 1;
    }

    /* set up the times */
    if (fglobInitTimes()) {
        /* error */
        return 1;
    }

    if (fglobCheckTypesForClass()) {
        /* error */
        return 1;
    }
    /* now check if the sensor list is valid given the class/type. */
    if (fglobCheckSensors()) {
        /* error */
        return 1;
    }

    return 0;
}


/*
 *  is_ok = fglobHandler(cData, opt_index, opt_arg);
 *
 *    Called by options processor.  Return 1 on error, 0 on success.
 */
static int fglobHandler(
    clientData  UNUSED(cData),
    int         opt_index,
    char       *opt_arg)
{
    fList->fg_user_option_count++;

    switch (opt_index) {
      case FGLOB_OPT_CLASS:
      case FGLOB_OPT_TYPE:
      case FGLOB_OPT_SENSORS:
      case FGLOB_OPT_START_DATE:
      case FGLOB_OPT_END_DATE:
        if (fList->fg_option[opt_index] != NULL) {
            skAppPrintErr("Option --%s given multiple times",
                          fglobOptions[opt_index].name);
            return 1;
        }
        fList->fg_option[opt_index] = opt_arg;
        break;

      case FGLOB_OPT_PRINT_MISSING_FILES:
        fList->fg_missing = 1;
        break;

      case FGLOB_OPT_DATA_ROOTDIR:
        if (!skDirExists(opt_arg)) {
            skAppPrintErr("Root data directory '%s' does not exist", opt_arg);
            return 1;
        }
        if (sksiteSetRootDir(opt_arg)) {
            skAppPrintErr("Unable to set root data directory to %s", opt_arg);
            return 1;
        }
        break;

      default:
        skAppPrintErr("fglobHandler: invalid index %d", opt_index);
        abort(); /* programmer error */

    } /* switch */

    return 0;                     /* OK */
}


/*
 *  have_more_data = fglobAdjustCountersFlowtype();
 *
 *    Go to the next (or first if fg_initialized is < 2) sensor, or
 *    type, or class, or hour, or day.  Return 0 if there is nothing
 *    else to iterate over, or 1 otherwise.
 *
 *    fglobInit() must be called before calling this function.
 *
 *    When fg_initialized < 2, the function assumes this is the first
 *    time it has been called and it will complete the initialization
 *    of the counters that was started by fglobInit(); otherwise it
 *    will increment the counters.
 */
static int fglobAdjustCountersFlowtype(void)
{
    if (fList->fg_initialized < 2) {
        /* was init called? */
        assert(fList->fg_initialized);

        /* This is the first call into this function.  All of the
         * indexes are at zero; there is nothing we need to lookup, so
         * simply set the "we've been here" flag and return. */
        fList->fg_initialized = 2;

        return 1;
    }

    /* This is not the first call into this function; need to
     * increment or reset the appropriate counters. */

    /* Make certain we haven't reached the end of the data. */
    if (fList->fg_time_idx > fList->fg_time_end) {
        return 0;
    }

    /* First, see if we can increment the sensor */
    fList->fg_sensor_idx++;
    if(fList->fg_sensor_idx < fList->fg_sensor_count[fList->fg_flowtype_idx]){
        /* we're good: looking at next sensor--same class, type & time */
        return 1;
    }
    /* On last sensor; reset and try class/type */
    fList->fg_sensor_idx = 0;

    /* Try to increment the class/type */
    if (fList->fg_flowtype_count > 1) {
        fList->fg_flowtype_idx++;
        if (fList->fg_flowtype_idx < fList->fg_flowtype_count) {
            /* we're good: looking at next class/type -- same time */
            return 1;
        }
        /* On last class/type; reset and try time */
        fList->fg_flowtype_idx = 0;
    }

    /* Finally, increment the time: go to next hour */
    fList->fg_time_idx += 3600000;
    if (fList->fg_time_idx > fList->fg_time_end)
    {
        /* We're done. */
        return 0;
    }

    return 1;
}


/*
 *  status = fglobLoadSiteConfig();
 *
 *    Load the site configuration file and allocate the arrays of
 *    flowtypes and sensors that depend on the number of items
 *    defined.  Return 0 for success, non-zero on error.
 */
static int fglobLoadSiteConfig(void)
{
    int flowtype_count;
    int sensor_count;
    int i;

    /* load the site config */
    if (sksiteConfigure(1)) {
        /* error */
        return 1;
    }

    /* return if we have already allocated everything */
    if (fList->fg_sensor_count != NULL) {
        return 0;
    }

    /* Allocate memory for lists, based on sizes from sksite */
    flowtype_count = sksiteFlowtypeGetMaxID() + 1;
    sensor_count = sksiteSensorGetMaxID() + 1;

    fList->fg_flowtype_list = calloc(flowtype_count, sizeof(flowtypeID_t));
    if (fList->fg_flowtype_list == NULL) {
        PERROR_MEM;
        return 1;
    }
    fList->fg_sensor_list = calloc(flowtype_count, sizeof(int *));
    if (fList->fg_sensor_list == NULL) {
        PERROR_MEM;
        return 1;
    }
    for (i = 0; i < flowtype_count; ++i) {
        fList->fg_sensor_list[i] = calloc(sensor_count + 1, sizeof(int));
        if (fList->fg_sensor_list[i] == NULL) {
            PERROR_MEM;
            return 1;
        }
    }

    fList->fg_sensor_count = calloc(flowtype_count, sizeof(int));
    if (fList->fg_sensor_count == NULL) {
        PERROR_MEM;
        return 1;
    }

    return 0;
}


/*
 *  is_ok = fglobInitTimes();
 *
 *    Verify the user's time inputs and initialize the start and end
 *    times based on the input.  Return 0 if all is well; otherwise
 *    print an error and return 1.
 */
static int fglobInitTimes(void)
{
    sktime_t start_val;
    sktime_t end_val;
    int start_precision = -1;
    int end_precision = -1;
    time_t t;
    int rv;
#if  SK_ENABLE_LOCALTIME
    struct tm work_tm;
    int work_hour;
#endif

    /* If no start time, make certain there was no end time, then look
     * at everything from today in local time. */
    if ( !fList->fg_option[FGLOB_OPT_START_DATE]) {
        if (fList->fg_option[FGLOB_OPT_END_DATE]) {
            skAppPrintErr("Cannot use --%s without --%s",
                          fglobOptions[FGLOB_OPT_END_DATE].name,
                          fglobOptions[FGLOB_OPT_START_DATE].name);
            return 1;
        }

        time(&t);

        /* Take the floor of the time in hours */
        t = t - (t % 3600);

        /* Set the ending time to current hour */
        fList->fg_time_end = (sktime_t)1000 * t;

        /* Go to start of today */
#if   SK_ENABLE_LOCALTIME
        localtime_r(&t, &work_tm);
        work_tm.tm_hour = 0;
        t = mktime(&work_tm);
#else
        t = t - (t % 86400);
#endif

        /* Set the starting time */
        fList->fg_time_start = (sktime_t)1000 * t;

        /* Set the current time to the start time */
        fList->fg_time_idx = fList->fg_time_start;
        return 0;
    }

    /* Parse the starting time */
    rv = skStringParseDatetime(&start_val,
                               fList->fg_option[FGLOB_OPT_START_DATE],
                               &start_precision);
    if (rv) {
        skAppPrintErr("Invalid %s '%s': %s",
                      fglobOptions[FGLOB_OPT_START_DATE].name,
                      fList->fg_option[FGLOB_OPT_START_DATE],
                      skStringParseStrerror(rv));
        return 1;
    }
    if (start_precision > 4) {
        skAppPrintErr("Warning: %s precision greater than hours ignored",
                      fglobOptions[FGLOB_OPT_START_DATE].name);
    }

    /* Take to start of hour */
    fList->fg_time_start = start_val - (start_val % 3600000);

    if (fList->fg_option[FGLOB_OPT_END_DATE]) {
        rv = skStringParseDatetime(&end_val,
                                   fList->fg_option[FGLOB_OPT_END_DATE],
                                   &end_precision);
        if (rv) {
            skAppPrintErr("Invalid %s '%s': %s",
                          fglobOptions[FGLOB_OPT_END_DATE].name,
                          fList->fg_option[FGLOB_OPT_END_DATE],
                          skStringParseStrerror(rv));
            return 1;
        }

        /* Force end time to start of hour */
        fList->fg_time_end = end_val - (end_val % 3600000);

        /* Make any required adjustements to end-time */
        if (start_precision == 3) {
            /* when no starting hour given, we look at the full days,
             * regardless of the precision of the ending time; go to
             * the last hour of the ending day. */
            if (end_precision >= 4) {
                skAppPrintErr(("Warning: %s precision greater than days\n"
                               "\tignored when %s has no hour"),
                              fglobOptions[FGLOB_OPT_END_DATE].name,
                              fglobOptions[FGLOB_OPT_START_DATE].name);
            }
            if (skDatetimeCeiling(&end_val, &end_val, start_precision)) {
                return 1;
            }
            fList->fg_time_end = end_val - (end_val % 3600000);
        } else if (end_precision < 4) {
            /* starting time has an hour but ending time does not; use
             * same hour for ending time */
#if  SK_ENABLE_LOCALTIME
            /* get starting hour */
            t = start_val / 1000;
            localtime_r(&t, &work_tm);
            work_hour = work_tm.tm_hour;
            /* break apart end time */
            t = end_val / 1000;
            localtime_r(&t, &work_tm);
            /* set end hour to start hour and re-combine */
            work_tm.tm_hour = work_hour;
            t = mktime(&work_tm);
            fList->fg_time_end = (sktime_t)1000 * (t - (t % 3600));
#else
            fList->fg_time_end = (fList->fg_time_end
                                  - (fList->fg_time_end % 86400000)
                                  + (fList->fg_time_start % 86400000));
#endif
        } else if (end_precision > 4) {
            skAppPrintErr("Warning: %s precision greater than hours ignored",
                          fglobOptions[FGLOB_OPT_END_DATE].name);
        }

    } else if (start_precision >= 4) {
        /* no ending time was given and the starting time contains an
         * hour; we only look at that single hour */
        fList->fg_time_end = fList->fg_time_start;
    } else {
        /* no ending time was given and the starting time was to the
         * day; look at that entire day */
        if (skDatetimeCeiling(&end_val, &start_val, start_precision)) {
            return 1;
        }
        /* Force end time to start of hour */
        fList->fg_time_end = end_val - (end_val % 3600000);
    }

    if ( fList->fg_time_end < fList->fg_time_start ) {
        skAppPrintErr("%s of %s is earlier than\n\t%s of %s",
                      fglobOptions[FGLOB_OPT_END_DATE].name,
                      fList->fg_option[FGLOB_OPT_END_DATE],
                      fglobOptions[FGLOB_OPT_START_DATE].name,
                      fList->fg_option[FGLOB_OPT_START_DATE]);
        return 1;
    }

    /* Set the current time to the starting value. */
    fList->fg_time_idx = fList->fg_time_start;

    return 0;
}


/*
 *  is_ok = fglobCheckSensors()
 *
 *    Check that the sensor list is good given the class/type.
 *
 *    Parses the sensor option given by the user.  Supports sensor
 *    IDs or sensor Names.  The names are handled first; things that
 *    look like numbers are copied into another C-string and parsed
 *    later.  Returns 0 on success; 1 otherwise.
 */
static int fglobCheckSensors(void)
{
    sk_bitmap_t *sensor_bits = NULL;
    int i;
    int found_sensor;
    int *sensors_for_flowtype = NULL;
    sensorID_t sensor_id;
    sensor_iter_t si;
    int rv = 1;

    char sensor_name[SK_MAX_STRLEN_SENSOR+1];
    char class_name[SK_MAX_STRLEN_FLOWTYPE+1];
    char type_name[SK_MAX_STRLEN_FLOWTYPE+1];

    /* if user specified no sensors, use all sensors for the given
     * flowtype(s) */
    if (NULL == fList->fg_option[FGLOB_OPT_SENSORS]) {
        fglobEnableAllSensors();
        return 0;
    }

    /* We will count the number of sensors we get for each class/type
     * combination, so we can complain if the user failed to specify
     * sensors for a class/type. */
    sensors_for_flowtype = calloc(sksiteFlowtypeGetMaxID()+1, sizeof(int));
    if (sensors_for_flowtype == NULL) {
        PERROR_MEM;
        goto END;
    }

    /* create a bitmap for all the sensors */
    if (skBitmapCreate(&sensor_bits, 1+sksiteSensorGetMaxID())) {
        goto END;
    }

    /* fill the bitamp with the sensors given in the user's input */
    if (fglobParseSensorCmdLine(fList->fg_option[FGLOB_OPT_SENSORS],
                                sensor_bits))
    {
        /* error.  msg should already be printed */
        goto END;
    }

    /* For each sensor bit that is set, verify that the sensor is
     * valid for the specified class/type(s).
     */

    /* loop 'sensor_id' over all the known sensor ids from sksite */
    sksiteSensorIterator(&si);
    while ( sksiteSensorIteratorNext(&si, &sensor_id) ) {
        /* skip sensors the user didn't select */
        if ( !skBitmapGetBit(sensor_bits, sensor_id)) {
            continue;
        }
        found_sensor = 0;

        /* loop 'i' over all the fglob class/types */
        for (i = 0; i < fList->fg_flowtype_count; ++i) {
            /* verify that sensor is in this flowtype's class */
            const classID_t class_from_flowtype =
                sksiteFlowtypeGetClassID(fList->fg_flowtype_list[i]);
            if ( sksiteIsSensorInClass(sensor_id, class_from_flowtype) ) {
                /* add the sensor name to this flowtype */
                fList->fg_sensor_list[i][fList->fg_sensor_count[i]++] =
                    sensor_id;
                ++sensors_for_flowtype[i];
                ++found_sensor;
            }
        }

        /* warn about unused sensor, but continue */
        if (0 == found_sensor) {
            sksiteSensorGetName(sensor_name, sizeof(sensor_name), sensor_id);
            skAppPrintErr(("Ignoring sensor %u (%s)--"
                           "not used by specified class%s"),
                          sensor_id, sensor_name,
                          ((fList->fg_flowtype_count > 1) ? "es" : ""));
        }
    }

    /* For any class/type combinations for which we didn't find a
     * sensor, print and error and return. */
    for (i = 0; i < fList->fg_flowtype_count; ++i) {
        if (sensors_for_flowtype[i] == 0) {
            sksiteFlowtypeGetClass(class_name, sizeof(class_name),
                                   fList->fg_flowtype_list[i]);
            sksiteFlowtypeGetType(type_name, sizeof(type_name),
                                  fList->fg_flowtype_list[i]);
            skAppPrintErr(("No corresponding sensors given for"
                           " class/type pair '%s/%s'"),
                          class_name, type_name);
            goto END;
        }
    }

    /* Success */
    rv = 0;

  END:
    if (sensor_bits) {
        skBitmapDestroy(&sensor_bits);
    }
    if (sensors_for_flowtype) {
        free(sensors_for_flowtype);
    }
    return rv;
}


/*
 *  fglobEnableAllSensors();
 *
 *    For each of the configured flowtypes, add every sensor that is
 *    valid for that flowtype.
 */
static void fglobEnableAllSensors(void)
{
    sensor_iter_t si;
    sensorID_t sensor_id;
    class_iter_t ci;
    classID_t class_of_sensor;
    int k;
    classID_t class_from_flowtype;

    /* loop 'sensor_id' over all the sensors */
    sksiteSensorIterator(&si);
    while ( sksiteSensorIteratorNext(&si, &sensor_id) ) {

        sksiteSensorClassIterator(sensor_id, &ci);
        while ( sksiteClassIteratorNext(&ci, &class_of_sensor) ) {

            /* loop 'k' over all the flowtypes we are using */
            for (k = 0; k < fList->fg_flowtype_count; ++k) {
                class_from_flowtype =
                    sksiteFlowtypeGetClassID(fList->fg_flowtype_list[k]);

                if ( class_from_flowtype == class_of_sensor ) {
                    /* add this sensor to this flowtype */
                    fList->fg_sensor_list[k][fList->fg_sensor_count[k]++] =
                        sensor_id;
                }
            }
        }
    }
}


/*
 *  is_ok = fglobParseSensorCmdLine(sensor_input, sensor_bitmap);
 *
 *    Parse the user's sensor input in sensor_input.  sensor_input can
 *    be a combination of named sensors and lone integers or integer
 *    ranges, separated by commas:  "S01,8,3-6,S02".
 *
 *    For each sensor, sets a bit in sensor_bitmap if that sensor is
 *    enabled.  The caller should create the bitmap with room for at
 *    least sksiteSensorGetMaxID()+1 sensors before calling this
 *    function.  This function will clear any bits set in the bitmap.
 *
 *    Function returns 0 on success or 1 on error: malloc error, bad
 *    sensor name, number out of range.
 */
static int fglobParseSensorCmdLine(
    const char    *sensor_input,
    sk_bitmap_t   *sensor_bits)
{
    char **sensor_tokens = NULL;
    char *sensor_str = NULL;
    char *ep;
    unsigned long max_sensor_id;
    unsigned long val;
    sensorID_t sid = SK_INVALID_SENSOR;
    int sensor_count;
    int j;
    int rv = 1; /* return value---assume error */

    assert(sensor_bits);

    max_sensor_id = sksiteSensorGetMaxID();

    /* ensure the bitmap is big enough */
    if (skBitmapGetSize(sensor_bits) <= max_sensor_id) {
        goto END;
    }
    skBitmapClearAllBits(sensor_bits);

    /* create a copy of the input string and an array of char*'s */
    sensor_str = strdup(sensor_input);
    sensor_tokens = calloc(max_sensor_id + 1, sizeof(char*));
    if (sensor_str == NULL || sensor_tokens == NULL) {
        PERROR_MEM;
        goto END;
    }

    sensor_count = fglobParseWordList(sensor_str, sensor_tokens,
                                      max_sensor_id + 1);
    if (sensor_count < 0) {
        skAppPrintErr("Too many sensors specified.  Only %lu allowed",
                      max_sensor_id + 1);
        goto END;
    }
    if (sensor_count == 0) {
        skAppPrintErr("No sensors were specified in '%s'", sensor_input);
        goto END;
    }

    for (j = 0; j < sensor_count; ++j) {
        sid = sksiteSensorLookup(sensor_tokens[j]);
        if (sid == SK_INVALID_SENSOR && isdigit((int)(sensor_tokens[j][0])))
        {
            /* could not parse as name, parse the token as a pure number */
            errno = 0;
            val = strtoul(sensor_tokens[j], &ep, 10);
            if (*ep != '\0') {
                /* parse error: non-digits in token */
            } else if (val == ULONG_MAX && errno == ERANGE) {
                /* overflow */
            } else if (val > max_sensor_id) {
                /* too big */
            } else if (sksiteSensorExists((sensorID_t)val)) {
                sid = (sensorID_t)val;
            }
        }

        if (sid != SK_INVALID_SENSOR) {
            skBitmapSetBit(sensor_bits, sid);
        } else {
            skAppPrintErr("Unknown sensor identifier '%s'", sensor_tokens[j]);
            goto END;
        }
    }

    /* Success */
    rv = 0;

 END:
    if (sensor_str) {
        free(sensor_str);
    }
    if (sensor_tokens) {
        free(sensor_tokens);
    }
    return rv;
}


/*
 *  count = fglobParseWordList(input_string, output_array, output_array_len);
 *
 *    Parses 'input_string' into a array of comma-separated tokens
 *    whose length is at least 1 (double comma is treated as a single
 *    comma).  Puts pointers to each word into 'output_array'.  The
 *    caller must have allocated 'output_array' and the caller should
 *    specify the length of 'output_array' in the 'output_array_len'
 *    parameter.  The function returns the number of words, or -1 if
 *    more than 'output_array_len' words were found.  This function
 *    will destructively modify input_string; the caller should pass
 *    in a mutable copy.  The values in output_array will point into
 *    input_string; this function allocates no memory.
 */
static int fglobParseWordList(
    char   *string,
    char  **word_list,
    int     max_word_list)
{
    int word_count = 0;
    char *cp;
    char *ep;

    cp = string;
    while (*cp) {
        ep = strchr(cp, ',');
        if (ep == cp) {
            /* double comma, ignore */
            ++cp;
            continue;
        }
        if (ep != NULL) {
            *ep = '\0';
            ++ep;
        } else {
            /* force ep onto final '\0' */
            ep = cp + strlen(cp);
        }

        if (word_count >= max_word_list) {
            return -1;
        }

        word_list[word_count++] = cp;
        cp = ep;
    }

    return word_count;
}


/*
 *  is_ok = fglobCheckTypesForClass();
 *
 *    Will parse the user's --class and --type input, or use the
 *    defaults if no class and/or type was given.  Return 0 on
 *    success, 1 on failure.
 *
 *    Will also verify that each listed type belongs to a class, and
 *    each class has at least one type.
 */
static int fglobCheckTypesForClass(void)
{
    char *type_str = NULL;
    char **type_names;
    int type_name_count;
    int num_classes;
    int *class_list;
    int *types_for_class_count;
    int i, j;
    int found_type;
    int rv = 0; /* return value */
    classID_t class_id;
    char class_name[SK_MAX_STRLEN_FLOWTYPE+1];
    flowtype_iter_t fi;
    flowtypeID_t flowtype_id;

    /* have we been here before? */
    if (fList->fg_flowtype_count > 0) {
        return 0;
    }

    type_names = (char **) calloc(sksiteFlowtypeGetMaxID()+1, sizeof (char *));
    class_list = (int *) calloc(FGLOB_NUM_CLASSES, sizeof(int));
    types_for_class_count = (int *) calloc(FGLOB_NUM_CLASSES, sizeof(int));

    if ((type_names == NULL)
        || (class_list == NULL)
        || (types_for_class_count == NULL))
    {
        PERROR_MEM;
        rv = 1;
        goto END;
    }

    if (fglobCheckClass(&num_classes, class_list)) {
        rv = 1;
        goto END;
    }

    /* if user didn't give --type, use default types for each class */
    if (fList->fg_option[FGLOB_OPT_TYPE] == NULL) {
        for ( i = 0; i < num_classes; i++ ) {
            class_id = class_list[i];
            sksiteClassDefaultFlowtypeIterator(class_id, &fi);
            while ( sksiteFlowtypeIteratorNext(&fi, &flowtype_id) ) {
                fList->fg_flowtype_list[fList->fg_flowtype_count++] =
                    flowtype_id;
            }
        }
        rv = 0;
        goto END;
    }

    /* if user said --type=all, use all types for each class */
    if (strcmp(fList->fg_option[FGLOB_OPT_TYPE], "all") == 0) {
        for ( i = 0; i < num_classes; i++ ) {
            class_id = class_list[i];
            sksiteClassFlowtypeIterator(class_id, &fi);
            while ( sksiteFlowtypeIteratorNext(&fi, &flowtype_id) ) {
                fList->fg_flowtype_list[fList->fg_flowtype_count++] =
                    flowtype_id;
            }
        }
        rv = 0;
        goto END;
    }

    /* We will count the number of types we get for each class, so we
     * can complain if the user failed to specify types for a
     * class. */
    memset(types_for_class_count, 0,
           FGLOB_NUM_CLASSES * sizeof(*types_for_class_count));

    /*
     * Match up the various types with the various classes.  Make a
     * modifiable copy of the types to parse into words.
     *
     * This probably needs to be thought through a bit better to
     * figure out what happens when types are given that don't
     * correspond to one class but not another.  warnings?
     */
    type_str = strdup(fList->fg_option[FGLOB_OPT_TYPE]);
    if (!type_str) {
        PERROR_MEM;
        rv = 1;
        goto END;
    }

    type_name_count = fglobParseWordList(type_str, type_names,
                                         sksiteFlowtypeGetMaxID() + 1);

    if (type_name_count < 0) {
        skAppPrintErr("Too many types specified.  Only %d allowed",
                      sksiteFlowtypeGetMaxID() + 1);
        rv = 1;
        goto END;
    }
    if (type_name_count == 0) {
        skAppPrintErr("No types were specified.");
        rv = 1;
        goto END;
    }

    for (j = 0; j < type_name_count; ++j) {
        /* look for type among all the classes.  FIXME: probably should do
         * something here to check for duplicates */
        found_type = 0;
        for (i = 0; i < num_classes; ++i) {
            class_id = class_list[i];
            flowtype_id = sksiteFlowtypeLookupByClassIDType(class_id,
                                                            type_names[j]);
            if ( flowtype_id != SK_INVALID_FLOWTYPE ) {
                fList->fg_flowtype_list[fList->fg_flowtype_count++] =
                    flowtype_id;
                ++types_for_class_count[i];
                ++found_type;
            }
        }

        if (0 == found_type) {
            skAppPrintErr(("Type '%s' not valid in specified class%s.\n"
                           "\tUse the --help option to see valid types "
                           "for each class"),
                          type_names[j], ((num_classes > 1) ? "es" : ""));
            rv = 1;
            goto END;
        }
    }

    /* For any classes specified for which we didn't find a type,
     * print and error and return. */
    for (i = 0; i < num_classes; ++i) {
        if (types_for_class_count[i] == 0) {
            sksiteClassGetName(class_name, sizeof(class_name), class_list[i]);
            skAppPrintErr("No corresponding types given for class '%s'",
                          class_name);
            rv = 1;
            goto END;
        }
    }

  END:
    if (type_str) {
        free(type_str);
    }
    if ( type_names != NULL ) {
        free(type_names);
    }
    if ( class_list != NULL ) {
        free(class_list);
    }
    if ( types_for_class_count != NULL ) {
        free(types_for_class_count);
    }
    return rv;
}


/*
 *  ok = fglobCheckClass(int *num_classes, int class_list[FGLOB_NUM_CLASSES]);
 *
 *    Check that the list of classes given by the user is valid.
 *    Returns 0 if it is value or 1 otherwise.
 *
 *    If no classes were specified, use the default class(es).
 *
 *    The value pointed to by 'num_classes' is set to the number of
 *    classes; the class_list[] is set to the class ids.
 */
static int fglobCheckClass(int *num_classes, int *class_list)
{
    char *class_str = NULL;
    char **class_names = NULL;
    int class_name_count;
    int i;
    int rv = 0; /* return value */
    classID_t class_id;

    /* check parameters */
    assert(num_classes);
    assert(class_list);

    /* put in known state */
    *num_classes = 0;

    /* if no class was specified by user, use the default class */
    if (NULL == fList->fg_option[FGLOB_OPT_CLASS]) {
        *num_classes = 1;
        class_list[0] = sksiteClassGetDefault();
        rv = 0;
        goto END;
    }

#if  FGLOB_MULTIPLE_CLASSES
    /* Enable all classes if user's input is "all" */
    if (0 == strcmp(fList->fg_option[FGLOB_OPT_CLASS], "all")) {
        class_iter_t ci;
        sksiteClassIterator(&ci);
        while ( sksiteClassIteratorNext(&ci, &class_id) ) {
            class_list[*num_classes] = class_id;
            ++*num_classes;
        }
        rv = 0;
        goto END;
    }
#endif /* FGLOB_MULTIPLE_CLASSES */

    /* make a modifiable copy of the user's class argument, and
     * allocate an array to hold pointers into that copy---a pointer
     * to the start of each word  */
    class_str = strdup(fList->fg_option[FGLOB_OPT_CLASS]);
    class_names = calloc(FGLOB_NUM_CLASSES, sizeof(char *));
    if (class_str == NULL || class_names == NULL) {
        PERROR_MEM;
        rv = 1;
        goto END;
    }

    class_name_count = fglobParseWordList(class_str, class_names,
                                          FGLOB_NUM_CLASSES);
    if ((class_name_count < 0) || (class_name_count > FGLOB_NUM_CLASSES)) {
        skAppPrintErr("Too many classes specified.  Only %d allowed",
                      FGLOB_NUM_CLASSES);
        rv = 1;
        goto END;
    }

    if (class_name_count == 0) {
        skAppPrintErr("No classes were specified");
        rv = 1;
        goto END;
    }

    for (i = 0; i < class_name_count; ++i) {
        /* look for the class */
        class_id = sksiteClassLookup(class_names[i]);
        if ( class_id == SK_INVALID_CLASS ) {
            /* print warning when class was not found and return */
            skAppPrintErr(("Invalid class '%s'\n"
                           "\tUse the --help option to see valid classes"),
                          class_names[i]);
            rv = 1;
            goto END;
        }
        class_list[(*num_classes)++] = class_id;
    }

  END:
    if (class_str) {
        free(class_str);
    }
    if ( class_names != NULL ) {
        free(class_names);
    }
    return rv;
}


/*
 *  is_used = fglobValid();
 *
 *    Return 1 if fglob is to be used; 0 if it is not to be used, or
 *    -1 if there were errors with classes, types, sensors, or
 *    times.
 */
int fglobValid(void)
{
    if ((fList != NULL) && (fList->fg_user_option_count == 0)) {
        /* no fglob options given */
        return 0;
    }

    if (!fList->fg_initialized) {
        if (fglobInit()) {
            return -1;
        }
    }
    return 1;
}


/*
 *  option_count = fglobSetFilters(sensor_bitmap, file_info_bitmap);
 *
 *    This function is used when filtering a previous data pull.  It
 *    allows the --class, --type, and --sensor switches to work over
 *    this data.
 *
 *    Fill in the 'sensor_bitmap' with the values the user provided to
 *    fglob's --sensor switch as defined in the silk.conf file.
 *
 *    Fill in the 'file_info_bitmap' with the values the user provided
 *    to fglob's --class and --type switches as defined in the
 *    silk.conf file.
 */
int fglobSetFilters(
    sk_bitmap_t   **sensor_bitmap,
    sk_bitmap_t   **flowtype_bitmap)
{
    int i;
    int rv = 0; /* no filters, no errors */

    assert(sensor_bitmap);
    assert(flowtype_bitmap);

    /* Do we have sensor info? */
    if (fList->fg_option[FGLOB_OPT_SENSORS]) {
        /* ensure site configuration file */
        if (fglobLoadSiteConfig()) {
            return -1;
        }

        if (skBitmapCreate(sensor_bitmap, sksiteSensorGetMaxID()+1)) {
            return -1;
        }
        if (fglobParseSensorCmdLine(fList->fg_option[FGLOB_OPT_SENSORS],
                                    *sensor_bitmap))
        {
            skBitmapDestroy(sensor_bitmap);
            return -1;
        }

        rv += 1;
    }


    if (fList->fg_option[FGLOB_OPT_CLASS] || fList->fg_option[FGLOB_OPT_TYPE])
    {
        /* ensure site configuration file */
        if (fglobLoadSiteConfig()) {
            return -1;
        }

        /* User gave us at least class/type information */
        if (fglobCheckTypesForClass()) {
            /* error */
            return -2;
        }

        if (skBitmapCreate(flowtype_bitmap, sksiteFlowtypeGetMaxID()+1)) {
            return -1;
        }

        for (i = 0; i < fList->fg_flowtype_count; ++i) {
            skBitmapSetBit(*flowtype_bitmap, fList->fg_flowtype_list[i]);
        }

        rv += 2;
    }

    /* Adjust the value of the 'fg_user_option_count' member */
    if (fList->fg_option[FGLOB_OPT_CLASS]) {
        --fList->fg_user_option_count;
    }
    if (fList->fg_option[FGLOB_OPT_TYPE]) {
        --fList->fg_user_option_count;
    }
    if (fList->fg_option[FGLOB_OPT_SENSORS]) {
        --fList->fg_user_option_count;
    }

    return rv;
}




/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
