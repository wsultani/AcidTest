/*
** Copyright (C) 2003-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  Reads PDUs from a router and writes the flows into packed files.
**
*/

#include "silk.h"

RCSIDENT("$SiLK: rwflowpack.c 11406 2008-04-30 15:37:57Z mthomas $");

#include <dlfcn.h>

#include "sksite.h"
#include "rwflowpack_priv.h"
#include "stream-cache.h"
#include "sktimer.h"
#include "skvector.h"
#include "skdaemon.h"
#include "dynlib.h"


/* MACROS AND DATA TYPES */

/* #undef DEBUGGING */
/* #define DEBUGGING 1 */

/* Where to write usage (--help) information */
#define USAGE_FH stdout

/* When (at what hour) to rotate the logs.  We will disable rotation
 * when not running as a daemon. */
#define LOG_ROTATION_HOUR 0

/* How big to make the global file cache, stream_cache */
#define STREAM_CACHE_DEPTH 64

/* The number of reader types to allow for */
#define MAX_READER_TYPE_COUNT 6

/* How often, in seconds, to flush the files in the stream_cache */
#define CACHE_FLUSH_TIMEOUT  120
#define CACHE_FLUSH_TIMEOUT_STRING "120"

/* Default record version to write. */
#ifndef RWFLOWPACK_DEFAULT_VERSION
#  define RWFLOWPACK_DEFAULT_VERSION SK_RECORD_VERSION_ANY
#endif

/* Must be greater than the number of switches defined */
#define MAX_OPTION_COUNT 32

/* Number of seconds to wait between polling the incoming directory */
#define DEFAULT_POLL_INTERVAL 15
#define DEFAULT_POLL_INTERVAL_STRING "15"

/* In each of the above mode, an option can be required, optional,
 * illegal, or non-sensical.  This enumerates those values; the
 * mode_options[][] array holds the values for each option for each
 * mode. */
typedef enum {
    MODOPT_ILLEGAL = 0, MODOPT_REQUIRED, MODOPT_OPTIONAL, MODOPT_NONSENSE
} mode_option_t;

typedef void (*cleanupHandler)(void *);

/* signal list */
struct siglist_st {
    int signal;
    char *name;
};

/* Create an array of these to cache the options we get from the
 * user */
typedef struct opt_cache_st {
    int     seen;
    char   *value;
} opt_cache_t;


/* LOCAL VARIABLES */

/* The packing logic to use to categorize flow records */
static packlogic_plugin_t packlogic;

/* initialize functions for the various flow readers */
static fr_initialize_fn_t reader_type_inits[] = {
    &fcReaderInitialize,
    &fcFilesReaderInitialize,
#if SK_ENABLE_IPFIX
    &ipfixReaderInitialize,
#endif
    &pduFileReaderInitialize,
    &pduReaderInitialize
};

/* The possible reader types */
static reader_type_t reader_types[MAX_READER_TYPE_COUNT];

/* Get a total count of the reader types actually implemented. */
static size_t num_reader_types = (sizeof(reader_type_inits)
                                  / sizeof(fr_initialize_fn_t));

/* The flow processors; one per probe */
static flow_proc_t *flow_processors = NULL;

/* The number of flow_processors */
static size_t num_flow_processors = 0;

/* The number of flow_processor threads currently running */
static int fproc_thread_count = 0;

/* Mutex controlling access to 'fproc_thread_count' */
static pthread_mutex_t fproc_thread_count_mutex = PTHREAD_MUTEX_INITIALIZER;

/* the compression method to use when writing the file.
 * sksiteCompmethodOptionsRegister() will set this to the default or
 * to the value the user specifies. */
static sk_compmethod_t comp_method;

/* Command line option giving the sensor---from the probeconf
 * configuration file---that this rwflowpack is packing.  If none
 * given, use first probe in the probeconf file. */
static const char *sensor_name = NULL;

/* Which of the reader_types is for flowcap? */
static size_t fcreader_position = UINT32_MAX;
/* And for flowcap files? */
static size_t fcfilesreader_position = UINT32_MAX;

/* True as long as we are reading. */
static uint8_t reading = 0;

/* non-zero when rwflowpack is shutting down */
static volatile int shuttingDown = 0;

/* non-zero when file locking is disabled */
static int no_file_locking = 0;

/* control thread */
static pthread_t main_thread;

/* Timer that flushes files every so often */
static skTimer_t timing_thread = NULL;

/* Number of seconds between cache flushes */
static uint32_t flush_timeout = CACHE_FLUSH_TIMEOUT;

/* All open files to which we are writing */
static stream_cache_t *stream_cache;

/* Mutex controlling access to the stream_cache */
static pthread_mutex_t cache_mutex = PTHREAD_MUTEX_INITIALIZER;

/* Byte order for newly packed files.  When appending to existing
 * files, use the files' existing byte order. */
static silk_endian_t byte_order = SILK_ENDIAN_NATIVE;

/* The directory where files successfully processed by rwflowpack are
 * stashed (for later debugging or re-packing).  Administrator should
 * create an an external cron job to clean this directory.*/
static const char *archive_directory = NULL;

/* When not in sending mode, rwflowpack writes the flows to files
 * located under the root directory (sksiteGetRootDir()). */

/* When in sending mode, rwflowpack uses this directory temporarily to
 * create the packed files while it is processing the flowcap input
 * file.  Files in this directory are incomplete. */
static const char *incremental_directory = NULL;

/* When in sending mode, rwflowpack copies the complete incremental
 * files to this directory and informs the sender about them. */
static const char *sender_directory = NULL;

static reader_options_t reader_opts;

/* options from the user's command line */
static opt_cache_t *opt_cache = NULL;

/* How to run: Input and Output Modes */
typedef enum {
    INPUT_STREAM,
    INPUT_PDUFILE,
    INPUT_FLOWCAP,
    INPUT_FLOWCAP_FILES,
    OUTPUT_LOCAL_STORAGE, OUTPUT_SENDING
} io_mode_t;

/* The number of modes */
#define NUM_MODES 6

/* input and output modes */
static io_mode_t input_mode = INPUT_STREAM;
static io_mode_t output_mode = OUTPUT_LOCAL_STORAGE;

/* The index of the first Output Mode */
static const io_mode_t first_output_mode = OUTPUT_LOCAL_STORAGE;

static const struct available_modes_st {
    const char *name;
    const char *title;
} available_modes[NUM_MODES] = {
    {"stream",         "Stream Input"},
    {"pdufile",        "PDU-File Input"},
    {"flowcap",        "Flowcap Input"},
    {"fcfiles",        "Flowcap Files Input"},
    {"local-storage",  "Local-Storage Output"},
    {"sending",        "Sending Output"}
};

/* which options are valid in which modes. */
static mode_option_t mode_options[NUM_MODES][MAX_OPTION_COUNT];

/* Options for byte-order switch */
static struct {
    const char     *name;
    silk_endian_t   value;
} byte_order_opts[] = {
    {"native", SILK_ENDIAN_NATIVE},
    {"little", SILK_ENDIAN_LITTLE},
    {"big",    SILK_ENDIAN_BIG},
    {NULL,     SILK_ENDIAN_ANY} /* sentinel */
};


/* OPTIONS SETUP */

typedef enum {
    OPT_INPUT_MODE, OPT_OUTPUT_MODE,
#ifndef SK_PACKING_LOGIC_PATH
    OPT_PACKING_LOGIC,
#endif
    OPT_SENSOR_CONFIG,
    OPT_BYTE_ORDER, OPT_PACK_INTERFACES,
    OPT_NO_FILE_LOCKING,
    OPT_FLUSH_TIMEOUT,
    OPT_SENSOR_NAME,
    OPT_FLOWCAP_ADDRESS, OPT_FLOWCAP_PORT,
    OPT_WORK_DIRECTORY, OPT_VALID_DIRECTORY,
    OPT_INCOMING_DIRECTORY, OPT_POLLING_INTERVAL,
    OPT_NETFLOW_FILE,
    OPT_ARCHIVE_DIRECTORY,
    OPT_ROOT_DIRECTORY,
    OPT_SENDER_DIRECTORY, OPT_INCREMENTAL_DIRECTORY
} appOptionsEnum;

static struct option appOptions[] = {
    {"input-mode",            REQUIRED_ARG, 0, OPT_INPUT_MODE},
    {"output-mode",           REQUIRED_ARG, 0, OPT_OUTPUT_MODE},

#ifndef SK_PACKING_LOGIC_PATH
    {"packing-logic",         REQUIRED_ARG, 0, OPT_PACKING_LOGIC},
#endif
    {"sensor-configuration",  REQUIRED_ARG, 0, OPT_SENSOR_CONFIG},
    {"byte-order",            REQUIRED_ARG, 0, OPT_BYTE_ORDER},
    {"pack-interfaces",       NO_ARG,       0, OPT_PACK_INTERFACES},
    {"no-file-locking",       NO_ARG,       0, OPT_NO_FILE_LOCKING},
    {"flush-timeout",         REQUIRED_ARG, 0, OPT_FLUSH_TIMEOUT},

    {"sensor-name",           REQUIRED_ARG, 0, OPT_SENSOR_NAME},

    {"flowcap-address",       REQUIRED_ARG, 0, OPT_FLOWCAP_ADDRESS},
    {"flowcap-port",          REQUIRED_ARG, 0, OPT_FLOWCAP_PORT},
    {"work-directory",        REQUIRED_ARG, 0, OPT_WORK_DIRECTORY},
    {"valid-directory",       REQUIRED_ARG, 0, OPT_VALID_DIRECTORY},
    {"incoming-directory",    REQUIRED_ARG, 0, OPT_INCOMING_DIRECTORY},
    {"polling-interval",      REQUIRED_ARG, 0, OPT_POLLING_INTERVAL},

    {"netflow-file",          REQUIRED_ARG, 0, OPT_NETFLOW_FILE},

    {"archive-directory",     REQUIRED_ARG, 0, OPT_ARCHIVE_DIRECTORY},

    {"root-directory",        REQUIRED_ARG, 0, OPT_ROOT_DIRECTORY},

    {"sender-directory",      REQUIRED_ARG, 0, OPT_SENDER_DIRECTORY},
    {"incremental-directory", REQUIRED_ARG, 0, OPT_INCREMENTAL_DIRECTORY},

    {0,0,0,0}                 /* sentinel entry */
};

static const char *appHelp[] = {
    ("Select the source of flow records"),
    ("Select the destination for SiLK flow records"),
#ifndef SK_PACKING_LOGIC_PATH
    ("Specify path to the plug-in that provides functions\n"
     "\tto determine into which class and type each flow record will be\n"
     "\tcategorized and the format of the output files"),
#endif
    ("Read sensor configuration from named file"),
    ("Byte order to use for newly packed files:\n"
     "\tChoices: 'native', 'little', or 'big'. Def. native"),
    ("Include SNMP interface indices in packed records\n"
     "\t(useful for debugging the router configuration). Def. No"),
    ("Do not attempt to lock the files prior to writing\n"
     "\trecords to them. Def. Use locking"),
    ("Time (in seconds) between periodic flushes of data\n"
     "\tto disk. Def. " CACHE_FLUSH_TIMEOUT_STRING),

    ("Ignore all sensors in the sensor-configuration file\n"
     "\texcept this sensor"),

    ("Connect to each of these hostname:port pair(s) and\n"
     "\treceive flowcap files as they are generated by flowcap process(es).\n"
     "\tArgument syntax is:  hostname[:port][,hostname[:port]]*\n"
     "\tWhen the port is not supplied, the --flowcap-port value is used"),
    ("Default port on which to connect to the machines\n"
     "\tspecified by the --flowcap-address option"),
    ("Directory used while receiving flowcap files;\n"
     "\tfiles in this directory are incomplete"),
    ("Directory where successfully received flowcap\n"
     "\tfiles are stored until processed by rwflowpack"),
    ("Directory which is monitored for flowcap files"),
    ("Interval (in seconds) between checks of the\n"
     "\tincoming directory for new files. Def. "
     DEFAULT_POLL_INTERVAL_STRING),

    ("Read NetFlow v5 flow records from the named file,\n"
     "\tpack the flows, and exit rwflowpack"),
    ("Root of the directory tree into which successfully\n"
     "\tprocessed input files are moved Def. None"),
    ("Store the packed files locally under the directory\n"
     "\ttree tree rooted at this location"),

    ("Move the packed files into this directory for\n"
     "\tprocessing by rwsender"),
    ("Temporary directory to use while generating\n"
     "\tpacked SiLK data files before moving the completed files to the\n"
     "\tsender-directory"),

    (char *)NULL  /* sentinel entry */
};

static const appOptionsEnum last_common_option = OPT_FLUSH_TIMEOUT;


/* LOCAL FUNCTION PROTOTYPES */

static void appUsageLong(void);
static void appTeardown(void);
static void appSetup(int argc, char **argv);
static int  appOptionsHandler(clientData cData, int opt_index, char *opt_arg);
static int  appOptionsProcessOpt(int opt_index, char *opt_arg);
static int  byteOrderParse(const char *endian_string);
static int  validateOptions(opt_cache_t *ocache, size_t arg_count);
static int  startProcessor(void);
static void stopProcessor(void);
static void closeFiles(void);
static int  writeRecord(const rwRec *rwrec, const skpc_probe_t *probe);
static int  getAllProbes(sk_vector_t *probe_vec);
static int  getProbesBySensor(sk_vector_t *probe_vec, const char *sensor_list);
static int  createFlowcapFlowProcessors(void);
static int  assignProbesToReaderTypes(void);
static void nullSigHandler(int sig);
static int  removeFilesFromDir(const char *dir_name);
static void sendFiles(void);
static int  defineRunModeOptions(void);
static int initPackingLogic(const char *user_path);
static fileFormat_t defaultDetermineFileFormat(
    const skpc_probe_t *probe,
    flowtypeID_t        ftype);


/* FUNCTION DEFINITIONS */

/*
 *  appUsageLong();
 *
 *    Print complete usage information to USAGE_FH.  Pass this
 *    function to skOptionsSetUsageCallback(); skOptionsParse() will
 *    call this funciton and then exit the program when the --help
 *    option is given.
 */
static void appUsageLong(void)
{
#define USAGE_MSG                                                       \
    ("<SWITCHES>\n"                                                     \
     "\tRead flow records generated by NetFlow(v5), IPFIX, or flowcap\n"  \
     "\tfrom a socket or from a file and pack the flow records into\n"  \
     "\thourly flat-files organized in a time-based directory structure.\n")

    FILE *fh = USAGE_FH;
    unsigned int i, j;

    fprintf(fh, "%s %s", skAppName(), USAGE_MSG);

    fprintf(fh, "\nCommon switches:\n");
    skOptionsDefaultUsage(fh);

    for (i = 0; i <= last_common_option; ++i) {
        fprintf(fh, "--%s %s. ", appOptions[i].name,
                SK_OPTION_HAS_ARG(appOptions[i]));
        switch (appOptions[i].val) {
          case OPT_INPUT_MODE:
            fprintf(fh, "%s\n\tChoices: %s",
                    appHelp[i], available_modes[0].name);
            for (j = 1; j < first_output_mode; ++j) {
                fprintf(fh, ", %s", available_modes[j].name);
            }
            for (j = 0; j < first_output_mode; ++j) {
                if (j == input_mode) {
                    fprintf(fh, ". Def. %s", available_modes[j].name);
                    break;
                }
            }
            break;
          case OPT_OUTPUT_MODE:
            fprintf(fh, "%s\n\tChoices: %s",
                    appHelp[i], available_modes[first_output_mode].name);
            for (j = 1+first_output_mode; j < NUM_MODES; ++j) {
                fprintf(fh, ", %s", available_modes[j].name);
            }
            for (j = first_output_mode; j < NUM_MODES; ++j) {
                if (j == output_mode) {
                    fprintf(fh, ". Def. %s", available_modes[j].name);
                    break;
                }
            }
            break;
          default:
            fprintf(fh, "%s", appHelp[i]);
            break;
        }
        fprintf(fh, "\n");
    }

    sksiteOptionsUsage(fh);
    sksiteCompmethodOptionsUsage(fh);

    fprintf(fh, "\nLogging and daemon switches:\n");
    skdaemonOptionsUsage(fh);

    for (j = 0; j < NUM_MODES; ++j) {
        fprintf(fh, "\n%s Mode (--%s=%s)",
                available_modes[j].title, appOptions[(j < first_output_mode)
                                                     ? OPT_INPUT_MODE
                                                     : OPT_OUTPUT_MODE].name,
                available_modes[j].name);
        if ((j == input_mode) || (j == output_mode)) {
            fprintf(fh, " [default]");
        }
        fprintf(fh, "\n");

        for (i = last_common_option+1; appOptions[i].name; ++i) {
            switch (mode_options[j][appOptions[i].val]) {
              case MODOPT_REQUIRED:
              case MODOPT_OPTIONAL:
                fprintf(fh, "--%s %s. %s\n", appOptions[i].name,
                        SK_OPTION_HAS_ARG(appOptions[i]), appHelp[i]);
                break;
              case MODOPT_ILLEGAL:
              case MODOPT_NONSENSE:
                break;
            }
        }
    }
}


/*
 *  appTeardown()
 *
 *    Teardown all modules, close all files, and tidy up all
 *    application state.
 *
 *    This function is idempotent.
 */
static void appTeardown(void)
{
    static int teardownFlag = 0;
    size_t i;
    reader_type_t *rt;

    if (teardownFlag) {
        return;
    }
    teardownFlag = 1;

    if (input_mode == INPUT_PDUFILE) {
       INFOMSG("Finishing rwflowpack...");
    } else {
       INFOMSG("Begin shutting down...");
    }
    shuttingDown = 1;
    stopProcessor();
    closeFiles();

    for (i = 0; i < num_reader_types; ++i) {
        rt = &reader_types[i];
        if (rt->teardown_fn != NULL) {
            rt->teardown_fn();
            rt->teardown_fn = NULL;
        }

        if (rt->probes != NULL) {
            skVectorDestroy(rt->probes);
            rt->probes = NULL;
        }
    }

    if (flow_processors) {
        free(flow_processors);
        flow_processors = NULL;
    }
    if (opt_cache) {
        free(opt_cache);
        opt_cache = NULL;
    }

    /* clean up any site-specific memory */
    if (packlogic.teardown_fn != NULL) {
        packlogic.teardown_fn();
    }
    if (packlogic.handle) {
        dlclose(packlogic.handle);
    }
    if (packlogic.path) {
        free(packlogic.path);
    }

    /* teardown the probe configuration */
    skpcTeardown();

    if (input_mode == INPUT_PDUFILE) {
       INFOMSG("Finished processing PDU file.");
    } else {
       INFOMSG("Finished shutting down.");
    }
    skdaemonTeardown();
    skAppUnregister();
}


/*
 *  appSetup(argc, argv);
 *
 *    Perform all the setup for this application include setting up
 *    required modules, parsing options, etc.  This function should be
 *    passed the same arguments that were passed into main().
 *
 *    Returns to the caller if all setup succeeds.  If anything fails,
 *    this function will cause the application to exit with a FAILURE
 *    exit status.
 */
static void appSetup(int argc, char **argv)
{
    int arg_index;
    size_t i;
    reader_type_t *rt;
    size_t arg_count = sizeof(appOptions)/sizeof(struct option);
    struct sigaction action;

    /* verify same number of options and help strings */
    assert((sizeof(appHelp)/sizeof(char *)) == arg_count);
    assert(arg_count < MAX_OPTION_COUNT);

    /* verify reader_types array is big enough */
    assert(num_reader_types <= MAX_READER_TYPE_COUNT);

    /* register the application */
    skAppRegister(argv[0]);
    skOptionsSetUsageCallback(&appUsageLong);

    /* initialize globals */
    memset(reader_types, 0, sizeof(reader_types));
    memset(&reader_opts, 0, sizeof(reader_opts));
    memset(&packlogic,   0, sizeof(packlogic));


    /* create an array to hold the user's command line options */
    opt_cache = calloc(arg_count, sizeof(opt_cache_t));
    if (NULL == opt_cache) {
        skAppPrintErr(FMT_MEM_FAILURE);
        exit(EXIT_FAILURE);
    }

    /* Set which switches are valid for which modes */
    if (defineRunModeOptions()) {
        skAppPrintErr("Unable to initialize modes");
        exit(EXIT_FAILURE);
    }

    /* register the options */
    if (skOptionsRegister(appOptions, &appOptionsHandler,(clientData)opt_cache)
        || sksiteCompmethodOptionsRegister(&comp_method)
        || sksiteOptionsRegister(SK_SITE_FLAG_CONFIG_FILE))
    {
        skAppPrintErr("Unable to register options");
        exit(EXIT_FAILURE);
    }

    /* rwflowcap runs as a daemon; use the threaded logger */
    if (skdaemonSetup((SKLOG_FEATURE_LEGACY | SKLOG_FEATURE_SYSLOG),
                      argc, argv)
        || sklogEnableThreadedLogging())
    {
        exit(EXIT_FAILURE);
    }

    /* Allow each reader to do its initial setup and register its options */
    for (i = 0; i < num_reader_types; ++i) {
        rt = &reader_types[i];

        /* is this the reader for flowcap? */
        if (&fcReaderInitialize == reader_type_inits[i]) {
            assert(fcreader_position == UINT32_MAX);
            fcreader_position = i;
        }
        /* is this the reader for flowcap files? */
        if (&fcFilesReaderInitialize == reader_type_inits[i]) {
            assert(fcfilesreader_position == UINT32_MAX);
            fcfilesreader_position = i;
        }

        /* call it's initialize function */
        if (0 != ((*reader_type_inits[i])(rt))) {
            /* initialize failed.  print error and exit. */
            if (rt->reader_name) {
                skAppPrintErr("Unable to setup the %s flow reader",
                              reader_types[i].reader_name);
            } else {
                skAppPrintErr("Unable to setup the flow reader number %u",
                              (unsigned int)i);
            }
            exit(EXIT_FAILURE);
        }
    }

    /* parse the options.  This first pass does very little parsing; it
     * primarily fills the 'opt_cache[]' array with the arguments.  The
     * appOptionsProcessOpt() fucntion called by validateOptions() is
     * where most of the parsing actually occurs. */
    arg_index = skOptionsParse(argc, argv);
    if (arg_index < 0) {
        /* options handler has printed error */
        skAppUsage();
    }

    /* check for additional arguments */
    if (argc != arg_index) {
        skAppPrintErr("Too many or unrecognized argument specified '%s'",
                      argv[arg_index]);
        skAppUsage();
    }

    /* validate the options */
    if (validateOptions(opt_cache, arg_count)) {
        skAppUsage();  /* never returns */
    }

    /* set the mask so that the mode is 0644 */
    (void)umask((mode_t)0022);

    if (output_mode == OUTPUT_SENDING) {
        /* clean out incremental dir */
        if (removeFilesFromDir(incremental_directory) == -1) {
            skAppPrintErr("Could not open %s '%s' for cleaning",
                          appOptions[OPT_INCREMENTAL_DIRECTORY].name,
                          incremental_directory);
            exit(EXIT_FAILURE);
        }
    }

    /* Set the application to process SIGUSR2 */
    memset(&action, 0, sizeof(action));
    /* mask any further signals while we're inside the handler */
    sigfillset(&action.sa_mask);
    action.sa_handler = &nullSigHandler;
    if (sigaction(SIGUSR2, &action, NULL) == -1) {
        skAppPrintErr("Could not handle SIGUSR2: %s",
                      strerror(errno));
        exit(EXIT_FAILURE);
    }

    /* who am I? */
    main_thread = pthread_self();

    return;                       /* OK */
}


/*
 *  status = appOptionsHandler(cData, opt_index, opt_arg);
 *
 *    This function is passed to skOptionsRegister(); it will be called
 *    by skOptionsParse() for each user-specified switch that the
 *    application has registered; it should handle the switch as
 *    required---typically by setting global variables---and return 1
 *    if the switch processing failed or 0 if it succeeded.  Returning
 *    a non-zero from from the handler causes skOptionsParse() to return
 *    a negative value.
 *
 *    The clientData in 'cData' is typically ignored; 'opt_index' is
 *    the index number that was specified as the last value for each
 *    struct option in appOptions[]; 'opt_arg' is the user's argument
 *    to the switch for options that have a REQUIRED_ARG or an
 *    OPTIONAL_ARG.
 */
static int appOptionsHandler(
    clientData  cData,
    int         opt_index,
    char       *opt_arg)
{
    static int arg_count = 0;
    opt_cache_t *ocache = (opt_cache_t*)cData;
    unsigned int i;
    int found_mode;

    switch ((appOptionsEnum)opt_index) {
      case OPT_INPUT_MODE:
        found_mode = 0;
        for (i = 0; i < first_output_mode; ++i) {
            if (0 == strcmp(opt_arg, available_modes[i].name)) {
                found_mode = 1;
                input_mode = (io_mode_t)i;
                break;
            }
        }
        if (!found_mode) {
            skAppPrintErr("Invalid %s '%s'",
                          appOptions[opt_index].name, opt_arg);
            return 1;
        }
        break;

      case OPT_OUTPUT_MODE:
        found_mode = 0;
        for (i = first_output_mode; i < NUM_MODES; ++i) {
            if (0 == strcmp(opt_arg, available_modes[i].name)) {
                found_mode = 1;
                output_mode = (io_mode_t)i;
                break;
            }
        }
        if (!found_mode) {
            skAppPrintErr("Invalid %s '%s'",
                          appOptions[opt_index].name, opt_arg);
            return 1;
        }
        break;

#ifndef SK_PACKING_LOGIC_PATH
      case OPT_PACKING_LOGIC:
        if (initPackingLogic(opt_arg)) {
            skAppPrintErr("Unable to load %s '%s'",
                          appOptions[opt_index].name, opt_arg);
            return 1;
        }
        break;
#endif  /* SK_PACKING_LOGIC_PATH */

      default:
        if (ocache[opt_index].seen) {
            skAppPrintErr("Switch %s already seen",
                          appOptions[opt_index].name);
            return 1;
        }

        ++arg_count;
        ocache[opt_index].seen = arg_count;
        ocache[opt_index].value = opt_arg;
        break;
    }

    return 0;
}


static int appOptionsProcessOpt(
    int         opt_index,
    char       *opt_arg)
{
    uint32_t opt_val;
    int rv;

    switch ((appOptionsEnum)opt_index) {
      case OPT_ROOT_DIRECTORY:
        if (skOptionsCheckDirectory(opt_arg, appOptions[opt_index].name)) {
            return 1;
        }
        sksiteSetRootDir(opt_arg);
        break;

      case OPT_ARCHIVE_DIRECTORY:
        if (skOptionsCheckDirectory(opt_arg, appOptions[opt_index].name)) {
            return 1;
        }
        archive_directory = opt_arg;
        break;

      case OPT_SENDER_DIRECTORY:
        if (skOptionsCheckDirectory(opt_arg, appOptions[opt_index].name)) {
            return 1;
        }
        sender_directory = opt_arg;
        break;

      case OPT_INCREMENTAL_DIRECTORY:
        if (skOptionsCheckDirectory(opt_arg, appOptions[opt_index].name)) {
            return 1;
        }
        incremental_directory = opt_arg;
        break;

      case OPT_BYTE_ORDER:
        return byteOrderParse(opt_arg);
        break;

      case OPT_PACK_INTERFACES:
        /* use function that includes SNMP information */
        packlogic.determine_fileformat_fn = &defaultDetermineFileFormat;
        break;

      case OPT_NO_FILE_LOCKING:
        no_file_locking = 1;
        break;

      case OPT_SENSOR_CONFIG:
        if (skpcParse(opt_arg, packlogic.verify_sensor_fn)) {
            skAppPrintErr("Errors during parsing %s file '%s'",
                          appOptions[opt_index].name, opt_arg);
            exit(EXIT_FAILURE);
        }
        break;

      case OPT_SENSOR_NAME:
        sensor_name = opt_arg;
        break;

      case OPT_FLOWCAP_PORT:
        rv = skStringParseUint32(&opt_val, opt_arg, 0, 0xFFFF);
        if (rv) {
            goto PARSE_ERROR;
        }
        reader_opts.flowcap.flowcap_default_port = (int)opt_val;
        break;

      case OPT_FLOWCAP_ADDRESS:
        reader_opts.flowcap.flowcap_address_string = opt_arg;
        break;

      case OPT_WORK_DIRECTORY:
        if (skOptionsCheckDirectory(opt_arg, appOptions[opt_index].name)) {
            return 1;
        }
        reader_opts.flowcap.work_directory = opt_arg;
        break;

      case OPT_VALID_DIRECTORY:
        if (skOptionsCheckDirectory(opt_arg, appOptions[opt_index].name)) {
            return 1;
        }
        reader_opts.flowcap.valid_directory = opt_arg;
        break;

      case OPT_INCOMING_DIRECTORY:
        if (skOptionsCheckDirectory(opt_arg, appOptions[opt_index].name)) {
            return 1;
        }
        reader_opts.fcfiles.incoming_directory = opt_arg;
        break;

      case OPT_POLLING_INTERVAL:
        rv = skStringParseUint32(&opt_val, opt_arg, 1, 0);
        if (rv) {
            goto PARSE_ERROR;
        }
        reader_opts.fcfiles.polling_interval = opt_val;
        break;

      case OPT_FLUSH_TIMEOUT:
        rv = skStringParseUint32(&opt_val, opt_arg, 1, 0);
        if (rv) {
            goto PARSE_ERROR;
        }
        flush_timeout = opt_val;
        break;

      case OPT_NETFLOW_FILE:
        if (opt_arg[0] == '\0') {
            skAppPrintErr("Empty %s supplied", appOptions[opt_index].name);
            return 1;
        }
        reader_opts.pdu_file.netflow_file = opt_arg;
        break;

      case OPT_INPUT_MODE:
      case OPT_OUTPUT_MODE:
#ifndef SK_PACKING_LOGIC_PATH
      case OPT_PACKING_LOGIC:
#endif
        /* ain't supposed to happen */
        assert(0);
        abort();
    }

    return 0;                     /* OK */

  PARSE_ERROR:
    skAppPrintErr("Invalid %s '%s': %s",
                  appOptions[opt_index].name, opt_arg,
                  skStringParseStrerror(rv));
    return 1;
}


/*
 *  ok = byteOrderParse(argument)
 *
 *    parse the argument to the --byte-order switch
 */
static int byteOrderParse(const char *endian_string)
{
    static int option_seen = 0;
    int i;
    size_t len;

    /* only process option one time */
    if (option_seen != 0) {
        skAppPrintErr("Option %s given multiple times",
                      appOptions[OPT_BYTE_ORDER].name);
        return 1;
    }
    option_seen = 1;

    len = strlen(endian_string);
    if (len == 0) {
        skAppPrintErr("Empty string given for %s option",
                      appOptions[OPT_BYTE_ORDER].name);
        return 1;
    }

    /* initialize byte order */
    byte_order = SILK_ENDIAN_ANY;

    /* parse user's input */
    for (i = 0; byte_order_opts[i].name != NULL; ++i) {
        if ((len <= strlen(byte_order_opts[i].name))
            && (0 == strncmp(byte_order_opts[i].name, endian_string, len)))
        {
            if (byte_order != SILK_ENDIAN_ANY) {
                skAppPrintErr("Ambiguous %s value '%s'",
                              byte_order_opts[i].name, endian_string);
                return 1;
            }
            byte_order = byte_order_opts[i].value;
        }
    }

    if (byte_order == SILK_ENDIAN_ANY) {
        skAppPrintErr("Cannot parse %s value '%s'",
                      appOptions[OPT_BYTE_ORDER].name, endian_string);
        return 1;
    }

    return 0;
}


/*
 *  ok = validateOptions(argc, argv);
 *
 *    Call the options parser.  If options parsing succeeds, validate
 *    that all the required arguments are present, and that the user
 *    didn't give inconsistent arguments.  Returns 0 on success, or -1
 *    otherwise.
 */
static int validateOptions(opt_cache_t *ocache, size_t arg_count)
{
    fp_daemon_mode_t old_deamon_mode = FP_DAEMON_OFF;
    fp_daemon_mode_t deamon_mode = FP_DAEMON_OFF;
    int daemon_seen;
    reader_type_t *rt;
    int options_error = 0;
    size_t i;

    /* Process the root directory first */
    if (ocache[OPT_ROOT_DIRECTORY].seen) {
        if (appOptionsProcessOpt(OPT_ROOT_DIRECTORY,
                                 ocache[OPT_ROOT_DIRECTORY].value))
        {
            return -1;
        }
    }

    /* ensure the site config is available; do this after setting the
     * root directory */
    if (sksiteConfigure(1)) {
        exit(EXIT_FAILURE);
    }

    /* setup the probe configuration parser */
    if (skpcSetup()) {
        skAppPrintErr("Unable to setup probe config file parser");
        exit(EXIT_FAILURE);
    }

    /* if the packing logic plug-in was not loaded, check whether the
     * plug-in is given statically and initialize it if it is.
     * Otherwise, check whether the site configuration defines a
     * packing-logic value, and use that.  If that also fails, tell
     * the user the --packing-logic switch is required. */
#ifdef SK_PACKING_LOGIC_PATH
    /* call the initialize function on the linked-in pack-logic */
    if (initPackingLogic(NULL)) {
        skAppPrintErr("Error loading statically linked packer logic");
        exit(EXIT_FAILURE);
    }
#else
    if (packlogic.determine_flowtype_fn == NULL) {
        char pack_path[PATH_MAX];

        if (sksiteGetPackingLogicPath(pack_path, sizeof(pack_path)) == NULL) {
            /* error if no site-specific packing logic */
            skAppPrintErr("The --%s switch is required",
                          appOptions[OPT_PACKING_LOGIC].name);
            options_error = 1;
        } else if (initPackingLogic(pack_path)) {
            skAppPrintErr("Unable to load packing logic from '%s'",
                          pack_path);
            exit(EXIT_FAILURE);
        }
    }
#endif  /* SK_PACKING_LOGIC_PATH */

    /* setup the site packing logic */
    if ((packlogic.setup_fn != NULL) && (packlogic.setup_fn() != 0)) {
        skAppPrintErr("Unable to setup packing logic plugin");
        exit(EXIT_FAILURE);
    }

    /*
     * Do the real options parsing.
     *
     * Given the input and output modes, check for or missing
     * inconsistent switches: Make sure the required options were
     * provided, and that no illegal options were given.  If the
     * option is given and we were supposed to see it, call the "real"
     * options handler to process it.
     */
    for (i = 0; i < arg_count; ++i) {
        if (ocache[i].seen == 0) {
            /* option 'i' not given; see if it is required */
            if (mode_options[input_mode][i] == MODOPT_REQUIRED) {
                skAppPrintErr("The --%s switch is required in %s Mode",
                              appOptions[i].name,
                              available_modes[input_mode].title);
                options_error = 1;
            } else if (mode_options[output_mode][i] == MODOPT_REQUIRED) {
                skAppPrintErr("The --%s switch is required in %s Mode",
                              appOptions[i].name,
                              available_modes[output_mode].title);
                options_error = 1;
            }
        } else {
            /* option 'i' was given; see if it is illegal */
            if (mode_options[input_mode][i] == MODOPT_ILLEGAL) {
                skAppPrintErr("The --%s switch is illegal in %s Mode",
                              appOptions[i].name,
                              available_modes[input_mode].title);
                options_error = 1;
            } else if (mode_options[output_mode][i] == MODOPT_ILLEGAL) {
                skAppPrintErr("The --%s switch is illegal in %s Mode",
                              appOptions[i].name,
                              available_modes[output_mode].title);
                options_error = 1;
            } else if (i == OPT_ROOT_DIRECTORY) {
                /* don't process this, we did it above */
            }  else if (appOptionsProcessOpt(i, ocache[i].value)) {
                options_error = 1;
            }
        }
    }

    /* verify the required options for logging */
    if (skdaemonOptionsVerify()) {
        options_error = 1;
    }

    /* return if we have options problems */
    if (options_error) {
        return -1;
    }

    /* Set the polling-interval default value */
    if (input_mode == INPUT_FLOWCAP_FILES
        && ocache[OPT_POLLING_INTERVAL].seen == 0)
    {
        reader_opts.fcfiles.polling_interval = DEFAULT_POLL_INTERVAL;
    }

    /* make certain we have at least one sensor from the configuration
     * file. */
    if (skpcCountSensors() == 0) {
        skAppPrintErr("No sensors were read from the configuration file.");
        return -1;
    }

    /* how we create the flow_processors depends on whether we're in
     * flowcap mode. */
    if (input_mode == INPUT_FLOWCAP || input_mode == INPUT_FLOWCAP_FILES) {
        if (createFlowcapFlowProcessors()) {
            return -1;
        }
    } else {
        if (assignProbesToReaderTypes()) {
            return -1;
        }
    }

    /* Call the setup function for each active reader; ignore readers
     * that have no probes. */
    daemon_seen = 0;
    for (i = 0; i < num_reader_types; ++i) {
        rt = &reader_types[i];
        if (NULL == rt->probes) {
            /* Call teardown_fn for this reader now? */
            continue;
        }

        if (rt->setup_fn(&deamon_mode, rt->probes, &reader_opts)) {
            return -1;
        }

        /* All the active reader_types must have same "daemon-ness" */
        if (daemon_seen == 0) {
            daemon_seen = 1;
            old_deamon_mode = deamon_mode;
        } else if (old_deamon_mode != deamon_mode) {
            skAppPrintErr("Cannot mix probes that work as daemons with\n"
                          "\tprobes that do not.");
            return -1;
        }
    }

    assert(daemon_seen);
    if (deamon_mode == FP_DAEMON_OFF) {
        skdaemonDontFork();
    }

    return 0;
}


/*
 *  status = initPackingLogic(path);
 *
 *    If 'path' is not NULL, treat it as the name of a plug-in to
 *    load.  Return an error code if the plug-in cannot be loaded or
 *    does not define the necessary functions.
 *
 *    If 'path' is NULL, verify that the packing-logic has been
 *    statically linked.
 *
 *    Call the initalize function on the packing-logic "plug-in", and
 *    verify that the required fucntion pointers are set.  Return an
 *    error code if they are not.
 *
 *    If all is well, return 0.
 */
static int initPackingLogic(const char *user_path)
{
    int (*init_fn)(packlogic_plugin_t *) = NULL;
    void *dl_handle = NULL;
    int debug = 0;
    char *env_value;

    if (user_path == NULL) {
        /* assumes the packing-logic is compiled in. */
#ifndef SK_PACKING_LOGIC_PATH
        skAppPrintErr("Bad argument to --%s switch",
                      appOptions[OPT_PACKING_LOGIC].name);
        return -1;
#else
        init_fn = &packLogicInitialize;
        if (init_fn == NULL) {
            /* linker should not have allowed this this program to compile */
            skAppPrintErr("No static packing logic function");
            abort();
        }
#endif  /* SK_PACKING_LOGIC_PATH */
    } else {
        char dl_path[PATH_MAX];

        /* check if debug is enabled */
        env_value = getenv(DYNLIB_DEBUG_ENVAR);
        if ((NULL != env_value) && ('\0' != env_value[0])) {
            debug = 1;
        }

        /* Attempt to find the full path to the plug-in, and set
         * 'dl_path' to its path; if we cannot find the path, copy the
         * plug-in's name to 'dl_path' and we'll let dlopen() handle
         * finding the plug-in. */
        if ( !skFindPluginPath(user_path, dl_path, sizeof(dl_path), debug)) {
            strncpy(dl_path, user_path, sizeof(dl_path));
            dl_path[sizeof(dl_path)-1] = '\0';
        }

        /* try to dlopen() the plug-in  */
        if (debug > 0) {
            skAppPrintErr("SILK_DYNLIB_DEBUG: dlopen'ing '%s'", dl_path);
        }
        dl_handle = dlopen(dl_path, RTLD_NOW | RTLD_GLOBAL);
        if (NULL == dl_handle) {
            if (debug > 0) {
                skAppPrintErr("SILK_DYNLIB_DEBUG: dlopen warning: %s",
                              dlerror());
            }
            goto ERROR;
        }
        if (debug > 0) {
            skAppPrintErr("SILK_DYNLIB_DEBUG: dlopen() successful");
        }

        /* get pointer to the initialization function */
        *(void**)&(init_fn) = dlsym(dl_handle, SK_PACKLOGIC_INIT);
        if (NULL == init_fn) {
            if (debug > 0) {
                skAppPrintErr("SILK_DYNLIB_DEBUG: function %s not found",
                              SK_PACKLOGIC_INIT);
            }
            goto ERROR;
        }

        /* stash the pathname */
        packlogic.path = strdup(dl_path);
        if (NULL == packlogic.path) {
            skAppPrintErr(FMT_MEM_FAILURE);
            goto ERROR;
        }
    }

    /* invoke the initialization function */
    if (init_fn(&packlogic)) {
        if (debug > 0) {
            skAppPrintErr("SILK_DYNLIB_DEBUG: function %s returned error",
                          SK_PACKLOGIC_INIT);
        }
        goto ERROR;
    }

    /* make certain required functions were provided */
    if (NULL == packlogic.determine_flowtype_fn) {
        skAppPrintErr(("Cannot find function to determine flowtype in the\n"
                       "\npacking logic plugin %s"),
                      (packlogic.path ? packlogic.path : ""));
        goto ERROR;
    }
    if (NULL == packlogic.verify_sensor_fn) {
        skAppPrintErr(("Cannot find function to verify sensor in the\n"
                       "\npacking logic plugin %s"),
                      (packlogic.path ? packlogic.path : ""));
        goto ERROR;
    }

    /* if not provided, use a default function for determining the
     * fileformat */
    if (NULL == packlogic.determine_fileformat_fn) {
        packlogic.determine_fileformat_fn = &defaultDetermineFileFormat;
    }

    /* fill out the remaining variables on the packlogic object */
    packlogic.handle = dl_handle;
    packlogic.initialize_fn = init_fn;

    /* all OK */
    return 0;

  ERROR:
    if (dl_handle) {
        dlclose(dl_handle);
    }
    if (packlogic.path) {
        free(packlogic.path);
    }
    return -1;
}



/*
 *  status = defineRunModeOptions();
 *
 *    Set the values mode_options[][] array.
 */
static int defineRunModeOptions(void)
{
    unsigned int i, j;

    memset(mode_options, MODOPT_ILLEGAL, sizeof(mode_options));

    /* common options; all are optional except sensor-config */
    for (i = 0; i < NUM_MODES; ++i) {
        for (j = 0; j <= last_common_option; ++j) {
            mode_options[i][j] = MODOPT_OPTIONAL;
        }
        mode_options[i][OPT_SENSOR_CONFIG] = MODOPT_REQUIRED;
    }

    /* for the input modes, we don't care whether the output options
     * were specified. */
    for (i = 0; i < first_output_mode; ++i) {
        mode_options[i][OPT_SENDER_DIRECTORY] = MODOPT_NONSENSE;
        mode_options[i][OPT_INCREMENTAL_DIRECTORY] = MODOPT_NONSENSE;
        mode_options[i][OPT_ROOT_DIRECTORY] = MODOPT_NONSENSE;
    }

    /* for the output modes, we don't care about input-only options */
    for (i = first_output_mode; i < NUM_MODES; ++i) {
        mode_options[i][OPT_WORK_DIRECTORY] = MODOPT_NONSENSE;
        mode_options[i][OPT_VALID_DIRECTORY] = MODOPT_NONSENSE;
        mode_options[i][OPT_FLOWCAP_ADDRESS] = MODOPT_NONSENSE;
        mode_options[i][OPT_FLOWCAP_PORT] = MODOPT_NONSENSE;
        mode_options[i][OPT_INCOMING_DIRECTORY] = MODOPT_NONSENSE;
        mode_options[i][OPT_POLLING_INTERVAL] = MODOPT_NONSENSE;
        mode_options[i][OPT_ARCHIVE_DIRECTORY] = MODOPT_NONSENSE;
        mode_options[i][OPT_NETFLOW_FILE] = MODOPT_NONSENSE;
        mode_options[i][OPT_SENSOR_NAME] = MODOPT_NONSENSE;
    }

    mode_options[INPUT_FLOWCAP][OPT_WORK_DIRECTORY] = MODOPT_REQUIRED;
    mode_options[INPUT_FLOWCAP][OPT_VALID_DIRECTORY] = MODOPT_REQUIRED;
    mode_options[INPUT_FLOWCAP][OPT_FLOWCAP_ADDRESS] = MODOPT_REQUIRED;
    mode_options[INPUT_FLOWCAP][OPT_FLOWCAP_PORT] = MODOPT_OPTIONAL;
    mode_options[INPUT_FLOWCAP][OPT_ARCHIVE_DIRECTORY] = MODOPT_OPTIONAL;

    mode_options[INPUT_FLOWCAP_FILES][OPT_INCOMING_DIRECTORY]=MODOPT_REQUIRED;
    mode_options[INPUT_FLOWCAP_FILES][OPT_POLLING_INTERVAL] = MODOPT_OPTIONAL;
    mode_options[INPUT_FLOWCAP_FILES][OPT_ARCHIVE_DIRECTORY] =MODOPT_OPTIONAL;

    mode_options[INPUT_PDUFILE][OPT_NETFLOW_FILE] = MODOPT_REQUIRED;
    mode_options[INPUT_PDUFILE][OPT_ARCHIVE_DIRECTORY] = MODOPT_OPTIONAL;
    mode_options[INPUT_PDUFILE][OPT_SENSOR_NAME] = MODOPT_OPTIONAL;

    mode_options[INPUT_STREAM][OPT_SENSOR_NAME] = MODOPT_OPTIONAL;

    mode_options[OUTPUT_SENDING][OPT_SENDER_DIRECTORY] = MODOPT_REQUIRED;
    mode_options[OUTPUT_SENDING][OPT_INCREMENTAL_DIRECTORY] = MODOPT_REQUIRED;

    mode_options[OUTPUT_LOCAL_STORAGE][OPT_ROOT_DIRECTORY] = MODOPT_REQUIRED;

    return 0;
}


/*
 *  nullSigHandler(signal);
 *
 *    Do nothing.  Called when SIGUSR2 is signaled.
 */
void nullSigHandler(int UNUSED(s))
{
    return;
}


/*
 *  flushFiles(NULL);
 *
 *  THREAD ENTRY POINT
 *
 *    Flushes all the files in global stream cache stream_cache.
 *
 *    Called every 'flush_timeout' seconds by the timing_thread.
 */
static skTimerRepeat_t flushFiles(void *UNUSED(dummy))
{
    pthread_cleanup_push((cleanupHandler)pthread_mutex_unlock,
                         (void *)&cache_mutex);
    pthread_mutex_lock(&cache_mutex);

    INFOMSG("Flushing files after %d seconds.", flush_timeout);
    skStreamCacheFlush(stream_cache);

    pthread_cleanup_pop(1);

    return SK_TIMER_REPEAT;
}


/*
 *  timedSendFiles(NULL);
 *
 *  THREAD ENTRY POINT
 *
 *    Closes all the open files in the stream cache and moves all the
 *    files in the incremental-directory to the sender-directory.
 *
 *    Called every 'flush_timeout' seconds by the timing_thread.
 */
static skTimerRepeat_t timedSendFiles(void *UNUSED(dummy))
{
    sendFiles();

    return SK_TIMER_REPEAT;
}


/*
 *  closeFiles();
 *
 *    Close all files in the global stream cache, stream_cache, and
 *    destroy the cache.
 */
static void closeFiles(void)
{
    pthread_cleanup_push((cleanupHandler)pthread_mutex_unlock,
                         (void *)&cache_mutex);
    pthread_mutex_lock(&cache_mutex);

    INFOMSG("Closing all files.");

    /* Destroy the cache, flushing, closing and freeing all the open
     * streams */
    skStreamCacheDestroy(stream_cache);

    pthread_cleanup_pop(1);
}


/*
 *  status = createFlowcapFlowProcessors()
 *
 *    When processing flowcap files---either in flowcap or fcfiles
 *    mode---the reader_type handles all probes, and there is a single
 *    flow_processor.
 */
static int createFlowcapFlowProcessors(void)
{
    reader_type_t *rt;

    /* get the correct reader */
    if (input_mode == INPUT_FLOWCAP) {
        assert(fcreader_position != UINT32_MAX);
        rt = &reader_types[fcreader_position];
    } else {
        assert(input_mode == INPUT_FLOWCAP_FILES);
        assert(fcfilesreader_position != UINT32_MAX);
        rt = &reader_types[fcfilesreader_position];
    }

    /* only one flow_processor is required. */
    num_flow_processors = 1;
    flow_processors = calloc(num_flow_processors, sizeof(flow_proc_t));
    if (!flow_processors) {
        skAppPrintErr(FMT_MEM_FAILURE);
        return -1;
    }
    flow_processors[0].probe = NULL;
    flow_processors[0].reader_type = rt;

    /* need to set the 'probes' field on the reader_type to a non-NULL
     * value, so we know the flowcap reader_type is in use.  Create an
     * empty vector; no need to fill it. */
    rt->probes = skVectorNew(sizeof(skpc_probe_t*));
    if (rt->probes == NULL) {
        skAppPrintErr(FMT_MEM_FAILURE);
        free(flow_processors);
        return -1;
    }

    return 0;
}


/*
 *
 */
static int assignProbesToReaderTypes(void)
{
    sk_vector_t *probe_vec;
    size_t count;
    size_t i, j;
    reader_type_t *rt;
    reader_type_t *probe_rt;
    skpc_probe_t *p;
    int rv = -1;

    /* create vector to hold probes */
    probe_vec = skVectorNew(sizeof(skpc_probe_t*));
    if (NULL == probe_vec) {
        skAppPrintErr(FMT_MEM_FAILURE);
        goto END;
    }

    /* If --sensor-name was specified, only use the probe(s) for that
     * sensor.  Otherwise, use all probes that are associated with a
     * sensor. */
    if (NULL == sensor_name) {
        if (getAllProbes(probe_vec)) {
            goto END;
        }
    } else {
        if (getProbesBySensor(probe_vec, sensor_name)) {
            goto END;
        }
    }

    /* determine number of probes */
    count = skVectorGetCount(probe_vec);
    if (count == 0) {
        if (sensor_name) {
            skAppPrintErr("No probes exist for sensor '%s'", sensor_name);
        } else {
            skAppPrintErr("Probes are not associated with any sensor");
        }
        goto END;
    }

    /* since there will never be more flow_processors than the
     * number of probes, allocate enough space for each probe to
     * have its own flow_processor */
    num_flow_processors = 0;
    flow_processors = calloc(count, sizeof(flow_proc_t));
    if (!flow_processors) {
        skAppPrintErr(FMT_MEM_FAILURE);
        goto END;
    }

    /* assign each probe to a reader_type */
    for (j = 0; 0 == skVectorGetValue(&p, probe_vec, j); ++j) {
        /* In collection mode, the probes must be valid */
        if (skpcProbeIsVerified(p) == 0) {
            skAppPrintErr("No collection information provided for probe %s",
                          skpcProbeGetName(p));
            goto END;
        }

        probe_rt = NULL;
        for (i = 0; i < num_reader_types; ++i) {
            rt = &reader_types[i];
            if (rt->want_probe_fn(p)) {
                /* reader 'rt' can process probe 'p'.  Check that no
                 * one else can. */
                if (probe_rt == NULL) {
                    probe_rt = rt;
                } else {
                    skAppPrintErr("Multiple readers can process probe %s",
                                  skpcProbeGetName(p));
                    goto END;
                }
            }
        }
        if (probe_rt == NULL) {
            skAppPrintErr("No reader wants to process probe %s",
                          skpcProbeGetName(p));
            goto END;
        }

        assert(num_flow_processors < count);
        flow_processors[num_flow_processors].probe = p;
        flow_processors[num_flow_processors].reader_type = probe_rt;
        num_flow_processors++;

        /* add the probe to the 'probes' vector on the reader_type,
         * creating the vector if it does not exist. */
        if (probe_rt->probes == NULL) {
            probe_rt->probes = skVectorNew(sizeof(skpc_probe_t*));
            if (probe_rt->probes == NULL) {
                skAppPrintErr(FMT_MEM_FAILURE);
                goto END;
            }
        }
        if (skVectorAppendValue(probe_rt->probes, &p)) {
            skAppPrintErr(FMT_MEM_FAILURE);
            goto END;
        }
    }

    /* sanity check that we processed every probe. */
    if (j != count) {
        skAppPrintErr("Error getting probe %u from vector",
                      (unsigned int)j);
        goto END;
    }

    /* should we realloc num_flow_processors here? */

    /* success */
    rv = 0;

  END:
    if (rv != 0) {
        /* failure.  clean up the vectors and the flow_processors[] */
        for (i = 0; i < num_reader_types; ++i) {
            if (reader_types[i].probes != NULL) {
                skVectorDestroy(reader_types[i].probes);
                reader_types[i].probes = NULL;
            }
        }
        if (flow_processors) {
            free(flow_processors);
            flow_processors = NULL;
        }
    }
    if (probe_vec) {
        skVectorDestroy(probe_vec);
    }
    return rv;
}


/*
 *  status = getAllProbes(out_probe_vector);
 *
 *    For each probe in the sensor.conf file, append it to the
 *    'out_probe_vector' if it is associated with a sensor.  Return 0
 *    on success, or -1 on error: memory allocation related.
 */
static int getAllProbes(sk_vector_t *probe_vec)
{
    const skpc_probe_t *p;
    skpc_probe_iter_t iter;

    /* get each probe from probeconf and append to 'probe_vec' */
    skpcProbeIteratorBind(&iter);
    while (skpcProbeIteratorNext(&iter, &p)) {
        if (skpcProbeGetSensorCount(p)) {
            if (skVectorAppendValue(probe_vec, &p)) {
                skAppPrintErr(FMT_MEM_FAILURE);
                return -1;
            }
        }
    }

    return 0;
}


/*
 *  status = getProbesBySensor(out_probe_vector, sensor_list);
 *
 *    Treat 'sensor_list' as a C string containing a comma separated
 *    list of Sensor Names.  Append all the probes defined in the
 *    probe-configuration file that appear in the sensor-list to the
 *    'out_probe_vector'.  Return 0 on success, or nonzero otherwise:
 *    memory allocation failure, unable to parse 'sensor_list', no
 *    probes existing for a specified sensor.
 */
static int getProbesBySensor(sk_vector_t *probe_vec, const char *sensor_list)
{
    const skpc_sensor_t *sensor;
    char *sensor_list_copy = NULL;
    char *cp;
    char *ep;
    int rv = -1;

    sensor_list_copy = strdup(sensor_list);
    if (sensor_list_copy == NULL) {
        goto END;
    }

    cp = sensor_list_copy;
    while (*cp) {
        ep = strchr(cp, ',');
        if (ep == cp) {
            /* double comma, ignore */
            ++cp;
            continue;
        }
        if (ep == NULL) {
            /* no more commas, set 'ep' to end of string */
            ep = cp + strlen(cp);
        } else {
            *ep = '\0';
            ep++;
        }

        sensor = skpcSensorLookupByName(cp);
        if (sensor == NULL) {
            skAppPrintErr("No packing rules specified for sensor '%s'", cp);
            goto END;
        }
        /* get probes for this sensor */
        skpcSensorGetProbes(sensor, probe_vec);

        /* goto next token */
        cp = ep;
    }

    /* success */
    rv = 0;

  END:
    if (sensor_list_copy != NULL) {
        free(sensor_list_copy);
    }
    return rv;
}


/*
 *  format = defaultDetermineFileFormat(probe, ftype);
 *
 *    This function is used when either the --pack-interfaces switch
 *    is given or when the packing logic plug-in (normally
 *    probeconf-<SITE>.c) does not set a function to return the file
 *    format.
 *
 *    This function returns the most compact file format capable of
 *    holding all the infomation that this installation of SiLK
 *    supports.  All these file formats provide space for the next-hop
 *    IP address and SNMP interface information.
 */
static fileFormat_t defaultDetermineFileFormat(
    const skpc_probe_t  UNUSED(*probe),
    flowtypeID_t        UNUSED(ftype))
{
    /* Use a format with SNMP interface information */
#if   SK_ENABLE_IPV6
    return FT_RWIPV6ROUTING;
#elif SK_ENABLE_INITIAL_TCPFLAGS
    return FT_RWAUGROUTING;
#else
    return FT_RWROUTED;
#endif
}


/*
 *  rwios = openOutputStream(timestamp, sensor_id, flowtype, probe);
 *
 *    Creates an rwIO Stream to store flow records of the specified
 *    'flowtype', hourly 'timestamp', and 'sensor_id'.
 *
 *    The file's location is determined by using the file location
 *    rules that are specified in the silk.conf file.
 *
 *    Gets a write lock on the file.
 *
 *    Returns the stream on success, or NULL on error.
 */
static rwIOStruct_t *openOutputStream(
    sktime_t            timestamp,
    sensorID_t          sensor_id,
    flowtypeID_t        flowtype_id,
    const skpc_probe_t *probe)
{
    sk_hentry_packedfile_t *hdr_entry;
    char filename[PATH_MAX];
    rwIOStruct_t *rwIOS = NULL;
    sk_file_header_t *hdr;
    fileFormat_t file_format;
    int errnum = 0;
    int rv;

    /* Build the file name--WHERE the records will be written onto
     * disk. */
    if (output_mode == OUTPUT_SENDING) {
        char tmpbuf[PATH_MAX];
        char *fname;

        sksiteGeneratePathname(tmpbuf, sizeof(tmpbuf),
                               flowtype_id, sensor_id, timestamp,
                               "", NULL, &fname);
        snprintf(filename, sizeof(filename), "%s/%s",
                 incremental_directory, fname);
    } else {
        sksiteGeneratePathname(filename, sizeof(filename),
                               flowtype_id, sensor_id, timestamp,
                               "", NULL, NULL);
    }

    /* Get the file output format---HOW the records will be written to
     * disk. */
    file_format = packlogic.determine_fileformat_fn(probe, flowtype_id);

    if (skFileExists(filename)) {
        /* Open existing file for append */
        DEBUGMSG("Opening existing output file %s", filename);

        rv = skStreamCreate(&rwIOS, SK_IO_APPEND, SK_CONTENT_SILK);
        if (rv == RWIO_OK) {
            rv = skStreamBind(rwIOS, filename);
        }
        if (rv == RWIO_OK) {
            rv = skStreamOpen(rwIOS);
        }
        if (rv == RWIO_OK && !no_file_locking) {
            rv = skStreamLockFile(rwIOS);
        }
        if (rv == RWIO_OK) {
            rv = skStreamReadSilkHeader(rwIOS, &hdr);
        }
        if (rv != RWIO_OK) {
            skStreamPrintLastErr(rwIOS, rv, &CRITMSG);
            if (rwIOS) {
                errnum = skStreamGetLastErrno(rwIOS);
            }
            skStreamDestroy(&rwIOS);
            goto END;
        }

        if (file_format != skHeaderGetFileFormat(hdr)) {
            NOTICEMSG(("Warning: File format of %s (%u)"
                       " does not match expected format (%u)"),
                      filename, skHeaderGetFileFormat(hdr),
                      file_format);
        }

        hdr_entry = ((sk_hentry_packedfile_t*)
                     skHeaderGetFirstMatch(hdr, SK_HENTRY_PACKEDFILE_ID));
        if (hdr_entry == NULL) {
            NOTICEMSG("No packedfile header entry on file %s",
                      filename);
        } else if (timestamp != skHentryPackedfileGetStartTime(hdr_entry)) {
            char buf1[SKTIMESTAMP_STRLEN];
            char buf2[SKTIMESTAMP_STRLEN];
            NOTICEMSG(("Warning: Timestamp of file %s (%s)"
                       " does not match expected (%s)"),
                      filename,
                      sktimestamp_r(buf1,
                                    skHentryPackedfileGetStartTime(hdr_entry),
                                    SKTIMESTAMP_NOMSEC),
                      sktimestamp_r(buf2, timestamp, SKTIMESTAMP_NOMSEC));
        }
    } else {
        /* Open a new file */
        INFOMSG("Opening new output file %s", filename);

        rv = skStreamCreate(&rwIOS, SK_IO_WRITE, SK_CONTENT_SILK_FLOW);
        if (rv == RWIO_OK) {
            rv = skStreamBind(rwIOS, filename);
        }
        if (rv == RWIO_OK) {
            rv = skStreamMakeDirectory(rwIOS);
        }
        if (rv == RWIO_OK) {
            hdr = skStreamGetSilkHeader(rwIOS);
            rv = skHeaderSetFileFormat(hdr, file_format);
        }
        if (rv == RWIO_OK) {
            rv = skHeaderSetRecordVersion(hdr, RWFLOWPACK_DEFAULT_VERSION);
        }
        if (rv == RWIO_OK) {
            rv = skHeaderSetCompressionMethod(hdr, comp_method);
        }
        if (rv == RWIO_OK) {
            rv = skHeaderSetByteOrder(hdr, byte_order);
        }
        if (rv == RWIO_OK) {
            rv = skHeaderAddPackedfile(hdr, timestamp, flowtype_id, sensor_id);
        }
        if (rv == RWIO_OK) {
            rv = skStreamOpen(rwIOS);
        }
        if (rv == RWIO_OK && !no_file_locking) {
            rv = skStreamLockFile(rwIOS);
        }
        if (rv == RWIO_OK) {
            rv = skStreamWriteSilkHeader(rwIOS);
        }
        if (rv != RWIO_OK) {
            skStreamPrintLastErr(rwIOS, rv, &CRITMSG);
            if (rwIOS) {
                errnum = skStreamGetLastErrno(rwIOS);
            }
            skStreamDestroy(&rwIOS);
            if (skFileExists(filename)) {
                unlink(filename);
            }
            goto END;
        }

        hdr_entry = ((sk_hentry_packedfile_t*)
                     skHeaderGetFirstMatch(hdr, SK_HENTRY_PACKEDFILE_ID));
    }

    /* rwioOpen() will map the sensor-name part of the file name to a
     * sensor-id based on the data in silk.conf.  If the rwioOpen()
     * mapping does not match the sensor_id that was given, consider
     * it a fatal error unless the rwioOpen() mapping gives an invalid
     * sensor ID. */
    if (hdr_entry) {
        if (sensor_id != skHentryPackedfileGetSensorID(hdr_entry)) {
            if (skHentryPackedfileGetSensorID(hdr_entry) != SK_INVALID_SENSOR){
                WARNINGMSG(("Sensor ID from file name (%u)"
                            " != specified sensor id (%u)"),
                           skHentryPackedfileGetSensorID(hdr_entry),
                           sensor_id);
                rwioDestroy(&rwIOS);
                goto END;
            }
        }
    }

  END:
    if (errnum == ENOLCK) {
        INFOMSG("Unable to get write lock; consider using the --%s switch",
                appOptions[OPT_NO_FILE_LOCKING].name);
    }
    return rwIOS;
}


/*
 *  ok = writeRecord(&rwrec, probe);
 *
 *    Given the time, sensor, and flowtype values as set in the SiLK
 *    flow record 'rwrec', pack the record into the correct file using
 *    the appropriate file output format.  Return 0 on success; return
 *    -1 to indicate a problem with the record, or -2 to indicate a
 *    problem with the file.
 */
static int writeRecord(const rwRec *rwrec, const skpc_probe_t *probe)
{
    rwIOStruct_t *rwIOS;
    sktime_t timestamp;
    sensorID_t sensor_id;
    flowtypeID_t flowtype_id;
    int rv = 0;

    /* The flowtype (class/type) and sensor says where the flow was
     * collected and where to write the flow. */
    flowtype_id = rwRecGetFlowType(rwrec);
    sensor_id = rwRecGetSensor(rwrec);

    /* Determine the hour this data is associated with.  This is a UTC
     * value expressed in milliseconds since the unix epoch, rounded
     * (down) to the hour. */
    timestamp = rwRecGetStartTime(rwrec);
    timestamp -= timestamp % 3600000;

    /* Only one thread accesses the file queue at a time */
    pthread_mutex_lock(&cache_mutex);

    /* Get the stream to write the record to: first see if we have an
     * already open stream in the cache */
    rwIOS = skStreamCacheLookup(stream_cache, timestamp, sensor_id,
                                flowtype_id);

    /* When the file is not in the cache, bring it in.  Opens or
     * creates file as necessary */
    if (rwIOS == NULL) {
        rwIOS = openOutputStream(timestamp, sensor_id, flowtype_id, probe);
        if (rwIOS == NULL) {
            rv = -2;
            goto END;
        }
        /* Add the stream to the cache */
        if (skStreamCacheAdd(stream_cache, rwIOS, timestamp, sensor_id,
                             flowtype_id))
        {
            rv = -2;
            goto END;
        }
    }

    /* Write record */
    rv = rwWrite(rwIOS, rwrec);
    if (rv != RWIO_OK) {
        if (RWIO_ERROR_IS_FATAL(rv)) {
            rwioPrintLastErr(rwIOS, rv, &ERRMSG);
            rv = -2;
        } else {
            rwioPrintLastErr(rwIOS, rv, &WARNINGMSG);
            rv = -1;
        }
    }

  END:
    pthread_mutex_unlock(&cache_mutex);
    return rv;
}


/*
 *  manageProcessor(NULL);
 *
 *  THREAD ENTRY POINT for the 'process_thread'.
 *
 *    Gets a flow record from the flowsource object and passes the
 *    record to writeRecord() for storage.  Runs until the flow
 *    source stream is exhausted (for file-based readers), until the
 *    global variable 'reading' is set to 0, or until an error occurs.
 */
static void *manageProcessor(void *vp_fproc)
{
    flow_proc_t *fproc = (flow_proc_t*)vp_fproc;
    reader_type_t *reader_type = fproc->reader_type;
    flowtypeID_t ftypes[MAX_SPLIT_FLOWTYPES];
    sensorID_t sensorids[MAX_SPLIT_FLOWTYPES];
    sigset_t sigs;
    rwRec rec;
    const skpc_probe_t *probe;
    int count;
    int rec_is_bad;
    int i;

    sigfillset(&sigs);
    pthread_sigmask(SIG_SETMASK, &sigs, NULL);

    while(1) {
        switch (reader_type->get_record_fn(&rec, &probe, fproc)) {
          case FP_FILE_BREAK:
            /* We've processed one input file; there may be more input
             * files.  Tell the sender to send the packed files we've
             * created.  This is a safe place to quit, so if we are no
             * longer reading, break out of the while().  Otherwise we
             * try again to get a record---we didn't get a record this
             * time. */
            sendFiles();
            if (!reading) {
                goto END;
            }
            continue;

          case FP_END_STREAM:
            /* We've processed all the input; there is no more.  Tell
             * the sender to send the packed files we've created.
             * Begin the shutdown process by disabling 'reading' and
             * setting shuttingDown. */
            sendFiles();
            reading = 0;
            shuttingDown = 1;
            goto END;

          case FP_GET_ERROR:
            /* An error occurred and we did not get a record.  Break
             * out of the while() if we are no longer reading,
             * otherwise try again to get a record. */
            if (!reading) {
                goto END;
            }
            continue;

          case FP_FATAL_ERROR:
            /* Exit the program.  The get_record_fn should have logged
             * an error. */
            exit(EXIT_FAILURE);

          case FP_BREAK_POINT:
            /* We got a record, and this is a safe place to quit if we
             * are no longer reading.  If not shutting down, process
             * the record. */
            if (!reading) {
                goto END;
            }
            /* FALLTHROUGH */

          case FP_RECORD:
            /* We got a record and we may NOT stop processing.
             * Process the record. */
            ++fproc->rec_count_total;

            /* Get the record's sensor(s) and flow_type(s) */
            count = packlogic.determine_flowtype_fn(probe, &rec,
                                                    ftypes, sensorids);
            assert(count >= -1);
            assert(count < MAX_SPLIT_FLOWTYPES);
            if (count == -1) {
                NOTICEMSG(("Cannot determine flowtype of record from"
                           " probe %s: input %d; output %d"),
                          skpcProbeGetName(probe), rwRecGetInput(&rec),
                          rwRecGetOutput(&rec));
                ++fproc->rec_count_bad;
                continue;
            }

            /* have we logged this record as bad? */
            rec_is_bad = 0;

            /* Store the record in each flowtype/sensor file. */
            for (i = 0; i < count; ++i) {
                rwRecSetFlowType(&rec, ftypes[i]);
                rwRecSetSensor(&rec, sensorids[i]);
                switch (writeRecord(&rec, probe)) {
                  case 0:
                    break;
                  case -1:
                    if (0 == rec_is_bad) {
                        /* Count bad records, but only once */
                        ++fproc->rec_count_bad;
                        rec_is_bad = 1;
                    }
                    break;
                  case -2:
                  default:
                    /* error writing to disk--exit this thread */
                    ERRMSG(("Stopping the processing of flows from"
                            " probe '%s' due to file system errors."),
                           skpcProbeGetName(probe));
                    fproc->reader_type->stop_fn(fproc);
                    goto END;
                }
            }
            break;

        } /*switch*/
    } /*while*/

  END:
    /* thread is ending, decrement the count */
    pthread_mutex_lock(&fproc_thread_count_mutex);
    --fproc_thread_count;
    pthread_mutex_unlock(&fproc_thread_count_mutex);

    /* tell the main thread to check the thread count */
    pthread_kill(main_thread, SIGUSR2);
    return NULL;
}


/*
 *  status = startProcessor();
 *
 *    Create the stream cache, spawn the timing_thread, start the
 *    reader_type, and finally spawn the process_thread to process
 *    records.
 *
 *    Return 1 if something fails, or 0 for success.
 */
static int startProcessor(void)
{
    skTimerRepeat_t (*timer_func)(void*) = &flushFiles;
    flow_proc_t *fproc;
    size_t i;

    /* Create a cache of streams (file handles) so we don't have to
     * incur the expense of reopening files */
    INFOMSG("Creating stream cache");
    stream_cache = skStreamCacheCreate(STREAM_CACHE_DEPTH);
    if (NULL == stream_cache) {
        ERRMSG("Unable to create stream cache.");
        return 1;
    }

    reading = 1;

    /* Start each flow_processor and create a thread to manage it */
    for (i = 0; i < num_flow_processors; ++i) {
        fproc = &flow_processors[i];
        if (fproc->reader_type->start_fn(fproc) != 0) {
            ERRMSG("Unable to start the flow reader.");
            reading = 0;
            return 1;
        }

        pthread_mutex_lock(&fproc_thread_count_mutex);
        ++fproc_thread_count;
        pthread_mutex_unlock(&fproc_thread_count_mutex);

        if (pthread_create(&fproc->thread, NULL, manageProcessor, fproc)) {
            ERRMSG("Unable to create the manageProcessor thread.");
            reading = 0;
            return 1;
        }
    }

    if (output_mode == OUTPUT_SENDING) {
        if (input_mode == INPUT_STREAM) {
            timer_func = &timedSendFiles;
        } else {
            /* disable timer */
            timer_func = NULL;
        }
    }

    /* Start timer */
    if (timer_func) {
        if (skTimerCreate(&timing_thread, flush_timeout, timer_func, NULL)
            == -1)
        {
            ERRMSG("Unable to start flush timer.");
            return 1;
        }
    }

    return 0;
}


static void stopProcessor(void)
{
    flow_proc_t *fproc;
    size_t i;

    if (reading) {
        INFOMSG("Stopping processors");
        reading = 0;

        /* Give the threads a chance to quit on their own---by their
         * checking the 'reading' variable. */
        sleep(2);

        if (timing_thread != NULL) {
            skTimerDestroy(timing_thread);
        }

        /* stop each flow processor and join its thread */
        INFOMSG("Waiting for record handlers.");
        for (i = 0; i < num_flow_processors; ++i) {
            fproc = &flow_processors[i];
            fproc->reader_type->stop_fn(fproc);
            pthread_join(fproc->thread, NULL); /* join */
        }
    }
}


/*
 *  sendFiles();
 *
 *    Closes all the open files in the stream cache and moves all the
 *    files in the incremental-directory to the sender-directory.
 */
static void sendFiles(void)
{
    int tmp_fd;
    char path[PATH_MAX];
    char newpath[PATH_MAX];
    struct dirent *entry;
    DIR *dir;
    int file_count = 0;
    int successfully_sent = 0;
    int rv;

    /* Return if sending mode not specified */
    if (output_mode != OUTPUT_SENDING) {
        return;
    }

    INFOMSG("Preparing to move files for sending...");

    /* Lock stream cache */
    pthread_cleanup_push((cleanupHandler)pthread_mutex_unlock,
                         (void *)&cache_mutex);
    pthread_mutex_lock(&cache_mutex);

    /* Close all the output files. */
    INFOMSG("Closing incremental files...");
    skStreamCacheCloseAll(stream_cache);

    /* Open the directory holding the files to send and loop over the
     * files in the directory. */
    dir = opendir(incremental_directory);
    if (NULL == dir) {
        CRITMSG("Fatal error: Unable to open incremental directory %s: %s",
                incremental_directory, strerror(errno));
        exit(EXIT_FAILURE);
    }

    INFOMSG("Moving files to %s...", sender_directory);
    while ((entry = readdir(dir)) != NULL) {
        /* ignore dot-files */
        if ('.' == entry->d_name[0]) {
            continue;
        }
        ++file_count;

        /* Copy each file to a unique name */
        snprintf(path, sizeof(path), "%s/%s",
                 incremental_directory, entry->d_name);
        snprintf(newpath, sizeof(newpath), "%s/%s.XXXXXX",
                 sender_directory, entry->d_name);
        tmp_fd = mkstemp(newpath);
        if (tmp_fd == -1) {
            ERRMSG("could not create and open temporary file %s: %s",
                   newpath, strerror(errno));
            continue;
        }
        close(tmp_fd);
        rv = skMoveFile(path, newpath);
        if (rv != 0) {
            ERRMSG("could not move file '%s' to '%s' for sending: %s",
                   path, newpath, strerror(rv));
            continue;
        }

        /* Moving a file to the sender_directory is considered a
         * successful send, even when no sender is running. */
        ++successfully_sent;
        INFOMSG("%s", newpath);
    }

    closedir(dir);

    /* Print status message */
    if (file_count == 0) {
        INFOMSG("No files to send.");
    } else {
        INFOMSG("Successfully moved %d/%d file%s.",
                successfully_sent, file_count, ((file_count == 1) ? "" : "s"));
    }

    pthread_cleanup_pop(1);
}


/*
 *  removeFilesFromDir(dir_name);
 *
 *    Remove all the files from dir_name.  Return the number of
 *    directory entries that COULD NOT be removed, or -1 if function
 *    is unable to open dir_name; i.e. 0 == fully successful, >0 ==
 *    unusual condition; <0 == error.
 */
static int removeFilesFromDir(const char *dir_name)
{
    char path[PATH_MAX];
    struct dirent *entry;
    DIR *dir;
    int count = 0;

    dir = opendir(dir_name);
    if (dir == NULL) {
        return -1;
    }

    while ((entry = readdir(dir))) {
        if (strcmp(entry->d_name, ".") == 0 ||
            strcmp(entry->d_name, "..") == 0)
        {
            continue;
        }

        snprintf(path, sizeof(path), "%s/%s", dir_name, entry->d_name);
        if (unlink(path) == -1) {
            skAppPrintErr("Could not remove the file '%s': %s",
                          path, strerror(errno));
            ++count;
        }
    }

    closedir(dir);

    return count;
}


/*
 *  status = archiveFile(filename);
 *
 *    Moves 'filename' into the directory tree rooted at
 *    'archive_directory'.  Files are stored in a subdirectory that is
 *    based on the current time.
 *
 *    Returns 0 on success; -1 on error; 1 if the archive_directory is
 *    NULL.
 */
int archiveFile(const char *fn)
{
    const char *c;
    char       *s;
    char        path[PATH_MAX];
    time_t      curtime;
    struct tm   ctm;
    int         rv;

    if ( !archive_directory) {
        return 1;
    }

    /* basename */
    if ((c = strrchr(fn, '/')) == NULL) {
        c = fn;
    } else {
        c++;
    }

    /* create archive path based on current UTC time */
    curtime = time(NULL);
    gmtime_r(&curtime, &ctm);
    snprintf(path, sizeof(path), "%s/%04d/%02d/%02d/%02d/%s",
             archive_directory,
             ctm.tm_year + 1900, ctm.tm_mon + 1, ctm.tm_mday, ctm.tm_hour,
             c);

    /* make the directory */
    s = strrchr(path, '/');
    *s = '\0';
    skMakeDir(path);
    *s = '/';

    /* move file */
    if ((rv = skMoveFile(fn, path)) != 0) {
        ERRMSG("Could not move '%s' to archive: %s",
               fn, strerror(rv));
        return -1;
    }

    return 0;
}


int main(int argc, char **argv)
{
    appSetup(argc, argv);                 /* never returns on error */

    /* start the logger and become a daemon */
#ifdef DEBUGGING
    skdaemonDontFork();
#endif
    if (skdaemonize(&shuttingDown, &appTeardown) == -1) {
        exit(EXIT_FAILURE);
    }

    /* Choose which processing thread to run based on user choice */
    if (startProcessor() != 0) {
        CRITMSG("Unable to start flow processor");
        exit(EXIT_FAILURE);
    }

    /* We now run forever, excepting signals, until the shuttingDown
     * flag is set or until all flow-processor threads exit. */
    while (!shuttingDown && fproc_thread_count > 0) {
        pause();
    }

    /* done */
    appTeardown();

    return 0;
}

/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
