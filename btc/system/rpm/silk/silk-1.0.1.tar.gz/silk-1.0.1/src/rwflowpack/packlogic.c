#include "silk.h"

/* RCSIDENT("$SiLK: packlogic.c 10721 2008-02-29 21:33:07Z mthomas $"); */

/* include the file containing the packing logic */
#include SK_PACKING_LOGIC_PATH

/*
** Local variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
