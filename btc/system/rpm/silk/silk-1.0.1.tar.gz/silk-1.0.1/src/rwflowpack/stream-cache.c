/*
** Copyright (C) 2004-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

#include "silk.h"

RCSIDENT("$SiLK: stream-cache.c 10466 2008-02-12 21:22:29Z mthomas $");

#include "utils.h"
#include "sklog.h"
#include "rwpack.h"
#include "stream-cache.h"
#include "sksite.h"
#include "redblack.h"


/* MACROS and DATA TYPES */

#ifndef DEBUG
#  define DEBUG 0
#endif

/* Message to print when out of memory */
#define FMT_MEM_FAILURE  "Out of memory at %s:%d", __FILE__, __LINE__


/* forward declaration */
struct cache_entry_st;
typedef struct cache_entry_st cache_entry_t;


/*
 *  The stream_cache_t contains a doubly linked list of 0 to
 *  'max_size' 'cache_entry_t's, and a redblack tree that is used to
 *  search through the list.  It also maintains a singly-linked list
 *  of "freed" cache_entries, to avoid having to re-alloc.
 */
struct stream_cache_st {
    /* head of the list of valid cache_entries; NULL if empty */
    cache_entry_t  *head;
    /* tail of the list of valid cache_entries; NULL if empty */
    cache_entry_t  *tail;
    /* list of "freed" entries */
    cache_entry_t  *free_list;
    /* the redblack tree used for searching */
    struct rbtree  *rbtree;
    /* current number of valid entries */
    int             size;
    /* maximum number of valid entries */
    int             max_size;
};


/*
 *  The cache_entry_t contains information about the file, the file
 *  handle, and the number of records in the file.  It also has
 *  pointers to the other nodes in the doubly linked list.
 */
struct cache_entry_st {
    /* the number of records in the file as of opening or the most
     * recent flush, used for log messages */
    uint64_t        rec_count;
    /* the hour that this file is for */
    sktime_t        time_stamp;
    /* the sensor that this file is for */
    sensorID_t      sensor_id;
    /* the flowtype (class/type) that this file is for */
    flowtypeID_t    flowtype_id;
    /* the open file handle */
    rwIOStruct_t   *stream;
    /* the previous entry in the linked list; NULL for head */
    cache_entry_t  *prev;
    /* the next entry in the linked list; NULL for tail */
    cache_entry_t  *next;
};


/*
 *  direction = _cacheEntryCompare(a, b, config);
 *
 *    The comparison function used by redblack.
 */
static int _cacheEntryCompare(
    const void *entry1_v,
    const void *entry2_v,
    const void UNUSED(*config))
{
    cache_entry_t *entry1 = (cache_entry_t*)entry1_v;
    cache_entry_t *entry2 = (cache_entry_t*)entry2_v;

    if (entry1->sensor_id < entry2->sensor_id) {
        return -1;
    }
    if (entry1->sensor_id > entry2->sensor_id) {
        return 1;
    }
    if (entry1->flowtype_id < entry2->flowtype_id) {
        return -1;
    }
    if (entry1->flowtype_id > entry2->flowtype_id) {
        return 1;
    }
    if (entry1->time_stamp < entry2->time_stamp) {
        return -1;
    }
    if (entry1->time_stamp > entry2->time_stamp) {
        return 1;
    }
    return 0;
}


/*
 *  _cacheEntryLogRecordCount(entry);
 *
 *    Write a message to the log giving the name of the file that
 *    'entry' wraps and the number of records written to that file
 *    since it was opened or last flushed.
 *
 *    The 'entry' will be updated with the new record count.
 */
static void _cacheEntryLogRecordCount(
    cache_entry_t  *entry)
{
    uint64_t new_count = skStreamGetRecordCount(entry->stream);

    if (entry->rec_count == new_count) {
        return;
    }
    assert(entry->rec_count < new_count);

    INFOMSG(("%s: %" PRId64 " recs"),
            skStreamGetPathname(entry->stream),(new_count - entry->rec_count));
    entry->rec_count = new_count;
}


/*
 *  _cacheEntryCloseFile(entry);
 *
 *    Close the stream that 'entry' wraps, destroy the stream, and
 *    remove the entry from the redblack tree.  In addition, log the
 *    number of records written.  Does not remove the entry from the
 *    linked list.
 */
static void _cacheEntryCloseFile(
    stream_cache_t *cache,
    cache_entry_t  *entry)
{
    int rv;

#if DEBUG
    DEBUGMSG("Stream cache closing file %s",
             skStreamGetPathname(entry->stream));
#endif

    _cacheEntryLogRecordCount(entry);
    rv = skStreamClose(entry->stream);
    if (rv) {
        skStreamPrintLastErr(entry->stream, rv, &NOTICEMSG);
    }
    skStreamDestroy(&entry->stream);
    rbdelete(entry, cache->rbtree);
}


/*
 *  cache = skStreamCacheCreate(max_size);
 *
 *    Create a stream_cache capable of keeping 'max_size' files open.
 *    Returns NULL if memory cannot be allocated.
 */
stream_cache_t *skStreamCacheCreate(int max_size)
{
    stream_cache_t *cache = NULL;

    /* verify input */
    if (max_size < STREAM_CACHE_MINIMUM_SIZE) {
        CRITMSG("Illegal maximum size (%d) for stream cache; use value > 1",
                max_size);
        return NULL;
    }

    cache = calloc(1, sizeof(stream_cache_t));
    if (cache == NULL) {
        CRITMSG(FMT_MEM_FAILURE);
        return NULL;
    }

    cache->rbtree = rbinit(&_cacheEntryCompare, NULL);
    if (cache->rbtree == NULL) {
        CRITMSG(FMT_MEM_FAILURE);
        free(cache);
        return NULL;
    }

    cache->max_size = max_size;
    return cache;
}


/*
 *  skStreamCacheDestroy(cache);
 *
 *    Close all streams and free all memory associated with the
 *    streams.  Free the memory associated with the cache.  The cache
 *    pointer is invalid after a call to this function.
 */
void skStreamCacheDestroy(stream_cache_t *cache)
{
    cache_entry_t *entry;
    cache_entry_t *next_entry = NULL;

    if (cache == NULL) {
        INFOMSG("Tried to destroy unitialized stream cache.");
        return;
    }

#if DEBUG
    DEBUGMSG("Destroying cache with %d entries", cache->size);
#endif

    /* free the valid entries */
    for (entry = cache->head; entry != NULL; entry = next_entry) {
        next_entry = entry->next;
        _cacheEntryCloseFile(cache, entry);
        free(entry);
    }

    /* free any entries on the free_list */
    next_entry = NULL;
    for (entry = cache->free_list; entry != NULL; entry = next_entry) {
        next_entry = entry->next;
        free(entry);
    }

    /* destroy the redblack tree */
    rbdestroy(cache->rbtree);

    /* Free the structure itself */
    free(cache);
}


/*
 *  skStreamCacheFlush(cache);
 *
 *    Flush all the streams in the cache, and log the number of
 *    records processed since the most recent flush or open.
 */
void skStreamCacheFlush(stream_cache_t *cache)
{
    int rv;
    cache_entry_t *entry;

    assert(cache);

#if DEBUG
    DEBUGMSG("Flushing cache with %d entries", cache->size);
#endif

    for (entry = cache->head; entry != NULL; entry = entry->next) {
        rv = skStreamFlush(entry->stream);
        if (rv) {
            skStreamPrintLastErr(entry->stream, rv, &NOTICEMSG);
        }
        _cacheEntryLogRecordCount(entry);
    }
}


/*
 *  skStreamCacheCloseAll(cache);
 *
 *    Close all the the streams in the cache and remove them from the
 *    cache.  For each file, log the number of records processed since
 *    the most recent flush or open.
 */
void skStreamCacheCloseAll(stream_cache_t *cache)
{
    cache_entry_t *entry;
    cache_entry_t *next_entry = NULL;

    assert(cache);

#if DEBUG
    DEBUGMSG("Closing files in cache with %d entries", cache->size);
#endif

    for (entry = cache->head; entry != NULL; entry = next_entry) {
        next_entry = entry->next;
        _cacheEntryCloseFile(cache, entry);
        entry->next = cache->free_list;
        cache->free_list = entry;
    }

    cache->head = NULL;
    cache->tail = NULL;
    cache->size = 0;
}


/*
 *  skStreamCacheAdd(cache, stream, timestamp, sensor, flowtype);
 *
 *    Add 'stream' to the stream cache 'cache'.  Use the 'timestamp',
 *    'sensor', and 'flowtype' as the key..  After this call, the
 *    cache will own stream memory and will free it when the stream
 *    falls off the end of the cache, or when the cache is destroyed.
 */
int skStreamCacheAdd(
    stream_cache_t *cache,
    rwIOStruct_t   *rwios,
    sktime_t        time_stamp,
    sensorID_t      sensor_id,
    flowtypeID_t    flowtype_id)
{
    cache_entry_t *entry;
    const void *rv;

    assert(cache);
    assert(rwios);

#if DEBUG
    DEBUGMSG("Adding new entry to cache with %d/%d entries",
             cache->size, cache->max_size);
#endif

    if (cache->free_list) {
        /* Entries are available on the free_list */
        entry = cache->free_list;
        cache->free_list = entry->next;
    } else if (cache->size < cache->max_size) {
        /* We're not to the max size yet, so allocate a stream */
        entry = malloc(sizeof(cache_entry_t));
        if (entry == NULL) {
            CRITMSG(FMT_MEM_FAILURE);
            return -1;
        }
    } else {
        /* The cache is full: flush, close and free the last stream */
        entry = cache->tail;
        entry->prev->next = NULL;
        cache->tail = entry->prev;
        _cacheEntryCloseFile(cache, entry);
        --cache->size;
    }

    /* fill out new entry */
    entry->time_stamp = time_stamp;
    entry->sensor_id = sensor_id;
    entry->flowtype_id = flowtype_id;
    entry->stream = rwios;
    entry->rec_count = skStreamGetRecordCount(rwios);
    entry->prev = NULL;
    entry->next = cache->head;

    /* add it to the linked list */
    if (entry->next) {
        entry->next->prev = entry;
    }
    if (cache->tail == NULL) {
        cache->tail = entry;
    }
    cache->head = entry;
    ++cache->size;

    /* add it to the redblack tree */
    rv = rbsearch(entry, cache->rbtree);
    if (rv != entry) {
        if (rv == NULL) {
            CRITMSG("Out of memory at %s:%d", __FILE__, __LINE__);
        } else {
            ERRMSG(("Duplicate entries in stream cache "
                    "for time=%" PRId64 " sensor=%d flowtype=%d"),
                   time_stamp, sensor_id, flowtype_id);
        }
        entry->next = cache->free_list;
        cache->free_list = entry;
        return -1;
    }

    return 0;
}


/*
 *  stream = skStreamCacheLookup(cache, time_stamp, sensor_id, flowtype_id);
 *
 *    Return the stream for the specified timestamp, sensor, and
 *    flowtype.  Return NULL if no stream for the specified values is
 *    found.
 */
rwIOStruct_t *skStreamCacheLookup(
    stream_cache_t *cache,
    sktime_t        time_stamp,
    sensorID_t      sensor_id,
    flowtypeID_t    flowtype_id)
{
    cache_entry_t *entry;
    cache_entry_t key;

    /* fill out the key */
    key.time_stamp = time_stamp;
    key.sensor_id = sensor_id;
    key.flowtype_id = flowtype_id;
    key.stream = NULL;
    key.prev = NULL;
    key.next = NULL;

    /* try to find the entry */
    entry = (cache_entry_t*)rbfind(&key, cache->rbtree);
#if DEBUG
    {
        char tstamp[SKTIMESTAMP_STRLEN];
        char sensor[SK_MAX_STRLEN_SENSOR+1];
        char flowtype[SK_MAX_STRLEN_FLOWTYPE+1];

        sksiteSensorGetName(sensor, sizeof(sensor), sensor_id);
        sksiteFlowtypeGetName(flowtype, sizeof(flowtype), flowtype_id);
        DEBUGMSG("Cache %s for stream %s %s %s",
                 ((entry == NULL) ? "miss" : "hit"),
                 sktimestamp_r(tstamp, time_stamp, SKTIMESTAMP_NOMSEC),
                 sensor, flowtype);
    }
#endif /* DEBUG */

    /* return if we didn't find it */
    if (entry == NULL) {
        return NULL;
    }

    /* found it, move it the head of the list unless it is already
     * there */
    if (entry->prev != NULL) {
        /* move to head of list */
        entry->prev->next = entry->next;
        if (entry->next) {
            entry->next->prev = entry->prev;
        } else {
            cache->tail = entry->prev;
        }
        entry->prev = NULL;
        entry->next = cache->head;
        entry->next->prev = entry;
        cache->head = entry;
    }

    return entry->stream;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
