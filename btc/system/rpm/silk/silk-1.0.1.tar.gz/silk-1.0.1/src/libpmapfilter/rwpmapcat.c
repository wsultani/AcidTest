/*
** Copyright (C) 2007-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  rwpmapcat.c
**
**    Print information about a prefix map file.  Very loosely based
**    on skprefixmap-test.c
**
**    Mark Thomas
**    January 2007
*/

#include "silk.h"

RCSIDENT("$SiLK: rwpmapcat.c 10649 2008-02-26 12:41:33Z mthomas $");

#include "utils.h"
#include "skprefixmap.h"
#include "skstringmap.h"
#include "skvector.h"
#include "skstream.h"


/* LOCAL DEFINES AND TYPEDEFS */

/* where to write --help output */
#define USAGE_FH stdout

/* types of output to produce */
#define OUTPUT_RANGES  (1<<0)
#define OUTPUT_LABELS  (1<<1)


/* LOCAL VARIABLES */

/* the opened prefix map */
static skPrefixMap_t *g_pmap = NULL;

/* output stream for the results */
static skstream_t *stream_out = NULL;

/* the value in the prefix map to ignore */
static uint32_t ignore_val = SKPREFIXMAP_NOT_FOUND;

/* the type(s) of output to produce */
static int output_types = OUTPUT_RANGES;

/* available output types */
static const sk_stringmap_entry_t output_type_names[] = {
    {"ranges",  OUTPUT_RANGES},
    {"labels",  OUTPUT_LABELS},
    {0, 0}      /* sentinel */
};

/* output flags */
static struct opt_flags_st {
    unsigned  no_cidr_blocks        :1;
    unsigned  no_titles             :1;
    unsigned  no_columns            :1;
    unsigned  no_final_delimiter    :1;
    unsigned  integer_ips           :1;
    unsigned  zero_pad_ips          :1;
} opt_flags;

/* output delimiter between columns */
static char delimiter = '|';


/* OPTIONS SETUP */

typedef enum {
    OPT_MAP_FILE, OPT_IGNORE_LABEL, OPT_IP_LABEL_TO_IGNORE, OPT_OUTPUT_TYPES,
    OPT_NO_CIDR_BLOCKS, OPT_INTEGER_IPS, OPT_ZERO_PAD_IPS,
    OPT_NO_TITLES, OPT_NO_COLUMNS, OPT_COLUMN_SEPARATOR,
    OPT_NO_FINAL_DELIMITER, OPT_DELIMITED,
    OPT_PAGER
} appOptionsEnum;

static struct option appOptions[] = {
    {"map-file",                REQUIRED_ARG, 0, OPT_MAP_FILE},
    {"ignore-label",            REQUIRED_ARG, 0, OPT_IGNORE_LABEL},
    {"ip-label-to-ignore",      REQUIRED_ARG, 0, OPT_IP_LABEL_TO_IGNORE},
    {"output-types",            REQUIRED_ARG, 0, OPT_OUTPUT_TYPES},
    {"no-cidr-blocks",          NO_ARG,       0, OPT_NO_CIDR_BLOCKS},
    {"integer-ips",             NO_ARG,       0, OPT_INTEGER_IPS},
    {"zero-pad-ips",            NO_ARG,       0, OPT_ZERO_PAD_IPS},
    {"no-titles",               NO_ARG,       0, OPT_NO_TITLES},
    {"no-columns",              NO_ARG,       0, OPT_NO_COLUMNS},
    {"column-separator",        REQUIRED_ARG, 0, OPT_COLUMN_SEPARATOR},
    {"no-final-delimiter",      NO_ARG,       0, OPT_NO_FINAL_DELIMITER},
    {"delimited",               OPTIONAL_ARG, 0, OPT_DELIMITED},
    {"pager",                   REQUIRED_ARG, 0, OPT_PAGER},
    {0,0,0,0}                   /* sentinel entry */
};

static const char *appHelp[] = {
    "Path to the prefix map file to process",
    "Do not print ranges having this label. Def. Print all",
    ("Do not print ranges having the label that\n"
     "\tthis IP has. Def. Print all"),
    NULL, /* generated dynamically */
    "Do not use CIDR notation. Def. Use CIDR notation",
    "Print IP numbers as integers. Def. Dotted decimal",
    "Print IP numbers as zero-padded dotted-decimal. Def. No",
    "Do not print column titles. Def. Print titles",
    "Disable fixed-width columnar output. Def. Columnar",
    "Use specified character between columns. Def. '|'",
    "Suppress column delimiter at end of line. Def. No",
    "Shortcut for --no-columns --no-final-del --column-sep=CHAR",
    "Program to invoke to page output. Def. $SILK_PAGER or $PAGER",
    NULL
};

typedef struct option_values_st {
    const char *map_file;
    const char *ignore_label;
    const char *ip_label_to_ignore;
    const char *output_types;
    const char *pager;
} option_values_t;



/* LOCAL FUNCTION PROTOTYPES */

static void appUsageLong(void);
static void appTeardown(void);
static void appSetup(int argc, char **argv);
static int  appOptionsHandler(clientData cData, int opt_index, char *opt_arg);
static skPrefixMap_t *openMapFile(const char *map_file);
static int parseOutputTypes(const char *type_list, int *output_type_flags);


/* FUNCTION DEFINITIONS */

/*
 *  appUsageLong();
 *
 *    Print complete usage information to USAGE_FH.  Pass this
 *    function to skOptionsSetUsageCallback(); skOptionsParse() will
 *    call this funciton and then exit the program when the --help
 *    option is given.
 */
static void appUsageLong(void)
{
#define USAGE_MSG                                                       \
    ("--map-file=MAPFILE [SWITCHES]\n"                                  \
     "\tPrint information about a prefix map file.  By default, print\n" \
     "\teach IP range in the map and its label\n")

    FILE *fh = USAGE_FH;
    int i, j;

    fprintf(fh, "%s %s", skAppName(), USAGE_MSG);
    fprintf(fh, "\nSWITCHES:\n");
    skOptionsDefaultUsage(fh);
    for (i = 0; appOptions[i].name; ++i) {
        fprintf(fh, "--%s %s. ",
                appOptions[i].name, SK_OPTION_HAS_ARG(appOptions[i]));
        switch (appOptions[i].val) {
          case OPT_OUTPUT_TYPES:
            fprintf(fh, ("What information to print about the map; enter as\n"
                         "\ta comma separated list. Def. '%s'\n"
                         "\tChoose among: %s"),
                    output_type_names[0].name, output_type_names[0].name);
            for (j = 1; output_type_names[j].name; ++j) {
                fprintf(fh, ",%s", output_type_names[j].name);
            }
            break;

          default:
            fprintf(fh, "%s", appHelp[i]);
            break;
        }
        fprintf(fh, "\n");
    }
}


/*
 *  appTeardown()
 *
 *    Teardown all modules, close all files, and tidy up all
 *    application state.
 *
 *    This function is idempotent.
 */
static void appTeardown(void)
{
    static int teardownFlag = 0;

    if (teardownFlag) {
        return;
    }
    teardownFlag = 1;

    if (g_pmap) {
        skPrefixMapDelete(g_pmap);
        g_pmap = NULL;
    }

    skStreamDestroy(&stream_out);
    skAppUnregister();
}


/*
 *  appSetup(argc, argv);
 *
 *    Perform all the setup for this application include setting up
 *    required modules, parsing options, etc.  This function should be
 *    passed the same arguments that were passed into main().
 *
 *    Returns to the caller if all setup succeeds.  If anything fails,
 *    this function will cause the application to exit with a FAILURE
 *    exit status.
 */
static void appSetup(int argc, char **argv)
{
    int arg_index;
    option_values_t opt_val;
    int rv;

    /* verify same number of options and help strings */
    assert((sizeof(appHelp)/sizeof(char *)) ==
           (sizeof(appOptions)/sizeof(struct option)));

    /* register the application */
    skAppRegister(argv[0]);
    skOptionsSetUsageCallback(&appUsageLong);

    /* initialize globals */
    memset(&opt_val, 0, sizeof(option_values_t));
    memset(&opt_flags, 0, sizeof(opt_flags));

    /* register the options */
    if (skOptionsRegister(appOptions, &appOptionsHandler,(clientData)&opt_val))
    {
        skAppPrintErr("Unable to register options");
        exit(EXIT_FAILURE);
    }

    /* parse the options */
    arg_index = skOptionsParse(argc, argv);
    if (arg_index < 0) {
        /* options parsing should print error */
        skAppUsage();           /* never returns */
    }

    /* verify that there was a map-file */
    if (NULL == opt_val.map_file) {
        skAppPrintErr("Required argument %s not provided",
                      appOptions[OPT_MAP_FILE].name);
        skAppUsage();
    }

    /* check for extra arguments */
    if (arg_index != argc) {
        skAppPrintErr("Too many arguments or unrecognized switch '%s'",
                      argv[arg_index]);
        skAppUsage();           /* never returns */
    }

    /* check for conflicting arguments */
    if (opt_val.ignore_label && opt_val.ip_label_to_ignore) {
        skAppPrintErr("Only one of --%s or --%s may be specified",
                      appOptions[OPT_IGNORE_LABEL].name,
                      appOptions[OPT_IP_LABEL_TO_IGNORE].name);
        exit(EXIT_FAILURE);
    }

    /* parse the output types */
    if (opt_val.output_types) {
        if (parseOutputTypes(opt_val.output_types, &output_types)) {
            exit(EXIT_FAILURE);
        }
    }

    /* open the prefix map file */
    g_pmap = openMapFile(opt_val.map_file);
    if (g_pmap == NULL) {
        exit(EXIT_FAILURE);
    }

    /* we've created the prefix map, make sure to delete it when done */
    if (atexit(appTeardown) < 0) {
        skAppPrintErr("Unable to register appTeardown() with atexit()");
        appTeardown();
        exit(EXIT_FAILURE);
    }

    /* Create the output stream */
    if ((rv = skStreamCreate(&stream_out, SK_IO_WRITE, SK_CONTENT_TEXT))
        || (rv = skStreamBind(stream_out, "stdout"))
        || (rv = skStreamPageOutput(stream_out, opt_val.pager))
        || (rv = skStreamOpen(stream_out)))
    {
        skStreamPrintLastErr(stream_out, rv, &skAppPrintErr);
        exit(EXIT_FAILURE);
    }

    /* if an ignore-label or an ignore-IP was given, find the
     * corresponding value. */
    if (opt_val.ignore_label) {
        ignore_val = skPrefixMapDictionaryLookup(g_pmap, opt_val.ignore_label);
        if (ignore_val == SKPREFIXMAP_NOT_FOUND) {
            skAppPrintErr("Invalid %s '%s': Value not in dictionary",
                          appOptions[OPT_IGNORE_LABEL].name,
                          opt_val.ignore_label);
            exit(EXIT_FAILURE);
        }
    } else if (opt_val.ip_label_to_ignore) {
        skipaddr_t ip;
        rv = skStringParseIP(&ip, opt_val.ip_label_to_ignore);
        if (rv) {
            skAppPrintErr("Invalid IP '%s': %s",
                          opt_val.ip_label_to_ignore,
                          skStringParseStrerror(rv));
            exit(EXIT_FAILURE);
        }
#if SK_ENABLE_IPV6
        if (skipaddrIsV6(&ip)) {
            skAppPrintErr("Invalid IP '%s': IPv6 addresses not supported",
                          opt_val.ip_label_to_ignore);
            exit(EXIT_FAILURE);
        }
#endif /* SK_ENABLE_IPV6 */
        ignore_val = skPrefixMapGet(g_pmap, skipaddrGetV4(&ip));
    }

    return;                     /* OK */
}


/*
 *  status = appOptionsHandler(cData, opt_index, opt_arg);
 *
 *    This function is passed to skOptionsRegister(); it will be called
 *    by skOptionsParse() for each user-specified switch that the
 *    application has registered; it should handle the switch as
 *    required---typically by setting global variables---and return 1
 *    if the switch processing failed or 0 if it succeeded.  Returning
 *    a non-zero from from the handler causes skOptionsParse() to return
 *    a negative value.
 *
 *    The clientData in 'cData' is typically ignored; 'opt_index' is
 *    the index number that was specified as the last value for each
 *    struct option in appOptions[]; 'opt_arg' is the user's argument
 *    to the switch for options that have a REQUIRED_ARG or an
 *    OPTIONAL_ARG.
 */
static int appOptionsHandler(
    clientData  cData,
    int         opt_index,
    char       *opt_arg)
{
    option_values_t *opt_val = (option_values_t*)cData;

    switch ((appOptionsEnum)opt_index) {
      case OPT_MAP_FILE:
        if (opt_val->map_file) {
            skAppPrintErr("May only specify the --%s switch one time",
                          appOptions[opt_index].name);
            return 1;
        }
        opt_val->map_file = opt_arg;
        break;

      case OPT_IGNORE_LABEL:
        if (opt_val->ignore_label) {
            skAppPrintErr("May only specify the --%s switch one time",
                          appOptions[opt_index].name);
            return 1;
        }
        opt_val->ignore_label = opt_arg;
        break;

      case OPT_IP_LABEL_TO_IGNORE:
        if (opt_val->ip_label_to_ignore) {
            skAppPrintErr("May only specify the --%s switch one time",
                          appOptions[opt_index].name);
            return 1;
        }
        opt_val->ip_label_to_ignore = opt_arg;
        break;

      case OPT_OUTPUT_TYPES:
        if (opt_val->output_types) {
            skAppPrintErr("May only specify the --%s switch one time",
                          appOptions[opt_index].name);
            return 1;
        }
        opt_val->output_types = opt_arg;
        break;

      case OPT_NO_CIDR_BLOCKS:
        opt_flags.no_cidr_blocks = 1;
        break;

      case OPT_INTEGER_IPS:
        if (opt_flags.zero_pad_ips) {
            skAppPrintErr("Warning: overriding previous output format;\n"
                          "\t will print IPs as integers.");
        }
        opt_flags.integer_ips = 1;
        break;

      case OPT_ZERO_PAD_IPS:
        if (opt_flags.integer_ips) {
            skAppPrintErr("Warning: overriding previous output format;\n"
                          "\t will print IPs as three-digit dotted decimal.");
        }
        opt_flags.zero_pad_ips = 1;
        break;

      case OPT_NO_TITLES:
        opt_flags.no_titles = 1;
        break;

      case OPT_NO_COLUMNS:
        opt_flags.no_columns = 1;
        break;

      case OPT_NO_FINAL_DELIMITER:
        opt_flags.no_final_delimiter = 1;
        break;

      case OPT_COLUMN_SEPARATOR:
        delimiter = opt_arg[0];
        break;

      case OPT_DELIMITED:
        opt_flags.no_columns = 1;
        opt_flags.no_final_delimiter = 1;
        if (opt_arg) {
            delimiter = opt_arg[0];
        }
        break;

      case OPT_PAGER:
        opt_val->pager = opt_arg;
        break;
    }

    return 0;                   /* OK */
}


/*
 *  pmap = openMapFile(path);
 *
 *    Open the prefix map file at 'path' and verify that it can be
 *    processed by this program.
 */
static skPrefixMap_t *openMapFile(const char *map_file)
{
    skPrefixMap_t *map = NULL;
    skPrefixMapErr_t map_error;

    /* open the prefixmap file and read it in */
    map_error = skPrefixMapLoad(&map, map_file);
    if ( SKPREFIXMAP_OK != map_error ) {
        if ( SKPREFIXMAP_ERR_ARGS == map_error ) {
            skAppPrintErr("Failed to read %s '%s': Invalid arguments",
                          appOptions[OPT_MAP_FILE].name, map_file);
        } else if ( SKPREFIXMAP_ERR_MEMORY == map_error ) {
            skAppPrintErr("Failed to read %s '%s': Out of memory",
                          appOptions[OPT_MAP_FILE].name, map_file);
        } else if ( SKPREFIXMAP_ERR_IO == map_error ) {
            skAppPrintErr("Failed to read %s '%s': I/O error",
                          appOptions[OPT_MAP_FILE].name, map_file);
        }
        map = NULL;
        goto ERROR;
    }

#if 0
    /* verify that the prefix map is of the correct generation */
    if (skPrefixMapDictionaryGetWordCount(map) == 0) {
        skAppPrintErr("The %s '%s' cannot be processed by this program",
                      appOptions[OPT_MAP_FILE].name, map_file);
        goto ERROR;
    }
#endif

    /* complain if ranges were requested and the file does not contain
     * address data.  if only ranges were requested, destroy the map. */
    if (SKPREFIXMAP_CONT_ADDR != skPrefixMapGetContentType(map)) {
        if (output_types & OUTPUT_RANGES) {
            skAppPrintErr("The %s '%s' does not contain an address prefix map",
                          appOptions[OPT_MAP_FILE].name, map_file);
            if ((output_types & OUTPUT_RANGES) == OUTPUT_RANGES) {
                /* only ranges requested */
                goto ERROR;
            }
        }
    }

    /* Success */
    return map;

  ERROR:
    if (map) {
        skPrefixMapDelete(map);
    }
    return NULL;
}


/*
 *  status = parseOutputTypes(type_list, &type_flags);
 *
 *    Parse the 'type_list', a comma separated list of the names from
 *    the output_type_names[] array, and set bits to HIGH in
 *    'type_flags' if the output type was requested.  Return 0 on
 *    success, or -1 on error.
 */
static int parseOutputTypes(const char *type_list, int *output_type_flags)
{
    sk_stringmap_t *str_map = NULL;
    sk_stringmap_status_t rv_map;
    sk_stringmap_entry_t *map_entry;
    sk_vector_t *types_vec = NULL;
    char *bad_type = NULL;
    size_t count;
    size_t i;
    int rv = -1;

    /* create a stringmap of the available output types */
    if (SKSTRINGMAP_OK != skStringMapCreate(&str_map)) {
        skAppPrintErr("Unable to create stringmap");
        goto END;
    }
    if (skStringMapAddIDArray(str_map, -1, output_type_names)!=SKSTRINGMAP_OK)
    {
        goto END;
    }

    /* create vector to hold match results */
    types_vec = skVectorNew(sizeof(sk_stringmap_entry_t*));
    if (types_vec == NULL) {
        skAppPrintErr("Allocation failure at %s:%d",
                      __FILE__, __LINE__);
        goto END;
    }

    /* attempt to match */
    rv_map = skStringMapMatch(types_vec, &bad_type, str_map, type_list);
    switch (rv_map) {
      case SKSTRINGMAP_OK:
        break;

      case SKSTRINGMAP_PARSE_AMBIGUOUS:
        skAppPrintErr("The %s value '%s' is ambiguous",
                      appOptions[OPT_OUTPUT_TYPES].name, bad_type);
        goto END;

      case SKSTRINGMAP_PARSE_NO_MATCH:
        skAppPrintErr(("The %s value '%s' is not valid"),
                      appOptions[OPT_OUTPUT_TYPES].name, bad_type);
        goto END;

      case SKSTRINGMAP_PARSE_UNPARSABLE:
        skAppPrintErr("Unable to parse the %s value '%s'",
                      appOptions[OPT_OUTPUT_TYPES].name, bad_type);
        goto END;

      default:
        skAppPrintErr("Unexpected return value from string-map parser (%d)",
                      rv_map);
        goto END;
    }

    *output_type_flags = 0;

    count = skVectorGetCount(types_vec);
    for (i = 0; i < count; ++i) {
        skVectorGetValue(&map_entry, types_vec, i);
        *output_type_flags |= map_entry->id;
    }

    /* success */
    rv = 0;

  END:
    if (types_vec) {
        skVectorDestroy(types_vec);
    }
    if (str_map) {
        skStringMapDestroy(str_map);
    }
    return rv;
}


/*
 *  printLabels(pamp);
 *
 *    Print the labels that appear in the prefix map 'pmap'.
 */
static void printLabels(skPrefixMap_t *pmap)
{
    char label[1024];
    uint32_t label_count;
    uint32_t i;

    label_count = skPrefixMapDictionaryGetWordCount(pmap);
    if (label_count == 0) {
        skStreamPrint(stream_out, ("NO LABELS ARE PRESENT;"
                                   " VALUE IS APPLICATION DEPENDENT\n"));
        return;
    }

    if (!opt_flags.no_titles) {
        skStreamPrint(stream_out, "LABELS:\n");
    }
    for (i = 0; i < label_count; ++i) {
        skPrefixMapDictionaryGetEntry(pmap, i, label, sizeof(label));
        skStreamPrint(stream_out, "%s\n", label);
    }
}


/*
 *  printOneRange(pmap, start_ip, end_ip, label_val)
 *
 *    Given a range of IPs from 'start_ip' to 'end_ip' that have the
 *    label 'label_val', produce output line(s) showing that
 *    information.  This could be mulitple lines if CIDR output is
 *    active.
 */
static void printOneRange(
    skPrefixMap_t  *pmap,
    uint32_t        start_ip,
    uint32_t        end_ip,
    uint32_t        label_val)
{
    const char *label_title;
    static int label_width = 0;
    static int ip_width = 0;
    char name[1024];
    char str_start[SK_NUM2DOT_STRLEN];
    char str_end[SK_NUM2DOT_STRLEN];
    int bit_count;
    uint32_t new_start_ip;
    char final_delim[] = {'\0', '\0'};

    if (label_val == ignore_val) {
        return;
    }

    if ( !opt_flags.no_final_delimiter) {
        final_delim[0] = delimiter;
    }

    if (label_width == 0) {
        if (skPrefixMapDictionaryGetWordCount(pmap) == 0) {
            label_title = "value";
        } else {
            label_title = "label";
        }
        if (opt_flags.no_columns) {
            label_width = 1;
            ip_width = 1;
        } else {
            if (opt_flags.integer_ips) {
                ip_width = 10;
            } else {
                ip_width = 15;
            }
            label_width = (int)skPrefixMapDictionaryGetMaxWordSize(pmap);
            if (label_width < (int)strlen(label_title)) {
                label_width = (int)strlen(label_title);
            }
        }

        /* print titles */
        if (!opt_flags.no_titles) {
            if (opt_flags.no_cidr_blocks) {
                skStreamPrint(stream_out, "%*s%c%*s%c%*s%s\n",
                              ip_width, "startIP", delimiter,
                              ip_width, "endIP", delimiter,
                              label_width, label_title, final_delim);
            } else {
                skStreamPrint(stream_out, "%*s%c%*s%s\n",
                              (ip_width + 3), "ipBlock", delimiter,
                              label_width, label_title, final_delim);
            }
        }
    }

    skPrefixMapDictionaryGetEntry(pmap, label_val, name, sizeof(name));

    /* handle the case with no CIDR blocks */
    if (opt_flags.no_cidr_blocks) {
        if (opt_flags.integer_ips) {
            snprintf(str_start, sizeof(str_start), "%u", (unsigned)start_ip);
            snprintf(str_end, sizeof(str_end), "%u", (unsigned)end_ip);
        } else if (opt_flags.zero_pad_ips) {
            num2dot0_r(start_ip, str_start);
            num2dot0_r(end_ip, str_end);
        } else {
            num2dot_r(start_ip, str_start);
            num2dot_r(end_ip, str_end);
        }
        skStreamPrint(stream_out, "%*s%c%*s%c%*s%s\n",
                      ip_width, str_start, delimiter,
                      ip_width, str_end, delimiter,
                      label_width, name, final_delim);
        return;
    }

    do {
        bit_count = skComputeCIDR(start_ip, end_ip, &new_start_ip);

        /* print this CIDR block */
        if (opt_flags.integer_ips) {
            snprintf(str_start, sizeof(str_start), "%u", (unsigned)start_ip);
        } else if (opt_flags.zero_pad_ips) {
            num2dot0_r(start_ip, str_start);
        } else {
            num2dot_r(start_ip, str_start);
        }
        skStreamPrint(stream_out, "%*s/%d%c%*s%s\n",
                      (ip_width + ((bit_count < 10) ? 1 : 0)), str_start,
                      bit_count, delimiter,
                      label_width, name, final_delim);
        start_ip = new_start_ip;
    } while (start_ip != 0);
}


/*
 *  printRanges(pamp);
 *
 *    Print the IP ranges and labels that appear in the prefix map
 *    'pmap'.
 */
static void printRanges(skPrefixMap_t *pmap)
{
    skPrefixMapIterator_t iter;
    uint32_t addr_start;
    uint32_t addr_end;
    uint32_t val;

    skPrefixMapIteratorBind(&iter, pmap);
    while (skPrefixMapIteratorNext(&iter, &addr_start, &addr_end, &val)
           != SK_ITERATOR_NO_MORE_ENTRIES)
    {
        printOneRange(pmap, addr_start, addr_end, val);
    }
}


int main(int argc, char **argv)
{
    int output_count = 0;

    appSetup(argc, argv);                       /* never returns on error */

    if (output_types & OUTPUT_LABELS) {
        if (output_count) {
            skStreamPrint(stream_out, "\n");
        }
        ++output_count;
        printLabels(g_pmap);
    }
    if ((output_types & OUTPUT_RANGES)
        && (SKPREFIXMAP_CONT_ADDR == skPrefixMapGetContentType(g_pmap)))
    {
        if (output_count) {
            skStreamPrint(stream_out, "\n");
        }
        ++output_count;
        printRanges(g_pmap);
    }

    /* done */
    appTeardown();

    return 0;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
