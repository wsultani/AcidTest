/*
** Copyright (C) 2004-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
** pmapfilter.c
**
** John McClary Prevost
** April 20th, 2004
**
** Plugin for country code lookups using the prefixmap data structure.
*/

#include "silk.h"

RCSIDENT("$SiLK: pmapfilter.c 11248 2008-04-11 19:07:39Z mthomas $");

#include "utils.h"
#include "dynlib.h"
#include "rwpack.h"
#include "skstringmap.h"
#include "skprefixmap.h"
#include "pmapfilter_priv.h"


/* EXPORTED FUNCTIONS */

/* these are called by dynlib */
int dynlib_api_version(void);
int setup(dynlibInfoStruct *dlISP, dynlibSymbolId appType);
int configure(dynlibInfoStruct *dlISP, void *data);
void teardown(dynlibSymbolId appType);
void optionsUsage(dynlibSymbolId appType, FILE *fh);
int initialize(dynlibInfoStruct *dlISP, dynlibSymbolId appType);
int filter(rwRec *rwrec);
int cut(unsigned int field, char *out, size_t len_out, rwRec *rwrec);
int sort(unsigned int field, uint8_t *bin_value, rwRec *rwrec);
int uniq(
    unsigned int    field,
    uint8_t        *bin_value,
    char           *text_value,
    size_t          text_len,
    rwRec          *rwrec);


/* TYPEDEFS AND DEFINES */

#define KEY_OF_PROTO_PORT(proto,port) (((proto) * 65536) + (port))


/* LOCAL VARIABLES */

/* use bits to store which values are to be allowed/disallowed */
static uint32_t *srcValVector;
static uint32_t *destValVector;

/* whether to filter on source or dest or both */
static int filterSrc = 0;
static int filterDest = 0;

/* what content type does the map have? */
static skPrefixMapContent_t filterType;

/* the prefixmap used to look up codes */
static skPrefixMap_t *prefixMap = NULL;

/* whether the prefixmap is being ignored.  if so, all functions
 * that use the prefixmap during setup should return success. */
static int ignorePrefixMap = 0;

/* Plugin's name */
static const char *pluginName = "pmapfilter";

/* maximum column width */
static int max_column_width = -1;

/* whether the column-width has been returned to the application */
static int set_column_width = 0;

/* OPTIONS SETUP */

/* option tags */
typedef enum pmapFilter_args_e {
    OPT_PMAP_FILE,
    OPT_PMAP_SADDRESS,
    OPT_PMAP_DADDRESS,
    OPT_PMAP_SPORT_PROTO,
    OPT_PMAP_DPORT_PROTO,
    OPT_PMAP_COLUMN_WIDTH
} pmapFilter_args_t;

/*
 * The options and help strings.  Since these vary depending on the
 * type of app that is using the plugin, they get set to one of the
 * options below once we know which app called us.
 */
static struct option *libOptions = NULL;
static const char **libOptionsHelp = NULL;

/* Options and Help for filtering */
static struct option filterOptions[] = {
    {"pmap-file",         REQUIRED_ARG, 0, OPT_PMAP_FILE},
    {"pmap-saddress",     REQUIRED_ARG, 0, OPT_PMAP_SADDRESS},
    {"pmap-daddress",     REQUIRED_ARG, 0, OPT_PMAP_DADDRESS},
    {"pmap-sport-proto",  REQUIRED_ARG, 0, OPT_PMAP_SPORT_PROTO},
    {"pmap-dport-proto",  REQUIRED_ARG, 0, OPT_PMAP_DPORT_PROTO},
    {0,0,0,0}
};

static const char *filterOptionsHelp[] = {
    "Prefix map file to read. Def. None",
    ("Source address maps to a label specified in this\n"
     "\tcomma separated list of labels. Mapping given by named --pmap-file"),
    "Destination address maps to a label in this list",
    ("Protocol and source port map to a label specified in\n"
     "\tthis comma separated list of labels. Requires the --pmap-file switch"),
    "Protocol and dest port map to a label in this list",
    NULL
};

/* Options and Help for filtering */
static struct option otherOptions[] = {
    {"pmap-file",         REQUIRED_ARG, 0, OPT_PMAP_FILE},
    {"pmap-column-width", REQUIRED_ARG, 0, OPT_PMAP_COLUMN_WIDTH},
    {0,0,0,0}
};

static const char *otherOptionsHelp[] = {
    "Prefix map file to read. Def. None",
    "Maximum column width to use for output.",
    NULL
};

/* Fields that get added to rwcut, rwsort, rwuniq */
static sk_stringmap_entry_t pmap_fields[] = {
    {"sval", 1},
    {"dval", 2},
    {NULL,  UINT32_MAX}         /* sentinel */
};


/* PRIVATE FUNCTION PROTOTYPES */

static pmapFilter_err_t libOptionsSetup(
    dynlibInfoStruct   *dlISP,
    dynlibSymbolId      aType);
static int optionsHandler(clientData cData, int opt_index, char *opt_arg);
static pmapFilter_err_t pmapFilterInit(dynlibInfoStruct *dlISP);
static pmapFilter_err_t pmapFilterSetupVector(uint32_t *vector, char *opt_arg);
static int local_cut(
    unsigned int    field,
    char           *out,
    size_t          len_out,
    rwRec          *rwrec);


/* FUNCTION DEFINITIONS */

/*
 *  int dynlib_api_version(void);
 *
 *    Return the dynlib API version that this plugin was compiled
 *    against.
 */
int dynlib_api_version(void)
{
    return DYNLIB_API_VERSION;
}


/*
 * int setup(dynlibInfoStruct *dlISP, dynlibSymbolId appType)
 *
 * Called by dynlib interface code to set up the plugin.  This routine
 * should set up options handling if required.  Arguments: pointer to
 * the dynamic library interface structure, application type that is
 * using this plugin.  Returns DYNLIB_FAILED if processing fails,
 * DYNLIB_WONTPROCESS if the application should do normal output, and
 * DYNLIB_WILLPROCESS if this plugin takes over output.
 */
int setup(dynlibInfoStruct *dlISP, dynlibSymbolId appType)
{
    /* Make the plugin use the application's context, so we can add
     * options to main app. */
    skAppContextSet(dynlibGetAppContext(dlISP));

    if (libOptionsSetup(dlISP, appType) != PMAPFILTER_OK) {
        return DYNLIB_FAILED;
    }
    return DYNLIB_WONTPROCESS;
}


/*
 *  int configure(dynlibInfoStruct *dlISP, void *data)
 *
 *    Perform additional configuration of the plug-in prior to
 *    processing the options.
 */
int configure(dynlibInfoStruct *dlISP, void *data)
{
    const dynlibSymbolId appType = dynlibGetAppType(dlISP);

    switch(appType) {
      case DYNLIB_CUT:
      case DYNLIB_SORT:
      case DYNLIB_UNIQ:
        /* for these apps, data is a pointer into which we should copy
         * the address of the fields this plug-in provides to the
         * application */
        if (data == NULL) {
            return -1;
        } else {
            sk_stringmap_entry_t **fields_ptr = (sk_stringmap_entry_t **)data;
            *fields_ptr = pmap_fields;
        }
        break;

      default:
        /* nothing to do */
        break;
    }

    return 0;
}


/*
 * void teardown(dynlibSymbolId appType);
 *
 * Called by dynlib interface code to tear down this plugin.
 */
void teardown(dynlibSymbolId UNUSED(appType))
{
    if ( NULL != srcValVector ) {
        free(srcValVector);
    }
    if ( NULL != destValVector ) {
        free(destValVector);
    }
    if ( NULL != prefixMap ) {
        skPrefixMapDelete(prefixMap);
    }
}

/*
 * int initialize(dynlibInfoStruct *dlISP, dynlibSymbolId appType);
 *
 * Does any expensive initialization required by the plugin.  Returns
 * 0 on success, 1 on failure.  Note that initialization for filtering
 * is handled in the options parsing, so that it is only done when the
 * plugin is actually going to be used.
 */
int initialize(dynlibInfoStruct *dlISP, dynlibSymbolId appType)
{
    if ( ignorePrefixMap ) {
        return 0;
    }

    /* Make sure that the prefixmap has been loaded */
    if ( prefixMap == NULL ) {
        skAppPrintErr("%s: No --pmap-file option specified", pluginName);
        return PMAPFILTER_ERR_ARGS;
    }

    switch (appType) {
      case DYNLIB_CUT:
      case DYNLIB_SORT:
      case DYNLIB_UNIQ:
        if ( PMAPFILTER_OK != pmapFilterInit(dlISP) ) {
            return 1;           /* Failed */
        }
        break;

      default:
        /* nothing to do */
        break;
    }

    return 0;
}

/*
 * void optionsUsage(dynlibSymbolId UNUSED(appType), FILE *fh);
 *
 * Called by the dynlib interface to allow this plugin to print the
 * options it accepts.
 */
void optionsUsage(dynlibSymbolId appType, FILE *fh)
{
    int i;

    if ( libOptions == NULL ) {
        return;
    }
    for (i = 0; libOptions[i].name; i++) {
        fprintf(fh, "--%s %s. %s\n", libOptions[i].name,
                SK_OPTION_HAS_ARG(libOptions[i]), libOptionsHelp[i]);
        if (libOptions[i].val == OPT_PMAP_FILE) {
            if (appType == DYNLIB_SHAR_FILTER) {
                fprintf(fh, ("\tThis switch must precede any other"
                             " --pmap-* switch\n"));
            } else {
                fprintf(fh, ("\tWhen using a pmap, this switch must"
                             " precede the --fields switch\n"));
            }
        }
    }
}

/*
 * pmapFilter_err_t libOptionsSetup(dynlibInfoStruct *dlISP,
 *                                  dynlibSymbolId appType);
 *
 * Sets up the options handler for this plugin.
 */
static pmapFilter_err_t libOptionsSetup(
    dynlibInfoStruct   *dlISP,
    dynlibSymbolId      appType)
{
    if ( NULL != libOptions ) {
        /* Already initialized. */
        return PMAPFILTER_OK;
    }

    /* verify same number of options and help strings */
    assert((sizeof(filterOptions)/sizeof(struct option))
           == (sizeof(filterOptionsHelp)/sizeof(char*)));
    assert((sizeof(otherOptions)/sizeof(struct option))
           == (sizeof(otherOptionsHelp)/sizeof(char*)));

    switch (appType) {
      case DYNLIB_SHAR_FILTER:
        libOptions = filterOptions;
        libOptionsHelp = filterOptionsHelp;
        break;

      case DYNLIB_CUT:
      case DYNLIB_SORT:
      case DYNLIB_UNIQ:
        libOptions = otherOptions;
        libOptionsHelp = otherOptionsHelp;
        /* no options for these apps */
        break;

      default:
        skAppPrintErr("Cannot use %s plug-in with %s application",
                      pluginName, skAppName());
        return PMAPFILTER_ERR_REGISTER;
    }

    /* register the options */
    if ( skOptionsRegister(libOptions, &optionsHandler, (clientData)dlISP) ) {
        skAppPrintErr("%s: Unable to register options.", pluginName);
        return PMAPFILTER_ERR_REGISTER;
    }

    return PMAPFILTER_OK;
}

/*
 * int optionsHandler(clientData cData, int opt_index, char *opt_arg);
 *
 * Handles options for the plugin.  cData is the dynlib ISP (which can
 * be used to find which application we are, among other things.)
 * opt_index is the enum passed in with the options descriptions.  opt_arg
 * is the argument, or NULL if no argument was given.  Returns 0 on
 * success, or 1 if there was a problem.
 */
static int optionsHandler(clientData cData, int opt_index, char *opt_arg)
{
    const dynlibSymbolId appType = dynlibGetAppType((dynlibInfoStruct*)cData);
    skPrefixMapErr_t map_error = SKPREFIXMAP_OK;
    const char *opt_name = NULL;
    uint32_t vectorLen = 0;
    skstream_t *stream;
    uint32_t tmp32;
    int i;
    int ok;
    int rv;

    assert(libOptions);

    switch (appType) {
      case DYNLIB_SHAR_FILTER:
      case DYNLIB_CUT:
      case DYNLIB_SORT:
      case DYNLIB_UNIQ:
        for (i = 0; libOptions[i].name; ++i) {
            if (libOptions[i].val == opt_index) {
                opt_name = libOptions[i].name;
                break;
            }
        }
        break;

      default:
        skAppPrintErr("%s: This plug-in does not support this application",
                      pluginName);
        return 1;
    }

    assert(opt_name != NULL);
    if (opt_name == NULL) {
        skAppPrintErr("%s: Unknown option identifier %d",
                      pluginName, opt_index);
        return 1;
    }

    if ( PMAPFILTER_OK != pmapFilterInit((dynlibInfoStruct*)cData) ) {
        skAppPrintErr("%s: Initialization failure.", pluginName);
        return 1;
    }

    switch ( opt_index ) {

      case OPT_PMAP_FILE:
        if ( prefixMap != NULL || ignorePrefixMap ) {
            skAppPrintErr("%s: Attempted to load multiple prefixmaps",
                          pluginName);
            return 1;
        }

        ok = dynlibOpenDataInputStream(&stream, SK_CONTENT_SILK, opt_arg);
        if (ok == -1) {
            /* program opening file */
            skAppPrintErr("%s: Failed to open pmap file '%s'",
                          pluginName, opt_arg);
            return 1;
        }
        if (ok == 1) {
            /* ignore the file */
            ignorePrefixMap = 1;
            return 0;
        }

        map_error = skPrefixMapRead(&prefixMap, stream);
        skStreamDestroy(&stream);
        if ( SKPREFIXMAP_OK != map_error ) {
            prefixMap = NULL;
            skAppPrintErr("%s: Failed to read pmap file '%s': %s",
                          pluginName, opt_arg, skPrefixMapStrerror(map_error));
            return 1;
        }

        /* Set the content type */
        filterType = skPrefixMapGetContentType(prefixMap);

        /* Allocate the vectors. */
        vectorLen = skPrefixMapDictionaryGetWordCount(prefixMap);

        srcValVector = calloc(vectorLen/32, sizeof(uint32_t));
        if ( NULL == srcValVector ) {
            skAppPrintErr("%s: Out of memory allocating sval vector.",
                          pluginName);
            return PMAPFILTER_ERR_MEM;
        }
        destValVector = calloc(vectorLen/32, sizeof(uint32_t));
        if ( NULL == destValVector ) {
            skAppPrintErr("%s: Out of memory allocating dval vector.",
                          pluginName);
            free(srcValVector);
            return PMAPFILTER_ERR_MEM;
        }
        break;

      case OPT_PMAP_SADDRESS:
        if (prefixMap == NULL) {
            skAppPrintErr("%s: The --%s switch must precede --%s",
                          pluginName, libOptions[OPT_PMAP_FILE].name,
                          opt_name);
            return 1;
        }
        if ( SKPREFIXMAP_CONT_ADDR != filterType ) {
            skAppPrintErr("%s: Cannot use --%s on %s prefixmap",
                          pluginName, opt_name,
                          skPrefixMapGetContentName(filterType));
            return 1;
        }
        if ( PMAPFILTER_OK != pmapFilterSetupVector(srcValVector, opt_arg) ) {
            return 1;
        }
        filterSrc = 1;
        break;

      case OPT_PMAP_SPORT_PROTO:
        if (prefixMap == NULL) {
            skAppPrintErr("%s: The --%s switch must precede --%s",
                          pluginName, libOptions[OPT_PMAP_FILE].name,
                          opt_name);
            return 1;
        }
        if ( SKPREFIXMAP_CONT_PROTO_PORT != filterType ) {
            skAppPrintErr("%s: Cannot use --%s on %s prefixmap.",
                          pluginName, opt_name,
                          skPrefixMapGetContentName(filterType));
            return 1;
        }
        if ( PMAPFILTER_OK != pmapFilterSetupVector(srcValVector, opt_arg) ) {
            return 1;
        }
        filterSrc = 1;
        break;

      case OPT_PMAP_DADDRESS:
        if (prefixMap == NULL) {
            skAppPrintErr("%s: The --%s switch must precede --%s",
                          pluginName, libOptions[OPT_PMAP_FILE].name,
                          opt_name);
            return 1;
        }
        if ( SKPREFIXMAP_CONT_ADDR != filterType ) {
            skAppPrintErr("%s: Cannot use --%s on %s prefixmap.",
                          pluginName, opt_name,
                          skPrefixMapGetContentName(filterType));
            return 1;
        }
        if ( PMAPFILTER_OK != pmapFilterSetupVector(destValVector, opt_arg) ) {
            return 1;
        }
        filterDest = 1;
        break;

      case OPT_PMAP_DPORT_PROTO:
        if (prefixMap == NULL) {
            skAppPrintErr("%s: The --%s switch must precede --%s",
                          pluginName, libOptions[OPT_PMAP_FILE].name,
                          opt_name);
            return 1;
        }
        if ( SKPREFIXMAP_CONT_PROTO_PORT != filterType ) {
            skAppPrintErr("%s: Cannot use --%s on %s prefixmap.",
                          pluginName, opt_name,
                          skPrefixMapGetContentName(filterType));
            return 1;
        }
        if ( PMAPFILTER_OK != pmapFilterSetupVector(destValVector, opt_arg) ) {
            return 1;
        }
        filterDest = 1;
        break;

      case OPT_PMAP_COLUMN_WIDTH:
        if (set_column_width) {
            skAppPrintErr("%s: Ignoring --%s switch after --fields",
                          pluginName, opt_name);
            break;
        }
        if (max_column_width > 0) {
            skAppPrintErr("%s: --%s specified multiple times",
                          pluginName, opt_name);
            return 1;
        }
        rv = skStringParseUint32(&tmp32, opt_arg, 1, INT32_MAX);
        if (rv) {
            skAppPrintErr("%s: Invalid %s '%s': %s",
                          pluginName, opt_name, opt_arg,
                          skStringParseStrerror(rv));
            return 1;
        }
        max_column_width = (int)tmp32;
        break;

      default:
        skAppPrintErr("%s: Unrecognized option: %d", pluginName, opt_index);
        return 1;
    }
    return 0;
}


/*
 *  int filter(rwRec *rwrec);
 *
 *    The function actually used to implement filtering for the filter
 *    plugin.  Returns 0 if the record passes the filter, 1 if it
 *    fails the filter.
 */
int filter(rwRec *rwrec)
{
    uint32_t key;               /* For non-address */
    uint32_t code;

    assert(ignorePrefixMap == 0);

    if ( filterType == SKPREFIXMAP_CONT_ADDR ) {
        if ( filterSrc ) {
            code = skPrefixMapGet(prefixMap, rwRecGetSIPv4(rwrec));
            if ( !PMAPFILTER_VECTOR_GET_BIT(srcValVector, code) ) {
                return 1;       /* Reject */
            }
        }
        if ( filterDest ) {
            code = skPrefixMapGet(prefixMap, rwRecGetDIPv4(rwrec));
            if ( !PMAPFILTER_VECTOR_GET_BIT(destValVector, code) ) {
                return 1;       /* Reject */
            }
        }
        return 0;               /* Accept */
    } else if ( filterType == SKPREFIXMAP_CONT_PROTO_PORT ) {
        if ( filterSrc ) {
            key = KEY_OF_PROTO_PORT(rwRecGetProto(rwrec),
                                    rwRecGetSPort(rwrec));
            code = skPrefixMapGet(prefixMap, key);
            if ( !PMAPFILTER_VECTOR_GET_BIT(srcValVector, code) ) {
                return 1;       /* Reject */
            }
        }
        if ( filterDest ) {
            key = KEY_OF_PROTO_PORT(rwRecGetProto(rwrec),
                                    rwRecGetDPort(rwrec));
            code = skPrefixMapGet(prefixMap, key);
            if ( !PMAPFILTER_VECTOR_GET_BIT(destValVector, code) ) {
                return 1;       /* Reject */
            }
        }
        return 0;               /* Accept */
    } else {
        /* Unknown type: Accept all */
        return 0;
    }
}

/*
 * int cut(unsigned int field, char *out, size_t len_out, rwRec *rwrec);
 *
 * If "field" is 0, then returns the number of supported fields.
 *
 * If "out" is NULL and "rwrec" is NULL, returns the size of the buffer
 * needed to store the title for this field.
 *
 * If "out" is NULL and "rwrec" is non-NULL, returns the size of the
 * buffer needed to store the value for this field.
 *
 * If "out" is non-NULL and "rwrec" is NULL, writes the title into "out",
 * and returns the number of bytes needed to store that string.
 *
 * If "out" is non-NULL and "rwrec" is non-NULL, writes the value for
 * that record into "out", and returns the number of bytes needed to
 * store that string.
 */
int cut(unsigned int field, char *out, size_t len_out, rwRec *rwrec)
{
    return local_cut(field, out, len_out, rwrec);
}

static int local_cut(
    unsigned int    field,
    char           *out,
    size_t          len_out,
    rwRec          *rwrec)
{
    int len;
    uint32_t key;

    assert(ignorePrefixMap == 0);

    if ( field == 0 ) {
        /* Request for number of supported fields */
        return 2;
    }

    if ( field > 2 ) {
        return -1;              /* Error: We don't support that field */
    }

    if ( (out == NULL) && (rwrec == NULL) ) {
        /* Request for buffer size for field title */
        return 5;               /* Four for "sval" or "dval" plus \0 */
    }

    if ( (out != NULL) && (rwrec == NULL ) ) {
        /* Request for field title */
        switch ( field ) {
        case 1:
            len = snprintf(out, len_out, "sval");
            return len;
        case 2:
            len = snprintf(out, len_out, "dval");
            return len;
        default:
            return -1;
        }
    }

    if ( (out == NULL) && (rwrec != NULL ) ) {
        /* Request for buffer size for textual field value */
        len = skPrefixMapDictionaryGetMaxWordSize(prefixMap);
        if (max_column_width > 0 && max_column_width < len) {
            len = max_column_width;
        }
        /* set our global flag noting the size has been set */
        set_column_width = 1;
        return (len + 1);
    }

    if ( (out != NULL) && (rwrec != NULL) ) {
        /* Request for field value */
        switch ( field ) {
          case 1:
            if ( SKPREFIXMAP_CONT_ADDR == filterType ) {
                return skPrefixMapGetString(prefixMap, rwRecGetSIPv4(rwrec),
                                            out, len_out);
            } else {
                key = KEY_OF_PROTO_PORT(rwRecGetProto(rwrec),
                                        rwRecGetSPort(rwrec));
                return skPrefixMapGetString(prefixMap, key, out, len_out);
            }

          case 2:
            if ( SKPREFIXMAP_CONT_ADDR == filterType ) {
                return skPrefixMapGetString(prefixMap, rwRecGetDIPv4(rwrec),
                                            out, len_out);
            } else {
                key = KEY_OF_PROTO_PORT(rwRecGetProto(rwrec),
                                        rwRecGetDPort(rwrec));
                return skPrefixMapGetString(prefixMap, key, out, len_out);
            }

        default:
            return -1;
        }
    }

    /* Should never get here */
    return -1;
}


/*
 *  int sort(unsigned int field, uint8_t *bin_value, rwRec *rwrec);
 *
 *  Arguments:
 *      f:        field to get the binary or textual value of
 *      bin_val:  buffer to fill with a binary value that rwsort will
 *                use for sorting; rwsort will not ask the plug-in for
 *                more data; this value should be everything rwsort
 *                needs to know.  rwsort will use memcmp() to compare
 *                values; the values should be in big-endian byte
 *                order.  THIS BUFFER MAY NOT BE WORD ALIGNED.
 *      rec:      SiLK flow record
 *  Returns:
 *      when 'f' is zero
 *        => the number of supported fields
 *      when 'f' is non-zero
 *        when 'bin_val' or 'rec' is NULL
 *          => the number of bytes required to hold the binary value
 *             of field 'f'
 *        when 'bin_val' and 'rec' are non-NULL
 *          => length of the binary value; uses 'rec' to compute the
 *             value of field 'f' and writes that binary value into
 *             'bin_val'.  ASSUMES 'bin_val' IS BIG ENOUGH!
 */
int sort(unsigned int field, uint8_t *bin_value, rwRec *rwrec)
{
    uint32_t code = 0;
    uint32_t key;

    assert(ignorePrefixMap == 0);

    if (field == 0) {
        /* Request for number of supported fields */
        return 2;
    }

    if (bin_value && rwrec) {
        switch (field) {
          case 1:
            if ( filterType == SKPREFIXMAP_CONT_ADDR ) {
                code = skPrefixMapGet(prefixMap, rwRecGetSIPv4(rwrec));
            } else {
                key = KEY_OF_PROTO_PORT(rwRecGetProto(rwrec),
                                        rwRecGetSPort(rwrec));
                code = skPrefixMapGet(prefixMap, key);
            }
            break;

          case 2:
            if ( filterType == SKPREFIXMAP_CONT_ADDR ) {
                code = skPrefixMapGet(prefixMap, rwRecGetDIPv4(rwrec));
            } else {
                key = KEY_OF_PROTO_PORT(rwRecGetProto(rwrec),
                                        rwRecGetDPort(rwrec));
                code = skPrefixMapGet(prefixMap, key);
            }
            break;

          default:
            return 0;
        }

        bin_value[0] = (code>>24) & 0xFF;
        bin_value[1] = (code>>16) & 0xFF;
        bin_value[2] = (code>>8) & 0xFF;
        bin_value[3] = code & 0xFF;
    }

    /* return size of binary value */
    return 4;
}


/*
 *  int uniq(unsigned int f, uint8_t bin_val, char *text_val, size_t text_len, rwRec *rec)
 *
 *  Arguments:
 *      f:        field to get the binary or textual value of
 *      bin_val:  buffer to fill with binary value, or buffer to pass
 *                in the binary value when converting to text.
 *      text_val: buffer to fill with the textual value
 *      text_len: length of the buffer 'out'
 *      rec:      SiLK flow record
 *  Returns:
 *      when 'f' is zero
 *        => the number of supported fields
 *      when 'f' is non-zero
 *        when 'bin_val' is NULL
 *          => the result of running cut(f, text_val, text_len, rwrec)
 *        when 'bin_val' is non-NULL
 *          when 'text_val' is non-NULL and 'rec' has any value
 *            => length of buffer necessary to hold the complete
 *               textual value; fills 'text_val' with the first
 *               'text_len'-1 bytes of converting the binary value in
 *               'bin_val', corresponding to field 'f', to text.
 *          when 'text_val' is NULL and 'text_len' has any value
 *            when 'rec' is non-NULL
 *              => length of the binary value; uses 'rec' to compute
 *                 the value of field 'f' and writes that binary value
 *                 into 'bin_val'.  ASSUMES 'bin_val' IS BIG ENOUGH!
 *             when 'rec' is NULL
 *               => the number of bytes required to hold the binary
 *                  value of field 'f'
 */
int uniq(
    unsigned int    field,
    uint8_t        *bin_value,
    char           *text_value,
    size_t          text_len,
    rwRec          *rwrec)
{
    uint32_t code;
    uint32_t key;

    assert(ignorePrefixMap == 0);

    if (field == 0) {
        return 2;
    } else if (bin_value) {
        if (text_value) {
            /* return the text value given the binary value */
            code = ((bin_value[0] << 24) | (bin_value[1] << 16) |
                    (bin_value[2] << 8) | (bin_value[3]));
            return skPrefixMapDictionaryGetEntry(prefixMap, code,
                                                 text_value, text_len);
        } else if (rwrec) {
            /* return the binary value for the given rwrec */
            switch (field) {
              case 1:
                if ( filterType == SKPREFIXMAP_CONT_ADDR ) {
                    code = skPrefixMapGet(prefixMap, rwRecGetSIPv4(rwrec));
                } else {
                    key = KEY_OF_PROTO_PORT(rwRecGetProto(rwrec),
                                            rwRecGetSPort(rwrec));
                    code = skPrefixMapGet(prefixMap, key);
                }
                break;

              case 2:
                if ( filterType == SKPREFIXMAP_CONT_ADDR ) {
                    code = skPrefixMapGet(prefixMap, rwRecGetDIPv4(rwrec));
                } else {
                    key = KEY_OF_PROTO_PORT(rwRecGetProto(rwrec),
                                            rwRecGetDPort(rwrec));
                    code = skPrefixMapGet(prefixMap, key);
                }
                break;

              default:
                return -1;
            }
            bin_value[0] = (code>>24) & 0xFF;
            bin_value[1] = (code>>16) & 0xFF;
            bin_value[2] = (code>>8) & 0xFF;
            bin_value[3] = code & 0xFF;

            return 4;
        } else {
            /* return the number of bytes in the binary value */
            return 4;
        }
    } else {
        return local_cut(field, text_value, text_len, rwrec);
    }

    return -1; /* NOTREACHED */
}


/*
 * pmapFilter_err_t pmapFilterInit(dynlibInfoStruct *dlISP);
 *
 *    The one-time-only initialization code.  This is called by
 *    initialize for rwcut, rwsort, and rwuniq, and by the option
 *    parsing code for rwfilter.  Returns PMAPFILTER_OK on success.
 */
pmapFilter_err_t pmapFilterInit(dynlibInfoStruct *dlISP)
{
    static int initialized = 0;

    if ( initialized ) {
        return PMAPFILTER_OK;
    }

    dynlibMakeActive(dlISP);
    initialized = 1;
    return PMAPFILTER_OK;
}


/*
 *  pmapFilter_err_t pmapFilterSetupVector(uint32_t *vector, char *opt_arg);
 *
 *    Parses "opt_arg", a string representation of pmap value to
 *    filter on (values, separated by commas) and sets the relevant
 *    bits in the bit-vector "vector".  Returns PMAPFILTER_ERR_ARGS if
 *    the argument was not parsable.
 */
pmapFilter_err_t pmapFilterSetupVector(uint32_t *vector, char *opt_arg)
{
    char *argCopy = NULL;
    char *codeStart;
    char *codeEnd;
    uint32_t code;
    int rv = PMAPFILTER_ERR_ARGS;

    if (ignorePrefixMap) {
        return 0;
    }

    /* Make sure that the prefixmap has been loaded */
    if ( prefixMap == NULL ) {
        skAppPrintErr("%s: No --pmap-file option specified before filter.",
                      pluginName);
        goto END;
    }

    argCopy = strdup(opt_arg);
    if ( argCopy == NULL ) {
        skAppPrintErr("%s: Failed to allocate memory for arg parsing.",
                      pluginName);
        rv = PMAPFILTER_ERR_MEM;
        goto END;
    }

    codeStart = argCopy;
    do {
        codeEnd = strchr(codeStart, ',');
        if ( codeEnd != NULL ) {
            *codeEnd = '\0';
        }
        code = skPrefixMapDictionaryLookup(prefixMap, codeStart);
        if ( SKPREFIXMAP_NOT_FOUND == code ) {
            skAppPrintErr("%s: Value '%s' not found in prefixmap dictionary.",
                          pluginName, codeStart);
            goto END;
        } else {
            PMAPFILTER_VECTOR_SET_BIT(vector, code);
        }
        if ( codeEnd == NULL ) {
            codeStart = NULL;
        } else {
            codeStart = codeEnd + 1;
        }
    } while ( NULL != codeStart );

    /* Success */
    rv = PMAPFILTER_OK;

  END:
    if (argCopy) {
        free(argCopy);
    }
    return rv;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
