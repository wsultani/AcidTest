/*
** Copyright (C) 2007-2008 by Carnegie Mellon University.
**
** @OPENSOURCE_HEADER_START@
**
** Use of the SILK system and related source code is subject to the terms
** of the following licenses:
**
** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
**
** NO WARRANTY
**
** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
** DELIVERABLES UNDER THIS LICENSE.
**
** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
** Mellon University, its trustees, officers, employees, and agents from
** all claims or demands made against them (and any related losses,
** expenses, or attorney's fees) arising out of, or relating to Licensee's
** and/or its sub licensees' negligent use or willful misuse of or
** negligent conduct or willful misconduct regarding the Software,
** facilities, or other rights or assistance granted by Carnegie Mellon
** University under this License, including, but not limited to, any
** claims of product liability, personal injury, death, damage to
** property, or violation of any laws or regulations.
**
** Carnegie Mellon University Software Engineering Institute authored
** documents are sponsored by the U.S. Department of Defense under
** Contract F19628-00-C-0003. Carnegie Mellon University retains
** copyrights in all material produced under this contract. The U.S.
** Government retains a non-exclusive, royalty-free license to publish or
** reproduce these documents, or allow others to do so, for U.S.
** Government purposes only pursuant to the copyright license under the
** contract clause at 252.227.7013.
**
** @OPENSOURCE_HEADER_END@
*/

/*
**  python-plugin.c
**
**  Python plugin for rwfilter
*/

#include "silk.h"

RCSIDENT("$SiLK: python-plugin.c 11411 2008-04-30 18:41:43Z mthomas $");

#include "utils.h"
#include "dynlib.h"
#include "rwpack.h"
#include <dlfcn.h>
#include <Python.h>
#include <osdefs.h>

/* The name of the Python function rwfilter will call for each record */
#define PYFILTER_NAME "rwfilter"

/* The name of the Python function rwfilter will call before exiting */
#define FINALIZER_NAME "finalize"

/* The name of the Python function rwcut will call in order to get
   field information */
#define PYCUT_NAME "rwcut"

/* The name of the rwrec when an expression is accepted on the command
   line */
#define PYREC_NAME "rec"

/* Block size when reading python files over an skStream */
#define FILE_BLOCK_SIZE SKIOBUF_DEFAULT_BLOCKSIZE

typedef enum {
    OPT_PYTHON_FILE,
    OPT_PYTHON_EXPR
} rwp_expr_option_t;

/* exported functions--called by dynlib */
int setup(dynlibInfoStruct *dlISP, dynlibSymbolId appType);
void teardown(dynlibSymbolId appType);
int initialize(dynlibInfoStruct *dlISP, dynlibSymbolId appType);
void optionsUsage(dynlibSymbolId appType, FILE *fh);
int supportsThreads(dynlibInfoStruct *dlISP);
int filter(rwRec *rwrec);
int cut(unsigned int field, char *out, size_t len_out, rwRec *rwrec);

/* private function prototypes */
static int libOptionsSetup(dynlibInfoStruct *dlISP, dynlibSymbolId aType);
static int optionsHandler(clientData cData, int opt_index, char *opt_arg);
static int python_initialize(dynlibSymbolId appType);
static void python_uninitialize(void);

/* The python filename */
static char *python_filename = NULL;

/* The python expression */
static char *python_expr = NULL;

/* The rwfilter function */
static PyObject *python_function = NULL;

/* The finalizer function */
static PyObject *python_finalizer = NULL;

/* The cut fields info */
static PyObject *python_cut_fields = NULL;

/* The number of cut fields */
static ssize_t num_cut_fields;

/* Field entries */
static sk_stringmap_t *field_map = NULL;

/* The python globals */
static PyObject *python_globals = NULL;

/* The rwrec to raw python function */
static PyObject *rwrec_to_raw_python = NULL;

/* The rwrec to python function */
static PyObject *rwrec_to_python = NULL;

/* The record wrapper */
static PyObject *python_rec = NULL;

/* An empty tuple */
static PyObject *empty_tuple = NULL;

/* A keyword dictionary */
static PyObject *kwd_dict = NULL;


/* Plugin's name */
static const char *pluginName = "python-plugin";

/* the options and help strings.  these vary depending on the type of
 * app that is using the shared library, and they get set to one of
 * the arrays below.
 */
static struct option *libOptions = NULL;
static const char **optionsHelp = NULL;
static int libOptionsCount = -1;

/* Options and Help for filtering */
static struct option optionsFilter[] = {
    {"python-file",       REQUIRED_ARG, 0, OPT_PYTHON_FILE},
    {"python-expr",       REQUIRED_ARG, 0, OPT_PYTHON_EXPR},
    /* include your options for rwfilter here */
    {0, 0, 0, 0}
};
static const char *optionsHelpFilter[] = {
    ("Executes the function \"" PYFILTER_NAME "\" from the\n"
     "\tgiven file over all the records"),
    ("Uses the return value of given python expression\n"
     "\tas the pass/fail determiner (flow record is called \""
     PYREC_NAME "\")"),
    (char*)NULL
};

/* Options and Help for filtering */
static struct option optionsCut[] = {
    {"python-file",       REQUIRED_ARG, 0, OPT_PYTHON_FILE},
    /* include your options for rwcut here */
    {0, 0, 0, 0}
};
static const char *optionsHelpCut[] = {
    ("Uses the function \"" PYCUT_NAME "\" from the \n"
     "\tgiven file as possible field outputers"),
    (char*)NULL
};


/*
 *  setup
 *      Called by dynlib interface code to setup this plugin.  This
 *      routine should set up options handling, if required.
 *  Arguments:
 *      --pointer to the dynamic library interface structure
 *      --Application type that is using this plugin.
 *  Returns:
 *      DYNLIB_FAILED - if processing fails
 *      DYNLIB_WONTPROCESS - if application should do normal output
 *      DYNLIB_WILLPROCESS - if this plugin takes over output
 *  Side Effects:
 */
int setup(dynlibInfoStruct *dlISP, dynlibSymbolId appType)
{
    skAppContextSet(dynlibGetAppContext(dlISP));
    if (libOptionsSetup(dlISP, appType)) {
        return DYNLIB_FAILED;
    }
    return DYNLIB_WONTPROCESS;
}


/*
 *  teardown
 *      Called by dynlib interface code to tear down this plugin.
 *  Arguments:
 *      --Application type that is using this plugin
 *  Returns:
 *      None.
 *  Side Effects:
 *      None.
 */
void teardown(dynlibSymbolId UNUSED(appType))
{
    if (Py_IsInitialized()) {
        if (python_finalizer) {
            PyObject *rv = PyObject_CallObject(python_finalizer, NULL);
            if (rv == NULL) {
                PyErr_Print();
                PyErr_Clear();
            } else {
                Py_DECREF(rv);
            }
        }

        python_uninitialize();
    }
    return;
}


/*
 *  optionsUsage
 *      Called by dynlib interface code to allow this plugin to print
 *      the options it accepts.
 *  Arguments:
 *      --Application type that is using this plugin
 *  Returns:
 *      None.
 *  Side Effects:
 *      None.
 */
void optionsUsage(dynlibSymbolId UNUSED(appType), FILE *fh)
{
    register int i;

    for (i = 0; i < libOptionsCount; ++i) {
        fprintf(fh, "--%s %s. %s\n", libOptions[i].name,
                libOptions[i].has_arg ? libOptions[i].has_arg == 1
                ? "Req. Arg" : "Opt. Arg" : "No Arg", optionsHelp[i]);
    }

    return;
}


/*
 *  libOptionsSetup
 *      Sets up the options handler for this plugin
 *  Arguments:
 *      --pointer to the dynamic library interface structure
 *      --Application type that is using this plugin.
 *  Returns:
 *      0 if o.k.; nonzero otherwise.
 *  Side Effects:
 *      Options are registered.
 */
static int libOptionsSetup(dynlibInfoStruct *dlISP, dynlibSymbolId appType)
{
    int help_size = 0;

    if (-1 != libOptionsCount) {
        /* we've been here before */
        return 0;
    }

    if (DYNLIB_SHAR_FILTER == appType) {
        libOptions = optionsFilter;
        optionsHelp = optionsHelpFilter;
    } else if (DYNLIB_CUT == appType) {
        libOptions = optionsCut;
        optionsHelp = optionsHelpCut;
    } else {
        libOptionsCount = 0;
        return 0;
    }

    for (libOptionsCount=0; libOptions[libOptionsCount].name; ++libOptionsCount)
        ; /* NO BODY */
    for (help_size = 0; optionsHelp[help_size]; ++help_size)
        ; /* NO BODY */

    /* verify same number of options and help strings */
    if (help_size != libOptionsCount) {
        skAppPrintErr("%s: mismatch in option (%d) and help (%d) counts",
                      pluginName, libOptionsCount, help_size);
        return 1;
    }

    if (skOptionsRegister(libOptions, &optionsHandler, (clientData)dlISP)) {
        skAppPrintErr("Unable to register options");
        return 1;
    }

    return 0;
}


/*
 *  optionsHandler
 *      Called by options parser to handle one user option
 *  Arguments:
 *      clientData cData: the dynamic lib interface struct pointer
 *      int index: index into appOptions of the specific option
 *      char *optarg: the argument; 0 if no argument was required/given.
 * Returns:
 *      0 if OK. 1 else.
 * Side Effects:
 *      Relevant options are set.
 */
static int optionsHandler(
    clientData cData,
    int        opt_index,
    char      *opt_arg)
{
    dynlibInfoStruct_t *dlISP = (dynlibInfoStruct_t *)cData;

    switch (opt_index) {

      case OPT_PYTHON_FILE:
        if (python_filename != NULL) {
            skAppPrintErr("Cannot use --%s more than once",
                          optionsFilter[OPT_PYTHON_FILE].name);
            return 1;
        }
        if (python_expr != NULL) {
            skAppPrintErr("Cannot use --%s at the same time as --%s",
                          optionsFilter[OPT_PYTHON_FILE].name,
                          optionsFilter[OPT_PYTHON_EXPR].name);
            return 1;
        }
        python_filename = opt_arg;

        if (dynlibGetAppType(dlISP) == DYNLIB_CUT) {
            /* Initialize python to set field values */
            if (python_initialize(dynlibGetAppType(dlISP)) != 0) {
                return 1;
            }
        }

        break;

      case OPT_PYTHON_EXPR:
        if (python_expr != NULL) {
            skAppPrintErr("Cannot use --%s more than once",
                          optionsFilter[OPT_PYTHON_FILE].name);
            return 1;
        }
        if (python_filename != NULL) {
            skAppPrintErr("Cannot use --%s at the same time as --%s",
                          optionsFilter[OPT_PYTHON_FILE].name,
                          optionsFilter[OPT_PYTHON_EXPR].name);
            return 1;
        }
        python_expr = opt_arg;
        break;

      default:
        skAppPrintErr("Unrecognized option");
        return 1;
    } /* switch */

    dynlibMakeActive(dlISP);

    return 0;
}


/*
 *  threads_ok = supportsThreads(dlISP);
 *
 *    Return 1 if the plug-in can run in a threaded environment, 0 if not.
 */
int supportsThreads(
    dynlibInfoStruct UNUSED(*dlISP))
{
    /* make sure we run in an unthreaded environment */
    return 0;
}

/*
 *  python_initialize
 *      Initialize python
 */
static int python_initialize(
    dynlibSymbolId appType)
{
    PyObject              *pysilk_module = NULL;
    PyObject              *silk_module   = NULL;
    PyObject              *inspect       = NULL;
    PyObject              *function      = NULL;
    PyObject              *builtin       = NULL;
    PyObject              *none          = NULL;
    PyObject              *arginfo       = NULL;
    PyObject              *compiled      = NULL;
    PyObject              *field         = NULL;
    skstream_t            *stream        = NULL;
    char                  *contents      = NULL;
    char                  *old_path;
    char                  *new_path;
    size_t                 path_len;
    PyObject              *arglist;
    PyObject              *defaults;
    ssize_t                len_defaults;
    ssize_t                len_args;
    sk_stringmap_status_t  status;
    int                    retval        = 0;
    int                    rv;

    if (Py_IsInitialized()) {
        return 0;
    }

    if (appType != DYNLIB_SHAR_FILTER && appType != DYNLIB_CUT) {
        return -1;
    }

    assert(python_filename != NULL || python_expr != NULL);

    Py_InitializeEx(0);

    silk_module = PyImport_ImportModule("silk");
    if (silk_module == NULL) {
        skAppPrintErr("Could not load the \"silk\" python module");
        goto err;
    }

    pysilk_module = PyImport_ImportModule("silk.pysilk_nl");
    if (pysilk_module == NULL) {
        skAppPrintErr("Could not load the \"silk.pysilk_nl\" python module");
        goto err;
    }

    rwrec_to_raw_python = PyObject_GetAttrString(pysilk_module,
                                                 "_raw_rwrec_copy");
    if (rwrec_to_raw_python == NULL) {
        skAppPrintErr("Could not find the \"silk._raw_rwrec_copy\" function");
        goto err;
    }

    rwrec_to_python = PyObject_GetAttrString(silk_module, "RWRec");
    if (rwrec_to_python == NULL) {
        skAppPrintErr("Could not find the \"silk.RWRec\" function");
        goto err;
    }

    builtin = PyImport_ImportModule("__builtin__");
    if (builtin == NULL) {
        skAppPrintErr("Could not load the \"__builtin__\" module");
        goto err;
    }

    python_globals = PyDict_New();
    if (python_globals == NULL) {
        goto err;
    }

    kwd_dict = PyDict_New();
    if (kwd_dict == NULL) {
        goto err;
    }

    empty_tuple = PyTuple_New(0);
    if (empty_tuple == NULL) {
        goto err;
    }

    /* Ensure cwd is in the python path */
    old_path = Py_GetPath();
    path_len = strlen(old_path) + 3;
    new_path = malloc(path_len);
    if (new_path == NULL) {
        goto err;
    }
    new_path[0] = '.';
    new_path[1] = DELIM;
    strcpy(&new_path[2], old_path);
    PySys_SetPath(new_path);
    free(new_path);

    if (python_filename) {
        size_t      size;
        size_t      remainder;
        char       *loc;
        ssize_t     num_read;

        rv = dynlibOpenDataInputStream(&stream, SK_CONTENT_TEXT,
                                       python_filename);
        if (rv != 0) {
            skAppPrintErr("Could not access %s", python_filename);
            goto err;
        }

        contents = malloc(FILE_BLOCK_SIZE);
        if (contents == NULL) {
            skAppPrintErr("Memory error");
            goto err;
        }

        loc = contents;
        size = FILE_BLOCK_SIZE;
        remainder = size;
        while ((num_read = skStreamRead(stream, loc, remainder)) > 0) {
            remainder -= num_read;
            loc += num_read;
            if (remainder == 0) {
                char *realloced;

                size += FILE_BLOCK_SIZE;
                realloced = realloc(contents, size);
                if (realloced == NULL) {
                    skAppPrintErr("Memory error");
                    goto err;
                }
                remainder = FILE_BLOCK_SIZE;
                contents = realloced;
                loc = contents + (size - FILE_BLOCK_SIZE);
            }
        }
        if (num_read != 0) {
            skAppPrintErr("Read error: %s",
                          strerror(skStreamGetLastErrno(stream)));
            goto err;
        }

        skStreamDestroy(&stream);

        compiled = PyObject_CallMethod(builtin, "compile", "s#ss",
                                       contents, loc - contents,
                                       python_filename, "exec");
        if (compiled == NULL) {
            skAppPrintErr("Could not compile %s", python_filename);
            goto err;
        }

        free(contents);
        contents = NULL;

        none = PyObject_CallMethod(builtin, "eval", "OO", compiled,
                                   python_globals);
        if (none == NULL || PyErr_Occurred()) {
            skAppPrintErr("Could not parse %s", python_filename);
            goto err;
        }
    } else {
        static char *prefix = ("def " PYFILTER_NAME "(" PYREC_NAME "): "
                               "return ");
        size_t  len         = strlen(prefix) + strlen(python_expr);
        char   *command     = malloc(len + 1);

        if (command == NULL) {
            skAppPrintErr("Memory error allocating string");
            goto err;
        }

        strcpy(command, prefix);
        strcat(command, python_expr);

        compiled = PyObject_CallMethod(builtin, "compile", "sss",
                                       command, "<command-line>", "exec");
        if (compiled == NULL) {
            skAppPrintErr("Could not compile python expression");
            goto err;
        }

        rv = PyDict_SetItemString(python_globals, "silk", silk_module);
        if (rv != 0) {
            skAppPrintErr("Python dictionary error");
            goto err;
        }

        none = PyObject_CallMethod(builtin, "eval", "OO", compiled,
                                   python_globals);
        if (none == NULL || PyErr_Occurred()) {
            skAppPrintErr("Could not parse python expression");
            goto err;
        }
    }

    inspect =  PyImport_ImportModule("inspect");
    if (inspect == NULL) {
        skAppPrintErr("Could not load the \"inspect\" python module");
        goto err;
    }

    if (DYNLIB_SHAR_FILTER == appType) {
        function = PyDict_GetItemString(python_globals, PYFILTER_NAME);
        if (function == NULL || !PyFunction_Check(function)) {
            skAppPrintErr(("The python function '" PYFILTER_NAME
                           "' was not defined"));
            goto err;
        }

        arginfo = PyObject_CallMethod(inspect, "getargspec", "O", function);
        arglist = PyTuple_GetItem(arginfo, 0);
        defaults = PyTuple_GetItem(arginfo, 3);

        len_defaults = (defaults == Py_None) ? 0 : PyTuple_Size(defaults);
        len_args = PyList_Size(arglist);
        if (len_args < 1 || len_args - len_defaults > 1) {
            skAppPrintErr(("The python function '" PYFILTER_NAME
                           "' must take a single argument, an RWRec"));
            goto err;
        }

        python_function = function;

        function = PyDict_GetItemString(python_globals, FINALIZER_NAME);
        if (function != NULL && PyFunction_Check(function)) {

            Py_XDECREF(arginfo);
            arginfo = PyObject_CallMethod(inspect, "getargspec", "O",
                                          function);
            arglist = PyTuple_GetItem(arginfo, 0);
            defaults = PyTuple_GetItem(arginfo, 3);

            len_defaults = (defaults == Py_None) ? 0 : PyTuple_Size(defaults);
            len_args = PyList_Size(arglist);
            if (len_args - len_defaults > 0) {
                skAppPrintErr(("The '" FINALIZER_NAME
                               "' function must take zero arguments"));
                goto err;
            }

            python_finalizer = function;
        }
    } else if (DYNLIB_CUT == appType) {
        ssize_t i;

        function = PyDict_GetItemString(python_globals, PYCUT_NAME);
        if (function == NULL || !PyFunction_Check(function)) {
            skAppPrintErr(("The python function '" PYCUT_NAME
                           "' was not defined"));
            goto err;
        }

        arginfo = PyObject_CallMethod(inspect, "getargspec", "O", function);
        arglist = PyTuple_GetItem(arginfo, 0);
        defaults = PyTuple_GetItem(arginfo, 3);

        len_defaults = (defaults == Py_None) ? 0 : PyTuple_Size(defaults);
        len_args = PyList_Size(arglist);
        if (len_args - len_defaults > 0) {
            skAppPrintErr(("The python function '" PYCUT_NAME
                           "' should take zero arguments"));
            goto err;
        }

        python_cut_fields = PyObject_CallFunctionObjArgs(
            function, NULL);
        if (python_cut_fields == NULL) {
            goto err;
        }
        if (!PySequence_Check(python_cut_fields)) {
            skAppPrintErr(("The python function '" PYCUT_NAME
                           "' did not return a sequence of "
                           "(title, fieldlen, function) triples"));
            goto err;
        }
        num_cut_fields = PySequence_Size(python_cut_fields);
        if (num_cut_fields == -1) {
            goto err;
        }

        assert(field_map == NULL);
        status = skStringMapCreate(&field_map);
        if (status != SKSTRINGMAP_OK) {
            skAppPrintErr("Error creating string map");
            goto err;
        }

        for (i = 0; i < num_cut_fields; i++) {
            PyObject *title;
            PyObject *size;
            PyObject *func;

            field = PySequence_GetItem(python_cut_fields, i);
            if (field == NULL) {
                goto err;
            }
            if (!PyTuple_Check(field) || PyTuple_Size(field) != 3) {
                skAppPrintErr(("The python function '" PYCUT_NAME
                               "' should return a sequence of "
                               "(title, fieldlen, function) tuples"));
                goto err;
            }
            title = PyTuple_GET_ITEM(field, 0);
            size = PyTuple_GET_ITEM(field, 1);
            func = PyTuple_GET_ITEM(field, 2);
            if (!PyString_Check(title) || !PyInt_Check(size) ||
                PyInt_AS_LONG(size) < 0 || !PyCallable_Check(function))
            {
                skAppPrintErr(("The python function '" PYCUT_NAME
                               "' should return a sequence of "
                               "(title, fieldlen, function) tuples"));
                goto err;
            }

            Py_XDECREF(arginfo);
            arginfo = PyObject_CallMethod(inspect, "getargspec",
                                          "O", func);
            arglist = PyTuple_GetItem(arginfo, 0);
            defaults = PyTuple_GetItem(arginfo, 3);

            len_defaults = (defaults == Py_None) ? 0 : PyTuple_Size(defaults);
            len_args = PyList_Size(arglist);
            if (len_args < 1 || len_args - len_defaults > 1) {
                skAppPrintErr(("The function part of the %s field should "
                               "take one argument, a silk.RWRec object"),
                              PyString_AS_STRING(title));
                goto err;
            }

            status = skStringMapAddID(field_map, PyString_AS_STRING(title),
                                      i + 1);
            if (status != SKSTRINGMAP_OK) {
                skAppPrintErr("Could not add '%s' as a field",
                              PyString_AS_STRING(title));
                goto err;
            }

            Py_CLEAR(field);
        }
    }

    python_rec = PyCObject_FromVoidPtr(NULL, NULL);
    if (python_rec == NULL) {
        goto err;
    }

  cleanup:
    if (contents) {
        free(contents);
    }
    skStreamDestroy(&stream);
    Py_XDECREF(pysilk_module);
    Py_XDECREF(silk_module);
    Py_XDECREF(compiled);
    Py_XDECREF(inspect);
    Py_XDECREF(builtin);
    Py_XDECREF(none);
    Py_XDECREF(arginfo);
    Py_XDECREF(field);

    return retval;

  err:
    if (PyErr_Occurred()) {
        PyErr_Print();
        PyErr_Clear();
    }
    retval = -1;
    goto cleanup;
}


/*
 *  python_unintiialize
 *      Un-Initialize python
 */
static void python_uninitialize(void)
{
    if (Py_IsInitialized()) {
        Py_CLEAR(python_globals); /* Includes python_function and
                                       python_finalizer */
        Py_CLEAR(python_rec);
        Py_CLEAR(empty_tuple);
        Py_CLEAR(kwd_dict);
        Py_CLEAR(python_cut_fields);

        Py_Finalize();
    }

    if (field_map != NULL) {
        skStringMapDestroy(field_map);
        field_map = NULL;
    }
}


/*
 *  initialize
 *      This subroutine handles the loading of the expressions for rwfilter
 */
int initialize(
    dynlibInfoStruct *UNUSED(dlISP),
    dynlibSymbolId    appType)
{
    if (appType != DYNLIB_CUT) {
        return python_initialize(appType);
    }

    return 0;
}


/*
 *  filter
 *      This subroutine works in tadem with the standard filtering rules
 *      of rwfilter (and other shared filter plugins) to determine
 *      whether the rwRec should pass the filter.  This subroutine may
 *      not see all rwRec records since they may be filtered by one of
 *      the standard rules.  The subroutine should return 0 if the rwRec
 *      passes the filter; 1 otherwise.
 *
 *      The dynlib plug-in code will call this filter() routine ONCE per
 *      rw-record.  If the user has specified multiple filter-rules
 *      switches which a single plug-in handles, the plugin must process
 *      all the switches before returning.
 *  Arguments:
 *      a RW record
 *  Returns:
 *      0 to accept the record, 1 to reject the record
 *  Side Effects:
 *      None
 */
int filter(rwRec *rwrec)
{
    int rv;
    PyObject *retval;
    PyObject *rawrec;
    PyObject *rec;

    rv = PyCObject_SetVoidPtr(python_rec, rwrec);
    if (rv == 0) {
        PyErr_Print();
        PyErr_Clear();
        exit(EXIT_FAILURE);
    }

    rawrec = PyObject_CallFunctionObjArgs(rwrec_to_raw_python,
                                          python_rec, NULL);
    if (rawrec == NULL) {
        PyErr_Print();
        PyErr_Clear();
        exit(EXIT_FAILURE);
    }

    rv = PyDict_SetItemString(kwd_dict, "_clone", rawrec);
    if (rv != 0) {
        PyErr_Print();
        PyErr_Clear();
        exit(EXIT_FAILURE);
    }

    rec = PyObject_Call(rwrec_to_python, empty_tuple, kwd_dict);
    if (rec == NULL) {
        PyErr_Print();
        PyErr_Clear();
        exit(EXIT_FAILURE);
    }

    retval = PyObject_CallFunctionObjArgs(python_function, rec, NULL);
    if (retval == NULL) {
        PyErr_Print();
        PyErr_Clear();
        exit(EXIT_FAILURE);
    }

    rv = PyObject_IsTrue(retval);
    Py_DECREF(retval);
    Py_DECREF(rec);

    return (rv == 1) ? 0 : 1;
}

/*
 *  cut
 *      Called by dynlib interface code to output records
 *  Arguments:
 *      which field to output (indexed from 1)
 *      a string buffer to hold the output
 *      the length of the buffer
 *      a RW record
 *  Returns:
 *      if field is zero, the number of supported fields
 *      if out is NULL and rwrec is NULL, the size of buffer needed
 *         for a title for this field
 *      if out is NULL and rwrec is non-NULL, the size of buffer
 *         needed for the value to be output for this field
 *      if out is non-NULL and rwrec is NULL, outputs the title,
 *         returns length of buffer necessary to hold full string
 *      if out is non-NULL and rwrec is non-NULL, outputs the value,
 *         returns length of buffer necessary to hold full string
 *  Side Effects:
 *      None
 */
int cut(unsigned int field, char *out, size_t len_out, rwRec *rwrec)
{
    int       rv;
    PyObject *obj;
    int       len;
    PyObject *retval;
    PyObject *rawrec;
    PyObject *rec;
    PyObject *str;

    if ( field == 0 ) {
        /* Request for number of supported fields */
        return num_cut_fields;
    }

    if (field > (unsigned int)num_cut_fields) {
        return -1;              /* Error: We don't support that field */
    }

    obj = PySequence_GetItem(python_cut_fields, field - 1);
    assert(obj != NULL);

    if ((out == NULL) && (rwrec == NULL)) {
        /* Request for buffer size for field title */
        len = PyString_GET_SIZE(PyTuple_GET_ITEM(obj, 0)) + 1;
        Py_DECREF(obj);
        return len;
    }

    if ((out != NULL) && rwrec == NULL) {
        /* Request for field title */
        len = snprintf(out, len_out,
                       "%s", PyString_AS_STRING(PyTuple_GET_ITEM(obj, 0)));
        Py_DECREF(obj);
        return len;
    }

    if ((out == NULL) && (rwrec != NULL)) {
        /* Request for buffer size for field value */
        len = PyInt_AS_LONG(PyTuple_GET_ITEM(obj, 1)) + 1;
        Py_DECREF(obj);
        return len;
    }

    /* Request for field value */
    assert((out != NULL) && (rwrec != NULL));

    rv = PyCObject_SetVoidPtr(python_rec, rwrec);
    if (rv == 0) {
        PyErr_Print();
        PyErr_Clear();
        exit(EXIT_FAILURE);
    }

    rawrec = PyObject_CallFunctionObjArgs(rwrec_to_raw_python,
                                          python_rec, NULL);
    if (rawrec == NULL) {
        PyErr_Print();
        PyErr_Clear();
        exit(EXIT_FAILURE);
    }

    rv = PyDict_SetItemString(kwd_dict, "_clone", rawrec);
    if (rv != 0) {
        PyErr_Print();
        PyErr_Clear();
        exit(EXIT_FAILURE);
    }

    rec = PyObject_Call(rwrec_to_python, empty_tuple, kwd_dict);
    if (rec == NULL) {
        PyErr_Print();
        PyErr_Clear();
        exit(EXIT_FAILURE);
    }

    retval = PyObject_CallFunctionObjArgs(PyTuple_GET_ITEM(obj, 2), rec, NULL);
    if (retval == NULL) {
        PyErr_Print();
        PyErr_Clear();
        exit(EXIT_FAILURE);
    }
    Py_DECREF(obj);

    str = PyObject_Str(retval);
    if (str == NULL) {
        PyErr_Print();
        PyErr_Clear();
        exit(EXIT_FAILURE);
    }

    len = snprintf(out, len_out, "%s", PyString_AS_STRING(str));

    Py_DECREF(str);
    Py_DECREF(retval);
    Py_DECREF(rec);

    return len;
}


/*
** Local Variables:
** mode:c
** indent-tabs-mode:nil
** c-basic-offset:4
** End:
*/
