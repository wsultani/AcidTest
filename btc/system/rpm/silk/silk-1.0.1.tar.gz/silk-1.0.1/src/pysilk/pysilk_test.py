#!/usr/bin/python
#######################################################################
# Copyright (C) 2008 by Carnegie Mellon University.
#
# @OPENSOURCE_HEADER_START@
#
# Use of the SILK system and related source code is subject to the terms
# of the following licenses:
#
# GNU Public License (GPL) Rights pursuant to Version 2, June 1991
# Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
#
# NO WARRANTY
#
# ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
# PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
# PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
# "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
# KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
# LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
# MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
# OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
# SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
# TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
# WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
# LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
# CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
# CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
# DELIVERABLES UNDER THIS LICENSE.
#
# Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
# Mellon University, its trustees, officers, employees, and agents from
# all claims or demands made against them (and any related losses,
# expenses, or attorney's fees) arising out of, or relating to Licensee's
# and/or its sub licensees' negligent use or willful misuse of or
# negligent conduct or willful misconduct regarding the Software,
# facilities, or other rights or assistance granted by Carnegie Mellon
# University under this License, including, but not limited to, any
# claims of product liability, personal injury, death, damage to
# property, or violation of any laws or regulations.
#
# Carnegie Mellon University Software Engineering Institute authored
# documents are sponsored by the U.S. Department of Defense under
# Contract F19628-00-C-0003. Carnegie Mellon University retains
# copyrights in all material produced under this contract. The U.S.
# Government retains a non-exclusive, royalty-free license to publish or
# reproduce these documents, or allow others to do so, for U.S.
# Government purposes only pursuant to the copyright license under the
# contract clause at 252.227.7013.
#
# @OPENSOURCE_HEADER_END@
#
#######################################################################

#######################################################################
# $SiLK: pysilk_test.py 10558 2008-02-20 17:04:11Z mwd $
#######################################################################

import unittest
import datetime
import tempfile
import warnings
import os
from silk import *

class TestIPAddr(unittest.TestCase):
    
    def testConstruction(self): 
        IPAddr("0.0.0.0")
        IPAddr("255.255.255.255")
        IPAddr("10.0.0.0")
        IPAddr("10.10.10.10")
        IPAddr("10.11.12.13")
        IPAddr(" 10.0.0.0")
        IPAddr("10.0.0.0 ")
        IPAddr("  10.0.0.0  ")
        IPAddr("010.000.000.000")
        IPAddr("4294967295")
        IPAddr("167772160")
        IPAddr("168430090")
        IPAddr("168496141")
        IPAddr("167772160")
        if ipv6_enabled():
            IPAddr("0:0:0:0:0:0:0:0")
            IPAddr("ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff")
            IPAddr("10:0:0:0:0:0:0:0")
            IPAddr("10:10:10:10:10:10:10:10")
            IPAddr("1010:1010:1010:1010:1010:1010:1010:1010")
            IPAddr("1011:1213:1415:1617:2021:2223:2425:2627")
            IPAddr("f0ff:f2f3:f4f5:f6f7:202f:2223:2425:2627")
            IPAddr("f0ff:faf3:f4f5:f6f7:a0af:aaa3:a4a5:a6a7")
            IPAddr("     f0ff:faf3:f4f5:f6f7:a0af:aaa3:a4a5:a6a7")
            IPAddr("f0ff:faf3:f4f5:f6f7:a0af:aaa3:a4a5:a6a7     ")
            IPAddr("   f0ff:faf3:f4f5:f6f7:a0af:aaa3:a4a5:a6a7  ")
            IPAddr("::")
            IPAddr("0::0")
            IPAddr("0:0::0")
            IPAddr("0:0:0::0")
            IPAddr("0:0:0:0::0")
            IPAddr("0:0:0:0:0::0")
            IPAddr("0:0:0:0:0:0::0")
            IPAddr("0:0:0:0:0::0:0")
            IPAddr("0:0:0:0::0:0:0")
            IPAddr("0:0:0::0:0:0:0")
            IPAddr("0:0::0:0:0:0:0")
            IPAddr("0::0:0:0:0:0:0")
            IPAddr("0::0:0:0:0:0")
            IPAddr("0::0:0:0:0")
            IPAddr("0::0:0:0")
            IPAddr("0::0:0")
            IPAddr("::0")
            IPAddr("::0:0")
            IPAddr("::0:0:0")
            IPAddr("::0:0:0:0")
            IPAddr("::0:0:0:0:0")
            IPAddr("::0:0:0:0:0:0")
            IPAddr("0:0:0:0:0:0:0::")
            IPAddr("0:0:0:0:0:0::0")
            IPAddr("0:0:0:0:0::")
            IPAddr("0:0:0:0::")
            IPAddr("0:0:0::")
            IPAddr("0:0::")
            IPAddr("0::")
            IPAddr("0:0:0:0:0:0:0.0.0.0")
            IPAddr("0:0:0:0:0::0.0.0.0")
            IPAddr("0:0:0:0::0.0.0.0")
            IPAddr("0:0:0::0.0.0.0")
            IPAddr("0:0::0.0.0.0")
            IPAddr("0::0.0.0.0")
            IPAddr("::0.0.0.0")
            IPAddr("::0:0.0.0.0")
            IPAddr("::0:0:0.0.0.0")
            IPAddr("::0:0:0:0.0.0.0")
            IPAddr("::0:0:0:0:0.0.0.0")
            IPAddr("::0:0:0:0:0:0.0.0.0")
            IPAddr("0::0:0:0:0:0.0.0.0")
            IPAddr("0:0::0:0:0:0.0.0.0")
            IPAddr("0:0:0::0:0:0.0.0.0")
            IPAddr("0:0:0:0::0:0.0.0.0")
            IPAddr("0:0:0:0:0::0.0.0.0")


    def testString(self):
        self.assertEqual(str(IPAddr("0.0.0.0")), "0.0.0.0")
        self.assertEqual(str(IPAddr("255.255.255.255")), "255.255.255.255")
        self.assertEqual(str(IPAddr("10.0.0.0")), "10.0.0.0")
        self.assertEqual(str(IPAddr("10.10.10.10")), "10.10.10.10")
        self.assertEqual(str(IPAddr("10.11.12.13")), "10.11.12.13")

    def testInt(self):
        self.assertEqual(int(IPAddr("0.0.0.0")), 0)
        self.assertEqual(int(IPAddr("255.255.255.255")), 4294967295)
        self.assertEqual(int(IPAddr("10.0.0.0")), 167772160)
        self.assertEqual(int(IPAddr("10.10.10.10")), 168430090)
        self.assertEqual(int(IPAddr("10.11.12.13")), 168496141)
        self.assertEqual(int(IPAddr(" 10.0.0.0")), 167772160)
        self.assertEqual(int(IPAddr("10.0.0.0 ")), 167772160)
        self.assertEqual(int(IPAddr("  10.0.0.0  ")), 167772160)
        self.assertEqual(int(IPAddr("010.000.000.000")), 167772160)
        self.assertEqual(int(IPAddr("4294967295")), 4294967295)
        self.assertEqual(int(IPAddr("167772160")), 167772160)
        self.assertEqual(int(IPAddr("168430090")), 168430090)
        self.assertEqual(int(IPAddr("168496141")), 168496141)
        self.assertEqual(int(IPAddr("167772160")), 167772160)
        if ipv6_enabled():
            self.assertEqual(int(IPAddr("0:0:0:0:0:0:0:0")), 0)
            self.assertEqual(int(IPAddr(
                        "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff")),
                             0xffffffffffffffffffffffffffffffff)
            self.assertEqual(int(IPAddr("10:0:0:0:0:0:0:0")),
                             0x00100000000000000000000000000000)
            self.assertEqual(int(IPAddr("10:10:10:10:10:10:10:10")),
                             0x00100010001000100010001000100010)
            self.assertEqual(int(IPAddr(
                        "1010:1010:1010:1010:1010:1010:1010:1010")),
                             0x10101010101010101010101010101010)
            self.assertEqual(int(IPAddr(
                        "1011:1213:1415:1617:2021:2223:2425:2627")),
                             0x10111213141516172021222324252627)
            self.assertEqual(int(IPAddr(
                        "f0ff:f2f3:f4f5:f6f7:202f:2223:2425:2627")),
                             0xf0fff2f3f4f5f6f7202f222324252627)
            self.assertEqual(int(IPAddr(
                        "f0ff:faf3:f4f5:f6f7:a0af:aaa3:a4a5:a6a7")),
                             0xf0fffaf3f4f5f6f7a0afaaa3a4a5a6a7)
            self.assertEqual(int(IPAddr("::")), 0)
            self.assertEqual(int(IPAddr("0::0")), 0)
            self.assertEqual(int(IPAddr("0:0::0")), 0)
            self.assertEqual(int(IPAddr("0:0:0::0")), 0)
            self.assertEqual(int(IPAddr("0:0:0:0::0")), 0)
            self.assertEqual(int(IPAddr("0:0:0:0:0::0")), 0)
            self.assertEqual(int(IPAddr("0:0:0:0:0:0::0")), 0)
            self.assertEqual(int(IPAddr("0:0:0:0:0::0:0")), 0)
            self.assertEqual(int(IPAddr("0:0:0:0::0:0:0")), 0)
            self.assertEqual(int(IPAddr("0:0:0::0:0:0:0")), 0)
            self.assertEqual(int(IPAddr("0:0::0:0:0:0:0")), 0)
            self.assertEqual(int(IPAddr("0::0:0:0:0:0:0")), 0)
            self.assertEqual(int(IPAddr("0::0:0:0:0:0")), 0)
            self.assertEqual(int(IPAddr("0::0:0:0:0")), 0)
            self.assertEqual(int(IPAddr("0::0:0:0")), 0)
            self.assertEqual(int(IPAddr("0::0:0")), 0)
            self.assertEqual(int(IPAddr("::0")), 0)
            self.assertEqual(int(IPAddr("::0:0")), 0)
            self.assertEqual(int(IPAddr("::0:0:0")), 0)
            self.assertEqual(int(IPAddr("::0:0:0:0")), 0)
            self.assertEqual(int(IPAddr("::0:0:0:0:0")), 0)
            self.assertEqual(int(IPAddr("::0:0:0:0:0:0")), 0)
            self.assertEqual(int(IPAddr("0:0:0:0:0:0:0::")), 0)
            self.assertEqual(int(IPAddr("0:0:0:0:0:0::0")), 0)
            self.assertEqual(int(IPAddr("0:0:0:0:0::")), 0)
            self.assertEqual(int(IPAddr("0:0:0:0::")), 0)
            self.assertEqual(int(IPAddr("0:0:0::")), 0)
            self.assertEqual(int(IPAddr("0:0::")), 0)
            self.assertEqual(int(IPAddr("0::")), 0)
            self.assertEqual(int(IPAddr("0:0:0:0:0:0:0.0.0.0")), 0)
            self.assertEqual(int(IPAddr("0:0:0:0:0::0.0.0.0")), 0)
            self.assertEqual(int(IPAddr("0:0:0:0::0.0.0.0")), 0)
            self.assertEqual(int(IPAddr("0:0:0::0.0.0.0")), 0)
            self.assertEqual(int(IPAddr("0:0::0.0.0.0")), 0)
            self.assertEqual(int(IPAddr("0::0.0.0.0")), 0)
            self.assertEqual(int(IPAddr("::0.0.0.0")), 0)
            self.assertEqual(int(IPAddr("::0:0.0.0.0")), 0)
            self.assertEqual(int(IPAddr("::0:0:0.0.0.0")), 0)
            self.assertEqual(int(IPAddr("::0:0:0:0.0.0.0")), 0)
            self.assertEqual(int(IPAddr("::0:0:0:0:0.0.0.0")), 0)
            self.assertEqual(int(IPAddr("::0:0:0:0:0:0.0.0.0")), 0)
            self.assertEqual(int(IPAddr("0::0:0:0:0:0.0.0.0")), 0)
            self.assertEqual(int(IPAddr("0:0::0:0:0:0.0.0.0")), 0)
            self.assertEqual(int(IPAddr("0:0:0::0:0:0.0.0.0")), 0)
            self.assertEqual(int(IPAddr("0:0:0:0::0:0.0.0.0")), 0)
            self.assertEqual(int(IPAddr("0:0:0:0:0::0.0.0.0")), 0)
            self.assertEqual(int(IPAddr(
                        "ffff:ffff:ffff:ffff:ffff:ffff:255.255.255.255")),
                             0xffffffffffffffffffffffffffffffff)
            self.assertEqual(int(IPAddr(
                        "1010:1010:1010:1010:1010:1010:16.16.16.16")),
                             0x10101010101010101010101010101010)
            self.assertEqual(int(IPAddr(
                        "1011:1213:1415:1617:2021:2223:36.37.38.39")),
                             0x10111213141516172021222324252627)
            
    def testFromInt(self):
        self.assertEqual(int(IPAddr(0)), 0)
        self.assertEqual(int(IPAddr(4294967295)), 4294967295)
        self.assertEqual(int(IPAddr(167772160)), 167772160)
        self.assertEqual(int(IPAddr(168430090)), 168430090)
        self.assertEqual(int(IPAddr(168496141)), 168496141)
        self.assertEqual(int(IPAddr(167772160)), 167772160)
        if ipv6_enabled():
            self.assertEqual(int(IPAddr(0xffffffffffffffffffffffffffffffff)),
                             0xffffffffffffffffffffffffffffffff)
            self.assertEqual(int(IPAddr(0x10101010101010101010101010101010)),
                             0x10101010101010101010101010101010)
            self.assertEqual(int(IPAddr(0x10111213141516172021222324252627)),
                             0x10111213141516172021222324252627)

    def testBadStrings(self):
        self.assertRaises(ValueError, IPAddr, "010.000.000.000x")
        self.assertRaises(ValueError, IPAddr, "010.000.000.000a")
        self.assertRaises(ValueError, IPAddr, "010.000.000.000|")
        self.assertRaises(ValueError, IPAddr, "       10.0.0.0:80")
        self.assertRaises(ValueError, IPAddr, "10.0.0.0       .")
        self.assertRaises(ValueError, IPAddr, "      167772160|")
        self.assertRaises(ValueError, IPAddr, "    10.10.10.10.10  ")
        self.assertRaises(ValueError, IPAddr, "")
        self.assertRaises(ValueError, IPAddr, "  ")
        self.assertRaises(ValueError, IPAddr, "     -167772160")
        self.assertRaises(ValueError, IPAddr, "     -167772160|")
        self.assertRaises(ValueError, IPAddr, "      167772160.")
        self.assertRaises(ValueError, IPAddr, " 256.256.256.256")
        self.assertRaises(ValueError, IPAddr, "  10.")
        self.assertRaises(ValueError, IPAddr, "  10.x.x.x  ")
        self.assertRaises(ValueError, IPAddr, "  .10.10.10.10  ")
        self.assertRaises(ValueError, IPAddr, "  10..10.10.10  ")
        self.assertRaises(ValueError, IPAddr, "  10.10..10.10  ")
        self.assertRaises(ValueError, IPAddr, "  10.10.10..10  ")
        self.assertRaises(ValueError, IPAddr, "  10.10.10.10.  ")
        self.assertRaises(ValueError, IPAddr, "  10.10:10.10   ")
        self.assertRaises(ValueError, IPAddr, 
                          "10.0.0.98752938745983475983475039248759")
        self.assertRaises(ValueError, IPAddr, "10.0|0.0")
        self.assertRaises(ValueError, IPAddr, " 10.  0.  0.  0")
        self.assertRaises(ValueError, IPAddr, "10 .   0.  0.  0")
        self.assertRaises(ValueError, IPAddr, " -10:0:0:0:0:0:0:0")
        self.assertRaises(ValueError, IPAddr, " 10000:0:0:0:0:0:0:0")
        self.assertRaises(ValueError, IPAddr, " 0:0:0:0:0:0:0:10000")
        self.assertRaises(ValueError, IPAddr, "  10:")
        self.assertRaises(ValueError, IPAddr, "0:0:0:0:0:0:0")
        self.assertRaises(ValueError, IPAddr, "  10:10.10:10::")
        self.assertRaises(ValueError, IPAddr, "  :10:10:10:10::")
        self.assertRaises(ValueError, IPAddr, "  ::10:10:10:10:STUFF")
        self.assertRaises(ValueError, IPAddr, "  ::10:10:10:10:")
        self.assertRaises(ValueError, IPAddr, "  10:10:10:::10")
        self.assertRaises(ValueError, IPAddr, "  10::10:10::10")
        self.assertRaises(ValueError, IPAddr, "  10:10::10::10")
        self.assertRaises(ValueError, IPAddr, "  10::10::10:10")
        self.assertRaises(ValueError, IPAddr, "  10:x:x:x:x:x:x:x  ")
        self.assertRaises(ValueError, IPAddr, 
                          "f0ff:faf3:f4f5:f6f7:a0af:aaa3:a4a5:a6a7:ffff")
        self.assertRaises(ValueError, IPAddr, 
                          ("11:12:13:14:15:16:17:"
                           "98752938745983475983475039248759"))
        self.assertRaises(ValueError, IPAddr, "10:0|0:0:0:0:0:0")
        self.assertRaises(ValueError, IPAddr, 
                          " 10:  0:  0:  0: 10: 10: 10: 10")
        self.assertRaises(ValueError, IPAddr, "10 :10:10:10:10:10:10:10")
        self.assertRaises(ValueError, IPAddr, ":10:10:10:10:10:10:10:10")
        self.assertRaises(ValueError, IPAddr, "0:0:0:0:0:0:0:0:0.0.0.0")
        self.assertRaises(ValueError, IPAddr, "0:0:0:0:0:0:0:0.0.0.0")
        self.assertRaises(ValueError, IPAddr, "::0.0.0.0:0")
        self.assertRaises(ValueError, IPAddr, "0::0.0.0.0:0")
        self.assertRaises(ValueError, IPAddr, "0::0.0.0.0.0")

    def testBadTypes(self):
        self.assertRaises(TypeError, IPAddr, 2.4)
        self.assertRaises(TypeError, IPAddr, IPAddr(0))

    def testOrdering(self):
        self.assert_(IPAddr(0) < IPAddr(256))
        self.assert_(IPAddr(256) > IPAddr(0))
        self.assert_(IPAddr(256) != IPAddr(0))
        self.assert_(IPAddr(0xffffffff) == IPAddr(0xffffffff))
        if ipv6_enabled():
            self.assert_(IPAddr(0xffffffff) < IPAddr("ffff::"))
            self.assert_(IPAddr(0xffffffff) != IPAddr("::255.255.255.255"))
            self.assert_(IPAddr("255.255.255.255") > 
                         IPAddr("::255.255.255.255"))
            self.assert_(IPAddr("0.0.0.0") == IPAddr("::ffff:0.0.0.0"))
            self.assert_(IPAddr("0.0.0.0") < IPAddr("::ffff:0.0.0.1"))

    def testIPv6(self):
        self.assert_(IPAddr("::").ipv6())
        self.assert_(IPAddr("::ffff:0.0.0.1").ipv6())
        self.assert_(not IPAddr("0.0.0.0").ipv6())
        self.assert_(not IPAddr("0.0.0.1").ipv6())


class TestIPWildcard(unittest.TestCase):
    def testConstruction(self):
        IPWildcard("0.0.0.0")
        IPWildcard("255.255.255.255")
        IPWildcard("     255.255.255.255")
        IPWildcard("255.255.255.255     ")
        IPWildcard("   255.255.255.255  ")
        IPWildcard("0.0.0.0/31")
        IPWildcard("255.255.255.254-255")
        IPWildcard("3,2,1.4.5.6")
        IPWildcard("0.0.0.1,31,51,71,91,101,121,141,161,181,211,231,251")
        IPWildcard("0,255.0,255.0,255.0,255")
        IPWildcard("1.1.128.0/22")
        IPWildcard("128.x.0.0")
        IPWildcard("128.0-255.0.0")
        IPWildcard("128.0,128-255,1-127.0.0")
        IPWildcard("128.0,128,129-253,255-255,254,1-127.0.0")
        IPWildcard("128.0,128-255,1-127.0.0  ")
        IPWildcard("  128.0,128-255,1-127.0.0  ")
        IPWildcard("  128.0,128-255,,1-127.0.0  ")
        if ipv6_enabled():
            IPWildcard("0:0:0:0:0:0:0:0")
            IPWildcard("::")
            IPWildcard("::0.0.0.0")
            IPWildcard("1:2:3:4:5:6:7:8")
            IPWildcard("1:203:405:607:809:a0b:c0d:e0f")
            IPWildcard("1:203:405:607:809:a0b:12.13.14.15")
            IPWildcard("::FFFF")
            IPWildcard("::FFFF:FFFF")
            IPWildcard("::0.0.255.255")
            IPWildcard("::255.255.255.255")
            IPWildcard("FFFF::")
            IPWildcard("0,FFFF::0,FFFF")
            IPWildcard("::FFFF:0,10.0.0.0,10")
            IPWildcard("::FFFF:0.0,160.0,160.0")
            IPWildcard("0:0:0:0:0:0:0:0/127")
            IPWildcard("::/127")
            IPWildcard("0:0:0:0:0:0:0:0/110")
            IPWildcard("0:0:0:0:0:0:0:0/95")
            IPWildcard("0:ffff::0/127")
            IPWildcard("0:ffff::0.0.0.0,1")
            IPWildcard("0:ffff::0.0.0.0-10")
            IPWildcard("0:ffff::0.0.0.x")
            IPWildcard("::ffff:0:0:0:0:0:0/110")
            IPWildcard("0:ffff::/112")
            IPWildcard("0:ffff:0:0:0:0:0:x")
            IPWildcard("0:ffff:0:0:0:0:0:x")
            IPWildcard("0:ffff:0:0:0:0:0:0-ffff")
            IPWildcard("0:ffff:0:0:0:0:0.0.x.x")
            IPWildcard("0:ffff:0:0:0:0:0.0.0-255.128-254,0-126,255,127")
            IPWildcard("0:ffff:0:0:0:0:0.0.128-254,0-126,255,127.x")
            IPWildcard("0:ffff:0:0:0:0:0.0.0.0/112")
            IPWildcard("0:ffff:0:0:0:0:0.0,1.x.x")
            IPWildcard("0:ffff:0:0:0:0:0:0-10,10-20,24,23,22,21,25-ffff")
            IPWildcard("0:ffff::x")
            IPWildcard("0:ffff:0:0:0:0:0:aaab-ffff,aaaa-aaaa,0-aaa9")
            IPWildcard("0:ffff:0:0:0:0:0:ff00/120")
            IPWildcard("0:ffff:0:0:0:0:0:ffff/120")
            IPWildcard("::ff00:0/104")
            IPWildcard("::x")
            IPWildcard("x::")
            IPWildcard("x::10.10.10.10")

    def testBadStrings(self):
        self.assertRaises(ValueError, IPWildcard, "0.0.0.0/33")
        self.assertRaises(ValueError, IPWildcard, "0.0.0.2-0")
        self.assertRaises(ValueError, IPWildcard, "0.0.0.256")
        self.assertRaises(ValueError, IPWildcard, "0.0.256.0")
        self.assertRaises(ValueError, IPWildcard, "0.0.0256.0")
        self.assertRaises(ValueError, IPWildcard, "0.256.0.0")
        self.assertRaises(ValueError, IPWildcard, "0.0.0.0.0")
        self.assertRaises(ValueError, IPWildcard, "0.0.x.0/31")
        self.assertRaises(ValueError, IPWildcard, "0.0.x.0:0")
        self.assertRaises(ValueError, IPWildcard, "0.0.0,1.0/31")
        self.assertRaises(ValueError, IPWildcard, "0.0.0-1.0/31")
        self.assertRaises(ValueError, IPWildcard, "0.0.0-1-.0")
        self.assertRaises(ValueError, IPWildcard, "0.0.0--1.0")
        self.assertRaises(ValueError, IPWildcard, "0.0.0.0 junk")
        self.assertRaises(ValueError, IPWildcard, "0.0.-0-1.0")
        self.assertRaises(ValueError, IPWildcard, "0.0.-1.0")
        self.assertRaises(ValueError, IPWildcard, "0.0.0..0")
        self.assertRaises(ValueError, IPWildcard, ".0.0.0.0")
        self.assertRaises(ValueError, IPWildcard, "0.0.0.0.")
        self.assertRaises(ValueError, IPWildcard, "1-FF::/16")
        self.assertRaises(ValueError, IPWildcard, "1,2::/16")
        self.assertRaises(ValueError, IPWildcard, "1::2::3")
        self.assertRaises(ValueError, IPWildcard, ":1::")
        self.assertRaises(ValueError, IPWildcard, ":1:2:3:4:5:6:7:8")
        self.assertRaises(ValueError, IPWildcard, "1:2:3:4:5:6:7:8:")
        self.assertRaises(ValueError, IPWildcard, "1:2:3:4:5:6:7.8.9:10")
        self.assertRaises(ValueError, IPWildcard, "1:2:3:4:5:6:7:8.9.10.11")
        self.assertRaises(ValueError, IPWildcard, ":")
        self.assertRaises(ValueError, IPWildcard, "1:2:3:4:5:6:7")
        self.assertRaises(ValueError, IPWildcard, "1:2:3:4:5:6:7/16")
        self.assertRaises(ValueError, IPWildcard, "FFFFF::")
        self.assertRaises(ValueError, IPWildcard, "::FFFFF")
        self.assertRaises(ValueError, IPWildcard, "1:FFFFF::7:8")
        self.assertRaises(ValueError, IPWildcard, "1:AAAA-FFFF0::")
        self.assertRaises(ValueError, IPWildcard, "FFFFF-AAAA::")
        self.assertRaises(ValueError, IPWildcard, "FFFF-AAAA::")
        self.assertRaises(ValueError, IPWildcard, "2-1::")
        self.assertRaises(ValueError, IPWildcard, "1:FFFF-0::")
        self.assertRaises(ValueError, IPWildcard, "1::FFFF-AAAA")
        self.assertRaises(ValueError, IPWildcard, ":::")
        self.assertRaises(ValueError, IPWildcard, "1:2:3:$::")
        self.assertRaises(ValueError, IPWildcard, "1.2.3.4:ffff::")
        self.assertRaises(ValueError, IPWildcard, "x")

    def testContainment(self):
        wild = IPWildcard("0.0.0.0")
        self.assert_(IPAddr("0.0.0.0") in wild)
        self.assert_(IPAddr("0.0.0.1") not in wild)
        self.assert_("0.0.0.0" in wild)
        self.assert_("0.0.0.1" not in wild)
        wild = IPWildcard("0.0.0.0/31")
        self.assert_(IPAddr("0.0.0.0") in wild)
        self.assert_(IPAddr("0.0.0.1") in wild)
        self.assert_(IPAddr("0.0.0.2") not in wild)
        self.assert_("0.0.0.0" in wild)
        self.assert_("0.0.0.1" in wild)
        self.assert_("0.0.0.2" not in wild)
        wild = IPWildcard("255.255.255.254-255")
        self.assert_(IPAddr("255.255.255.254") in wild)
        self.assert_(IPAddr("255.255.255.255") in wild)
        self.assert_(IPAddr("255.255.255.253") not in wild)
        self.assert_("255.255.255.254" in wild)
        self.assert_("255.255.255.255" in wild)
        self.assert_("255.255.255.253" not in wild)
        wild = IPWildcard("3,2,1.4.5.6")
        self.assert_(IPAddr("1.4.5.6") in wild)
        self.assert_(IPAddr("2.4.5.6") in wild)
        self.assert_(IPAddr("3.4.5.6") in wild)
        self.assert_(IPAddr("4.4.5.6") not in wild)
        self.assert_("1.4.5.6" in wild)
        self.assert_("2.4.5.6" in wild)
        self.assert_("3.4.5.6" in wild)
        self.assert_("4.4.5.6" not in wild)
        wild = IPWildcard("0,255.0,255.0,255.0,255")
        self.assert_(IPAddr("0.0.0.0") in wild)
        self.assert_(IPAddr("0.0.0.255") in wild)
        self.assert_(IPAddr("0.0.255.0") in wild)
        self.assert_(IPAddr("0.255.0.0") in wild)
        self.assert_(IPAddr("255.0.0.0") in wild)
        self.assert_(IPAddr("255.255.0.0") in wild)
        self.assert_(IPAddr("255.0.255.0") in wild)
        self.assert_(IPAddr("255.0.0.255") in wild)
        self.assert_(IPAddr("0.255.0.255") in wild)
        self.assert_(IPAddr("0.255.255.0") in wild)
        self.assert_(IPAddr("0.0.255.255") in wild)
        self.assert_(IPAddr("0.255.255.255") in wild)
        self.assert_(IPAddr("255.0.255.255") in wild)
        self.assert_(IPAddr("255.255.0.255") in wild)
        self.assert_(IPAddr("255.255.255.0") in wild)
        self.assert_(IPAddr("255.255.255.255") in wild)
        self.assert_(IPAddr("255.255.255.254") not in wild)
        self.assert_(IPAddr("255.255.254.255") not in wild)
        self.assert_(IPAddr("255.254.255.255") not in wild)
        self.assert_(IPAddr("254.255.255.255") not in wild)
        self.assert_("0.0.0.0" in wild)
        self.assert_("0.0.0.255" in wild)
        self.assert_("0.0.255.0" in wild)
        self.assert_("0.255.0.0" in wild)
        self.assert_("255.0.0.0" in wild)
        self.assert_("255.255.0.0" in wild)
        self.assert_("255.0.255.0" in wild)
        self.assert_("255.0.0.255" in wild)
        self.assert_("0.255.0.255" in wild)
        self.assert_("0.255.255.0" in wild)
        self.assert_("0.0.255.255" in wild)
        self.assert_("0.255.255.255" in wild)
        self.assert_("255.0.255.255" in wild)
        self.assert_("255.255.0.255" in wild)
        self.assert_("255.255.255.0" in wild)
        self.assert_("255.255.255.255" in wild)
        self.assert_("255.255.255.254" not in wild)
        self.assert_("255.255.254.255" not in wild)
        self.assert_("255.254.255.255" not in wild)
        self.assert_("254.255.255.255" not in wild)
        if ipv6_enabled():
            wild = IPWildcard("::")
            self.assert_(IPAddr("::") in wild)
            self.assert_(IPAddr("::1") not in wild)
            self.assert_("::" in wild)
            self.assert_("::1" not in wild)
            wild = IPWildcard("::/127")
            self.assert_(IPAddr("::") in wild)
            self.assert_(IPAddr("::1") in wild)
            self.assert_(IPAddr("::2") not in wild)
            self.assert_("::" in wild)
            self.assert_("::1" in wild)
            self.assert_("::2" not in wild)
            wild = IPWildcard("0:ffff::0.0.0.0,1")
            self.assert_(IPAddr("0:ffff::0.0.0.0") in wild)
            self.assert_(IPAddr("0:ffff::0.0.0.1") in wild)
            self.assert_(IPAddr("0:ffff::0.0.0.2") not in wild)
            self.assert_("0:ffff::0.0.0.0" in wild)
            self.assert_("0:ffff::0.0.0.1" in wild)
            self.assert_("0:ffff::0.0.0.2" not in wild)
            wild = IPWildcard("0:ffff:0:0:0:0:0.253-254.125-126,255.x")
            self.assert_(IPAddr("0:ffff::0.253.125.1") in wild)
            self.assert_(IPAddr("0:ffff::0.254.125.2") in wild)
            self.assert_(IPAddr("0:ffff::0.253.126.3") in wild)
            self.assert_(IPAddr("0:ffff::0.254.126.4") in wild)
            self.assert_(IPAddr("0:ffff::0.253.255.5") in wild)
            self.assert_(IPAddr("0:ffff::0.254.255.6") in wild)
            self.assert_(IPAddr("0:ffff::0.255.255.7") not in wild)
            self.assert_("0:ffff::0.253.125.1" in wild)
            self.assert_("0:ffff::0.254.125.2" in wild)
            self.assert_("0:ffff::0.253.126.3" in wild)
            self.assert_("0:ffff::0.254.126.4" in wild)
            self.assert_("0:ffff::0.253.255.5" in wild)
            self.assert_("0:ffff::0.254.255.6" in wild)
            self.assert_("0:ffff::0.255.255.7" not in wild)
            wild = IPWildcard("0.0.0.0")
            self.assert_("::ffff:0:0" in wild)
            self.assert_("::" not in wild)
            wild = IPWildcard("::ffff:0:0")
            self.assert_("0.0.0.0" in wild)
            wild = IPWildcard("::")
            self.assert_("0.0.0.0" not in wild)

    def testIteration(self):
        self.assertEqual(set(IPWildcard("0.0.0.0")), set([IPAddr("0.0.0.0")]))
        self.assertEqual(set(IPWildcard("0.0.0.0/31")), 
                         set(map(IPAddr, ["0.0.0.0", "0.0.0.1"])))
        self.assertEqual(set(IPWildcard("255.255.255.254-255")),
                         set(map(IPAddr, ["255.255.255.254", 
                                          "255.255.255.255"])))
        self.assertEqual(set(IPWildcard("3,2,1.4.5.6")),
                         set(map(IPAddr, ["1.4.5.6", 
                                          "2.4.5.6",
                                          "3.4.5.6"])))
        self.assertEqual(set(IPWildcard("0,255.0,255.0,255.0,255")),
                         set(map(IPAddr, ["0.0.0.0",
                                          "0.0.0.255",
                                          "0.0.255.0",
                                          "0.255.0.0",
                                          "255.0.0.0",
                                          "255.255.0.0",
                                          "255.0.255.0",
                                          "255.0.0.255",
                                          "0.255.0.255",
                                          "0.255.255.0",
                                          "0.0.255.255",
                                          "0.255.255.255",
                                          "255.0.255.255",
                                          "255.255.0.255",
                                          "255.255.255.0",
                                          "255.255.255.255"])))
        if ipv6_enabled():
            self.assertEqual(set(IPWildcard("::")), set([IPAddr("::")]))
            self.assertEqual(set(IPWildcard("::/127")),
                             set(map(IPAddr, ["::0", "::1"])))
            self.assertEqual(set(IPWildcard("0:ffff::0.0.0.0,1")),
                             set(map(IPAddr, ["0:ffff::0", "0:ffff::1"])))
            self.assertEqual(set(IPWildcard(
                        "0:ffff::0.253-254.125-126,255.1")),
                             set(map(IPAddr, ["0:ffff::0.253.125.1",
                                              "0:ffff::0.253.126.1",
                                              "0:ffff::0.253.255.1",
                                              "0:ffff::0.254.125.1",
                                              "0:ffff::0.254.126.1",
                                              "0:ffff::0.254.255.1"])))
                                              
class TestTCPFlags(unittest.TestCase):
    
    def testConstruction(self):
        for i in range(0, 256):
            TCPFlags(i)
        TCPFlags('F')
        TCPFlags('S')
        TCPFlags('R')
        TCPFlags('P')
        TCPFlags('U')
        TCPFlags('E')
        TCPFlags('C')
        TCPFlags('  A  ')
        TCPFlags('FSRPUECA')
        TCPFlags('f')
        TCPFlags('s')
        TCPFlags('r')
        TCPFlags('p')
        TCPFlags('u')
        TCPFlags('e')
        TCPFlags('c')
        TCPFlags('  a  ')
        TCPFlags('fsrpueca')
        TCPFlags('aa')
        TCPFlags('')
        TCPFlags(TCPFlags(0))
        TCPFlags(TCPFlags(''))

    def testBadValues(self):
        self.assertRaises(OverflowError, TCPFlags, -1)
        self.assertRaises(OverflowError, TCPFlags, 256)
        self.assertRaises(ValueError, TCPFlags, 'x')
        self.assertRaises(ValueError, TCPFlags, 'fsrpuecax')

    def testMembers(self):
        flags = TCPFlags('fsrpueca')
        self.assertEqual(flags.FIN, True)
        self.assertEqual(flags.SYN, True)
        self.assertEqual(flags.RST, True)
        self.assertEqual(flags.PSH, True)
        self.assertEqual(flags.ACK, True)
        self.assertEqual(flags.URG, True)
        self.assertEqual(flags.ECE, True)
        self.assertEqual(flags.CWR, True)
        flags = TCPFlags('')
        self.assertEqual(flags.FIN, False)
        self.assertEqual(flags.SYN, False)
        self.assertEqual(flags.RST, False)
        self.assertEqual(flags.PSH, False)
        self.assertEqual(flags.ACK, False)
        self.assertEqual(flags.URG, False)
        self.assertEqual(flags.ECE, False)
        self.assertEqual(flags.CWR, False)

    def testConstants(self):
        self.assertEqual(TCPFlags('f'), FIN)
        self.assertEqual(TCPFlags('s'), SYN)
        self.assertEqual(TCPFlags('r'), RST)
        self.assertEqual(TCPFlags('p'), PSH)
        self.assertEqual(TCPFlags('a'), ACK)
        self.assertEqual(TCPFlags('u'), URG)
        self.assertEqual(TCPFlags('e'), ECE)
        self.assertEqual(TCPFlags('c'), CWR)

    def testIntConv(self):
        self.assertEqual(int(FIN), 1)
        self.assertEqual(int(SYN), 2)
        self.assertEqual(int(RST), 4)
        self.assertEqual(int(PSH), 8)
        self.assertEqual(int(ACK), 16)
        self.assertEqual(int(URG), 32)
        self.assertEqual(int(ECE), 64)
        self.assertEqual(int(CWR), 128)

    def testInequality(self):
        self.assert_(TCPFlags('f') == TCPFlags ('F'))
        self.assert_(TCPFlags('f') != TCPFlags ('FA'))

    def testBinary(self):
        self.assertEqual(~TCPFlags('fsrp'), TCPFlags('ueca'))
        self.assertEqual(TCPFlags('fsrp') & TCPFlags('fpua'), TCPFlags('fp'))
        self.assertEqual(TCPFlags('frp') | TCPFlags('fa'), TCPFlags('frpa'))
        self.assertEqual(TCPFlags('frp') ^ TCPFlags('fa'), TCPFlags('rpa'))
        self.assert_(TCPFlags('a'))
        self.assert_(not TCPFlags(''))

    def testMatches(self):
        self.assertEqual(TCPFlags('fsrp').matches('fs/fsau'), True)
        self.assertEqual(TCPFlags('fsrp').matches('fs/fspu'), False)
        self.assertEqual(TCPFlags('fs').matches('fs'), True)
        self.assertEqual(TCPFlags('fsa').matches('fs'), True)
        self.assertRaises(ValueError, TCPFlags('').matches, 'a/s/')
        self.assertRaises(ValueError, TCPFlags('').matches, 'x')


class TestRWRec(unittest.TestCase):
    
    def testEmptyRec(self):
        RWRec()

    def testMostlyFullRec(self):
        RWRec(application = 1, bytes = 2, dip = "3.4.5.6", dport = 7,
              duration = datetime.timedelta(8), initflags = TCPFlags(9),
              input = 10, nhip = "11.12.13.14", output = 15, packets = 16,
              protocol = 17, restflags = TCPFlags(18), sip = "19.20.21.22",
              sport = 23, stime = datetime.datetime.utcnow(), 
              tcpflags = TCPFlags(25))
        RWRec({'application': 1, 'bytes': 2, 'dip': "3.4.5.6", 'dport': 7,
               'duration': datetime.timedelta(8), 'initflags': TCPFlags(9),
               'input': 10, 'nhip': "11.12.13.14", 'output': 15, 'packets': 16,
               'protocol': 17, 'restflags': TCPFlags(18), 'sip': "19.20.21.22",
               'sport': 23, 'stime': datetime.datetime.utcnow(), 
               'tcpflags': TCPFlags(25)})

    def testIntegerFields(self):
        rec = RWRec()
        rec.application = 1
        rec.bytes = 2
        rec.dport = 3
        rec.input = 4
        rec.output = 5
        rec.packets = 6
        rec.protocol = 7
        rec.sport = 8
        self.assertEqual(rec.application, 1)
        self.assertEqual(rec.bytes, 2)
        self.assertEqual(rec.dport, 3)
        self.assertEqual(rec.input, 4)
        self.assertEqual(rec.output, 5)
        self.assertEqual(rec.packets, 6)
        self.assertEqual(rec.protocol, 7)
        self.assertEqual(rec.sport, 8)
        self.assertRaises(TypeError, setattr, rec, 'application', -1)
        self.assertRaises(TypeError, setattr, rec, 'bytes', -1)
        self.assertRaises(TypeError, setattr, rec, 'dport', -1)
        self.assertRaises(TypeError, setattr, rec, 'input', -1)
        self.assertRaises(TypeError, setattr, rec, 'output', -1)
        self.assertRaises(TypeError, setattr, rec, 'packets', -1)
        self.assertRaises(TypeError, setattr, rec, 'protocol', -1)
        self.assertRaises(TypeError, setattr, rec, 'sport', -1)
        self.assertRaises(TypeError, setattr, rec, 'application', 0x10000)
        self.assertRaises(TypeError, setattr, rec, 'bytes', 0x100000000)
        self.assertRaises(TypeError, setattr, rec, 'dport', 0x10000)
        self.assertRaises(TypeError, setattr, rec, 'input', 0x10000)
        self.assertRaises(TypeError, setattr, rec, 'output', 0x10000)
        self.assertRaises(TypeError, setattr, rec, 'packets', 0x100000000)
        self.assertRaises(TypeError, setattr, rec, 'protocol', 0x100)
        self.assertRaises(TypeError, setattr, rec, 'sport', 0x10000)
        self.assertRaises(TypeError, setattr, rec, 'application', '0')
        self.assertRaises(TypeError, setattr, rec, 'bytes', '0')
        self.assertRaises(TypeError, setattr, rec, 'dport', '0')
        self.assertRaises(TypeError, setattr, rec, 'input', '0')
        self.assertRaises(TypeError, setattr, rec, 'output', '0')
        self.assertRaises(TypeError, setattr, rec, 'packets', '0')
        self.assertRaises(TypeError, setattr, rec, 'protocol', '0')
        self.assertRaises(TypeError, setattr, rec, 'sport', '0')

    def testIPFields(self):
        rec = RWRec()
        rec.sip = IPAddr("1.2.3.4")
        rec.dip = IPAddr("5.6.7.8")
        rec.nhip = IPAddr("9.10.11.12")
        self.assertEqual(rec.sip, IPAddr("1.2.3.4"))
        self.assertEqual(rec.dip, IPAddr("5.6.7.8"))
        self.assertEqual(rec.nhip, IPAddr("9.10.11.12"))
        rec.sip = "1.2.3.4"
        rec.dip = "5.6.7.8"
        rec.nhip = "9.10.11.12"
        self.assertEqual(rec.sip, IPAddr("1.2.3.4"))
        self.assertEqual(rec.dip, IPAddr("5.6.7.8"))
        self.assertEqual(rec.nhip, IPAddr("9.10.11.12"))
        self.assertRaises(ValueError, setattr, rec, 'sip', '0.0.0')
        self.assertRaises(ValueError, setattr, rec, 'dip', '0.0.0')
        self.assertRaises(ValueError, setattr, rec, 'nhip', '0.0.0')
        self.assertRaises(ValueError, setattr, rec, 'sip', '::x')
        self.assertRaises(ValueError, setattr, rec, 'dip', '::x')
        self.assertRaises(ValueError, setattr, rec, 'nhip', '::x')
        self.assertRaises(TypeError, setattr, rec, 'sip', 0)
        self.assertRaises(TypeError, setattr, rec, 'dip', 0)
        self.assertRaises(TypeError, setattr, rec, 'nhip', 0)
        if ipv6_enabled():
            rec.sip = IPAddr("0102:0304:0506::1.2.3.4")
            rec.dip = IPAddr("0708:090a:0b0c::5.6.7.8")
            rec.nhip = IPAddr("0d0e:0f10:1112::9.10.11.12")
            self.assertEqual(rec.sip, IPAddr("0102:0304:0506::1.2.3.4"))
            self.assertEqual(rec.dip, IPAddr("0708:090a:0b0c::5.6.7.8"))
            self.assertEqual(rec.nhip, IPAddr("0d0e:0f10:1112::9.10.11.12"))
            rec.sip = "0102:0304:0506::1.2.3.4"
            rec.dip = "0708:090a:0b0c::5.6.7.8"
            rec.nhip = "0d0e:0f10:1112::9.10.11.12"
            self.assertEqual(rec.sip, IPAddr("0102:0304:0506::1.2.3.4"))
            self.assertEqual(rec.dip, IPAddr("0708:090a:0b0c::5.6.7.8"))
            self.assertEqual(rec.nhip, IPAddr("0d0e:0f10:1112::9.10.11.12"))

    def testFlagsFields(self):
        rec = RWRec()
        self.assertEqual(rec.tcpflags, TCPFlags(''))
        self.assertEqual(rec.initflags, None)
        self.assertEqual(rec.restflags, None)
        rec.tcpflags = TCPFlags('a')
        rec.initflags = TCPFlags('a')
        rec.restflags = TCPFlags('a')
        self.assertEqual(rec.tcpflags, TCPFlags('a'))
        self.assertEqual(rec.initflags, TCPFlags('a'))
        self.assertEqual(rec.restflags, TCPFlags('a'))
        rec.tcpflags = 'a'
        rec.initflags = 'a'
        rec.restflags = 'a'
        self.assertEqual(rec.tcpflags, TCPFlags('a'))
        self.assertEqual(rec.initflags, TCPFlags('a'))
        self.assertEqual(rec.restflags, TCPFlags('a'))
        rec.tcpflags = 16
        rec.initflags = 16
        rec.restflags = 16
        self.assertEqual(rec.tcpflags, TCPFlags('a'))
        self.assertEqual(rec.initflags, TCPFlags('a'))
        self.assertEqual(rec.restflags, TCPFlags('a'))
        self.assertRaises(ValueError, setattr, rec, 'tcpflags', -1)
        self.assertRaises(ValueError, setattr, rec, 'tcpflags', 'x')
        self.assertRaises(ValueError, setattr, rec, 'tcpflags', 256)
        self.assertRaises(ValueError, setattr, rec, 'initflags', -1)
        self.assertRaises(ValueError, setattr, rec, 'initflags', 'x')
        self.assertRaises(ValueError, setattr, rec, 'initflags', 256)
        self.assertRaises(ValueError, setattr, rec, 'restflags', -1)
        self.assertRaises(ValueError, setattr, rec, 'restflags', 'x')
        self.assertRaises(ValueError, setattr, rec, 'restflags', 256)

    def testSiteBasedFields(self):
        if have_site_config():
            s = sensors[0]
            classtype = classtypes[0]
            rec = RWRec()
            rec.sensor = s
            rec.classtype = classtype
            self.assertEqual(rec.sensor, s)
            self.assertEqual(rec.classtype, classtype)
            self.assertEqual(rec.classname, classtype[0])
            self.assertEqual(rec.typename, classtype[1])
        self.assertRaises(TypeError, setattr, rec, 'sensor', 1)
        self.assertRaises(TypeError, setattr, rec, 'classtype', (1, 1))
        self.assertRaises(TypeError, setattr, rec, 'classname', 'all')
        self.assertRaises(TypeError, setattr, rec, 'typename', 'in')

    def testBitFields(self):
        rec = RWRec()
        self.assertEqual(rec.finnoack, None)
        self.assertEqual(rec.timeout_killed, None)
        self.assertEqual(rec.timeout_started, None)
        rec.finnoack = True
        self.assertEqual(rec.finnoack, True)
        self.assertEqual(rec.timeout_killed, False)
        self.assertEqual(rec.timeout_started, False)
        rec.timeout_killed = True
        self.assertEqual(rec.finnoack, True)
        self.assertEqual(rec.timeout_killed, True)
        self.assertEqual(rec.timeout_started, False)
        rec.timeout_started = True
        self.assertEqual(rec.finnoack, True)
        self.assertEqual(rec.timeout_killed, True)
        self.assertEqual(rec.timeout_started, True)
        rec.finnoack = False
        rec.timeout_killed = False
        rec.timeout_started = False
        self.assertEqual(rec.finnoack, False)
        self.assertEqual(rec.timeout_killed, False)
        self.assertEqual(rec.timeout_started, False)

    def testIPV6Conversion(self):
        if ipv6_enabled():
            rec = RWRec()
            self.assertEqual(rec.sip.ipv6(), False)
            self.assertEqual(rec.dip.ipv6(), False)
            self.assertEqual(rec.nhip.ipv6(), False)
            rec.sip = "::"
            self.assertEqual(rec.sip.ipv6(), True)
            self.assertEqual(rec.dip.ipv6(), True)
            self.assertEqual(rec.nhip.ipv6(), True)
            self.assertEqual(rec.dip, IPAddr("::ffff:0000:0000"))
            self.assertEqual(rec.nhip, IPAddr("::ffff:0000:0000"))
            rec.sip = "0.0.0.0"
            self.assertEqual(rec.sip.ipv6(), True)
            self.assertEqual(rec.dip.ipv6(), True)
            self.assertEqual(rec.nhip.ipv6(), True)
            self.assertEqual(rec.sip, IPAddr("::ffff:0000:0000"))
            self.assertEqual(rec.dip, IPAddr("::ffff:0000:0000"))
            self.assertEqual(rec.nhip, IPAddr("::ffff:0000:0000"))

    def testIsWeb(self):
        self.assertEqual(RWRec().is_web(), False)
        self.assertEqual(RWRec(sport=80).is_web(), False)
        self.assertEqual(RWRec(dport=80).is_web(), False)
        self.assertEqual(RWRec(sport=8080).is_web(), False)
        self.assertEqual(RWRec(dport=8080).is_web(), False)
        self.assertEqual(RWRec(sport=443).is_web(), False)
        self.assertEqual(RWRec(dport=443).is_web(), False)
        self.assertEqual(RWRec(protocol=6, sport=80).is_web(), True)
        self.assertEqual(RWRec(protocol=6, dport=80).is_web(), True)
        self.assertEqual(RWRec(protocol=6, sport=8080).is_web(), True)
        self.assertEqual(RWRec(protocol=6, dport=8080).is_web(), True)
        self.assertEqual(RWRec(protocol=6, sport=443).is_web(), True)
        self.assertEqual(RWRec(protocol=6, dport=443).is_web(), True)
        rec = RWRec(protocol=6, sport=80, dport=80)
        self.assertEqual(rec.is_web(), True)
        rec.sport = 0
        self.assertEqual(rec.is_web(), True)
        rec.dport = 0
        self.assertEqual(rec.is_web(), False)

    def testEquality(self):
        reca = RWRec()
        recb = RWRec()
        self.assertEqual(reca == recb, True)
        self.assertEqual(reca != recb, False)
        reca.input = 1
        self.assertEqual(reca == recb, False)
        self.assertEqual(reca != recb, True)
        recb.input = 1
        self.assertEqual(reca == recb, True)
        self.assertEqual(reca != recb, False)

    def testAsDict(self):
        rec = RWRec(sip="1.1.1.1", input=4)
        recdict = rec.as_dict()
        self.assertEqual(recdict['sip'] == IPAddr("1.1.1.1"), True)
        self.assertEqual(recdict['input'] == 4, True)

    def testTimeFields(self):
        rec = RWRec(stime=datetime.datetime(year=1970,month=1,day=1),
                    duration = datetime.timedelta(minutes=1))
        self.assertEqual(rec.stime, datetime.datetime(year=1970,month=1,day=1))
        self.assertEqual(rec.duration, datetime.timedelta(minutes=1))
        self.assertEqual(rec.etime, datetime.datetime(year=1970,month=1,day=1,
                                                      minute=1))
        rec.etime = datetime.datetime(year=1970,month=1,day=1,minute=2)
        self.assertEqual(rec.stime, datetime.datetime(year=1970,month=1,day=1))
        self.assertEqual(rec.duration, datetime.timedelta(minutes=2))
        self.assertEqual(rec.etime, datetime.datetime(year=1970,month=1,day=1,
                                                      minute=2))
        rec.stime = datetime.datetime(year=1970,month=1,day=1,minute=1)
        self.assertEqual(rec.stime, datetime.datetime(year=1970,month=1,day=1,
                                                      minute=1))
        self.assertEqual(rec.duration, datetime.timedelta(minutes=2))
        self.assertEqual(rec.etime, datetime.datetime(year=1970,month=1,day=1,
                                                      minute=3))
        rec.duration = datetime.timedelta(minutes=1)
        self.assertEqual(rec.stime, datetime.datetime(year=1970,month=1,day=1,
                                                      minute=1))
        self.assertEqual(rec.duration, datetime.timedelta(minutes=1))
        self.assertEqual(rec.etime, datetime.datetime(year=1970,month=1,day=1,
                                                      minute=2))
        self.assertRaises(OverflowError, setattr, rec, 'stime', 
                          datetime.datetime(year=1969,month=12,day=31))
        rec.duration = datetime.timedelta(milliseconds=0xffffffff)
        self.assertRaises(OverflowError, setattr, rec, 'duration', 
                          datetime.timedelta(milliseconds=0x100000000))
        self.assertRaises(OverflowError, setattr, rec, 'etime',
                          rec.stime + 
                          datetime.timedelta(milliseconds=0x100000000))
        self.assertEqual(rec.etime, rec.stime + rec.duration)
                         

class TestIPSet(unittest.TestCase):
    def setUp(self):
        warnings.simplefilter("ignore", RuntimeWarning)
        self.tmpdir = tempfile.mkdtemp()
        self.tmpfile = os.tempnam(self.tmpdir)
        warnings.simplefilter("default", RuntimeWarning)

    def rmfile(self):
        os.remove(self.tmpfile)
        
    def tearDown(self):
        try:
            self.rmfile()
        except:
            pass
        os.rmdir(self.tmpdir)
    
    def testConstruction(self):
        s = IPSet()
        s.save(self.tmpfile)
        IPSet.load(self.tmpfile)
        self.rmfile()
        IPSet(["1.2.3.4"])
        IPSet(["1.2.3.4", "5.6.7.8"])
        IPSet(map(IPAddr, ["1.2.3.4"]))
        IPSet(map(IPAddr, ["1.2.3.4", "5.6.7.8"]))
        IPSet(["1.2.3.4", IPAddr("5.6.7.8")])

    def testAddAndIn(self):
        s = IPSet()
        s.add("1.2.3.4")
        self.assertEqual("1.2.3.4" in s, True)
        self.assertEqual("0.0.0.0" not in s, True)
        self.assertEqual(IPAddr("1.2.3.4") in s, True)
        self.assertEqual(IPAddr("0.0.0.0") not in s, True)
        s.add(IPAddr("5.6.7.8"))
        self.assertEqual("1.2.3.4" in s, True)
        self.assertEqual("5.6.7.8" in s, True)
        self.assertEqual("0.0.0.0" not in s, True)
        self.assertEqual(IPAddr("1.2.3.4") in s, True)
        self.assertEqual(IPAddr("5.6.7.8") in s, True)
        self.assertEqual(IPAddr("0.0.0.0") not in s, True)
        self.assertRaises(TypeError, s.add, 0)
        self.assertRaises(ValueError, s.add, "::")
        self.assertRaises(ValueError, s.add, IPAddr("::"))
        self.assertRaises(ValueError, s.add, IPAddr("::ffff:0.0.0.0"))


    def testCopy(self):
        s1 = IPSet()
        s2 = s1
        s3 = s1.copy()
        self.assert_(s1 == s2 == s3)
        self.assert_(s1 is s2)
        self.assert_(s1 is not s3)
        s1.add("1.2.3.4")
        s1.add("5.6.7.8")
        s3 = s1.copy()
        self.assert_(s1 == s2 == s3)
        self.assert_(s1 is s2)
        self.assert_(s1 is not s3)

    def testRemove(self):
        s = IPSet()
        s.add("1.2.3.4")
        s.add("5.6.7.8")
        self.assert_("1.2.3.4" in s)
        self.assert_("5.6.7.8" in s)
        s.remove("1.2.3.4")
        self.assert_("1.2.3.4" not in s)
        self.assert_("5.6.7.8" in s)
        s.remove("5.6.7.8")
        self.assert_("1.2.3.4" not in s)
        self.assert_("5.6.7.8" not in s)
        self.assertRaises(KeyError, s.remove, "1.2.3.4")

    def testDiscard(self):
        s = IPSet()
        s.add("1.2.3.4")
        s.add("5.6.7.8")
        self.assert_("1.2.3.4" in s)
        self.assert_("5.6.7.8" in s)
        s.discard("1.2.3.4")
        self.assert_("1.2.3.4" not in s)
        self.assert_("5.6.7.8" in s)
        s.discard("5.6.7.8")
        self.assert_("1.2.3.4" not in s)
        self.assert_("5.6.7.8" not in s)
        s.discard("1.2.3.4")
        self.assert_("1.2.3.4" not in s)
        self.assert_("5.6.7.8" not in s)

    def testClear(self):
        s = IPSet()
        s.add("1.2.3.4")
        s.add("5.6.7.8")
        self.assert_("1.2.3.4" in s)
        self.assert_("5.6.7.8" in s)
        s.clear()
        self.assert_("1.2.3.4" not in s)
        self.assert_("5.6.7.8" not in s)

    def testLenAndCard(self):
        s = IPSet()
        self.assertEqual(len(s), 0)
        self.assertEqual(s.cardinality(), 0)
        s.add("1.2.3.4")
        s.add("5.6.7.8")
        self.assertEqual(len(s), 2)
        self.assertEqual(s.cardinality(), 2)
        s.remove("1.2.3.4")
        self.assertEqual(len(s), 1)
        self.assertEqual(s.cardinality(), 1)

    def testSubsetSuperset(self):
        s1 = IPSet()
        s2 = IPSet()
        self.assert_(s1.issubset(s2))
        self.assert_(s2.issubset(s1))
        self.assert_(s1.issuperset(s2))
        self.assert_(s2.issuperset(s1))
        self.assert_(s1 <= s2)
        self.assert_(s2 <= s1)
        self.assert_(s1 >= s2)
        self.assert_(s2 >= s1)
        s1.add("1.2.3.4")
        s1.add("5.6.7.8")
        s2.add("5.6.7.8")
        self.assertEqual(s1.issubset(s2), False)
        self.assertEqual(s2.issubset(s1), True)
        self.assertEqual(s1.issuperset(s2), True)
        self.assertEqual(s2.issuperset(s1), False)
        self.assertEqual(s1 <= s2, False)
        self.assertEqual(s2 <= s1, True)
        self.assertEqual(s1 >= s2, True)
        self.assertEqual(s2 >= s1, False)
        self.assertEqual(s2.issubset(["1.2.3.4", "5.6.7.8"]), True)
        self.assertEqual(s2.issubset(["1.2.3.4"]), False)
        self.assertEqual(s1.issuperset(["1.2.3.4"]), True)
        self.assertEqual(s1.issuperset(["1.2.3.4", "0.0.0.0"]), False)
        self.assertRaises(TypeError, s2.__le__, ["1.2.3.4", "5.6.7.8"])
        self.assertRaises(TypeError, s1.__ge__, ["1.2.3.4"])

    def testUnion(self):
        s1 = IPSet()
        s2 = IPSet()
        s1.add("1.2.3.4")
        s1.add("5.6.7.8")
        s2.add("5.6.7.8")
        s2.add("9.10.11.12")
        s3 = s1.union(s2)
        s4 = s2.union(s1)
        s5 = s1.copy()
        s5.update(s2)
        self.assert_(s3 == s4 == s5)
        self.assert_(s1 <= s3)
        self.assert_(s2 <= s3)
        self.assert_(s1 <= s4)
        self.assert_(s2 <= s4)
        self.assert_(s1 <= s5)
        self.assert_(s2 <= s5)
        self.assertEqual(s3.cardinality(), 3)
        self.assertEqual(s4.cardinality(), 3)
        self.assertEqual(s5.cardinality(), 3)
        s3 = s1 | s2
        s4 = s2 | s1
        s5 = s1.copy()
        s5 |= s2
        self.assert_(s3 == s4 == s5)
        self.assert_(s1 <= s3)
        self.assert_(s2 <= s3)
        self.assert_(s1 <= s4)
        self.assert_(s2 <= s4)
        self.assert_(s1 <= s5)
        self.assert_(s2 <= s5)
        self.assertEqual(s3.cardinality(), 3)
        self.assertEqual(s4.cardinality(), 3)
        self.assertEqual(s5.cardinality(), 3)
        s3 = s1.union(["5.6.7.8", "9.10.11.12"])
        s4 = s2.union(["1.2.3.4", "5.6.7.8"])
        s5 = s1.copy()
        s5.update(["5.6.7.8", "9.10.11.12"])
        self.assert_(s3 == s4 == s5)
        self.assert_(s1 <= s3)
        self.assert_(s2 <= s3)
        self.assert_(s1 <= s4)
        self.assert_(s2 <= s4)
        self.assert_(s1 <= s5)
        self.assert_(s2 <= s5)
        self.assertEqual(s3.cardinality(), 3)
        self.assertEqual(s4.cardinality(), 3)
        self.assertEqual(s5.cardinality(), 3)
        s5 = s1.copy()
        self.assertRaises(TypeError, s1.__or__, ["5.6.7.8", "9.10.11.12"])
        self.assertRaises(TypeError, s2.__or__, ["1.2.3.4", "5.6.7.8"])
        self.assertRaises(TypeError, s5.__ior__, ["5.6.7.8", "9.10.11.12"])

    def testIntersection(self):
        s1 = IPSet()
        s2 = IPSet()
        s1.add("1.2.3.4")
        s1.add("5.6.7.8")
        s2.add("5.6.7.8")
        s2.add("9.10.11.12")
        s3 = s1.intersection(s2)
        s4 = s2.intersection(s1)
        s5 = s1.copy()
        s5.intersection_update(s2)
        self.assert_(s3 == s4 == s5)
        self.assert_(s1 >= s3)
        self.assert_(s2 >= s3)
        self.assert_(s1 >= s4)
        self.assert_(s2 >= s4)
        self.assert_(s1 >= s5)
        self.assert_(s2 >= s5)
        self.assertEqual(s3.cardinality(), 1)
        self.assertEqual(s4.cardinality(), 1)
        self.assertEqual(s5.cardinality(), 1)
        s3 = s1 & s2
        s4 = s2 & s1
        s5 = s1.copy()
        s5 &= s2
        self.assert_(s3 == s4 == s5)
        self.assert_(s1 >= s3)
        self.assert_(s2 >= s3)
        self.assert_(s1 >= s4)
        self.assert_(s2 >= s4)
        self.assert_(s1 >= s5)
        self.assert_(s2 >= s5)
        self.assertEqual(s3.cardinality(), 1)
        self.assertEqual(s4.cardinality(), 1)
        self.assertEqual(s5.cardinality(), 1)
        s3 = s1.intersection(["5.6.7.8", "9.10.11.12"])
        s4 = s2.intersection(["1.2.3.4", "5.6.7.8"])
        s5 = s1.copy()
        s5.intersection_update(["5.6.7.8", "9.10.11.12"])
        self.assert_(s3 == s4 == s5)
        self.assert_(s1 >= s3)
        self.assert_(s2 >= s3)
        self.assert_(s1 >= s4)
        self.assert_(s2 >= s4)
        self.assert_(s1 >= s5)
        self.assert_(s2 >= s5)
        self.assertEqual(s3.cardinality(), 1)
        self.assertEqual(s4.cardinality(), 1)
        self.assertEqual(s5.cardinality(), 1)
        s5 = s1.copy()
        self.assertRaises(TypeError, s1.__and__, ["5.6.7.8", "9.10.11.12"])
        self.assertRaises(TypeError, s2.__and__, ["1.2.3.4", "5.6.7.8"])
        self.assertRaises(TypeError, s5.__iand__, ["5.6.7.8", "9.10.11.12"])

    def testDifference(self):
        s1 = IPSet()
        s2 = IPSet()
        s1.add("1.2.3.4")
        s1.add("5.6.7.8")
        s2.add("5.6.7.8")
        s2.add("9.10.11.12")
        s3 = s1.difference(s2)
        s4 = s2.difference(s1)
        s5 = s1.copy()
        s5.difference_update(s2)
        self.assertNotEqual(s3, s4)
        self.assertNotEqual(s5, s4)
        self.assert_(s1 >= s3)
        self.assert_(not (s3 & s2))
        self.assert_(s1 >= s5)
        self.assert_(not (s5 & s2))
        self.assert_(s2 >= s4)
        self.assert_(not (s4 & s1))
        self.assertEqual(s3.cardinality(), 1)
        self.assertEqual(s4.cardinality(), 1)
        self.assertEqual(s5.cardinality(), 1)
        s3 = s1 - s2
        s4 = s2 - s1
        s5 = s1.copy()
        s5 -= s2
        self.assertNotEqual(s3, s4)
        self.assertNotEqual(s5, s4)
        self.assert_(s1 >= s3)
        self.assert_(not (s3 & s2))
        self.assert_(s1 >= s5)
        self.assert_(not (s5 & s2))
        self.assert_(s2 >= s4)
        self.assert_(not (s4 & s1))
        self.assertEqual(s3.cardinality(), 1)
        self.assertEqual(s4.cardinality(), 1)
        self.assertEqual(s5.cardinality(), 1)
        s3 = s1.difference(["5.6.7.8", "9.10.11.12"])
        s4 = s2.difference(["1.2.3.4", "5.6.7.8"])
        s5 = s1.copy()
        s5.difference_update(["5.6.7.8", "9.10.11.12"])
        self.assertNotEqual(s3, s4)
        self.assertNotEqual(s5, s4)
        self.assert_(s1 >= s3)
        self.assert_(not (s3 & s2))
        self.assert_(s1 >= s5)
        self.assert_(not (s5 & s2))
        self.assert_(s2 >= s4)
        self.assert_(not (s4 & s1))
        self.assertEqual(s3.cardinality(), 1)
        self.assertEqual(s4.cardinality(), 1)
        self.assertEqual(s5.cardinality(), 1)
        self.assertRaises(TypeError, s1.__sub__, ["5.6.7.8", "9.10.11.12"])
        self.assertRaises(TypeError, s2.__sub__, ["1.2.3.4", "5.6.7.8"])
        self.assertRaises(TypeError, s5.__isub__, ["5.6.7.8", "9.10.11.12"])

    def testSymmetricDifference(self):
        s1 = IPSet()
        s2 = IPSet()
        s1.add("1.2.3.4")
        s1.add("5.6.7.8")
        s2.add("5.6.7.8")
        s2.add("9.10.11.12")
        s3 = s1.symmetric_difference(s2)
        s4 = s2.symmetric_difference(s1)
        s5 = s1.copy()
        s5.symmetric_difference_update(s2)
        self.assert_(s3 == s4 == s5)
        self.assert_(not s1 >= s3)
        self.assert_(not s2 >= s3)
        self.assert_(not s1 >= s4)
        self.assert_(not s2 >= s4)
        self.assert_(not s1 >= s5)
        self.assert_(not s2 >= s5)
        self.assert_(not s1 <= s3)
        self.assert_(not s2 <= s3)
        self.assert_(not s1 <= s4)
        self.assert_(not s2 <= s4)
        self.assert_(not s1 <= s5)
        self.assert_(not s2 <= s5)
        self.assertEqual(s3.cardinality(), 2)
        self.assertEqual(s4.cardinality(), 2)
        self.assertEqual(s5.cardinality(), 2)
        s3 = s1 ^ s2
        s4 = s2 ^ s1
        s5 = s1.copy()
        s5 ^= s2
        self.assert_(s3 == s4 == s5)
        self.assert_(not s1 >= s3)
        self.assert_(not s2 >= s3)
        self.assert_(not s1 >= s4)
        self.assert_(not s2 >= s4)
        self.assert_(not s1 >= s5)
        self.assert_(not s2 >= s5)
        self.assert_(not s1 <= s3)
        self.assert_(not s2 <= s3)
        self.assert_(not s1 <= s4)
        self.assert_(not s2 <= s4)
        self.assert_(not s1 <= s5)
        self.assert_(not s2 <= s5)
        self.assertEqual(s3.cardinality(), 2)
        self.assertEqual(s4.cardinality(), 2)
        self.assertEqual(s5.cardinality(), 2)
        s3 = s1.symmetric_difference(["5.6.7.8", "9.10.11.12"])
        s4 = s2.symmetric_difference(["1.2.3.4", "5.6.7.8"])
        s5 = s1.copy()
        s5.symmetric_difference_update(["5.6.7.8", "9.10.11.12"])
        self.assert_(s3 == s4 == s5)
        self.assert_(not s1 >= s3)
        self.assert_(not s2 >= s3)
        self.assert_(not s1 >= s4)
        self.assert_(not s2 >= s4)
        self.assert_(not s1 >= s5)
        self.assert_(not s2 >= s5)
        self.assert_(not s1 <= s3)
        self.assert_(not s2 <= s3)
        self.assert_(not s1 <= s4)
        self.assert_(not s2 <= s4)
        self.assert_(not s1 <= s5)
        self.assert_(not s2 <= s5)
        self.assertEqual(s3.cardinality(), 2)
        self.assertEqual(s4.cardinality(), 2)
        self.assertEqual(s5.cardinality(), 2)
        s5 = s1.copy()
        self.assertRaises(TypeError, s1.__xor__, ["5.6.7.8", "9.10.11.12"])
        self.assertRaises(TypeError, s2.__xor__, ["1.2.3.4", "5.6.7.8"])
        self.assertRaises(TypeError, s5.__ixor__, ["5.6.7.8", "9.10.11.12"])

    def testIterators(self):
        ipaddrs = map(IPAddr, ["1.2.3.4", "1.2.3.5", "1.2.3.6", "1.2.3.7",
                               "1.2.3.8", "1.2.3.9", "0.0.0.0"])
        s = IPSet(ipaddrs)
        count = 0
        for x in s:
            self.assert_(x in s)
            self.assert_(x in ipaddrs)
            count += 1
        self.assertEqual(count, len(ipaddrs))
        cidrlist = list(s.cidr_iter())
        self.assertEqual(len(cidrlist), 3)
        blocks = map(IPAddr, ['0.0.0.0', '1.2.3.4', '1.2.3.8'])
        prefixes = [32, 30, 31]
        self.assertEqual(set(cidrlist), set(zip(blocks, prefixes)))

    def testIO(self):
        s = IPSet(["1.2.3.4", "1.2.3.5", "1.2.3.6", "1.2.3.7",
                   "1.2.3.8", "1.2.3.9", "0.0.0.0"])
        s.save(self.tmpfile)
        ns = IPSet.load(self.tmpfile)
        self.assert_(s is not ns)
        self.assertEqual(s, ns)
        self.rmfile()


class TestSilkFile(unittest.TestCase):

    def setUp(self):
        warnings.simplefilter("ignore", RuntimeWarning)
        self.tmpdir = tempfile.mkdtemp()
        self.tmpfile = os.tempnam(self.tmpdir)
        warnings.simplefilter("default", RuntimeWarning)
        self.baserec = RWRec(application = 1, bytes = 2, dip = "3.4.5.6", 
                             dport = 7, duration = datetime.timedelta(8), 
                             initflags = TCPFlags(9), input = 10, 
                             nhip = "11.12.13.14", output = 15, packets = 16,
                             protocol = 17, restflags = TCPFlags(18),
                             sip = "19.20.21.22", sport = 23,
                             stime = datetime.datetime.utcnow(), 
                             tcpflags = TCPFlags(25))

    def rmfile(self):
        os.remove(self.tmpfile)
        
    def tearDown(self):
        try:
            self.rmfile()
        except:
            pass
        os.rmdir(self.tmpdir)

    def testReadWriteDefault(self):
        recs = []
        for i in range(10):
            recs.append(RWRec(self.baserec, input=i))
        f = SilkFile(self.tmpfile, WRITE)
        for x in recs:
            f.write(x)
        f.close()
        nf = SilkFile(self.tmpfile, READ)
        nf = SilkFile(self.tmpfile, READ)
        nrecs = []
        for x in nf:
            nrecs.append(x)
        nf.close()
        self.assertEqual(recs, nrecs)
        nf = SilkFile(self.tmpfile, READ)
        nrecs = []
        x = nf.read()
        while x:
            nrecs.append(x)
            x = nf.read()
        nf.close()
        self.assertEqual(recs, nrecs)
        nf = SilkFile(self.tmpfile, READ)
        nrecs = list(nf)
        nf.close()
        self.assertEqual(recs, nrecs)
        self.rmfile()

    def testReadWriteAnnotations(self):
        recs = []
        for i in range(10):
            recs.append(RWRec(self.baserec, input=i))
        f = SilkFile(self.tmpfile, WRITE, 
                     annotations=["Annot1", "Annot2"],
                     invocations=["Invoc1", "Invoc2"])
        for x in recs:
            f.write(x)
        f.close()
        nf = SilkFile(self.tmpfile, READ)
        self.assertEqual(nf.annotations(), ["Annot1", "Annot2"])
        self.assertEqual(nf.invocations(), ["Invoc1", "Invoc2"])
        nrecs = list(nf)
        nf.close()
        self.assertEqual(recs, nrecs)
        self.rmfile()
        f = SilkFile(self.tmpfile, WRITE) 
        for x in recs:
            f.write(x)
        f.close()
        nf = SilkFile(self.tmpfile, READ)
        self.assertEqual(nf.annotations(), [])
        self.assertEqual(nf.invocations(), [])
        self.rmfile()
        self.assertRaises(TypeError, SilkFile, self.tmpfile, WRITE,
                          annotations="Annot1")
        self.assertRaises(TypeError, SilkFile, self.tmpfile, WRITE,
                          annotations="Invoc1")

    def testReadWriteAnnotations(self):
        recs = []
        for i in range(10):
            recs.append(RWRec(self.baserec, input=i))
        f = SilkFile(self.tmpfile, WRITE, compression=DEFAULT)
        for x in recs:
            f.write(x)
        f.close()
        nf = SilkFile(self.tmpfile, READ)
        nrecs = list(nf)
        nf.close()
        self.assertEqual(recs, nrecs)
        self.rmfile()

        f = SilkFile(self.tmpfile, WRITE, compression=NO_COMPRESSION)
        for x in recs:
            f.write(x)
        f.close()
        nf = SilkFile(self.tmpfile, READ)
        nrecs = list(nf)
        nf.close()
        self.assertEqual(recs, nrecs)
        self.rmfile()

        try:
            f = SilkFile(self.tmpfile, WRITE, compression=ZLIB)
        except IOError:
            pass
        else:
            for x in recs:
                f.write(x)
            f.close()
            nf = SilkFile(self.tmpfile, READ)
            nrecs = list(nf)
            nf.close()
            self.assertEqual(recs, nrecs)
            self.rmfile()

        try:
            f = SilkFile(self.tmpfile, WRITE, compression=LZO1X)
        except IOError:
            pass
        else:
            for x in recs:
                f.write(x)
            f.close()
            nf = SilkFile(self.tmpfile, READ)
            nrecs = list(nf)
            nf.close()
            self.assertEqual(recs, nrecs)
            self.rmfile()


def suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestIPAddr))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestIPWildcard))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestTCPFlags))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestRWRec))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestIPSet))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestSilkFile))
    return suite

if __name__ == '__main__':
    unittest.TextTestRunner(verbosity=2).run(suite())
