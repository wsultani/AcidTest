#######################################################################
# Copyright (C) 2007, 2008 by Carnegie Mellon University.
#
# @OPENSOURCE_HEADER_START@
#
# Use of the SILK system and related source code is subject to the terms
# of the following licenses:
#
# GNU Public License (GPL) Rights pursuant to Version 2, June 1991
# Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
#
# NO WARRANTY
#
# ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
# PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
# PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
# "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
# KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
# LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
# MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
# OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
# SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
# TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
# WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
# LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
# CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
# CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
# DELIVERABLES UNDER THIS LICENSE.
#
# Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
# Mellon University, its trustees, officers, employees, and agents from
# all claims or demands made against them (and any related losses,
# expenses, or attorney's fees) arising out of, or relating to Licensee's
# and/or its sub licensees' negligent use or willful misuse of or
# negligent conduct or willful misconduct regarding the Software,
# facilities, or other rights or assistance granted by Carnegie Mellon
# University under this License, including, but not limited to, any
# claims of product liability, personal injury, death, damage to
# property, or violation of any laws or regulations.
#
# Carnegie Mellon University Software Engineering Institute authored
# documents are sponsored by the U.S. Department of Defense under
# Contract F19628-00-C-0003. Carnegie Mellon University retains
# copyrights in all material produced under this contract. The U.S.
# Government retains a non-exclusive, royalty-free license to publish or
# reproduce these documents, or allow others to do so, for U.S.
# Government purposes only pursuant to the copyright license under the
# contract clause at 252.227.7013.
#
# @OPENSOURCE_HEADER_END@
#
#######################################################################

#######################################################################
# $SiLK: __init__.py 11026 2008-03-24 17:48:56Z mwd $
#######################################################################

#import sys,traceback

try:
    from silk.pysilk_nl import *
except ImportError:
#     print "Exception when importing silk.pysilk_nl:"
#     print '-'*60
#     traceback.print_exc(file=sys.stdout)
#     print '-'*60
    from silk.pysilk import *

from silk.fglob import FGlob

__all__ = ['IPAddr', 'IPWildcard', 'IPSet', 'RWRec', 'TCPFlags', 'SilkFile',
           'IGNORE', 'ASV4', 'MIX', 'FORCE', 'ONLY',
           'READ', 'WRITE', 'APPEND',
           'DEFAULT', 'NO_COMPRESSION', 'ZLIB', 'LZO1X',
           'FIN', 'SYN', 'RST', 'PSH', 'ACK', 'URG', 'ECE', 'CWR',
           'sensors', 'classes', 'classtypes',
           'have_site_config',
           'initial_tcpflags_enabled', 'ipv6_enabled',
           'FGlob']


rwrec_kwds = set(["application", "bytes", "classtype", "dip",
                  "dport", "duration", "etime", "icmpcode", "icmptype",
                  "initflags", "input", "nhip", "output", "packets",
                  "protocol", "restflags", "sensor", "sip", "sport",
                  "stime", "tcpflags", "finnoack", "timeout_killed", 
                  "timeout_started"])


class RWRec(RWRecBase):

    def __init__(self, rec=None, _clone=None, **kwds):
        """RWRec() -> empty RWRec
        RWRec(rec, **kwds) -> clone of rec, updated by given keywords
        RWRec(dict, **kwds) -> RWRec, updated by dict and keywords

        Examples:
          foo = RWRec()
          bar = RWRec(foo, dip="192.168.1.1", dport=2000)
          baz = RWRec(bar.as_dict(), application=1)
        """
        if _clone:
            RWRecBase.__init__(self, clone=_clone)
        else:
            if isinstance(rec, dict):
                rec.update(kwds)
                kwds = rec
                rec = None
            if rec:
                RWRecBase.__init__(self, copy=rec)
            else:
                RWRecBase.__init__(self)
        for key, val in kwds.iteritems():
            if key not in rwrec_kwds:
                raise TypeError, (("'%s' is an invalid keyword "
                                   "argument for this function") % key)
            setattr(self, key, val)

    def as_dict(self):
        "Returns the rwrec as a dictionary."
        recdict = dict()
        for x in ['application', 'bytes', 'dip', 'duration', 'stime',
                  'input', 'nhip', 'output', 'packets', 'protocol', 'sip']:
            recdict[x] = getattr(self, x)
        if have_site_config():
            for x in ['classtype', 'sensor']:
                recdict[x] = getattr(self, x)
        protocol = self.protocol
        if protocol in [6, 17, 132]:
            for x in ['sport', 'dport']:
                recdict[x] = getattr(self, x)
        if protocol == 1:
            for x in ['icmptype', 'icmpcode']:
                recdict[x] = getattr(self, x)
        elif protocol == 6:
            recdict[x] = self.tcpflags

        if self.finnoack != None:
            for x in ['finnoack', 'timeout_killed', 'timeout_started']:
                recdict[x] = getattr(self, x)
            if protocol == 6:
                for x in ['initflags', 'restflags']:
                    recdict[x] = getattr(self, x)
        return recdict

    def __str__(self):
        return self.as_dict().__str__()

    def __repr__(self):
        return ("silk.RWRec(%s)" % self)


class SilkFile(SilkFileBase):

    def __init__(self, *args, **kwds):
        SilkFileBase.__init__(self, *args, **kwds)

    def read(self):
        rawrec = SilkFileBase.read(self)
        if rawrec:
            rawrec = RWRec(_clone = rawrec)
        return rawrec

    def __iter__(self):
        return self

    def next(self):
        rec = self.read()
        if not rec:
            raise StopIteration
        return rec


class IPSet(IPSetBase):
    """IPSet() -> empty IPSet
    IPSet(iterable) -> IPSet with items from the iterable inserted
    """
    def __init__(self, arg=None, _filename=None):
        if _filename:
            IPSetBase.__init__(self, _filename)
        else:
            IPSetBase.__init__(self)
        if arg:
            for item in arg:
                self.add(item)

    @classmethod
    def load(cls, fname):
        "IPSet.load(filename) -> IPSet -- Load an IPSet from a file"
        return cls(_filename=fname)

    def __nonzero__(self):
        "Return whether the IPSet is non-empty"
        try:
            iter(self).next()
        except StopIteration:
            return False
        return True

    def update(self, arg):
        "Update an IPSet with the union of itself and another."
        if isinstance(arg, IPSet):
            return IPSetBase.update(self, arg)
        for x in arg:
            self.add(x)
        return self

    def union(self, arg):
        """Return the union of two IPSets as a new IPSet.

        (i.e. all elements that are in either IPSet.)
        """
        return self.copy().update(arg)

    def intersection_update(self, arg):
        "Update an IPSet with the intersection of itself and another."
        if isinstance(arg, IPSet):
            return IPSetBase.intersection_update(self, arg)
        return self.intersection_update(IPSet(arg))

    def intersection(self, arg):
        """Return the intersection of two IPSets as a new IPSet.

        (i.e. all elements that are in both IPSets.)
        """
        return self.copy().intersection_update(arg)

    def difference_update(self, arg):
        "Remove all elements of another IPSet from this IPSet."
        if isinstance(arg, IPSet):
            return IPSetBase.difference_update(self, arg)
        return self.difference_update(IPSet(arg))

    def difference(self, arg):
        """Return the difference of two IPSets as a new IPSet.
        
        (i.e. all elements that are in this IPSet but not the other.)
        """
        return self.copy().difference_update(arg)

    def symmetric_difference(self, arg):
        """Return the symmetric difference of two IPSets as a new IPSet.

        (i.e. all elements that are in exactly one of the IPSets.)
        """
        intersect = self.intersection(arg)
        combine = self.union(arg)
        return combine.difference_update(intersect)

    def symmetric_difference_update(self, arg):
        "Update an IPSet with the symmetric difference of itself and another."
        intersect = self.intersection(arg)
        self.update(arg)
        return self.difference_update(intersect)

    def issubset(self, arg):
        "Report whether another IPSet contains this IPSet."
        return not self.difference(arg)

    def issuperset(self, arg):
        "Report whether this IPSet contains another IPSet."
        if isinstance(arg, IPSet):
            newarg = arg
        else:
            newarg = IPSet(arg)
        return not newarg.difference(self)

    def copy(self):
        "Return a copy of this IPSet."
        return IPSet().update(self)

    def discard(self, arg):
        """Remove an IP address from an IPSet if it is a member.

        If the IP address is not a member, do nothing.
        """
        if arg in self:
            self.difference_update(IPSet().add(arg))
        return self

    def remove(self, arg):
        """Remove an IP address from an IPSet; it must be a member.

        If the IP address is not a member, raise a KeyError.
        """
        if arg not in self:
            raise KeyError
        return self.difference_update(IPSet().add(arg))

    def __le__(self, arg):
        "ipset.issubset(ipset)"
        if not isinstance(arg, IPSet):
            raise TypeError, "can only compare to an IPSet"
        return self.issubset(arg)

    def __ge__(self, arg):
        "ipset.issuperset(ipset)"
        if not isinstance(arg, IPSet):
            raise TypeError, "can only compare to an IPSet"
        return self.issuperset(arg)

    def __or__(self, arg):
        "ipset.union(ipset)"
        if not isinstance(arg, IPSet):
            raise TypeError, "can only compare to an IPSet"
        return self.union(arg)

    def __and__(self, arg):
        "ipset.intersection(ipset)"
        if not isinstance(arg, IPSet):
            raise TypeError, "can only compare to an IPSet"
        return self.intersection(arg)

    def __sub__(self, arg):
        "ipset.difference(ipset)"
        if not isinstance(arg, IPSet):
            raise TypeError, "can only compare to an IPSet"
        return self.difference(arg)

    def __xor__(self, arg):
        "ipset.symmetric_difference(ipset)"
        if not isinstance(arg, IPSet):
            raise TypeError, "can only compare to an IPSet"
        return self.symmetric_difference(arg)

    def __ior__(self, arg):
        "ipset.upodate(ipset)"
        if not isinstance(arg, IPSet):
            raise TypeError, "can only compare to an IPSet"
        return self.update(arg)

    def __iand__(self, arg):
        "ipset.intersection_update(ipset)"
        if not isinstance(arg, IPSet):
            raise TypeError, "can only compare to an IPSet"
        return self.intersection_update(arg)

    def __isub__(self, arg):
        "ipset.difference_update(ipset)"
        if not isinstance(arg, IPSet):
            raise TypeError, "can only compare to an IPSet"
        return self.difference_update(arg)

    def __ixor__(self, arg):
        "ipset.symmetric_difference_update(ipset)"
        if not isinstance(arg, IPSet):
            raise TypeError, "can only compare to an IPSet"
        return self.symmetric_difference_update(arg)

    def __eq__(self, arg):
        return self <= arg and self >= arg

    def __ne__(self, arg):
        return not (self == arg)
