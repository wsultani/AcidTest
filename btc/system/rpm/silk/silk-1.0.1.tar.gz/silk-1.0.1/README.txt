  SiLK is a collection of NetFlow tools developed by the CERT/NetSA to
  facilitate security analysis in large networks.  SiLK consists of a
  suite of tools which collect and examine NetFlow data, allowing
  analysts to rapidly query large sets of data.

  Use of the SiLK system and related source code is subject to the
  terms described in LICENSES.txt.

  To install SiLK, follow the instructions given in
  http://tools.netsa.cert.org/silk/install-handbook.html or
  http://tools.netsa.cert.org/silk/install-handbook.pdf.

  A textual version of those instructions is available in INSTALL.txt.

  Documentation is available at http://tools.netsa.cert.org/silk/
